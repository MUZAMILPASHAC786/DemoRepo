# Copy assets need for demo-app
cp node_modules/jquery/dist/jquery.min.js demo-app/lib/jquery.min.js
cp node_modules/bootstrap/dist/css/bootstrap.min.css demo-app/lib/bootstrap.min.css
cp node_modules/jquery.cookie/jquery.cookie.js demo-app/lib/jquery.cookie.js
cp node_modules/bootstrap/dist/js/bootstrap.min.js demo-app/lib/bootstrap.min.js