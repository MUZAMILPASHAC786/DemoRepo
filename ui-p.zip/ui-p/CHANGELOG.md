# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [0.11.0](https://github.com/AllegiantTravelCo/gqa-prova-ui/compare/v0.10.13...v0.11.0) (2024-10-15)


### Features

* QAA-28532 Added hideKeyboard and closeAllButCurrentTab method ([#2](https://github.com/AllegiantTravelCo/gqa-prova-ui/issues/2)) ([a7fcb66](https://github.com/AllegiantTravelCo/gqa-prova-ui/commit/a7fcb66a06d395e6f8980dcd1213aaf83045ea15))

### [0.10.13](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.12...v0.10.13) (2024-08-20)


### Bug Fixes

* QAA-28114-Made the changes in multi remote files to make it work with the MR capabilities ([c9e7866](https://git.allegiantair.com:7999/gqa/prova-ui/commit/c9e78664c30e5132e2a835dddaa56877711de621))

### [0.10.12](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.11...v0.10.12) (2024-07-02)


### Bug Fixes

* QAA-27943-Added the logic to perform the actions as click, setValue etc., post zoom in/out ([a498787](https://git.allegiantair.com:7999/gqa/prova-ui/commit/a4987879caf4e7659207d944c210e08f0f0adb91))

### [0.10.11](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.10...v0.10.11) (2024-06-24)


### Bug Fixes

* QAA-27906-Fixed the issue wrt the ZoomInOutPercentage method ([e343b99](https://git.allegiantair.com:7999/gqa/prova-ui/commit/e343b991e101a94e1118c4349526d5ddd119cdb1))

### [0.10.10](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.9...v0.10.10) (2024-06-06)


### Features

* QAA-27554-Added seperate and missed methods for handling alerts ([bb50298](https://git.allegiantair.com:7999/gqa/prova-ui/commit/bb502981875814a124faf1a563a6ce6ff6dd384a))

### [0.10.9](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.8...v0.10.9) (2024-06-03)


### Features

* QAA-27526 Added unit test for fetchDataLayer and getEventsDetails; Added afterAll and afterEach globally in setup.js ([80d3636](https://git.allegiantair.com:7999/gqa/prova-ui/commit/80d3636229007ec2511110deaaa3661504af467b))

### [0.10.8](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.7...v0.10.8) (2024-05-23)

### [0.10.7](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.6...v0.10.7) (2024-05-16)

### [0.10.6](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.5...v0.10.6) (2024-05-16)

### [0.10.5](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.4...v0.10.5) (2024-05-16)

### [0.10.4](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.3...v0.10.4) (2024-05-15)

### [0.10.3](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.2...v0.10.3) (2024-05-15)

### [0.10.2](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.1...v0.10.2) (2024-05-15)

### [0.10.1](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.10.0...v0.10.1) (2024-05-03)


### Features

* fixed unittest issues in action and check ([724ed54](https://git.allegiantair.com:7999/gqa/prova-ui/commit/724ed54486525b6238f61e9642805d40d1ca98b6))
* QAA-27526 Added coverage in pre-commit ([af8536b](https://git.allegiantair.com:7999/gqa/prova-ui/commit/af8536b9f9bf2f96bed6fc240af3d86016e34990))
* QAA-27526 Added unit test for falsecases ([aa9d78b](https://git.allegiantair.com:7999/gqa/prova-ui/commit/aa9d78b6b9181b02c7776dcf9e6c0762153e82ce))
* QAA-27526 fixed selector instance issue in check ([aa52538](https://git.allegiantair.com:7999/gqa/prova-ui/commit/aa52538f46c2154bf89b4ff0dc6d8dbd7c7366bf))
* QAA-27526 Unit tests and test coverage for prova-ui ([7b93332](https://git.allegiantair.com:7999/gqa/prova-ui/commit/7b9333259b98a35fa4faddfaba7cba1a7491f2fb))
* QAA-27526 Updated check ([6c3d4b8](https://git.allegiantair.com:7999/gqa/prova-ui/commit/6c3d4b84e72a180ba1e0a05cff60e13f4bde30ba))
* QAA-27558_updated jsDoc for all functions/methods ([3145d73](https://git.allegiantair.com:7999/gqa/prova-ui/commit/3145d73efe75516cc1d34b09d0f085f0ec41b07a))

## [0.10.0](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.9.1...v0.10.0) (2024-04-08)


### Features

* #QAA-27533 Added Data layer object validation ([769fbb1](https://git.allegiantair.com:7999/gqa/prova-ui/commit/769fbb1b625547ce86e7f90f7feeb41a4b497ae0)), closes [#QAA-27533](https://git.allegiantair.com:7999/gqa/prova-ui/issues/QAA-27533)

### [0.9.1](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.9.0...v0.9.1) (2024-03-28)


### Bug Fixes

* #QAA-27509 logger on validaiton class ([7523211](https://git.allegiantair.com:7999/gqa/prova-ui/commit/752321199158c8aca7d72496b08f06bcd2f4aac0)), closes [#QAA-27509](https://git.allegiantair.com:7999/gqa/prova-ui/issues/QAA-27509)
* #QAA-27509 moved getElementSize fn from validation to action class ([e0fd432](https://git.allegiantair.com:7999/gqa/prova-ui/commit/e0fd432e3a4f3513ef8629d1f0fc2fe30426c84f)), closes [#QAA-27509](https://git.allegiantair.com:7999/gqa/prova-ui/issues/QAA-27509)

## [0.9.0](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.8.0...v0.9.0) (2024-03-20)


### Features

* QAA-27429 : Added the scroll, element size and zooming features ([6ae5809](https://git.allegiantair.com:7999/gqa/prova-ui/commit/6ae5809f602ca85217d86c5ce1b066b3a2082d0d))
* QAA-27437-Mobile_Added scroll to text feature ([0fe12d8](https://git.allegiantair.com:7999/gqa/prova-ui/commit/0fe12d8379856bf0998ecdae1521526df3b347ad))
* Updated the format for mobile class ([38c658b](https://git.allegiantair.com:7999/gqa/prova-ui/commit/38c658bbdde548435c1362b340fc7a12ff53130a))

## [0.8.0](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.7.1...v0.8.0) (2024-03-01)


### Features

* QAA-27320- Created multiRemoteCheck class where we have all the validation methods related to multi-remote. ([3b325c6](https://git.allegiantair.com:7999/gqa/prova-ui/commit/3b325c682e1adf6af28ea67d1baf88b7acd0395e))
* QAA-27320-Added the multi-remote capability feature ([adeca06](https://git.allegiantair.com:7999/gqa/prova-ui/commit/adeca06dfa0418a252623ca056c5f24e14463dd2))

### [0.7.1](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.7.0...v0.7.1) (2024-02-12)


### Bug Fixes

* QAA-27206 - Removed the validation for the methods getValue and getText ([78a8733](https://git.allegiantair.com:7999/gqa/prova-ui/commit/78a8733de9e01bd04634e68290fe4a003fd35284))

## [0.7.0](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.6.5...v0.7.0) (2024-02-12)


### Features

* QAA-27206 - Added the mobile releated methods like startActivity, switchContext, getContexts and closeApp. ([8c73038](https://git.allegiantair.com:7999/gqa/prova-ui/commit/8c7303886809a275c651886801b5a31a09eac8d7))

### [0.6.5](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.6.4...v0.6.5) (2023-12-15)


### Features

* QAA-26910-Added the parameters for few methods like scroll, closeAllButFirstTab etc., to get the proper log on the CAT for the failure cases. ([a18d0db](https://git.allegiantair.com:7999/gqa/prova-ui/commit/a18d0dbc0486de90b1e674493579024c32d92de0))
* QAA-26995 - Updated JSDoc information for all the methods in action and validation classes ([feca9c6](https://git.allegiantair.com:7999/gqa/prova-ui/commit/feca9c696e7aee9cbd7a07f8a338e67c58dc9350))

### [0.6.4](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.6.3...v0.6.4) (2023-10-27)


### Features

* QAA-26872-error handling in prova-UI ([de873c6](https://git.allegiantair.com:7999/gqa/prova-ui/commit/de873c66fe08e6eaab43974372b3afcd650ad784))
* QAA-26872-resolve issues in Prova-UI ([bc136ca](https://git.allegiantair.com:7999/gqa/prova-ui/commit/bc136ca8c60792faeb127e858d0cdedc66e629b2))
* QAA-26872-resolve issues in Prova-UI ([179ed53](https://git.allegiantair.com:7999/gqa/prova-ui/commit/179ed53a6b8abf32e19b2eca6f89f3fcabce6992))
* QAA-26872-reverted the changes in validations.js ([2029e9b](https://git.allegiantair.com:7999/gqa/prova-ui/commit/2029e9b19cea36e5c5e4769690c3ed538b977243))
* QAA-26872-updated error handling in prova-UI ([ac2834e](https://git.allegiantair.com:7999/gqa/prova-ui/commit/ac2834ea96ccd061630ad050511e1ee67f9f8ece))

### [0.6.3](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.6.2...v0.6.3) (2023-09-26)


### Features

* QAA-26739- enhancements and additional validations ([0efe4d6](https://git.allegiantair.com:7999/gqa/prova-ui/commit/0efe4d6f3fd3ea7ee09402c45027cc59644eec49))

### [0.6.2](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.6.1...v0.6.2) (2023-08-30)


### Bug Fixes

* QAA-26695- Updated logger and return values for verifying methods ([e3082c4](https://git.allegiantair.com:7999/gqa/prova-ui/commit/e3082c4f247837a41c0e5d8aecf58855f1089902))

### [0.6.1](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.6.0...v0.6.1) (2023-08-25)

## [0.6.0](https://git.allegiantair.com:7999/gqa/prova-ui/compare/v0.5.1...v0.6.0) (2023-08-25)


### Features

* Added the new methods ([645b5b4](https://git.allegiantair.com:7999/gqa/prova-ui/commit/645b5b4cc26fb9594e7f66204201e7dc6e102c50))
* QAA-26710 -  Added the new methods ([3d67faa](https://git.allegiantair.com:7999/gqa/prova-ui/commit/3d67faad48e43081e840c07596615a74717f11c2))
* QAA-26710 - Added the new methods ([50adf9e](https://git.allegiantair.com:7999/gqa/prova-ui/commit/50adf9e41679f59e10ba8afaa4e45303e3a91286))

### 0.5.1 (2023-07-12)


### Features

* added standard version in provaUI ([0b6c3cf](https://git.allegiantair.com:7999/gqa/prova-ui/commit/0b6c3cf51d56cc303d11fb898de61cba305d1f78))
* QAA-26560 Added cap for certain lib ([cd8a049](https://git.allegiantair.com:7999/gqa/prova-ui/commit/cd8a049f8e0c3c59c60dd0a8dd29a58b26a2d2af))
* QAA-26560 Added cap for certain lib ([0fea28d](https://git.allegiantair.com:7999/gqa/prova-ui/commit/0fea28debb6994a6de761bc5e45415f9151c4500))
* QAA-26560 disabled the auto upgrade ([e432287](https://git.allegiantair.com:7999/gqa/prova-ui/commit/e432287e14582abffe2170294fa29ab5991e4343))
* QAA-26560 modified the npmrc ([269f7de](https://git.allegiantair.com:7999/gqa/prova-ui/commit/269f7de19a11c19c968447fe5762334b0a2b3262))

## [0.5.0] - 2023-06-19
- QAA-26491 Added HTML and Allure report generation capabilities to the framework
- Added calender scrolling functionality

## [0.4.1] - 2023-06-12
- QAA-26442 Added the extra method for scrolling to the particular element

## [0.4.0] - 2023-06-06
 - QAA-26442 Added the methods which works for mobile automation

## [0.3.3] - 2023-05-26
 - QAA-26447 Resolved issues with respect to the promises of objects

## [0.3.2] - 2023-05-18
 - QAA-26424 Added the new dependency for the transpile purpose

## [0.3.1] - 2023-05-04
 - QAA-26381 Added the missing and updated the existing dependencies
 - Added the missed methods
 - Made it compatible with Javascript ES6 by using import keywords rather than using require

## [0.3.0] - 2023-04-13
 - QAA-26319 Handled the objects along with the strings for selectors

## [0.2.0] - 2023-03-28
 - QAA-26145 Added the missing methods and modified the existing methods

## [0.1.1] - 2023-02-13
 - QAA-25980 Updated the JSDoc for all the methods to make it easier for user while passing the parameters 

## [0.1.0] - 2023-02-02
 - QAA-25921 Modified all the methods to make those easier to use for the user
 - Changed the given when then step def according to the methods

## [0.0.6] - 2022-12-07
 -  Added methods which were not already available to make framework more resourceful

## [0.0.5] - 2022-12-02
 -  Added test features to test the changes

## [0.0.4] - 2022-11-29
 -  Updated the given when then steps def from sync to async

## [0.0.3] - 2022-11-28
 -  Changed the dev dependencies to dependencies to help the user of prova-ui

## [0.0.2] - 2022-11-22
 -  This version is stable and Node Version 18 compatible

## [0.0.1] - 2022-11-29
 -  Initial Release of prova-ui Framework
