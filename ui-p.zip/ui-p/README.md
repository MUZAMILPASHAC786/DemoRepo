# Prova-UI

---

#### Automation Framework using Cucumber.js and WebdriverIO.

### Etymology

`Prova` is a translation of `Testing` in Italian

### Goals

-   Provide a unified framework for BDD for all UI apps.
-   Provide a comprehensive set of rich and easy-to-use Glossaries.
-   Provide a powerful CLI for quickly setting up a prova based test setup in any codebase along with other commands.
-   Provide Generic Page Objects and other helper utilites.

### Dependencies

-   Install python (if you are new installation)
-   Node >= v18
-   Npm >= v8

## Install

```bash
# install prova cli
* [Prova CLI](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/browse)
```

<br />

#### How your project will use Prova-UI

Your test suite that will be setup by `prova init` will add `prova` as a dependency in package.json.
All the [BDD Glossary](docs/bdd-glossary.md),
[Actions](docs/actions.md),
[Helpers](docs/helpers.md) will be available to use.
![picture](images/prova-framework.png)

### Documentation

-   [BDD Glossary](docs/bdd-glossary.md)
-   [Actions](docs/actions.md)
-   [Contribute to Prova Development](docs/contribute.md)
-   Helpers
-   [Page](docs/page-helper.md)

### Release Notes

-   Please find release notes under CHANGELOG
    https://git.allegiantair.com:8443/projects/GQA/repos/prova-ui/browse/CHANGELOG.md

### Confluence

For More information check in below
https://confluence.allegiantair.com/pages/viewpage.action?pageId=383356554

### Contribute

Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License

Copyright (c) Allegiant Travel Company
