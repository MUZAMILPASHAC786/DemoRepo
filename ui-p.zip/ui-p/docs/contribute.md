## Prova Development

---

#### Lets make prova better, together !!

We are thrilled that you chose to contibute !! Welcome aboard !!

### Dependencies

-   Java >= v8 (This lib was tested with v8)
-   Node >= v10 (This lib was tested with v10.16.0)
-   Npm >= v6 (This lib was tested with v6.9.0)
-   Node Gyp v6.1.0

### Installation

```bash
# Clone repo
ssh://git@git.allegiantair.com:7999/~ks8d/g4js-prova.git

# Install deps
npm install --unsafe-perm
```

### Linting

```bash
npm run lint
```

### Run Unit tests

```bash
npm run test:unit
```

### Run Feature tests

```bash
npm run test:feature
```

### Publishing to Nexus

```bash
# Login to Nexu Repo using your AD credentials
npm login --registry=https://nexus3.allegiantair.com/repository/g4npm_hosted/

# Publish
npm publish
```

### Contribute

Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License

Copyright (c) Allegiant Travel Company
