import actions from '../../src/support/actions';
import check from '../../src/support/validations';
const MOD = "//a//span[contains(text(),'MOD')]";
const STNS = "//a//span[contains(text(),'STNS')]";
const SVT = "//a//span[contains(text(),'SVT')]";
const FMM = "//span[text()='FMM']";
const ATL = "//span[contains(text(),'ATL')]";
const RQ = "//a//span[text()='RQ']";
const SAT = "//a//span[text()='SAT']";
const STS = "//a//span[text()='STS']";
const CAR = "//span[contains(text(),'CAR')]";
const CL = "//span[contains(text(),'CL')]";
const ESP = "//span[contains(text(),'ESP')]";
const HOT = "//span[contains(text(),'HOT')]";
const HSM = "//span[contains(text(),'HSM')]";
const AIS = "//span[contains(text(),'AIS')]";
const FM = "//span[contains(text(),'FM')]";
const BOOK = "//a//span[contains(text(),'BOOK')]";
const AISX = "//a//span[contains(text(),'AISX')]";
const flightOperations = "//span[contains(text(),'FLIGHT OPERATIONS')]";
const selectFlightMaintenance = "//span[contains(text(),'FLIGHT MAINTENANCE')]";
class g4PortalPage {
    async getEnvironmentValue() {
        let envVar;
        let envs = 'https://www.stg01.aws.allegiantair.com';
        let value = envs.split('www')[1];
        envVar = value.split('.allegiantair.com')[0];
        process.env.ENV = envVar;
        console.log(envVar);
    }
    async urlBuilderFmm() {
        await this.getEnvironmentValue();
        var getEnv = process.env.ENV;
        let g4url;
        let g4PortalToken;
        if (getEnv.includes('okd') && !getEnv.includes('nexusg4')) {
            var envURL = getEnv.split('-')[1].split('.')[0];
            var env = envURL.slice(0, 3) + '.' + envURL.slice(3, 8) + '.' + envURL.slice(8, 13);
            g4url = 'https://g4plus-portal-' + envURL + '.okd.allegiantair.com/portal';
            g4PortalToken =
                'https://g4plus-res-' + envURL + '.okd.allegiantair.com/test/token?roles=OPS_FMM';
        } else {
            // let envURL = getEnv.split('.')[1]
            let env = envURL;
            g4url = 'https://g4plus-portal' + getEnv + '.allegiantair.com/portal';
            console.log('g4url: ', g4url);
            g4PortalToken =
                'https://g4plus-res' +
                getEnv +
                '.allegiantair.com/test/token?roles=OPS_FMM,FMM_OCC_MGR,OPS_FMM_OCC_SUPER_USER,FMM_STATION_SUPER_USER,station_agent,ops_stations,ops_stations_checkin,ops_stations_cass,ops_stations_boarding,fmm_station_super_user,res_customer,res_booking,res_booking_agent,res_booking_waiver,res_booking_override,res_booking_manager,call_center_agent,ops_airline_bags,ops_airline_pb,ops_airline_seats,ops_eswap,res_airline_reaccom,ota_vehicle,ota_trip_flex,ota_payments,ota_surcharge,ota_surcharge_accounting,ota_surcharge_revenue,ota_hotel,ota_hotel_revenue,ota_hotel_inventory,ota_hotel_inventory_manager,ota_shows,ota_shows_inventory,ota_shows_revenue,ota_accounting,ota_accounting_invoicing,ota_accounting_atl,ota_accounting_invoicing_suspended_managers,ota_accounting_invoicing_suspended_coordinators,ops_fee_management,ops_flight_operations,ops_flight_operations_manager,ota_flights,ota_flights_inventory,ota_flights_revenue,ssim_user,ssim_admin,ais_air_only,ais_bk_non_rev_standby,ais_bk_non_rev_standby_svc_provider,ais_bk_nrps,ais_bk_pilot_jump_seat';
            console.log('g4PortalToken: ', g4PortalToken);
        }
        return [g4PortalToken, g4url];
    }

    async navigateToG4Fmm() {
        await this.getEnvironmentValue();
        if (process.env.ENV.includes('prod')) {
            console.log('CAME HERE>>>>>>>>>>>>>>>>>>PROD');
            await browser.maximizeWindow();
            await browser.deleteAllCookies();
            await actions.openWebsite('https://g4plus-portal.allegiantair.com');
            await actions.pause(1000);
            await actions.setInputField('setValue', process.env.username, g4UserName, 'g4UserName');
            await actions.setInputField('setValue', process.env.password, g4Password, 'g4Password');
            await actions.clickElement('click', g4Submit, 'g4Submit');
        } else if (process.env.ENV.includes('prd')) {
            console.log('CAME HERE>>>>>>>>>>>>>>>>>>PROD');
            await browser.maximizeWindow();
            await browser.deleteAllCookies();
            await browser.url('https://g4plus-portal-prd01.allegiantair.com');
            await actions.pause(1000);
            await $(g4UserName).setValue(process.env.username);
            await $(g4Password).setValue(process.env.password);
            await $(g4Submit).click();
            await actions.pause(5000);
        } else {
            await browser.maximizeWindow();
            await actions.deleteAllCookies();
            await actions.openWebsite((await this.urlBuilderFmm())[0]);
            await actions.pause(1000);
            await actions.openWebsite((await this.urlBuilderFmm())[1]);
        }
    }
    async selectAppFromG4Portal(app) {
        if (app === 'MOD') {
            await actions.clickElement('click', MOD, 'MOD Button');
            await actions.pause(5000);
        }
        if (app === 'STNS') {
            await actions.clickElement('click', STNS, 'STNS Button');
        }
        if (app === 'SVT') {
            await actions.clickElement('click', SVT, 'SVT Button');
        }
        if (app === 'FMM') {
            await actions.pause(5000);
            await actions.clickElement('click', FMM, 'FMM Button');
            await actions.pause(5000);
        }
        if (app === 'ATL') {
            await actions.clickElement('click', ATL, 'ATL Button');
        }
        if (app === 'RQ') {
            await actions.clickElement('click', RQ, 'RQ Button');
        }
        if (app === 'SAT') {
            await actions.clickElement('click', SAT, 'SAT Button');
        }
        if (app === 'STS') {
            await actions.pause(5000);
            await actions.clickElement('click', STS, 'STS Button');
        }
        if (app === 'HSM') {
            await actions.clickElement('click', HSM, 'HSM Button');
        }
        if (app === 'HOT') {
            await actions.clickElement('click', HOT, 'HOT Button');
        }
        if (app === 'FM') {
            await actions.clickElement('click', FM, 'FM Button');
        }
        if (app === 'ESP') {
            await actions.clickElement('click', ESP, 'ESP Button');
        }
        if (app === 'CL') {
            await actions.clickElement('click', CL, 'CL Button');
        }
        if (app === 'CAR') {
            await actions.clickElement('click', CAR, 'CAR Button');
        }
        if (app === 'AIS') {
            await actions.clickElement('click', AIS, 'AIS Button');
        }

        if (app === 'BOOK') {
            await actions.clickElement('click', BOOK, 'BOOK Button');
        }

        if (app === 'FM') {
            await actions.clickElement('click', FM, 'FM Button');
        }

        if (app === 'STNS') {
            await actions.clickElement('click', STNS, 'STNS Button');
        }
        if (app === 'AISX') {
            await actions.pause(5000);
            await actions.clickElement('click', AISX, 'AISX Button');
            await actions.pause(5000);
        }
    }
    async selectFlightMaintenance() {
        await actions.pause(3000);
        // let tab1 = await actions.getWindowHandles();
        await actions.switchWindow('https://ais.stg01.aws.allegiantair.com/menu.php?action=menu');
        await actions.waitForDisplayed(flightOperations, 'flightOperations', 3000);
        await actions.waitForClickable(flightOperations, 'flightOperations', 3000);
        await actions.clickElement('click', flightOperations, 'flightOperations');
        await actions.waitForClickable(selectFlightMaintenance, 'selectFlightMaintenance', 3000);
        await actions.clickElement('click', selectFlightMaintenance, 'selectFlightMaintenance');
        await actions.pause(3000);
        await actions.switchWindow('FLIGHT MAINTENANCE');
        await actions.pause(3000);
    }
    async switchBackToG4Portal() {
        await actions.switchWindow('https://g4plus-portal.stg01.aws.allegiantair.com/portal');
        await actions.pause(3000);
    }
}
export default new g4PortalPage();
