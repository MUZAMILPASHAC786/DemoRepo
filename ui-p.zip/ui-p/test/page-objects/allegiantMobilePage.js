import actions from '../../src/support/actions'
import mobileActions from '../../src/support/mobileActions'

let version = ("id=com.lixar.allegiant:id/versionNumberIdentifier")
let doneBtn = ('id=com.lixar.allegiant:id/doneBtn')
let popup = ("id=com.android.permissioncontroller:id/permission_allow_foreground_only_button")

class Mobile {

    async selectEnvironment() {
        let envbutton
        let env = process.env.Env
        console.log("Came to app installtion");
        await browser.launchApp()
        for (var i = 0; i < 4; i++) {
            await this.scrolling('up')
        }
        if (env.toLowerCase().includes('stg')) {
            envbutton = ("//*[@text='Stage']")
        } else if (env.toLowerCase().includes('qa1')) {
            envbutton = ("//*[@text='QA1']")
        } else if (env.toLowerCase().includes('qa2')) {
            envbutton = ("//*[@text='QA2']")
        } else if (env.toLowerCase().includes('qatnexusg4')) {
            envbutton = ("//*[@text='QATNEXUSG4']")
        } else if (env.toLowerCase().includes('intnexusg4')) {
            envbutton = ("//*[@text='INTNEXUSG4']")
        } else if (env.toLowerCase().includes('dev01')) {
            envbutton = ("//*[@text='Dev01']")
        } else if (env.toLowerCase().includes('prod01')) {
            envbutton = ("//*[@text='Prod01']")
        }
        let envVisibilty = await actions.isDisplayed(envbutton, 'button')
        if (!envVisibilty) {
            await this.scrollToElement(envbutton)
            await browser.pause(2000)
        }
        await actions.waitForDisplayed(envbutton, "Environment radio button", 15000)
        await actions.isDisplayed(envbutton, "Environment radio button")
        await browser.pause(5000)
        await actions.click(envbutton, "Environment radio button")
        await mobileActions.scrollToElement(version, 'version')
        let envVersion = await actions.getText(version, 'Environment Version')
        console.log("The app details are : ", envVersion)
        await actions.waitForDisplayed(doneBtn, "Done button", 15000)
        await actions.isDisplayed(doneBtn, "Done button")
        await actions.click(doneBtn, "Done Button")
        await actions.isDisplayed(popup, "Pop Up")
        await actions.click(popup, "Pop Up")
        let MaintancancePOPUPVisibility = await actions.isDisplayed("//android.widget.Button[@text='Close']", "MaintancancePOPUP")
        if (MaintancancePOPUPVisibility) {
            await actions.click("//android.widget.Button[@text='Close']", "Pop Up")
        }
        await actions.pause(3000)
        await mobileActions.closeApp()
    }

    async launchingAppinMob() {
        console.log("Let's see chrome will open or not")
        await mobileActions.startActivity("com.android.chrome", "com.google.android.apps.chrome.Main", "Chrome Home Page")
        await actions.pause(3000)
        console.log(await mobileActions.getContexts())
        await mobileActions.switchContext('WEBVIEW_chrome');
        await browser.url("https://www.qa1.allegiantair.com/")
        await actions.pause(3000)
        await mobileActions.closeApp()
        await actions.pause(3000)
    }

    async appValidation() {
        console.log("I'm waiting to switch back to APP")
        await actions.pause(3000)
        await mobileActions.startActivity("com.lixar.allegiant", "com.lixar.allegiant.environment.EnvironmentPickerActivity", "Allegiant Home Page");
        await actions.pause(3000)
        await mobileActions.switchContext('NATIVE_APP');
        await actions.pause(3000)
        await mobileActions.scrollToElement(version, 'version')
        let envVersion = await actions.getText(version, 'Environment Version')
        console.log("The new launch app details are : ", envVersion)
    }

    async scrolling(direction) {
        let side = direction.toLowerCase();
        var { width, height } = await browser.getWindowSize();
        let startX;
        let startY;
        let endX;
        let endY;

        if (side === "down") {
            startX = parseInt(width * 0.5);
            startY = parseInt(height * 0.9);
            endX = parseInt(width * 0.5);
            endY = parseInt(height * 0.5);
        }
        if (side === "up") {
            startX = parseInt(width * 0.5);
            startY = parseInt(height * 0.4);
            endX = parseInt(width * 0.5);
            endY = parseInt(height * 0.9);
        }
        await browser.touchAction([
            { action: "press", x: startX, y: startY },
            { action: "wait", ms: 2000 },
            { action: "moveTo", x: endX, y: endY },
            "release",
        ]);
    }

    async scrollToElement(selector) {
        var { width, height } = await browser.getWindowSize();
        let elementVisibilty;
        let startX;
        let startY;
        let endX;
        let endY;
        do {
            elementVisibilty = await $(selector).isDisplayed();
            if (elementVisibilty === false) {
                startX = parseInt(width * 0.5);
                startY = parseInt(height * 0.5);
                endX = parseInt(width * 0.5);
                endY = parseInt(height * 0.1);
                await browser.touchAction([
                    { action: "press", x: startX, y: startY },
                    { action: "wait", ms: 2000 },
                    { action: "moveTo", x: endX, y: endY },
                    "release",
                ]);
            }
        } while (elementVisibilty === false);
    }
}

export default new Mobile()