import actions from '../../src/support/actions';
import check from '../../src/support/validations';

const buttontoclosepopup = "//button[@class='Popup__CloseIcon-sc-1kasz48-2 eKPgGA']/img";
const cookieepopup = "//button[contains(@class,'close-button')]";
const loginpath = "[data-hook='header-user-menu-item_log-in']";
const oneway = "[data-hook='flight-search-trip-type_ONEWAY']";
const roundtrip = "[data-hook='flight-search-trip-type_ROUNDTRIP']";
const origin = "[data-hook='flight-search-origin']";
const originloc = "[data-hook='flight-search-origin'] input";
const destination = "[data-hook='flight-search-destination']";
const destinationloc = "[data-hook='flight-search-destination'] input";
const departureDate = "[data-hook='flight-search-date-picker_expand-start-date']";
const departureDateField = "[data-hook='flight-search-date-picker_input-start-date']";
const datePickerPrevious = "[data-hook='flight-search-date-picker_navigate-previous-month']";
const datePickerNext =
    "//button[@data-hook='flight-search-date-picker_navigate-next-month']|//button[@aria-label='Go to next month']";
const calendarMonthAndYearTextLeft =
    "[data-hook='flight-search-date-picker_calendar-0_display-month-year']";
const calendarMonthAndYearTextRight =
    "[data-hook='flight-search-date-picker_calendar-1_display-month-year']";
const returningDate = "//button[@data-hook='flight-search-date-picker_expand-end-date']";
const returnDatePlaceholder = "//input[@data-hook='flight-search-date-picker_input-end-date']";
const isRoundTripSelected = "//label[@data-hook='flight-search-trip-type_ROUNDTRIP']//div//input";
const dateExpand = "[data-hook='flight-search-date-picker_expand-start-date']";
const homesubmit = "[data-hook='flight-search-submit']";
const scrollingpurpose = "[data-hook='flight-search-travelers-expando-button']";
const classcheck = '#personalized-deals-disclaimer';
var billboardNameList = [];
var BookingDisabledFromMonth;
let newDate = new Date();

class HomePage {
    async openURL(page) {
        await actions.openWebsite(page);
        // await check.checkURL('https://www.stg.allegiantair.com/',"opening the allegiantair application")
        // await check.checkTitle('Rediffmail','reddiff-mail website')
        // await check.checkURLPath('/','allegiantair UI')
    }

    async newWindowURL(url) {
        await actions.setWindowSize(1000, 500);
        await actions.newWindow(url);
    }

    async closeFirstTab() {
        await actions.closeAllButFirstTab();
    }
    async closeCurrentTab() {
        await actions.closeAllButCurrentTab();
        await actions.pause(5000);
    }

    async popupClosing() {
        // await browser.pause(5000)
        await actions.pause(10000);
        console.log('Hello Karth');
        try {
            // await actions.waitFor(buttontoclosepopup, 5000)
            // await actions.isDisplayed(buttontoclosepopup, "Overlay Merchandise Pop-up button")
            // await actions.waitForClickable(buttontoclosepopup, 'Overlay Merchandise Pop-up button')
            await actions.clickElement(
                'click',
                buttontoclosepopup,
                'button to close the Overlay Merchandise pop-up',
            );
        } catch (error) {
            console.log('Overlay Merchandise Popup not Displayed');
        }
        if (await actions.isDisplayed(cookieepopup, 'Accept All Cookies Popup button')) {
            // await actions.waitForDisplayed(cookieepopup, 'Accept All Cookies Popup button')
            // await actions.waitForClickable(cookieepopup, 'Accept All Cookies Popup button')
            await actions.clickElement(
                'click',
                cookieepopup,
                'Button to close Accept All Cookies Popup',
            );
        } else {
            console.log('Accept All Cookies Popup not Displayed');
        }
    }
    async loginlink() {
        await actions.clickElement('click', loginpath, 'log-in link');
    }

    async oneway() {
        await actions.clickElement('click', oneway, 'one-way radio-button');
    }
    async selectingorigin(value) {
        // await actions.waitForDisplayed(origin, "origin")
        // await actions.waitForClickable(origin, "origin")
        await actions.clickElement('click', origin, 'origin input field');
        await actions.setInputField('setValue', value, originloc, 'origin-input-field');
        await actions.pressButton('Enter');
    }

    async selectingdestination(value) {
        await actions.scroll(destination);
        await actions.clickElement('click', destination, 'destination input field');
        await actions.setInputField('setValue', value, destinationloc, 'destination-input-field');
        await actions.pressButton('Enter');
        await actions.pause(3000);
        await actions.clickElement('click', dateExpand, 'date expand button');
        // await browser.pause(3000)
        // await check.isEnabled(departureDate,true,'date-selection field after city-pair selection')
    }

    async openReturningDateCalendar() {
        await actions.click(returningDate, 'returning date');
    }

    async chooseDepartingDate(dateNumber) {
        const day1 =
            "button[data-hook='flight-search-date-picker_calendar-0_select-day-X'][aria-hidden='false']";
        const day2 =
            "button[data-hook='flight-search-date-picker_calendar-1_select-day-X'][aria-hidden='false']";
        await actions.waitForEnabled(departureDate, 'departureDate');
        let departureDateIsEnabled = await actions.isEnabled(departureDate, 'Date-Expand button');
        if (departureDateIsEnabled) {
            let newDate = new Date();
            let { calendarMonthLeft, month, dayInt, nextDate } = await this.calculateDate(
                dateNumber,
                newDate,
            );
            if (month === calendarMonthLeft) {
                await actions.clickElement('click', day1.replace('X', dayInt), 'Start Day');
            } else {
                await actions.clickElement('click', day2.replace('X', dayInt), 'End Day');
            }
            return nextDate;
        } else {
            console.log('Expected Departing date is not enabled to select');
        }
    }

    async chooseReturningDate(dateNumber, departureDate) {
        let roundTripisSelected = await actions.isSelected(
            isRoundTripSelected,
            'isRoundTripSelected',
        );
        if (roundTripisSelected) {
            let returnDate = new Date();
            let { calendarMonthLeft, month, dayInt } = await this.calculateDate(
                dateNumber,
                departureDate,
            );
            let dateSelection =
                "button[data-hook='flight-search-date-picker_calendar-0_select-day-" +
                dayInt +
                "'][aria-hidden='false']";
            let dateSelectionret =
                "button[data-hook='flight-search-date-picker_calendar-1_select-day-" +
                dayInt +
                "'][aria-hidden='false']";
            if (month === calendarMonthLeft) {
                await actions.clickElement(
                    'click',
                    dateSelection,
                    'button to select the departure date',
                );
            } else {
                await actions.clickElement(
                    'click',
                    dateSelectionret,
                    'button to select the departure date',
                );
            }
            return returnDate;
        } else {
            let roundTripIsSelcted = await actions.isSelected(
                isRoundTripSelected,
                'isRoundTripSelected',
            );
            if (roundTripIsSelcted) {
                let returnDate = new Date();
                let { calendarMonthLeft, month, dayInt } = await this.calculateDate(
                    dateNumber,
                    departureDate,
                );
                let dateSelection =
                    "button[data-hook='flight-search-date-picker_calendar-0_select-day-" +
                    dayInt +
                    "'][aria-hidden='false']";
                let dateSelectionret =
                    "button[data-hook='flight-search-date-picker_calendar-1_select-day-" +
                    dayInt +
                    "'][aria-hidden='false']";
                if (month === calendarMonthLeft) {
                    await actions.clickElement(
                        'click',
                        dateSelection,
                        'button to select the departure date',
                    );
                } else {
                    await actions.clickElement(
                        'click',
                        dateSelectionret,
                        'button to select the departure date',
                    );
                }
                return returnDate;
            }
        }
    }

    async selectMonth(month, direction) {
        let calMonthLeft = await actions.getText(calendarMonthAndYearTextLeft, 'month and year');
        let calendarMonthLeft = await calMonthLeft.toString().split(' ')[0].slice(0, 3).trim();
        let calMonthRight = await actions.getText(calendarMonthAndYearTextRight, 'month and year');
        let calendarMonthRight = await calMonthRight.toString().split(' ')[0].slice(0, 3).trim();
        while (!(month === calendarMonthLeft || month === calendarMonthRight)) {
            let nextMonth = await $(direction).getAttribute('disabled');
            if (nextMonth == null) {
                await actions.clickElement('click', direction, 'direction button');
            } else {
                return null;
            }
            calMonthLeft = await actions.getText(calendarMonthAndYearTextLeft, 'Month and Year');
            calendarMonthLeft = await calMonthLeft.toString().split(' ')[0].slice(0, 3).trim();

            calMonthRight = await actions.getText(calendarMonthAndYearTextRight, 'Month and Year');
            calendarMonthRight = await calMonthRight.toString().split(' ')[0].slice(0, 3).trim();
        }
        return calendarMonthLeft;
    }

    async calculateDate(dateNumber, newDate) {
        let dateSelected = parseInt(dateNumber);
        await newDate.setDate(newDate.getDate() + dateSelected);
        let stringDate = await newDate.toDateString().slice(3);
        let month = await stringDate.slice(0, -8).trim();
        let day = await stringDate.slice(4, -5).trim();
        let dayInt = parseInt(day);
        let year = await stringDate.slice(7).trim();
        await browser.pause(3000);
        let calLeftData = await actions.getText(
            calendarMonthAndYearTextLeft,
            'calendarMonthAndYearTextLeft',
        );
        await browser.pause(5000);
        let calendarYearLeft = await calLeftData.toString().split(' ')[1].trim();
        let calRightData = await actions.getText(
            calendarMonthAndYearTextRight,
            'calendarMonthAndYearTextRight',
        );
        let calendarYearRight = await calRightData.toString().split(' ')[1].trim();
        //
        while (!(year === calendarYearLeft || year === calendarYearRight)) {
            await $(datePickerNext).click();

            calLeftData = await $(calendarMonthAndYearTextLeft).getText();
            calendarYearLeft = await calLeftData.toString().split(' ')[1].trim();
            calRightData = await $(calendarMonthAndYearTextRight).getText();
            calendarYearRight = await calRightData.toString().split(' ')[1].trim();
        }
        let direction;
        if (dateNumber < 0) {
            direction = datePickerPrevious;
        } else {
            direction = datePickerNext;
        }
        let calendarMonthLeft = await this.selectMonth(month, direction);
        let monthNumber;
        while (calendarMonthLeft == null) {
            // await $(departureDate).click();
            await actions.click(departureDate, 'departureDate');
            monthNumber = newDate.getMonth() + 1;
            newDate = new Date(year, monthNumber, 1);
            stringDate = newDate.toDateString().slice(3);
            month = stringDate.slice(0, -8).trim();
            dayInt = 1;
            calendarMonthLeft = await this.selectMonth(month, direction);
        }
        let isDisabled = false;
        let dayCalendar;
        if (month === calendarMonthLeft) {
            dayCalendar =
                "button[data-hook='flight-search-date-picker_calendar-0_select-day-" +
                dayInt +
                "'][aria-hidden='false']";
        } else {
            dayCalendar =
                "button[data-hook='flight-search-date-picker_calendar-1_select-day-" +
                dayInt +
                "'][aria-hidden='false']";
        }
        //isDisabled = await $(dayCalendar).isClickable();
        isDisabled = await actions.isClickable(dayCalendar, 'Day Calender');
        let nextDate = newDate;
        while (!isDisabled) {
            await nextDate.setDate(nextDate.getDate() + 1);
            stringDate = await nextDate.toDateString().slice(3);
            day = await stringDate.slice(4, -5).trim();
            dayInt = parseInt(day);
            month = await stringDate.slice(0, -8).trim();
            calendarMonthLeft = await this.selectMonth(month, direction);

            if (month === calendarMonthLeft) {
                dayCalendar =
                    "button[data-hook='flight-search-date-picker_calendar-0_select-day-" +
                    dayInt +
                    "'][aria-hidden='false']";
            } else {
                dayCalendar =
                    "button[data-hook='flight-search-date-picker_calendar-1_select-day-" +
                    dayInt +
                    "'][aria-hidden='false']";
            }
            isDisabled = await actions.isEnabled(dayCalendar, 'dayCalendar');
        }
        return { calendarMonthLeft, month, dayInt, nextDate };
    }

    async submithomepage() {
        // await actions.scroll(classcheck)
        // await check.checkClass(classcheck,'disclaimer','disclaimer-class')
        await actions.scroll(scrollingpurpose);
        await actions.clickElement('click', homesubmit, 'submit button');
    }
}
export default new HomePage();
export { BookingDisabledFromMonth, billboardNameList };
