import mrActions from '../../src/support/multiRemoteActions';
import mrCheck from '../../src/support/multiRemoteCheck';
import actions from '../../src/support/actions';
import ChromeDriverService from 'wdio-chromedriver-service';
import Logger from '../../src/common/loggers';

//Mobile-Selectors
const version = 'id=com.lixar.allegiant:id/versionNumberIdentifier';
const doneBtn = 'id=com.lixar.allegiant:id/doneBtn';
const popup = 'id=com.android.permissioncontroller:id/permission_allow_foreground_only_button';

//Web Selectors
const buttontoclosepopup = "//button[@class='Popup__CloseIcon-sc-1kasz48-2 eKPgGA']/img";
const cookieepopup = "//button[contains(@class,'close-button')]";

// const FirstNamefield = 'id=com.lixar.allegiant:id/firstNameInputCheckin';
// const LastNamefield = 'id=com.lixar.allegiant:id/lastNameInputCheckin';
// const addNewTrip = 'id=com.lixar.allegiant:id/add_trip_txt';
//android
const FirstNamefield = '~add_trips_firstname_text';
const LastNamefield = '~add_trips_lastname_text';
const addNewTrip = '~AddNewTripButton';
// //ios

class Mobile {
    webobjIns;
    mobObjIns;
    mobileActionMR;
    webActionMR;
    mobileValidationMR;
    webValidationMR;
    constructor() {
        if (!browser.capabilities) {
            this.webobjIns = new Function('return myChromeBrowser')();
            this.mobObjIns = new Function('return myMobile')();
            this.mobileActionMR = new mrActions('myMobile');
            this.webActionMR = new mrActions('myChromeBrowser');
            this.mobileValidationMR = new mrCheck('myMobile');
            this.webValidationMR = new mrCheck('myChromeBrowser');
        }
    }

    async launchWWWApplication() {
        await actions.pause(5000);
        await this.webActionMR.openWebsite('https://www.qa2.allegiantair.com/');
        await this.webValidationMR.checkURL('https://www.qa2.allegiantair.com/');
        await this.webobjIns.pause(3000);
        await this.webActionMR.refresh('Allegiant');
    }

    async popUps() {
        await this.webobjIns.pause(5000);
        try {
            let buttontoclosepopupVisibilty = await this.webActionMR.isDisplayed(
                buttontoclosepopup,
                'button to close Merchandise Pop-up',
            );
            if (buttontoclosepopupVisibilty) {
                await this.webValidationMR.isDisplayed(
                    buttontoclosepopup,
                    'buttontoclosepopup',
                    true,
                );
                await this.webActionMR.waitForDisplayed(
                    buttontoclosepopup,
                    'Overlay Merchandise Pop-up button',
                    5000,
                );
                await this.webActionMR.isDisplayed(
                    buttontoclosepopup,
                    'Overlay Merchandise Pop-up button',
                );
                await this.webActionMR.waitForClickable(
                    buttontoclosepopup,
                    'Overlay Merchandise Pop-up button',
                );
                await this.webValidationMR.isEnabled(
                    buttontoclosepopup,
                    'buttontoclosepopup',
                    true,
                );
                await this.webActionMR.clickElement(
                    'click',
                    buttontoclosepopup,
                    'button to close the Overlay Merchandise pop-up',
                );
            }
        } catch (error) {
            console.log('Overlay Merchandise Popup not Displayed');
        }
        await this.webobjIns.pause(2000);
        let cookieepopupVisibile = await this.webActionMR.isDisplayed(
            cookieepopup,
            'Accept All Cookies Popup button',
        );
        if (cookieepopupVisibile) {
            await this.webActionMR.waitForDisplayed(
                cookieepopup,
                'Accept All Cookies Popup button',
                5000,
            );
            await this.webActionMR.waitForClickable(
                cookieepopup,
                'Accept All Cookies Popup button',
            );
            await this.webActionMR.clickElement(
                'click',
                cookieepopup,
                'Button to close Accept All Cookies Popup',
            );
        } else {
            console.log('Accept All Cookies Popup not Displayed');
        }
    }

    async selectEnvironment() {
        let envbutton;
        let env = process.env.Env;
        // await this.mobileActionMR.launchApp()
        for (var i = 0; i < 4; i++) {
            await this.mobileActionMR.scrolling('up');
        }
        if (env.toLowerCase().includes('stg')) {
            envbutton = "//*[@text='Stage']";
        } else if (env.toLowerCase().includes('qa1')) {
            envbutton = "//*[@text='QA1']";
        } else if (env.toLowerCase().includes('qa2')) {
            envbutton = "//*[@text='QA2']";
        } else if (env.toLowerCase().includes('qatnexusg4')) {
            envbutton = "//*[@text='QATNEXUSG4']";
        } else if (env.toLowerCase().includes('intnexusg4')) {
            envbutton = "//*[@text='INTNEXUSG4']";
        } else if (env.toLowerCase().includes('dev01')) {
            envbutton = "//*[@text='Dev01']";
        } else if (env.toLowerCase().includes('prod01')) {
            envbutton = "//*[@text='Prod01']";
        }
        let envVisibilty = await this.mobObjIns.$(envbutton).isDisplayed();
        if (!envVisibilty) {
            await this.mobileActionMR.scrollToElement(envbutton);
            await this.mobileActionMR.pause(2000);
        }
        await this.mobileActionMR.waitForDisplayed(envbutton, 'envbutton');
        await this.mobileActionMR.isDisplayed(envbutton, 'envbutton');
        await this.mobileValidationMR.isEnabled(envbutton, 'envbutton', true);
        await this.mobObjIns.$(envbutton).click();
        await this.mobileActionMR.scrollToElement(version, 'version');
        await this.mobileActionMR.waitForDisplayed(version, 'Env Version', 5000);
        let envVersion = await this.mobileActionMR.getText(version, 'Environment Version');
        console.log('The app details are : ', envVersion);
        await this.mobileActionMR.waitForDisplayed(doneBtn, 'Done button', 5000);
        await this.mobileActionMR.isDisplayed(doneBtn, 'Done button');
        await this.mobileActionMR.clickElement('click', doneBtn, 'Done Button');
        await this.mobileActionMR.isDisplayed(popup, 'Pop Up');
        await this.mobileActionMR.clickElement('click', popup, 'Pop Up');
        let MaintancancePOPUPVisibility = await this.mobileActionMR.isDisplayed(
            "//android.widget.Button[@text='Close']",
            'MaintancancePOPUP',
        );
        if (MaintancancePOPUPVisibility) {
            await this.mobileActionMR.clickElement(
                'click',
                "//android.widget.Button[@text='Close']",
                'Pop Up',
            );
        }
    }

    async iOSValidation() {
        let homeButton = "//XCUIElementTypeButton[@name='Home']";
        let selectEnvironment = '(//XCUIElementTypeStaticText)[6]';
        let moreMenu = "//XCUIElementTypeButton[@name='More']";
        let debugMenu = "//XCUIElementTypeStaticText[@name='Debug Menu']";
        let envSelector = "//XCUIElementTypeStaticText[@name='Environment Selector']";
        let allowAccessButton = "(//XCUIElementTypeButton[contains(@name,'Allow')])[1]";
        let envbutton;
        let env = process.env.Env;
        let allowAccessButtonisDisplay = await this.mobileActionMR.isDisplayed(
            allowAccessButton,
            'allowAccessButton',
        );
        if (allowAccessButtonisDisplay) {
            try {
                await this.mobileActionMR.waitForDisplayed(
                    allowAccessButton,
                    'allowAccess Button',
                    3000,
                );
                await this.mobObjIns.pause(5000);
                await this.mobileActionMR.click(allowAccessButton, 'allowAccessButton');
            } catch (e) {
                console.log('Allow button is not Displayed');
            }
        }
        await this.mobObjIns.pause(5000);
        await this.mobileActionMR.waitForDisplayed(moreMenu, 'moreMenu', 3000);
        await this.mobileActionMR.click(moreMenu, 'more Menu');
        await this.mobObjIns.pause(5000);
        await this.mobileActionMR.waitForDisplayed(debugMenu, 'debugMenu', 5000);
        await this.mobileActionMR.clickElement('click', debugMenu, 'debug Menu');
        await this.mobileActionMR.waitForDisplayed(envSelector, 'envSelector', 5000);
        await this.mobileActionMR.clickElement('click', envSelector, 'env Selector');
        await this.mobileActionMR.pause('2000');
        if (env.toLowerCase().includes('stg')) {
            envbutton = "//XCUIElementTypeStaticText[@name='Stage']";
        } else if (env.toLowerCase().includes('qa1')) {
            envbutton = "//XCUIElementTypeStaticText[@name='QA1']";
        } else if (env.toLowerCase().includes('qa2')) {
            envbutton = "//XCUIElementTypeStaticText[@name='QA2']";
        } else if (env.toLowerCase().includes('qatnexusg4')) {
            envbutton = "//XCUIElementTypeStaticText[@name='QATNEXUSG4']";
        } else if (env.toLowerCase().includes('intnexusg4')) {
            envbutton = "//XCUIElementTypeStaticText[@name='INTNEXUSG4']";
        } else if (env.toLowerCase().includes('dev01')) {
            envbutton = "//XCUIElementTypeStaticText[@name='Dev01']";
        } else if (env.toLowerCase().includes('prod01')) {
            envbutton = "//XCUIElementTypeStaticText[@name='Prod01']";
        }

        let envVisibilty = await this.mobileActionMR.isDisplayed(envbutton, 'button');
        if (!envVisibilty) {
            await this.mobileActionMR.scrollToElement(envbutton);
            await this.mobileActionMR.pause(2000);
        }
        await this.mobileValidationMR.isEnabled(envbutton, 'envbutton', true);
        await this.mobileActionMR.clickElement('click', envbutton, 'Environment radio button');
        await this.mobileActionMR.pause(5000);
        let selectedEnv = await this.mobileActionMR.getText(selectEnvironment, 'selectEnvironment');
        console.log('The selected env is : ', selectedEnv);
        let versionNum =
            "//XCUIElementTypeStaticText[@name='Version:']/following::XCUIElementTypeStaticText[1]";
        let usedVersion = await this.mobileActionMR.getText(versionNum, 'version Number');
        console.log('The app version is : ', usedVersion);
        let buildNum =
            "//XCUIElementTypeStaticText[@name='Build:']/following::XCUIElementTypeStaticText[1]";
        let build = await this.mobileActionMR.getText(buildNum, 'Build Number');
        console.log('The build version is : ', build);
        await this.mobileActionMR.pause(4000);
        await this.mobileActionMR.clickElement('click', homeButton, 'home Button');
    }

    async scrolling(direction) {
        let side = direction.toLowerCase();
        var { width, height } = await browser.getWindowSize();
        let startX;
        let startY;
        let endX;
        let endY;

        if (side === 'down') {
            startX = parseInt(width * 0.5);
            startY = parseInt(height * 0.9);
            endX = parseInt(width * 0.5);
            endY = parseInt(height * 0.5);
        }
        if (side === 'up') {
            startX = parseInt(width * 0.5);
            startY = parseInt(height * 0.4);
            endX = parseInt(width * 0.5);
            endY = parseInt(height * 0.9);
        }
        await browser.touchAction([
            { action: 'press', x: startX, y: startY },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: endX, y: endY },
            'release',
        ]);
    }

    async scrollToElement(selector) {
        var { width, height } = await browser.getWindowSize();
        let elementVisibilty;
        let startX;
        let startY;
        let endX;
        let endY;
        do {
            elementVisibilty = await $(selector).isDisplayed();
            if (elementVisibilty === false) {
                startX = parseInt(width * 0.5);
                startY = parseInt(height * 0.5);
                endX = parseInt(width * 0.5);
                endY = parseInt(height * 0.1);
                await browser.touchAction([
                    { action: 'press', x: startX, y: startY },
                    { action: 'wait', ms: 2000 },
                    { action: 'moveTo', x: endX, y: endY },
                    'release',
                ]);
            }
        } while (elementVisibilty === false);
    }
    async hideTheKeyboard() {
        await actions.pause(2000);
        await this.mobileActionMR.hideKeyboard('tapOutside');
    }
    async clickAddNewTrip() {
        if (process.env.MR == 'yes') {
            console.log('locator is = ' + addNewTrip);
            await this.mobileActionMR.waitForDisplayed(addNewTrip, 'add New Trip', '3000');
            await this.mobileActionMR.isDisplayed(addNewTrip, 'add New Trip');
            await this.mobileActionMR.clickElement('click', addNewTrip, 'add New Trip');
        } else {
            await actions.waitForDisplayed(addNewTrip, 'add New Trip');
            await actions.isDisplayed(addNewTrip, 'add New Trip');
            await actions.clickElement('click', addNewTrip, 'add New Trip');
        }
    }
    async EnterFirstName(FirstName) {
        if (process.env.MR == 'yes') {
            await this.mobileActionMR.waitForDisplayed(FirstNamefield, 'First Name');
            await this.mobileActionMR.isDisplayed(FirstNamefield, 'First Name');
            //await mobileActionMR.setInputField('setValue',FirstName,FirstNamefield,'First Name')
            if (!FirstName) {
                Logger.error('The First name is null please check');
            } else {
                Logger.log(`The firstName is ${FirstName}`);
            }
            await this.mobileActionMR.setInputField(
                'setValue',
                FirstName,
                FirstNamefield,
                'First Name',
            );
            await this.mobileActionMR.hideKeyboard('tapOutside');
            // await this.chromObjIns.hideKeyboard('tapOutside');
        } else {
            await actions.waitForDisplayed(FirstNamefield, 'First Name');
            await actions.isDisplayed(FirstNamefield, 'First Name');
            //await actions.setInputField('setValue',FirstName,FirstNamefield,'First Name')
            if (!FirstName) {
                Logger.error('The First name is null please check');
            } else {
                Logger.log(`The firstName is ${FirstName}`);
            }
            await actions.setInputField('setValue', FirstName, FirstNamefield, 'First Name');
            if (browser.isAndroid) {
                await browser.hideKeyboard('tapOutside');
            }
        }
    }
}

export default new Mobile();
