//SpyOn console error, info, log and assert
import { assert } from 'chai';

global.error = jest.spyOn(console, 'error').mockImplementation(() => { })
global.info = jest.spyOn(console, 'info').mockImplementation(() => { })
global.log = jest.spyOn(console, 'log').mockImplementation(() => { })
global.warn = jest.spyOn(console, 'warn').mockImplementation(() => { })
global.time = jest.spyOn(console, 'time').mockImplementation(() => { })
global.timeEnd = jest.spyOn(console, 'timeEnd').mockImplementation(() => { })
global.assert = jest.spyOn(assert, 'fail').mockImplementation(() => { })

afterAll(() => {
    global.error.mockRestore();
    global.info.mockRestore();
    global.log.mockRestore();
    global.warn.mockRestore();
    global.time.mockRestore();
    global.timeEnd.mockRestore();
    global.assert.mockRestore();
});
afterEach(() => {
    global.error.mockClear();
    global.info.mockClear()
    global.log.mockClear()
    global.warn.mockClear()
    global.time.mockClear();
    global.timeEnd.mockClear();
    global.assert.mockClear()
});

//document
const mockDocument = {
    body: {
        style: {
            zoom: null
        }
    }
}
global.document = mockDocument

/* eslint-disable no-var, no-unused-vars, no-underscore-dangle */

// Create the WebdriverIO browser object
var browser = {};

// Make a proxy of the global Jest expect function so we can test the global
// expect-webdriverio version
global._expect = global.expect;
