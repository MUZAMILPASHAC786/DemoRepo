import check from '../../../src/support/validations';

let getSizeMock;

describe('checkDimension', () => {

    beforeEach(() => {
        getSizeMock = jest.fn(() => ({
            width: 100,
            height: 200,
        }));
        global.$ = jest.fn().mockReturnValue({
            getSize: getSizeMock,
        });
    });

    it('Should test the height of an element against a given value', async () => {
        let selectorElement = $('element')
        await check.checkDimension(selectorElement, 200, 'tall', true);
        _expect(getSizeMock).toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()
    });

    it('Should test the width of an element against a given value', async () => {
        await check.checkDimension('element2', 100, 'broad', false);
        _expect(getSizeMock).toHaveBeenCalledTimes(1);
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test the height of an element against a given value (falseCase)', async () => {
        await check.checkDimension('element3', 200, 'tall', true);
        _expect(getSizeMock).toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()
    });
});
