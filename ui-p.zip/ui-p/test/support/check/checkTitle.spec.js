import check from '../../../src/support/validations';

describe('checkTitle', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        global.browser = {
            getTitle: jest.fn(() => 'page title'),
        };

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });
    it('Should test if the title matches the given text', async () => {
        await check.checkTitle('google', 'page title', true);
        _expect(global.browser.getTitle).toHaveBeenCalledTimes(1);
        _expect(global.browser.getTitle).toHaveBeenCalledWith();
        expect(global.browser.getTitle).toEqual('google')
        _expect(global.info).toHaveBeenCalled()

    });

    it('Should test if the title does not match the given text', async () => {
        await check.checkTitle('sample', 'page title', false);
        _expect(global.browser.getTitle).toHaveBeenCalledTimes(1);
        _expect(global.browser.getTitle).toHaveBeenCalledWith();
        expect(global.browser.getTitle).not.toEqual('google')
        _expect(global.info).toHaveBeenCalled()
    });
});
