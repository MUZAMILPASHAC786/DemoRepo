import check from '../../../src/support/validations';

describe('checkIsOpenedInNewWindow', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandles: jest.fn(() => ['window1', 'window2']),
            switchToWindow: jest.fn(() => {
            }),
            getUrl: jest.fn(() => 'http://www.example.com/test'),
            closeWindow: jest.fn(() => {
            }),
        };
    });

    it('Should fail if no popup was opened', async () => {
        global.expect = await jest.fn(() => {
            throw new Error();
        });
        await global.browser.getWindowHandles.mockReturnValueOnce(['window1']);
        await check.checkIsOpenedInNewWindow('http://www.google.com/');
        _expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        _expect(global.browser.getWindowHandles).toHaveBeenCalledWith();
        _expect(global.browser.switchToWindow).toHaveBeenCalled();
        _expect(global.browser.getUrl).toHaveBeenCalled();
        _expect(global.browser.closeWindow).toHaveBeenCalled();
        _expect(global.expect).toHaveBeenCalledTimes(0);
        _expect(global.expect).toThrow();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should not fail if the URL of the popup does match', async () => {
        await check.checkIsOpenedInNewWindow('http://www.example.com/test');
        _expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        _expect(global.browser.getWindowHandles).toHaveBeenCalledWith();
        _expect(global.browser.switchToWindow).toHaveBeenCalledTimes(1);
        _expect(global.browser.switchToWindow).toHaveBeenCalledWith('window2');
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        _expect(global.browser.closeWindow).toHaveBeenCalledTimes(1);
        _expect(global.browser.closeWindow).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });
});
