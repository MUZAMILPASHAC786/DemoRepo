import check from '../../../src/support/validations';

let getCSSMock;
let getAttributeMock;

describe('checkProperty', () => {
    beforeEach(() => {
        getCSSMock = jest.fn(() => {
        });
        getAttributeMock = jest.fn(() => 'element-name');
        global.$ = jest.fn().mockReturnValue({
            getCSSProperty: getCSSMock,
            getAttribute: getAttributeMock,
        });
    });

    it('Should test if the element has the correct color', async () => {
        let selectorElement = $('element')
        await getCSSMock.mockReturnValueOnce({ value: 'black' });
        await check.checkProperty(true, selectorElement, 'color', 'black', 'checkcolor', false);
        _expect(getCSSMock).toHaveBeenCalledTimes(1);
        _expect(getCSSMock).toHaveBeenCalledWith('color');
        _expect(getAttributeMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element has the correct color code', async () => {
        const expectedValue = 10;
        jest.spyOn(Number, 'isFinite').mockReturnValue(true);
        let selectorElement = $('element')
        await getCSSMock.mockReturnValueOnce({ value: 'black' });
        await check.checkProperty(true, selectorElement, 'color', expectedValue, 'checkcolor', false);
        _expect(getCSSMock).toHaveBeenCalledTimes(1);
        _expect(getCSSMock).toHaveBeenCalledWith('color');
        _expect(getAttributeMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
        expect(Number.isFinite).toHaveBeenCalledWith(expectedValue);
    });

    it('Should test if the element does not have a width of 1px', async () => {
        await getCSSMock.mockReturnValueOnce('1px');
        await check.checkProperty(true, '#elem2', 'width', '1px', 'checkwidth', true);
        _expect(getCSSMock).toHaveBeenCalledTimes(1);
        _expect(getCSSMock).toHaveBeenCalledWith('width');
        _expect(getAttributeMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element has the correct name', async () => {
        await check.checkProperty(false, 'name', '#elem3', false, 'element-name');
        _expect(getAttributeMock).toHaveBeenCalledTimes(1);
        _expect(getAttributeMock).toHaveBeenCalledWith('#elem3');
        _expect(getCSSMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element has the line-height of 1.25', async () => {
        getCSSMock = await jest.fn(() => 1.25);
        global.$ = await jest.fn().mockReturnValue({
            getCSSProperty: getCSSMock,
        });
        await check.checkProperty(true, 'line-height', '#elem4', false, 1.25);
        _expect(getAttributeMock).not.toHaveBeenCalled();
        _expect(getCSSMock).toHaveBeenCalledTimes(1);
        _expect(getCSSMock).toHaveBeenCalledWith('#elem4');
        _expect(global.info).toHaveBeenCalled()
    });
});
