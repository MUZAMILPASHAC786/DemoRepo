import check from '../../../src/support/validations';

describe('checkCookieContains', () => {

    beforeEach(() => {
        global.browser = {
            getCookies: jest.fn(() => ([{
                name: 'cookie1',
                value: 'value1',
            }])),
        };
    });
    it('Should fail if no cookie was found with the given name', async () => {
        await check.checkCookieContains('cookie2', '', true);
        _expect(global.browser.getCookies).toHaveBeenCalledTimes(1);
        _expect(global.browser.getCookies).toHaveBeenCalledWith('cookie2');
        _expect(global.info).toHaveBeenCalled()
    });

    it('Handle the false case', async () => {
        await check.checkCookieContains('cookie1', 'value2', false);
        _expect(global.browser.getCookies).toHaveBeenCalledTimes(1);
        _expect(global.browser.getCookies).toHaveBeenCalledWith('cookie1');
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should be able to validated against an expected string', async () => {
        await check.checkCookieContains('cookie1', 'value2', false);
        _expect(global.browser.getCookies).toHaveBeenCalledTimes(1);
        _expect(global.browser.getCookies).toHaveBeenCalledWith('cookie1');
        _expect(global.info).toHaveBeenCalled()
    });
});
