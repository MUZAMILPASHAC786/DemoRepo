import check from '../../../src/support/validations';

describe('checkIfElementExists', () => {

    beforeEach(() => {
        global.$$ = jest.fn(() => 1);
    });

    it('Should test if the element exists', async () => {
        await check.checkIfElementExists('an', 'element1', true);
        _expect(global.$$).toHaveBeenCalledTimes(1);
        _expect(global.$$).toHaveBeenCalledWith('an');
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element does not exist', async () => {
        await check.checkIfElementExists('no', 'element2', false);
        _expect(global.$$).toHaveBeenCalledTimes(1);
        _expect(global.$$).toHaveBeenCalledWith('no');
        _expect(global.info).toHaveBeenCalled()

    });
});
