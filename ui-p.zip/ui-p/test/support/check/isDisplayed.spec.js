import check from '../../../src/support/validations';

let isDisplayedMock;

describe('isDisplayed', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        isDisplayedMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            isDisplayed: isDisplayedMock,
        });

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the element is enabled', async () => {
        let selectorElement = $('#elem1')
        await check.isDisplayed(selectorElement, '#elem1', true);
        _expect(isDisplayedMock).toHaveBeenCalledTimes(1);
        expect(isDisplayedMock).toEqual('true')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element is not enabled', async () => {
        await check.isDisplayed('#elem2', '#elem2', false);
        _expect(isDisplayedMock).toHaveBeenCalledTimes(1);
        expect(isDisplayedMock).toEqual('false')
        _expect(global.assert).toHaveBeenCalled()
    });
});
