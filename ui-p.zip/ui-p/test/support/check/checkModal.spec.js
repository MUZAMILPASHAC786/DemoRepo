import check from '../../../src/support/validations';

describe('checkModal', () => {
    beforeEach(() => {
        global.browser = {
            getAlertText: jest.fn(() => 'test'),
        };
    });
    it('Should test if alertbox is opened', async () => {
        global.browser.getAlertText = await jest.fn(() => {
            throw new Error();
        });
        await check.checkModal('alertbox', true);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if confirmbox is not opened', async () => {
        await check.checkModal('confirmbox', false);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.assert).toHaveBeenCalled()
    });

    it('Should test if alertbox is not opened', async () => {
        global.browser.getAlertText = await jest.fn(() => {
            throw new Error();
        });
        await check.checkModal('alertbox', false);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if confirmbox is opened', async () => {
        await check.checkModal('confirmbox', true);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });
});
