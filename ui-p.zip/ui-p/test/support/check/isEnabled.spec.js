import check from '../../../src/support/validations';

let isEnabledMock;

describe('isEnabled', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        isEnabledMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            isEnabled: isEnabledMock,
        });

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the element is enabled', async () => {
        let selectorElement = $('#elem1')
        await check.isEnabled(selectorElement, '#elem1', true);
        _expect(isEnabledMock).toHaveBeenCalledTimes(1);
        expect(isEnabledMock).toEqual('true')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element is not enabled', async () => {
        await check.isEnabled('#elem2', '#elem2', false);
        _expect(isEnabledMock).toHaveBeenCalledTimes(1);
        expect(isEnabledMock).toEqual('false')
        _expect(global.assert).toHaveBeenCalled()

    });
});
