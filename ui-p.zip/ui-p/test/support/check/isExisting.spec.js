import check from '../../../src/support/validations';


describe('isExisting', () => {
    beforeEach(() => {
        global.$$ = jest.fn().mockReturnValue(['true']);
    });
    test('Should test if the element exists', async () => {
        await check.isExisting('#elem1', '#elem1', true);
        _expect(global.$$).toHaveBeenCalledTimes(1);
        _expect(global.$$).toHaveBeenCalledWith('#elem1');
        _expect(global.info).toHaveBeenCalled()
    });

    test('Should test if the element does not exist', async () => {
        await check.isExisting('#elem2', '#elem2', false);
        _expect(global.$$).toHaveBeenCalledTimes(1);
        _expect(global.$$).toHaveBeenCalledWith('#elem2');
        _expect(global.assert).toHaveBeenCalled()
    });
});
