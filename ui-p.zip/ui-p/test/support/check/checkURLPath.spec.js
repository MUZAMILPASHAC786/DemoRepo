import check from '../../../src/support/validations';

describe('checkURLPath', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        global.browser = {
            getUrl: jest.fn(() => 'http://example.com/test'),
        };

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the URL path matches the given value', async () => {
        await check.checkURLPath('/test', 'test', true);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        expect(global.browser.getUrl).toEqual('https://www.google.com/test')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the URL path does not match the given value', async () => {
        await check.checkURLPath('/autotravel', 'test', false);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        expect(global.browser.getUrl).not.toEqual('https://www.google.com/test')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should replace the domain from the current getUrl', async () => {
        await global.browser.getUrl.mockReturnValueOnce('http://www.example.com/test');
        await check.checkURLPath('/test', 'test', true);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()

    });
});
