import check from '../../../src/support/validations';

describe('checkClass', () => {
    let getAttributeMock;

    beforeEach(() => {
        getAttributeMock = jest.fn(() => 'class1 class2');
        global.$ = jest.fn().mockReturnValue({
            getAttribute: getAttributeMock,
        });
    });

    it('should call checkClass on the browser object - class1', async () => {
        let selectorElement = $('element')
        await check.checkClass(selectorElement, 'has', 'class1', true);
        _expect(getAttributeMock).toHaveBeenCalledTimes(1);
        _expect(getAttributeMock).toHaveBeenCalledWith('class');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call checkClass on the browser object - class3', async () => {
        await check.checkClass('element1', 'has', 'class3', true);
        _expect(getAttributeMock).toHaveBeenCalledTimes(1);
        _expect(getAttributeMock).toHaveBeenCalledWith('class');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call checkClass on the browser object (falseCase) - class3', async () => {
        await check.checkClass('element1', 'does not have', 'class3', false);
        _expect(getAttributeMock).toHaveBeenCalledTimes(1);
        _expect(getAttributeMock).toHaveBeenCalledWith('class');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call checkClass on the browser object (falseCase) - class1', async () => {
        await check.checkClass('element1', 'does not have', 'class1', false);
        _expect(getAttributeMock).toHaveBeenCalledTimes(1);
        _expect(getAttributeMock).toHaveBeenCalledWith('class');
        _expect(global.info).toHaveBeenCalled()
    });
});
