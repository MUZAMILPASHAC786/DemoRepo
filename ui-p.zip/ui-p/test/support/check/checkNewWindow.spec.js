import check from '../../../src/support/validations';

describe('checkNewWindow', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandles: jest.fn(() => ({
                value: ['window1'],
            })),
        };
    });

    it('Should test if a new window is opened', async () => {
        await check.checkNewWindow('', true);
        _expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        _expect(global.browser.getWindowHandles).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if a new window is not opened', async () => {
        await check.checkNewWindow('', false);
        _expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        _expect(global.browser.getWindowHandles).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });
});
