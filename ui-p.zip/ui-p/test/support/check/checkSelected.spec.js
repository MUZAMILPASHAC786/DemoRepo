import check from '../../../src/support/validations';

let isSelectedMock;

describe('checkSelected', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        isSelectedMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            isSelected: isSelectedMock,
        });

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the element is selected', async () => {
        let selectorElement = $('element')
        await check.checkSelected(selectorElement, '#elem1', true);
        _expect(isSelectedMock).toHaveBeenCalled();
        _expect(isSelectedMock).toHaveBeenCalledTimes(1);
        expect(isSelectedMock).toEqual('true')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element is not selected', async () => {
        await check.checkSelected('#elem2', '#elem2', false);
        _expect(isSelectedMock).toHaveBeenCalledTimes(1);
        expect(isSelectedMock).toEqual('false')
        _expect(global.assert).toHaveBeenCalled()
    });
});
