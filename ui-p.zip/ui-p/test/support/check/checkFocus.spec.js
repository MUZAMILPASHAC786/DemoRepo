import check from '../../../src/support/validations';

let hasFocusMock;

describe('checkFocus', () => {

    beforeEach(() => {
        hasFocusMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            isFocused: hasFocusMock,
        });
    });
    it('Should test if the element has focus', async () => {
        let selectorElement = $('element')
        await check.checkFocus(selectorElement, 'element1', true);
        _expect(hasFocusMock).toHaveBeenCalledTimes(1);
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element does not have the focus', async () => {
        await check.checkFocus('element1', 'element1', false);
        _expect(hasFocusMock).toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()
    });
});
