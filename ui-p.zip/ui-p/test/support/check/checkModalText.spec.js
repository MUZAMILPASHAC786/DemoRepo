import check from '../../../src/support/validations';

describe('checkModalText', () => {
    beforeEach(() => {
        global.browser = {
            getAlertText: jest.fn(() => 'test'),
        };
    });

    it('Should test if getAlertText contains the given value', async () => {
        await check.checkModalText('confirmbox', 'test', true);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if getAlertText does not contain the given value', async () => {
        await check.checkModalText('confirmbox', 'test', false);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.assert).toHaveBeenCalled()
    });

    it(`Should test if getAlertText does not contain 
        the given value (when no modal is opened)`, async () => {
        await check.checkModalText('confirmbox', 'test', false);
        _expect(global.browser.getAlertText).toHaveBeenCalledTimes(1);
        _expect(global.browser.getAlertText).toHaveBeenCalledWith();
        _expect(global.assert).toHaveBeenCalled()
    });
});
