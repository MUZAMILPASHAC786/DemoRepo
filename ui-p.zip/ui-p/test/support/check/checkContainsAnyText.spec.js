import check from '../../../src/support/validations';

describe('checkContainsAnyText', () => {
    let getTextMock;
    let getValueMock;
    let getAttributeMock;

    beforeEach(() => {
        getTextMock = jest.fn(() => 'text');
        getValueMock = jest.fn(() => 'value');
        getAttributeMock = jest.fn(() => null);
        global.$ = jest.fn().mockReturnValue({
            getText: getTextMock,
            getValue: getValueMock,
            getAttribute: getAttributeMock,
        });
    });

    it('Should handle input fields', async () => {
        let selectorElement = $('element')
        await getAttributeMock.mockReturnValueOnce(() => '');
        await check.checkContainsAnyText(selectorElement, 'element1', true);
        _expect(getTextMock).not.toHaveBeenCalledTimes(1);
        _expect(getValueMock).toHaveBeenCalledTimes(0);
        _expect(global.assert).toHaveBeenCalled()
    });

    it('Should handle elements', async () => {
        await check.checkContainsAnyText('element', 'element1', false);
        _expect(getTextMock).toHaveBeenCalledTimes(1);
        _expect(getValueMock).not.toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()
    });

    it('Should handle buttons', async () => {
        await check.checkContainsAnyText('element', 'element1', false);
        _expect(getTextMock).toHaveBeenCalledTimes(1);
        _expect(getValueMock).not.toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()
    });

    it('Handle the false case', async () => {
        await check.checkContainsAnyText('element', 'element1', true);
        _expect(getTextMock).toHaveBeenCalledTimes(1);
        _expect(getValueMock).not.toHaveBeenCalledTimes(1);
        _expect(global.info).toHaveBeenCalled()
    });

    it('should handle no expected text and no falsecase', async () => {
        await check.checkContainsAnyText('element', 'element1', '');
        _expect(getTextMock).toHaveBeenCalledTimes(1);
        _expect(getValueMock).not.toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()
    });
});
