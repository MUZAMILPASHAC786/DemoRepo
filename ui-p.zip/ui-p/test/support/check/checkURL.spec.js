import check from '../../../src/support/validations';

describe('checkURL', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        global.browser = {
            getUrl: jest.fn(() => 'http://www.example.com/test'),
        };

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
        global.$$ = jest.fn().mockReturnValue(['true']);
    });
    it('Should test if the current URL matches the expected value', async () => {
        await check.checkURL('https://www.google.com/', 'google', true);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        expect(global.browser.getUrl).toEqual('https://www.google.com/')
        _expect(global.info).toHaveBeenCalled()
    });

    it(
        'Should test if the current URL doesn\'t match the expected value',
        async () => {
            await check.checkURL('https://www.google.com/test', 'google', false);
            _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
            _expect(global.browser.getUrl).toHaveBeenCalledWith();
            expect(global.browser.getUrl).not.toEqual('https://www.google.com/test')
            _expect(global.info).toHaveBeenCalled()
        });
});
