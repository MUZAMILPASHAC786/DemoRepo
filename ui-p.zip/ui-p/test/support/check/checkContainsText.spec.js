import check from '../../../src/support/validations';

describe('checkContainsText', () => {
    let getTextMock;
    let getValueMock;
    let getAttributeMock;
    let waitForDisplayedMock;

    beforeEach(() => {
        getTextMock = jest.fn(() => 'text');
        getValueMock = jest.fn(() => 'value');
        getAttributeMock = jest.fn(() => '');
        waitForDisplayedMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            getText: getTextMock,
            getValue: getValueMock,
            getAttribute: getAttributeMock,
            waitForDisplayed: waitForDisplayedMock,
        });
    });

    it('should call checkContainsText on the button object', async () => {
        let selectorElement = $('element')
        await check.checkContainsText(selectorElement, 'text', true, 'button1');
        _expect(getTextMock).toHaveBeenCalledTimes(1);
        _expect(global.info).toHaveBeenCalled()

    });

    it('should call checkContainsText on the element object', async () => {
        await getAttributeMock.mockReturnValueOnce(() => '');
        await check.checkContainsText('element', 'text', true, 'element2');
        _expect(getTextMock).not.toHaveBeenCalledTimes(1);
        _expect(getValueMock).toHaveBeenCalled();
        _expect(global.assert).toHaveBeenCalled()
    });

    it('should call checkContainsText on the element object (falseCase)', async () => {
        await check.checkContainsText('element', 'text', false, 'element2');
        _expect(getAttributeMock).toHaveBeenCalledTimes(1);
        _expect(global.assert).toHaveBeenCalled()

    });
});
