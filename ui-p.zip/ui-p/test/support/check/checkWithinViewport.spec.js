import check from '../../../src/support/validations';

let isDisplayedInViewportMock;

describe('checkWithinViewport', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        isDisplayedInViewportMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isDisplayedInViewport: isDisplayedInViewportMock,
        });

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the element is visible within the viewport', async () => {
        let selectorElement = $('#elem1')
        await check.checkWithinViewport(selectorElement, '#elem1', true);
        _expect(isDisplayedInViewportMock).toHaveBeenCalledTimes(1);
        _expect(global.$).toHaveBeenCalledWith('#elem1');
        expect(isDisplayedInViewportMock).toEqual('true')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element is not visible within the viewport', async () => {
        await check.checkWithinViewport('#elem2', '#elem2', false);
        _expect(isDisplayedInViewportMock).toHaveBeenCalledTimes(1);
        _expect(global.$).toHaveBeenCalledWith('#elem2');
        expect(isDisplayedInViewportMock).toEqual('false')
        _expect(global.assert).toHaveBeenCalled()
    });
});
