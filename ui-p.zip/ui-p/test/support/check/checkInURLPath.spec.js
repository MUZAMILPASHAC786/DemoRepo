import check from '../../../src/support/validations';

describe('checkURLPath', () => {
    beforeEach(() => {
        global.browser = {
            getUrl: jest.fn(() => 'http://example.com/test'),
        };
    });

    it('Should test if the URL path matches the given value', async () => {
        await check.checkURLPath('http://google.com/','test',true);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the URL path does not match the given value', async () => {
        await check.checkURLPath('http://google.com/','test',false);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should replace the domain from the current getUrl', async () => {
        await global.browser.getUrl.mockReturnValueOnce('http://www.example.com/test');
        await check.checkURLPath('http://www.example.com/test','test',false);
        _expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        _expect(global.browser.getUrl).toHaveBeenCalledWith();
        _expect(global.info).toHaveBeenCalled()
    });
});
