import check from '../../../src/support/validations';

describe('checkCookieExists', () => {

    beforeEach(() => {
        global.browser = {
            getCookies: jest.fn(),
        };
    });

    it('Should succeed if a cookie was found with the given name', async () => {
        await global.browser.getCookies.mockReturnValueOnce({
            name: 'cookie1',
            value: 'value1',
        });
        await check.checkCookieExists('cookie1', true);
        _expect(global.browser.getCookies).toHaveBeenCalledTimes(1);
        _expect(global.browser.getCookies).toHaveBeenCalledWith('cookie1');
        _expect(global.assert).toHaveBeenCalled()
    });

    it('Should fail if no cookie was found with the given name', async () => {
        await global.browser.getCookies.mockReturnValueOnce([]);
        await check.checkCookieExists('cookie2', false);
        _expect(global.browser.getCookies).toHaveBeenCalledTimes(1);
        _expect(global.browser.getCookies).toHaveBeenCalledWith('cookie2');
        _expect(global.info).toHaveBeenCalled()
    });
});
