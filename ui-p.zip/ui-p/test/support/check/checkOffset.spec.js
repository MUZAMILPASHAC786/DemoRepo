import check from '../../../src/support/validations';

let getLocationMock;

describe('checkOffset', () => {
    beforeEach(() => {
        getLocationMock = jest.fn(() => 100);
        global.$ = jest.fn().mockReturnValue({
            getLocation: getLocationMock,
        });
    });

    it(
        'Should test if the element is positioned at the expected location',
        async () => {
            let selectorElement = $('element')
            await check.checkOffset(selectorElement, '480', '380', 'x', true);
            _expect(getLocationMock).toHaveBeenCalledTimes(1);
            _expect(getLocationMock).toHaveBeenCalledWith('380');
            _expect(global.info).toHaveBeenCalled()
        },
    );

    it(
        'Should test if the element is not positioned at the expected '
        + 'location',
        async () => {
            await check.checkOffset('#elem2', '480', '230', 'y', false);
            _expect(getLocationMock).toHaveBeenCalledTimes(1);
            _expect(getLocationMock).toHaveBeenCalledWith('230');
            _expect(global.info).toHaveBeenCalled()
        },
    );
});
