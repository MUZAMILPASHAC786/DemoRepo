import check from '../../../src/support/validations';

let getTextMock;

describe('compareText', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        getTextMock = jest.fn(() => 'test');
        global.$ = jest.fn().mockReturnValue({
            getText: getTextMock,
        });

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the text of the given element is the same', async () => {
        await check.compareText('#elem1', '#elem2', true);
        _expect(getTextMock).toHaveBeenCalledTimes(2);
        expect(getTextMock).toEqual('true')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the text of the given element is not the same', async () => {
        await check.compareText('#elem3', '#elem4', false);
        _expect(getTextMock).toHaveBeenCalledTimes(2);
        expect(getTextMock).toEqual('false')
        _expect(global.assert).toHaveBeenCalled()
    });
});
