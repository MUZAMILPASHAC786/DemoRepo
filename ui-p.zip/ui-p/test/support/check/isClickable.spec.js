import check from '../../../src/support/validations';

let isClickableMock;

describe('isClickable', () => {
    let expectToEqual;
    let expectToNotEqual;

    beforeEach(() => {
        isClickableMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            isClickable: isClickableMock,
        });

        expectToEqual = jest.fn();
        expectToNotEqual = jest.fn();

        global.expect = jest.fn(() => ({
            not: {
                toEqual: expectToNotEqual,
            },
            toEqual: expectToEqual,
        }));
    });

    it('Should test if the element is enabled', async () => {
        let selectorElement = $('#elem1')
        await check.isClickable(selectorElement, '#elem1', true);
        _expect(isClickableMock).toHaveBeenCalledTimes(1);
        expect(isClickableMock).toEqual('true')
        _expect(global.info).toHaveBeenCalled()
    });

    it('Should test if the element is not enabled', async () => {
        await check.isClickable('#elem2', '#elem2', false);
        _expect(isClickableMock).toHaveBeenCalledTimes(1);
        expect(isClickableMock).toEqual('false')
        _expect(global.assert).toHaveBeenCalled()
    });
});
