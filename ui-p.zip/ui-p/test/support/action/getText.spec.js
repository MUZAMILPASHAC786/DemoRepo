import actions from '../../../src/support/actions';

describe('getText', () => {
    let getText
    beforeEach(() => {
        getText = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            getText,
        });
    });

    it('should call getText on the browser', async () => {
        await actions.getText('element', 'input text');
        expect(getText).toHaveBeenCalled();
        expect(getText).toHaveBeenCalledTimes(1);
        expect(getText).toHaveBeenCalledWith();
        expect(global.info).toHaveBeenCalled()
    });


    it('should call getText throws error', async () => {
        getText.mockImplementation(() => { throw new Error('Failed getText') })
        await actions.getText('element', 'input text');
        expect(getText).toHaveBeenCalled();
        expect(getText).toHaveBeenCalledTimes(1);
        expect(getText).toHaveBeenCalledWith();
        expect(getText).toThrow('Failed getText')
        expect(global.error).toHaveBeenCalled()
    });
});
