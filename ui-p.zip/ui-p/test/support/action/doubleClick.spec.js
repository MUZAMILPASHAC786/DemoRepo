import actions from '../../../src/support/actions';

let doubleClickMock;
let waitForDisplayedMock;

describe('doubleClick', () => {
    let expectToHaveLengthOf;
    let expectToHaveLengthOfAtLeast;

    beforeEach(() => {
        global.$$ = jest.fn(() => ['1'])
            .mockImplementationOnce(() => []);

        doubleClickMock = jest.fn();
        waitForDisplayedMock = jest.fn()
        global.$ = jest.fn().mockReturnValue({
            doubleClick: doubleClickMock,
            waitForDisplayed: waitForDisplayedMock,
        });

        expectToHaveLengthOf = jest.fn();
        expectToHaveLengthOfAtLeast = jest.fn();

        global.expect = jest.fn(() => ({
            toBeGreaterThanOrEqual: expectToHaveLengthOfAtLeast,
            toHaveLength: expectToHaveLengthOf,
        }));
    });
    it('should fail if the given element does not exist', async () => {
        doubleClickMock.mockImplementation(() => { throw new Error('Failed doubleClick') })
        await actions.doubleClick('element', 'element0');
        _expect(global.$).toHaveBeenCalledWith('element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(doubleClickMock).toHaveBeenCalled();
        _expect(doubleClickMock).toThrow('Failed doubleClick')
        _expect(global.error).toHaveBeenCalled()
    });

    it('should call doubleClick on the browser', async () => {
        await actions.doubleClick('element', 'element1');
        _expect(global.$).toHaveBeenCalledWith('element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(doubleClickMock).toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });
});
