import actions from '../../../src/support/actions';

describe('fetctDataLayer', () => {
    beforeEach(() => {
        global.browser = {
            waitUntil: jest.fn(() => 'https://www.google.com/'),
            execute:jest.fn()
        };
    });

    it('should call fetchDataLayert', async () => {
        await actions.fetctDataLayer();
        _expect(global.browser.waitUntil).toHaveBeenCalled()
        _expect(global.browser.waitUntil).toHaveBeenCalledTimes(1)
    });
});
