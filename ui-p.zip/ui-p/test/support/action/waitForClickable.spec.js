import actions from '../../../src/support/actions';

let waitForClickableMock;

describe('waitForClickable', () => {
    beforeEach(() => {
        waitForClickableMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            waitForClickable: waitForClickableMock,
        });
    });

    it('should call waitForClickable on the browser object', async () => {
        let selectorElement = $('element')
        await actions.waitForClickable(selectorElement, 'element', 2000);
        expect(waitForClickableMock).toHaveBeenCalled();
        expect(waitForClickableMock).toHaveBeenCalledTimes(1);
        expect(waitForClickableMock).toHaveBeenCalledWith({ "timeout": 2000 });
    });

    it('should call waitForClickable returns false', async () => {
        waitForClickableMock.mockImplementation(() => { throw new Error('Failed waitForClickable') })
        await actions.waitForClickable('element', 'element', 2000);
        expect(waitForClickableMock).toHaveBeenCalled();
        expect(waitForClickableMock).toHaveBeenCalledTimes(1);
        expect(waitForClickableMock).toHaveBeenCalledWith({ "timeout": 2000 });
        expect(waitForClickableMock).toThrow('Failed waitForClickable')
    });
});
