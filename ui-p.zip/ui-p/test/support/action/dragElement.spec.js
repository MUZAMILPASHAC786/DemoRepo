import actions from '../../../src/support/actions';

let dragElementMock;

describe('dragElement', () => {
    beforeEach(() => {
        dragElementMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            dragAndDrop: dragElementMock,
        });
    });

    it('should call dragAndDrop on the browser', async () => {
        await actions.dragElement('source', 'destination');
        expect(dragElementMock).toHaveBeenCalledTimes(1);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call dragAndDrop throws error', async () => {
        dragElementMock.mockImplementation(() => { throw new Error('Failed dragElement') })
        await actions.dragElement('source', 'destination');
        expect(dragElementMock).toHaveBeenCalledTimes(1);
        expect(dragElementMock).toThrow('Failed dragElement')
        expect(global.error).toHaveBeenCalled()
    });
});
