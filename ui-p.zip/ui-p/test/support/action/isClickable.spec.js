import actions from '../../../src/support/actions';

let isClickableMock;

describe('isClickable', () => {
    beforeEach(() => {
        isClickableMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isClickable: isClickableMock,
        });
    });

    it('should call isClickable on the browser object', async () => {
        let selectorElement = $('element')
        await actions.isClickable(selectorElement, 'element');
        expect(isClickableMock).toHaveBeenCalled();
        expect(isClickableMock).toHaveBeenCalledTimes(1);
        expect(isClickableMock).toHaveBeenCalledWith();
    });

    it('should call isClickable returns false', async () => {
        isClickableMock.mockImplementation(() => { throw new Error('Failed to click') })
        await actions.isClickable('element0', 'element');
        expect(isClickableMock).toHaveBeenCalled();
        expect(isClickableMock).toHaveBeenCalledTimes(1);
        expect(isClickableMock).toHaveBeenCalledWith();
        expect(isClickableMock).toThrow('Failed to click')
    });
});
