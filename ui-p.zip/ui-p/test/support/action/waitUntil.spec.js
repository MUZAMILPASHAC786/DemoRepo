import actions from '../../../src/support/actions';

let isDisplayedMock;

describe('waitUntil', () => {
    beforeEach(() => {
        isDisplayedMock = jest.fn(() => true)
        global.$ = jest.fn().mockReturnValue({
            isDisplayed: isDisplayedMock
        });
        global.browser = {
            waitUntil: jest.fn(async () => {
                return isDisplayedMock;
            }, { timeout: '10' })
        }
    });

    it('should call waitUntil on the browser object', async () => {
        await actions.waitUntil('#element', 'element', 2000);
        _expect(global.browser.waitUntil).toHaveBeenCalled()
        _expect(global.browser.waitUntil).toHaveBeenCalledTimes(1)
        _expect(isDisplayedMock).not.toHaveBeenCalled()
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call waitUntil throws error', async () => {
        global.browser.waitUntil.mockImplementation(() => { throw new Error('Failed waitUntil') })
        await actions.waitUntil('#element', 'element', 2000);
        _expect(global.browser.waitUntil).toHaveBeenCalled()
        _expect(global.error).toHaveBeenCalled()
        expect(global.browser.waitUntil).toThrow('Failed waitUntil')
    });
});
