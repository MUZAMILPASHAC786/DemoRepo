import actions from '../../../src/support/actions';

describe('pressButton', () => {
    beforeEach(() => {
        global.browser = {
            keys: jest.fn(),
        };
    });

    it('should call keys on the browser object', async() => {
        await actions.pressButton('e');
        expect(global.browser.keys).toHaveBeenCalledTimes(1);
        expect(global.browser.keys).toHaveBeenCalledWith('e');
    });

    it('should pressButton throw Error', async() => {
        global.browser.keys.mockImplementation(() => { throw new Error('Failed pressButton') })
        await actions.pressButton('e');
        expect(global.browser.keys).toHaveBeenCalledTimes(1);
        expect(global.browser.keys).toHaveBeenCalledWith('e');
        expect(global.browser.keys).toThrow('Failed pressButton')
        _expect(global.error).toHaveBeenCalled()
    });
});
