import actions from '../../../src/support/actions';

let scrollIntoViewMock;

describe('scroll', () => {
    beforeEach(() => {
        scrollIntoViewMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            scrollIntoView: scrollIntoViewMock,
        });
    });

    it('should call scrollIntoView on the browser object', async () => {
        let selectorElement = $('element')
        await actions.scroll(selectorElement);
        expect(scrollIntoViewMock).toHaveBeenCalledTimes(1);
    });

    it('should call scrollIntoView throw Error', async () => {
        scrollIntoViewMock.mockImplementation(() => { throw new Error('Failed scrollIntoView') })
        await actions.scroll('element');
        expect(scrollIntoViewMock).toHaveBeenCalledTimes(1);
        expect(scrollIntoViewMock).toThrow('Failed scrollIntoView')
        _expect(global.error).toHaveBeenCalled()
    });
});
