import actions from '../../../src/support/actions';

describe('zoomInOutByPercentage', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandle: jest.fn().mockResolvedValue('mockWindowHandle'),
            execute: jest.fn().mockImplementation((callback, zoomFactor) => {
                callback(zoomFactor);
            }),
        };
    });

    it('should Zoom out', async () => {
        await actions.zoomInOutByPercentage('85');
        expect(global.browser.getWindowHandle).toHaveBeenCalled();
        expect(global.browser.getWindowHandle).toHaveBeenCalledTimes(1);
        expect(global.browser.execute).toHaveBeenCalled();
        expect(global.browser.execute).toHaveBeenCalledTimes(1);
        expect(global.info).toHaveBeenCalled();
    });

    it('should Zoom in', async () => {
        await actions.zoomInOutByPercentage('150');
        expect(global.browser.getWindowHandle).toHaveBeenCalled();
        expect(global.browser.getWindowHandle).toHaveBeenCalledTimes(1);
        expect(global.browser.execute).toHaveBeenCalled();
        expect(global.browser.execute).toHaveBeenCalledTimes(1);
        expect(global.info).toHaveBeenCalled();
    });

    it('should Reset to default zoom', async () => {
        await actions.zoomInOutByPercentage('100');
        expect(global.browser.getWindowHandle).toHaveBeenCalled();
        expect(global.browser.getWindowHandle).toHaveBeenCalledTimes(1);
        expect(global.browser.execute).toHaveBeenCalled();
        expect(global.browser.execute).toHaveBeenCalledTimes(1);
    });
});
