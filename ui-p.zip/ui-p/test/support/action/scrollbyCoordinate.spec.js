import actions from '../../../src/support/actions';

describe('scrollbyCoordinate', () => {
    beforeEach(() => {
        global.browser = {
            execute: jest.fn(),
        };
        global.window = Object.create(global)
        global.window.scrollTo = jest.fn();
    });

    it('should call scrollIntoView on the browser object', async () => {
        const XAxis = 100;
        const YAxis = 200;
        await actions.scrollbyCoordinate(XAxis, YAxis);
        expect(global.browser.execute).toHaveBeenCalledTimes(1);
        expect(global.browser.execute).toHaveBeenCalledWith(expect.any(Function), XAxis, YAxis);
        // Execute the function passed to browser.execute to ensure it calls window.scrollTo
        const funcArg = global.browser.execute.mock.calls[0][0];
        funcArg(XAxis, YAxis);
        expect(global.window.scrollTo).toHaveBeenCalledWith(XAxis, YAxis);
    });
});
