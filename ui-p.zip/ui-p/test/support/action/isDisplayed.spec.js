import actions from '../../../src/support/actions';

let isDisplayedMock;

describe('isDisplayed', () => {
    beforeEach(() => {
        isDisplayedMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isDisplayed: isDisplayedMock,
        });
    });

    it('should call isDisplayed on the browser object', async () => {
        let selectorElement = $('element')
        await actions.isDisplayed(selectorElement, 'element');
        expect(isDisplayedMock).toHaveBeenCalled();
        expect(isDisplayedMock).toHaveBeenCalledTimes(1);
        expect(isDisplayedMock).toHaveBeenCalledWith();
        expect(isDisplayedMock).toBeTruthy()
    });

    it('should call isDisplayed returns false', async () => {
        isDisplayedMock.mockImplementation(() => { throw new Error('Failed to display') })
        await actions.isDisplayed('element', 'element');
        expect(isDisplayedMock).toHaveBeenCalled();
        expect(isDisplayedMock).toHaveBeenCalledTimes(1);
        expect(isDisplayedMock).toHaveBeenCalledWith();
        expect(isDisplayedMock).toThrow('Failed to display')
    });
});