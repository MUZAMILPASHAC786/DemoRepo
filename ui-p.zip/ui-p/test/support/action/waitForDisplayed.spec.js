import actions from '../../../src/support/actions';

let waitForDisplayedMock;

describe('waitForDisplayed', () => {
    beforeEach(() => {
        waitForDisplayedMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            waitForDisplayed: waitForDisplayedMock,
        });
    });

    it('should call waitForDisplayed on the browser object', async () => {
        let selectorElement = $('element')
        await actions.waitForDisplayed(selectorElement, 'element', 3000);
        expect(waitForDisplayedMock).toHaveBeenCalled();
        expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        expect(waitForDisplayedMock).toHaveBeenCalledWith({ "timeout": 3000 });
        expect(global.info).toHaveBeenCalled()
    });

    it('should call waitForDisplayed returns false', async () => {
        waitForDisplayedMock.mockImplementation(() => { throw new Error('Failed waitForDisplayed') })
        await actions.waitForDisplayed('element', 'element');
        expect(waitForDisplayedMock).toHaveBeenCalled();
        expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        expect(waitForDisplayedMock).toHaveBeenCalledWith();
        expect(waitForDisplayedMock).toThrow('Failed waitForDisplayed')
    });
});
