import actions from '../../../src/support/actions';

let moveToMock;

describe('moveTo', () => {
    beforeEach(() => {
        moveToMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            moveTo: moveToMock,
        });
    });

    it(
        'should call moveToObject with only the element when no x and y '
        + 'are provided',
        async () => {
            await actions.moveTo('element', undefined, undefined);
            expect(moveToMock).toHaveBeenCalledTimes(1);
            expect(moveToMock).toHaveBeenCalledWith(undefined, undefined);
            expect(global.info).toHaveBeenCalled()
        },
    );

    it('should call moveToObject with x when provided as int', async () => {
        await actions.moveTo('element', 1, undefined);
        expect(moveToMock).toHaveBeenCalledTimes(1);
        expect(moveToMock).toHaveBeenCalledWith(1, undefined);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call moveToObject with y when provided as int', async () => {
        await actions.moveTo('element', undefined, 1);
        expect(moveToMock).toHaveBeenCalledTimes(1);
        expect(moveToMock).toHaveBeenCalledWith(undefined, 1);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call moveToObject with x and y when provided as int', async () => {
        let selectorElement = $('element')
        await actions.moveTo(selectorElement, 1, 2);
        expect(moveToMock).toHaveBeenCalledTimes(1);
        expect(moveToMock).toHaveBeenCalledWith(1, 2);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call moveToObject throws error', async () => {
        moveToMock.mockImplementation(() => { throw new Error('Failed moveToMock') })
        await actions.moveTo('element', 1, 2);
        expect(moveToMock).toHaveBeenCalledTimes(1);
        expect(moveToMock).toHaveBeenCalledWith(1, 2);
        expect(moveToMock).toThrow('Failed moveToMock')
        expect(global.error).toHaveBeenCalled()
    });
});
