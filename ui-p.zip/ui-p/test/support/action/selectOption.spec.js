import actions from '../../../src/support/actions';

describe('selectOption', () => {
    let selectByAttribute;
    let selectByValue;
    let selectByVisibleText;

    beforeEach(() => {
        selectByAttribute = jest.fn();
        selectByValue = jest.fn();
        selectByVisibleText = jest.fn();

        global.$ = jest.fn().mockReturnValue({
            selectByAttribute,
            selectByValue,
            selectByVisibleText,
        });
    });
    it('should call selectByAttribute on the browser object', async () => {
        let selectorElement = $('name1')
        await actions.selectOption(selectorElement, 'name', 'element1');
        expect(selectByAttribute).toHaveBeenCalledTimes(1);
        expect(selectByAttribute).toHaveBeenCalledWith('name', 'element1');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call selectByValue on the browser object', async () => {
        await actions.selectOption('value1', 'value', 'element2');
        expect(selectByAttribute).toHaveBeenCalledTimes(1);
        expect(selectByAttribute).toHaveBeenCalledWith('value', 'element2');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call selectByText on the browser object', async () => {
        await actions.selectOption('text1', 'text', 'element3');
        expect(selectByVisibleText).toHaveBeenCalledTimes(1);
        expect(selectByVisibleText).toHaveBeenCalledWith('element3');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should throw an error when an unknown selection type is passed', async () => {
        const errorSpy = jest.spyOn(global, 'Error');
        errorSpy.mockImplementation(() => {
            throw new Error('Mocked error');
        });
        try {
            await actions.selectOption('text', null, 'element3');
        } catch (error) {
            expect(errorSpy).toBeCalled()
            expect(errorSpy).toHaveBeenCalledWith('Mocked error');
        }
        errorSpy.mockRestore()
    });

    it('should call selectByText throw error', async () => {
        selectByVisibleText.mockImplementation(() => { throw new Error('Failed selectByVisibleText') })
        await actions.selectOption('text1', 'text', 'element3');
        expect(selectByVisibleText).toHaveBeenCalledTimes(1);
        expect(selectByVisibleText).toHaveBeenCalledWith('element3');
        _expect(global.info).toHaveBeenCalled()
        expect(selectByVisibleText).toThrow('Failed selectByVisibleText')
    });
});
