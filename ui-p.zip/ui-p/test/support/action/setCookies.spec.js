import actions from '../../../src/support/actions';

describe('setCookie', () => {
    beforeEach(() => {
        global.browser = {
            setCookies: jest.fn(),
        };
    });

    it('should call setCookie on the browser object', async() => {
        await actions.setCookie('cookieName', 'cookieContent');

        expect(global.browser.setCookies).toHaveBeenCalledTimes(1);
        expect(global.browser.setCookies)
            .toHaveBeenCalledWith({
                name: 'cookieName',
                value: 'cookieContent',
            });
    });

    it('should throw error setCookie on the browser object', async() => {
        global.browser.setCookies.mockImplementation(() => { throw new Error('Failed setCookie') })
        await actions.setCookie();
        expect(global.browser.setCookies).toHaveBeenCalledTimes(1);
        expect(global.browser.setCookies)
            .toHaveBeenCalledWith({
                name: undefined,
                value: undefined,
            });
        expect(global.browser.setCookies).toThrow('Failed setCookie')
        _expect(global.error).toHaveBeenCalled()
    });
});
