import actions from '../../../src/support/actions';

describe('deleteAllCookies', () => {
    beforeEach(() => {
        global.browser = {
            deleteAllCookies: jest.fn(),
        };
    });
    it('should call deleteAllCookies on the browser', async() => {
        await actions.deleteAllCookies('test');
        expect(global.browser.deleteAllCookies).toHaveBeenCalled();
        expect(global.browser.deleteAllCookies).toHaveBeenCalledTimes(1);
        expect(global.browser.deleteAllCookies).toHaveBeenCalledWith();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call deleteAllCookies throws error', async() => {
        global.browser.deleteAllCookies.mockImplementation(() => { throw new Error('Failed deleteAllCookies') })
        await actions.deleteAllCookies('test');
        expect(global.browser.deleteAllCookies).toHaveBeenCalled();
        expect(global.browser.deleteAllCookies).toHaveBeenCalledTimes(1);
        expect(global.browser.deleteAllCookies).toHaveBeenCalledWith();
        expect(global.browser.deleteAllCookies).toThrow('Failed deleteAllCookies')
        expect(global.error).toHaveBeenCalled()
    });
});
