import actions from '../../../src/support/actions';

describe('getWindowHandles', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandles: jest.fn(),
        };
    });

    it('should get window handles', async() => {
        await actions.getWindowHandles();
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.getWindowHandles).toHaveBeenCalledWith();
        expect(global.info).toHaveBeenCalled()
    });

    it('should get window handles throws error', async() => {
        global.browser.getWindowHandles.mockImplementation(() => { throw new Error('Failed getWindowHandles') })
        await actions.getWindowHandles();
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.getWindowHandles).toHaveBeenCalledWith();
        expect(global.browser.getWindowHandles).toThrow('Failed getWindowHandles')
        expect(global.error).toHaveBeenCalled()
    });
});
