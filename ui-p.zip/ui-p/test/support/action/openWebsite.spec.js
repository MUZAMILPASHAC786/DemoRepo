import actions from '../../../src/support/actions';

describe('openWebsite', () => {
    beforeEach(() => {
        global.browser = {
            url: jest.fn(),
            options: {
                baseUrl: 'https://www.google.com/test',
            },
            maximizeWindow: jest.fn(),
            getUrl: jest.fn(() => 'https://www.google.com/test'),
        };
    });

    it('should call url with the given url on the browser object', async () => {
        await actions.openWebsite('https://www.google.com/test');
        expect(global.browser.url).toHaveBeenCalled();
        expect(global.browser.url).toHaveBeenCalledTimes(1);
        expect(global.browser.url).toHaveBeenCalledWith('https://www.google.com/test');
        expect(global.browser.maximizeWindow).toHaveBeenCalled();
        expect(global.browser.maximizeWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.maximizeWindow).toHaveBeenCalledWith();
        expect(global.browser.getUrl).toHaveBeenCalled();
        expect(global.browser.getUrl).toHaveBeenCalledTimes(1);
        expect(global.browser.getUrl).toHaveBeenCalledWith();
        expect(global.info).toHaveBeenCalled()
    });

    it(
        'should call url with the given path on the baseUrl if the first '
        + 'param is `site`',
        async () => {
            await actions.openWebsite('/test');
            expect(global.browser.url).toHaveBeenCalledTimes(1);
            expect(global.browser.url).toHaveBeenCalledWith('/test');
            expect(global.info).toHaveBeenCalled()
        },
    );

    it('should call url with path', async () => {
        await actions.openWebsite('/path');
        expect(global.browser.url).toHaveBeenCalledTimes(1);
        expect(global.browser.url).toHaveBeenCalledWith('/path');
        expect(global.warn).toHaveBeenCalled()
    },
    );

    it('should call url throws error', async () => {
        global.browser.url.mockImplementation(() => { throw new Error('Failed url') })
        await actions.openWebsite('https://www.google.com/');
        expect(global.browser.url).toHaveBeenCalledTimes(1);
        expect(global.browser.url).toHaveBeenCalledWith('https://www.google.com/');
        expect(global.browser.url).toThrow('Failed url')
        expect(global.error).toHaveBeenCalled()
    });
});
