import actions from '../../../src/support/actions';

describe('setWindowSize', () => {
    beforeEach(() => {
        global.browser = {
            setWindowSize: jest.fn(() => ({
                width: 100,
                height: 200,
            })),
            getWindowSize: jest.fn(() => ({
                width: 100,
                height: 200,
            })),
        };
    });

    it('should call setWindowSize on the browser object', async () => {
        await actions.setWindowSize('1024', '768');
        expect(global.browser.setWindowSize).toHaveBeenCalledTimes(1);
        expect(global.browser.getWindowSize).toHaveBeenCalled();
        expect(global.browser.getWindowSize).toHaveBeenCalledTimes(1);
        expect(global.browser.setWindowSize).toHaveBeenCalledWith(1024, 768);
    });

    it('should call setWindowSize throws error', async () => {
        global.browser.setWindowSize.mockImplementation(() => { throw new Error('Unable to set window size') })
        await actions.setWindowSize();
        expect(global.browser.setWindowSize).toHaveBeenCalled();
        expect(global.browser.setWindowSize).toHaveBeenCalledTimes(1);
        expect(global.browser.setWindowSize).toThrow('Unable to set window size')
    });
});
