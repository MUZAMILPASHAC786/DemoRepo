import actions from '../../../src/support/actions';

let selectByIndexMock;

describe('selectOptionByIndex', () => {
    beforeEach(() => {
        selectByIndexMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            selectByIndex: selectByIndexMock,
        });
    });

    it('should call selectByIndex on the browser object', async () => {
        let selectorElement = $('element')
        await actions.selectOptionByIndex(selectorElement, 1, 'elementindex');
        expect(selectByIndexMock).toHaveBeenCalledTimes(1);
        expect(selectByIndexMock).toHaveBeenCalledWith(1);
    });

    it('should call selectByIndex throw error', async () => {
        selectByIndexMock.mockImplementation(() => { throw new Error('Failed selectByIndex') })
        await actions.selectOptionByIndex('element', 1, 'elementindex');
        expect(selectByIndexMock).toHaveBeenCalledTimes(1);
        expect(selectByIndexMock).toHaveBeenCalledWith(1);
        expect(selectByIndexMock).toThrow('Failed selectByIndex')
        _expect(global.error).toHaveBeenCalled()
    });
});
