import actions from '../../../src/support/actions';

describe('getTitle', () => {
    beforeEach(() => {
        global.browser = {
            getTitle: jest.fn(),
        };
    });

    it('should get title', async () => {
        await actions.getTitle();
        expect(global.browser.getTitle).toHaveBeenCalled();
        expect(global.browser.getTitle).toHaveBeenCalledTimes(1);
        expect(global.browser.getTitle).toHaveBeenCalledWith();
    });

    it('should throw error while fetching title', async () => {
        global.browser.getTitle.mockImplementation(() => { throw new Error('Failed to get title') })
        await actions.getTitle();
        expect(global.browser.getTitle).toHaveBeenCalled();
        expect(global.browser.getTitle).toHaveBeenCalledTimes(1);
        expect(global.browser.getTitle).toHaveBeenCalledWith();
        expect(global.browser.getTitle).toThrow('Failed to get title')
    });
});
