import actions from '../../../src/support/actions';

describe('focusLastOpenedWindow', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandles: jest.fn(() => [
                'one',
                'two',
                'three',
            ]),
            switchToWindow: jest.fn(),
        };
    });

    it('should call focusLastOpenedWindow on the browser', async () => {
        await actions.focusLastOpenedWindow('');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledWith('three');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call focusLastOpenedWindow throws error', async () => {
        global.browser.switchToWindow.mockImplementation(() => { throw new Error('Failed focusLastOpenedWindow') })
        await actions.focusLastOpenedWindow('');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledWith('three');
        expect(global.browser.switchToWindow).toThrow('Failed focusLastOpenedWindow')
        expect(global.error).toHaveBeenCalled()
    });
});
