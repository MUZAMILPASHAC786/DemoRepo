import actions from '../../../src/support/actions';

let waitForEnabledMock;

describe('waitForEnabled', () => {
    beforeEach(() => {
        waitForEnabledMock = jest.fn(() => true);
        global.$ = jest.fn().mockReturnValue({
            waitForEnabled: waitForEnabledMock,
        });
    });

    it('should call waitForEnabled on the browser object', async () => {
        let selectorElement = $('element')
        await actions.waitForEnabled(selectorElement, 'element', 2000);
        expect(waitForEnabledMock).toHaveBeenCalled();
        expect(waitForEnabledMock).toHaveBeenCalledTimes(1);
        expect(waitForEnabledMock).toHaveBeenCalledWith({ "timeout": 2000 });
    });

    it('should call waitForEnabled returns false', async () => {
        waitForEnabledMock.mockImplementation(() => { throw new Error('Failed waitForEnabled') })
        await actions.waitForEnabled('', '', 2000);
        expect(waitForEnabledMock).toHaveBeenCalledTimes(1);
        expect(waitForEnabledMock).toHaveBeenCalledWith({"timeout": 2000});
        expect(waitForEnabledMock).toThrow('Failed waitForEnabled')
    });
});
