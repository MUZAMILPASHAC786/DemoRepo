import actions from '../../../src/support/actions';

describe('switchToParentFrame', () => {
    let switchToParentFrame
    beforeEach(() => {
        switchToParentFrame = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            switchToParentFrame,
        });
    });
    it('should call switchToParentFrame on the browser', async () => {
        await actions.switchToParentFrame('first frame');
        _expect(global.assert).toHaveBeenCalled()
    });
});
