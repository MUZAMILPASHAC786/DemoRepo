import actions from '../../../src/support/actions';

describe('handleModal', () => {
    beforeEach(() => {
        global.browser = {
            acceptAlert: jest.fn(),
            dismissAlert: jest.fn(),
            getAlertText: jest.fn(),
        };
    });

    it('should call acceptAlert on the browser to close a alertbox', async () => {
        await actions.handleModal('accept', 'alertbox');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call acceptAlert on the browser to close a confirmbox', async() => {
        await actions.handleModal('accept', 'confirmbox');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call acceptAlert on the browser to close a prompt', async() => {
        await actions.handleModal('accept', 'prompt');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call acceptAlert on the browser to dismiss a alertbox', async() => {
        await actions.handleModal('dismiss', 'alertbox');
        expect(global.browser.acceptAlert).not.toHaveBeenCalled();
        expect(global.browser.dismissAlert).toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it(
        'should call dismissAlert on the browser to dismiss a confirmbox',
        async() => {
            await actions.handleModal('dismiss', 'confirmbox');
            expect(global.browser.dismissAlert).toHaveBeenCalledTimes(1);
            expect(global.browser.acceptAlert).not.toHaveBeenCalled();
            expect(global.browser.getAlertText).not.toHaveBeenCalled();
            expect(global.info).toHaveBeenCalled()
        },
    );

    it('should call dismissAlert on the browser to dismiss a prompt', async() => {
        await actions.handleModal('dismiss', 'prompt');
        expect(global.browser.dismissAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.acceptAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call acceptAlert on the browser throws error', async () => {
        global.browser.acceptAlert.mockImplementation(() => { throw new Error('Failed acceptAlert') })
        await actions.handleModal('accept', 'alertbox');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.browser.acceptAlert).toThrow('Failed acceptAlert')
        expect(global.error).toHaveBeenCalled()
    });
});
