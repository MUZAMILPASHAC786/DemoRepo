import actions from '../../../src/support/actions';

describe('switchWindow', () => {
    beforeEach(() => {
        global.browser = {
            switchWindow: jest.fn(() => 'https://www.google.com/'),
        };
    });

    it('should call switchWindow on the browser', async() => {
        await actions.switchWindow('https://www.google.com/');
        expect(global.browser.switchWindow).toHaveBeenCalled();
        expect(global.browser.switchWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.switchWindow).toHaveBeenCalledWith('https://www.google.com/');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call switchWindow throws error', async() => {
        global.browser.switchWindow.mockImplementation(() => { throw new Error('Failed switchWindow') })
        await actions.switchWindow('https://www.google.com/');
        expect(global.browser.switchWindow).toHaveBeenCalled();
        expect(global.browser.switchWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.switchWindow).toHaveBeenCalledWith('https://www.google.com/');
        expect(global.browser.switchWindow).toThrow('Failed switchWindow')
        expect(global.error).toHaveBeenCalled()
    });
});
