import actions from '../../../src/support/actions';

describe('maximizeWindow', () => {
    beforeEach(() => {
        global.browser = {
            maximizeWindow: jest.fn(),
        };
    });

    it('should call maximizeWindow on the browser', async() => {
        await actions.maximizeWindow();
        expect(global.browser.maximizeWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.maximizeWindow).toHaveBeenCalledWith();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call maximizeWindow throws error', async() => {
        global.browser.maximizeWindow.mockImplementation(() => { throw new Error('Failed maximizeWindow') })
        await actions.maximizeWindow();
        expect(global.browser.maximizeWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.maximizeWindow).toHaveBeenCalledWith();
        expect(global.browser.maximizeWindow).toThrow('Failed maximizeWindow')
        expect(global.error).toHaveBeenCalled()
    });
});
