import actions from '../../../src/support/actions';

let isSelectedMock;

describe('isSelected', () => {
    beforeEach(() => {
        isSelectedMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isSelected: isSelectedMock,
        });
    });

    it('should call isSelected on the browser object', async () => {
        let selectorElement = $('element')
        await actions.isSelected(selectorElement, 'element');
        expect(isSelectedMock).toHaveBeenCalled();
        expect(isSelectedMock).toHaveBeenCalledTimes(1);
        expect(isSelectedMock).toHaveBeenCalledWith();
    });

    it('should call isSelected throw error', async () => {
        isSelectedMock.mockImplementation(() => { throw new Error('Failed isSelected') })
        await actions.isSelected('element', 'element');
        expect(isSelectedMock).toHaveBeenCalled();
        expect(isSelectedMock).toHaveBeenCalledTimes(1);
        expect(isSelectedMock).toHaveBeenCalledWith();
        expect(isSelectedMock).toThrow('Failed isSelected')
    });
});
