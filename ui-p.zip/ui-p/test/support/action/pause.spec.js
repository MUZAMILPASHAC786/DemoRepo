import actions from '../../../src/support/actions';

describe('pause', () => {
    beforeEach(() => {
        global.browser = {
            pause: jest.fn(),
        };
    });

    it('should call pause on the browser object', async() => {
        await actions.pause(1000);

        expect(global.browser.pause).toHaveBeenCalledTimes(1);
        expect(global.browser.pause).toHaveBeenCalledWith(1000);
    });

    it('should throw error on pause', async() => {
        global.browser.pause.mockImplementation(() => { throw new Error('Failed to pause') })
        await actions.pause(1000);
        expect(global.browser.pause).toHaveBeenCalledTimes(1);
        expect(global.browser.pause).toHaveBeenCalledWith(1000);
        expect(global.browser.pause).toThrow('Failed to pause')
    });
});
