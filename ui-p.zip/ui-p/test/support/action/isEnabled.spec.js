import actions from '../../../src/support/actions';

let isEnabledMock;

describe('isEnabled', () => {
    beforeEach(() => {
        isEnabledMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isEnabled: isEnabledMock,
        });
    });

    it('should call isEnabled on the browser object', async () => {
        let selectorElement = $('element')
        await actions.isEnabled(selectorElement, 'element');
        expect(isEnabledMock).toHaveBeenCalled();
        expect(isEnabledMock).toHaveBeenCalledTimes(1);
        expect(isEnabledMock).toHaveBeenCalledWith();
    });

    it('should throw error isEnabled on the browser object', async () => {
        isEnabledMock.mockImplementation(() => { throw new Error('Failed to enable') })
        await actions.isEnabled('element', 'element');
        expect(isEnabledMock).toHaveBeenCalled();
        expect(isEnabledMock).toHaveBeenCalledTimes(1);
        expect(isEnabledMock).toHaveBeenCalledWith();
        expect(isEnabledMock).toThrow('Failed to enable')
    });
});
