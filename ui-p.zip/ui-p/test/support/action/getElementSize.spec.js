import actions from '../../../src/support/actions';

describe('getElementSize', () => {

    beforeEach(() => {
        global.$$ = jest.fn();
    });

    it('should get ElementSize on the browser object', async () => {
        await actions.getElementSize('element');
        expect(global.$$).toHaveBeenCalled();
        expect(global.$$).toHaveBeenCalledTimes(1);
        expect(global.$$).toHaveBeenCalledWith('element');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should get ElementSize returns false', async () => {
        await actions.getElementSize();
        expect(global.$$).toHaveBeenCalled();
        expect(global.$$).toHaveBeenCalledTimes(1);
        _expect(global.error).toHaveBeenCalled()
    });
});
