import actions from '../../../src/support/actions';

describe('setValue', () => {
    let setValue
    beforeEach(() => {
        setValue = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            setValue,
        });
    });

    it('should call setValue on the browser', async () => {
        let selectorElement = $('element')
        await actions.setValue('hai', selectorElement, 'input text');
        expect(setValue).toHaveBeenCalled();
        expect(setValue).toHaveBeenCalledTimes(1);
        expect(setValue).toHaveBeenCalledWith('hai');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call setValue throws error', async () => {
        setValue.mockImplementation(() => { throw new Error('Failed setValue') })
        await actions.setValue('hai', 'element', 'input text');
        expect(setValue).toHaveBeenCalled();
        expect(setValue).toHaveBeenCalledTimes(1);
        expect(setValue).toHaveBeenCalledWith('hai');
        expect(setValue).toThrow('Failed setValue')
        _expect(global.error).toHaveBeenCalled()
    });
});
