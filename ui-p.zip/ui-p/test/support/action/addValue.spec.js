import actions from '../../../src/support/actions';

describe('addValue', () => {
    let addValue
    beforeEach(() => {
        addValue = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            addValue,
        });
    });

    it('should call addValue on the browser', async () => {
        await actions.addValue('hai', 'element', 'input text');
        expect(addValue).toHaveBeenCalled();
        expect(addValue).toHaveBeenCalledTimes(1);
        expect(addValue).toHaveBeenCalledWith('hai');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call addValue throws error', async () => {
        addValue.mockImplementation(() => { throw new Error('Failed addValue') })
        await actions.addValue('hai', 'element', 'input text');
        expect(addValue).toHaveBeenCalled();
        expect(addValue).toHaveBeenCalledTimes(1);
        expect(addValue).toHaveBeenCalledWith('hai');
        expect(addValue).toThrow('Failed addValue')
        expect(global.error).toHaveBeenCalled()
    });
});
