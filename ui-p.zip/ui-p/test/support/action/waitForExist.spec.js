import actions from '../../../src/support/actions';

let waitForExist;

describe('waitFor', () => {
    beforeEach(() => {
        waitForExist = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            waitForExist,
        });
    });

    it('should call waitForExist on the element object (trueCase)', async () => {
        let selectorElement = $('element')
        await actions.waitForExist(selectorElement, 'element1', 2000);
        expect(waitForExist).toHaveBeenCalled();
        expect(waitForExist).toHaveBeenCalledTimes(1);
        expect(waitForExist).toHaveBeenCalledWith({ "timeout": 2000 });
    });

    it('should call waitForExist on the element object (falsecase)', async () => {
        waitForExist.mockImplementation(() => { throw new Error('Failed waitForExist') })
        await actions.waitForExist();
        expect(waitForExist).toHaveBeenCalled();
        expect(waitForExist).toHaveBeenCalledTimes(1);
        expect(waitForExist).toHaveBeenCalledWith({ "timeout": 120000 });
        _expect(global.info).toHaveBeenCalled()
        expect(waitForExist).toThrow('Failed waitForExist')
    });
});
