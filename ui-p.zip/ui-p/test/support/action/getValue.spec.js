import actions from '../../../src/support/actions';

describe('getValue', () => {
    let getValue
    beforeEach(() => {
        getValue = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            getValue,
        });
    });

    it('should call getValue on the browser', async() => {
        await actions.getValue('element','input text');
        expect(getValue).toHaveBeenCalled();
        expect(getValue).toHaveBeenCalledTimes(1);
        expect(getValue).toHaveBeenCalledWith();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getValue throws error', async() => {
        getValue.mockImplementation(() => { throw new Error('Failed getValue') })
        await actions.getValue('element','input text');
        expect(getValue).toHaveBeenCalled();
        expect(getValue).toHaveBeenCalledTimes(1);
        expect(getValue).toHaveBeenCalledWith();
        expect(getValue).toThrow('Failed getValue')
        expect(global.error).toHaveBeenCalled()
    });
});
