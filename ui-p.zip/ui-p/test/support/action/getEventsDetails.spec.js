import actions from '../../../src/support/actions';

describe('getEventsDetails', () => {
    let dataLayer;

    beforeEach(() => {

        dataLayer = [
            { event: 'event1', data: 'data1' },
            { event: 'event2', data: 'data2' },
            { event: 'event1', data: 'data3' }
        ];
    });

    it('should call getEventsDetails: object', async () => {
        const eventInfo = { event: 'event1' };
        const result = await actions.getEventsDetails(dataLayer, eventInfo);
        expect(result).toEqual([dataLayer[0], dataLayer[2]]);
    });

    it('should call getEventsDetails: string', async () => {
        const eventInfo = 'event1';
        const result = await actions.getEventsDetails(dataLayer, eventInfo);
        expect(result).toEqual([dataLayer[0], dataLayer[2]]);
    });

    it('should return an empty array if no events match the string', async () => {
        const eventInfo = 'event3';
        const result = await actions.getEventsDetails(dataLayer, eventInfo);
        expect(result).toEqual([]);
    });
});
