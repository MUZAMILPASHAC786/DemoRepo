import actions from '../../../src/support/actions';

describe('newWindow', () => {
    beforeEach(() => {
        global.browser = {
            newWindow: jest.fn(() => 'https://www.google.com/'),
            getWindowHandles: jest.fn(() => [
                'one',
                'two',
                'three',
            ]),
            switchToWindow: jest.fn(),
        };
    });

    it('should call newWindow on the browser', async() => {
        await actions.newWindow('https://www.google.com/');
        expect(global.browser.newWindow).toHaveBeenCalled();
        expect(global.browser.newWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.newWindow).toHaveBeenCalledWith('https://www.google.com/');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledWith('three');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call newWindow throws error', async() => {
        global.browser.newWindow.mockImplementation(() => { throw new Error('Failed newWindow') })
        await actions.newWindow('https://www.google.com/');
        expect(global.browser.newWindow).toHaveBeenCalled();
        expect(global.browser.newWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.newWindow).toHaveBeenCalledWith('https://www.google.com/');
        expect( global.browser.newWindow).toThrow('Failed newWindow')
        expect(global.error).toHaveBeenCalled()
    });
});
