import actions from '../../../src/support/actions';

let isDisplayedInViewportMock;

describe('isDisplayedViewport', () => {
    beforeEach(() => {
        isDisplayedInViewportMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isDisplayedInViewport: isDisplayedInViewportMock,
        });
    });

    it('should call isDisplayedViewport on the browser object', async () => {
        let selectorElement = $('element')
        await actions.isDisplayedViewport(selectorElement, 'element');
        expect(isDisplayedInViewportMock).toHaveBeenCalled();
        expect(isDisplayedInViewportMock).toHaveBeenCalledTimes(1);
        expect(isDisplayedInViewportMock).toHaveBeenCalledWith();
    });

    it('should isDisplayedInViewportMock returns false', async () => {
        isDisplayedInViewportMock.mockImplementation(() => { throw new Error('Failed to displayed in Viewport') })
        await actions.isDisplayedViewport('element', 'element');
        expect(isDisplayedInViewportMock).toHaveBeenCalled();
        expect(isDisplayedInViewportMock).toHaveBeenCalledTimes(1);
        expect(isDisplayedInViewportMock).toHaveBeenCalledWith();
        expect(isDisplayedInViewportMock).toThrow('Failed to displayed in Viewport')
    });
});
