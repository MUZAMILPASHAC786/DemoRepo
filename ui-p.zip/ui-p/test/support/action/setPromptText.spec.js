import actions from '../../../src/support/actions';

describe('setPromptText', () => {
    beforeEach(() => {
        global.browser = {
            sendAlertText: jest.fn(),
        };
    });

    it('should call getAlertText on the browser object', async () => {
        await actions.setPromptText("modalText","modalName");

        expect(global.browser.sendAlertText).toHaveBeenCalledTimes(1);
        expect(global.browser.sendAlertText).toHaveBeenCalledWith('modalText');
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call fail when no prompt is open', async() => {
        const error = new Error();
        global.browser.sendAlertText = jest.fn(() => {
            throw error;
        });
        await actions.setPromptText("modalText2","modalName2");

        expect(global.browser.sendAlertText).toHaveBeenCalledTimes(1);
        expect(global.browser.sendAlertText).toHaveBeenCalledWith('modalText2');
        expect(global.browser.sendAlertText).toThrow();
        _expect(global.assert).toHaveBeenCalled()
    });
});
