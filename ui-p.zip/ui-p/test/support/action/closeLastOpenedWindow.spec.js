import actions from '../../../src/support/actions';

describe('closeLastOpenedWindow', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandles: jest.fn(() => [
                'one',
                'two',
                'three',
            ]),
            switchToWindow: jest.fn(),
            closeWindow: jest.fn(),
        };
    });

    it('should call closeLastOpenedWindow on the browser', async () => {
        await actions.closeLastOpenedWindow('');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).toHaveBeenCalledWith('three');
        expect(global.browser.closeWindow).toHaveBeenCalledTimes(1);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call closeLastOpenedWindow throws error', async () => {
        global.browser.getWindowHandles.mockImplementation(() => { throw new Error('Failed closeLastOpenedWindow') })
        await actions.closeLastOpenedWindow('');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).not.toHaveBeenCalled();
        expect(global.browser.closeWindow).not.toHaveBeenCalled();
        expect(global.browser.getWindowHandles).toThrow('Failed closeLastOpenedWindow')
        expect(global.error).toHaveBeenCalled()
    });
});
