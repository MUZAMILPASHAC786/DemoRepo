import actions from '../../../src/support/actions';

let isExistingMock;

describe('isExisting', () => {
    beforeEach(() => {
        isExistingMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isExisting: isExistingMock,
        });
    });

    it('should call isExisting on the browser object', async () => {
        let selectorElement = $('element')
        await actions.isExisting(selectorElement, 'element');
        expect(isExistingMock).toHaveBeenCalled();
        expect(isExistingMock).toHaveBeenCalledTimes(1);
        expect(isExistingMock).toHaveBeenCalledWith();
    });

    it('should call isExisting throw error', async () => {
        isExistingMock.mockImplementation(() => { throw new Error('Failed isExisting') })
        await actions.isExisting('element', 'element');
        expect(isExistingMock).toHaveBeenCalled();
        expect(isExistingMock).toHaveBeenCalledTimes(1);
        expect(isExistingMock).toHaveBeenCalledWith();
        expect(isExistingMock).toThrow('Failed isExisting')
    });
});
