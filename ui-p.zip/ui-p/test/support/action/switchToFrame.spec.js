import actions from '../../../src/support/actions';

describe('switchToFrame', () => {
    let switchToFrame
    beforeEach(() => {
        switchToFrame = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            switchToFrame,
        });
    });

    it('should call switchToFrame on the browser', async () => {
        let selectorElement = $('element')
        await actions.switchToFrame(selectorElement, 'first frame');
        _expect(global.assert).toHaveBeenCalled()
    });
});
