import actions from '../../../src/support/actions';

describe('closeAllButFirstTab', () => {
    beforeEach(() => {
        global.browser = {
            getWindowHandles: jest.fn(() => [
                'one',
                'two',
                'three',
            ]),
            switchToWindow: jest.fn(() => ({
                close() {
                },
            })),
            closeWindow: jest.fn(),
        };
    });

    it('should call closeAllButFirstTab on the browser', async () => {
        await actions.closeAllButFirstTab('');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(2);
        expect(global.browser.switchToWindow).toHaveBeenCalledTimes(3);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call closeAllButFirstTab throws error', async () => {
        global.browser.getWindowHandles.mockImplementation(() => { throw new Error('Failed closeAllButFirstTab') })
        await actions.closeAllButFirstTab('');
        expect(global.browser.getWindowHandles).toHaveBeenCalledTimes(1);
        expect(global.browser.switchToWindow).not.toHaveBeenCalled();
        expect(global.browser.getWindowHandles).toThrow('Failed closeAllButFirstTab')
        expect(global.error).toHaveBeenCalled()
    });
});
