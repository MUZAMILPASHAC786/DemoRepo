import actions from '../../../src/support/actions';

describe('deleteCookies', () => {
    beforeEach(() => {
        global.browser = {
            deleteCookies: jest.fn(),
        };
    });

    it('should call deleteCookies on the browser', async() => {
        await actions.deleteCookies('test');
        expect(global.browser.deleteCookies).toHaveBeenCalledTimes(1);
        expect(global.browser.deleteCookies).toHaveBeenCalledWith(["test"]);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call deleteCookies throws error', async() => {
        global.browser.deleteCookies.mockImplementation(() => { throw new Error('Failed deleteCookies') })
        await actions.deleteCookies('test');
        expect(global.browser.deleteCookies).toHaveBeenCalledTimes(1);
        expect(global.browser.deleteCookies).toHaveBeenCalledWith(["test"]);
        expect(global.browser.deleteCookies).toThrow('Failed deleteCookies')
        expect(global.error).toHaveBeenCalled()
    });
});
