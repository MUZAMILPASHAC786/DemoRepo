import actions from '../../../src/support/actions';

describe('setInputField', () => {
    let expectToHaveLengthOf;
    let expectToHaveLengthOfAtLeast;
    let addValueMock;
    let setValueMock;
    let waitForDisplayedMock

    beforeEach(() => {
        addValueMock = jest.fn();
        setValueMock = jest.fn();
        waitForDisplayedMock = jest.fn()
        global.$ = jest.fn().mockReturnValue({
            addValue: addValueMock,
            setValue: setValueMock,
            waitForDisplayed: waitForDisplayedMock
        });

        global.$$ = jest.fn(() => (['1']))
            .mockImplementationOnce(() => [])
            .mockImplementationOnce(() => ['1', '2']);

        expectToHaveLengthOf = jest.fn();
        expectToHaveLengthOfAtLeast = jest.fn();

        global.expect = jest.fn(() => ({
            toBeGreaterThanOrEqual: expectToHaveLengthOfAtLeast,
            toHaveLength: expectToHaveLengthOf,
        }));
    });
    it('should fail if the element is not on the page', async () => {
        waitForDisplayedMock.mockImplementation(() => { throw new Error('Failed addValue') })
        await actions.setInputField('add', 'value', 'element', 'element1');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        _expect(addValueMock).not.toHaveBeenCalled();
        _expect(setValueMock).not.toHaveBeenCalled();
        _expect(waitForDisplayedMock).toThrow('Failed addValue')
        _expect(global.error).toHaveBeenCalled()
    });

    it('should fail if there is more than 1 element on the page', async () => {
        let selectorElement = $('element')
        await actions.setInputField('add', 'value', selectorElement);
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        _expect(addValueMock).toHaveBeenCalledTimes(1);
        _expect(addValueMock).toHaveBeenCalledWith('value');

        _expect(setValueMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });

    it('should be able to add a value to an element', async () => {
        await actions.setInputField('add', 'value', 'element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        _expect(addValueMock).toHaveBeenCalledTimes(1);
        _expect(addValueMock).toHaveBeenCalledWith('value');

        _expect(setValueMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });

    it('should be able to set the value of an element', async () => {
        await actions.setInputField('set', 'value', 'element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        _expect(setValueMock).toHaveBeenCalledTimes(1);
        _expect(setValueMock).toHaveBeenCalledWith('value');

        _expect(addValueMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });

    it('should be able to set an empty value of an element', async () => {
        await actions.setInputField('set', '', 'element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        _expect(setValueMock).toHaveBeenCalledTimes(1);
        _expect(setValueMock).toHaveBeenCalledWith('');

        _expect(addValueMock).not.toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });
});
