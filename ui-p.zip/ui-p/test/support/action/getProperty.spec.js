import actions from '../../../src/support/actions';

describe('getProperty', () => {
    let getProperty
    beforeEach(() => {
        getProperty = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            getProperty,
        });
    });

    it('should call getProperty on the browser', async() => {
        await actions.getProperty('element','value','input');
        expect(getProperty).toHaveBeenCalled();
        expect(getProperty).toHaveBeenCalledTimes(1);
        expect(getProperty).toHaveBeenCalledWith('value');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getProperty throws error', async() => {
        getProperty.mockImplementation(() => { throw new Error('Failed getProperty') })
        await actions.getProperty('element','value','input');
        expect(getProperty).toHaveBeenCalled();
        expect(getProperty).toHaveBeenCalledTimes(1);
        expect(getProperty).toHaveBeenCalledWith('value');
        expect(getProperty).toThrow('Failed getProperty')
        expect(global.error).toHaveBeenCalled()
    });
});
