import actions from '../../../src/support/actions';

let clickMock;
let waitForDisplayedMock;

describe('clickElement', () => {
    let expectToHaveLengthOf;
    let expectToHaveLengthOfAtLeast;

    beforeEach(() => {
        global.$$ = jest.fn(() => ['1'])
            .mockImplementationOnce(() => []);

        clickMock = jest.fn();
        waitForDisplayedMock = jest.fn()
        global.$ = jest.fn().mockReturnValue({
            click: clickMock,
            waitForDisplayed: waitForDisplayedMock,
        });

        expectToHaveLengthOf = jest.fn();
        expectToHaveLengthOfAtLeast = jest.fn();

        global.expect = jest.fn(() => ({
            toBeGreaterThanOrEqual: expectToHaveLengthOfAtLeast,
            toHaveLength: expectToHaveLengthOf,
        }));
    });
    it('should fail if the given element does not exist', async () => {
        clickMock.mockImplementation(() => { throw new Error('Failed click') })
        await actions.click('element', 'element0');
        _expect(global.$).toHaveBeenCalledWith('element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(clickMock).toHaveBeenCalled();
        _expect(clickMock).toThrow('Failed click')
        _expect(global.error).toHaveBeenCalled()
    });

    it('should call click on the browser', async () => {
        await actions.click('element', 'element1');
        _expect(global.$).toHaveBeenCalledWith('element');
        _expect(waitForDisplayedMock).toHaveBeenCalled();
        _expect(clickMock).toHaveBeenCalled();
        _expect(global.info).toHaveBeenCalled()
    });
});
