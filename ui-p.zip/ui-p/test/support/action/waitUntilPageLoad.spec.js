import actions from '../../../src/support/actions';


describe('waitUntilPageLoad', () => {
    beforeEach(() => {
        global.browser = {
            waitUntil: jest.fn(() => 'https://www.google.com/'),
            execute:jest.fn()
        };
    });

    it('should call waitUntilPageLoad on the browser object', async () => {
        await actions.waitUntilPageLoad('https://www.google.com/');
        expect(global.browser.waitUntil).toHaveBeenCalled();
        expect(global.browser.waitUntil).toHaveBeenCalledTimes(1);
    });

    it('should call waitUntilPageLoad on the browser object (falseCase)', async () => {
        await actions.waitUntilPageLoad('https://www.google.com/test');
        expect(global.browser.waitUntil).toHaveBeenCalled();
        expect(global.browser.waitUntil).toHaveBeenCalledTimes(1);
    });
});
