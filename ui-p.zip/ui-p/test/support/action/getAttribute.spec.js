import actions from '../../../src/support/actions';

describe('getAttribute', () => {
    let getAttribute
    beforeEach(() => {
        getAttribute = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            getAttribute,
        });
    });

    it('should call getAttribute on the browser', async () => {
        await actions.getAttribute('element', 'name', 'input text');
        expect(getAttribute).toHaveBeenCalled();
        expect(getAttribute).toHaveBeenCalledTimes(1);
        expect(getAttribute).toHaveBeenCalledWith('name');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getAttribute throws error', async () => {
        getAttribute.mockImplementation(() => { throw new Error('Failed getAttribute') })
        await actions.getAttribute('element', 'name', 'input text');
        expect(getAttribute).toHaveBeenCalled();
        expect(getAttribute).toHaveBeenCalledTimes(1);
        expect(getAttribute).toHaveBeenCalledWith('name');
        expect(getAttribute).toThrow('Failed getAttribute')
        expect(global.error).toHaveBeenCalled()
    });
});
