import actions from '../../../src/support/actions';

let clearElementMock,waitForDisplayedMock;

describe('clearInputField', () => {
    let element;

    beforeEach(() => {
        clearElementMock = jest.fn();
        waitForDisplayedMock = jest.fn()
        global.$ = jest.fn().mockReturnValue({
            clearValue: clearElementMock,
            waitForDisplayed: waitForDisplayedMock,
        });
        element = 'element_selector';
    });

    it('should call clearElement on the browser', async () => {
        await actions.clearInputField(element,"clear element");
        expect(clearElementMock).toHaveBeenCalledTimes(1);
        expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        _expect(global.info).toHaveBeenCalled()
    });

    it('should call clearElement throws error', async () => {
        clearElementMock.mockImplementation(() => { throw new Error('Failed clearElement') })
        await actions.clearInputField(element,"clear element");
        expect(clearElementMock).toHaveBeenCalledTimes(1);
        expect(waitForDisplayedMock).toHaveBeenCalledTimes(1);
        expect(clearElementMock).toThrow('Failed clearElement')
        expect(global.error).toHaveBeenCalled()
    });
});
