import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('selectOptionByIndex', () => {
    let currentInstance;
    let waitForDisplayedFunction;
    let isSelectedFunction;

    beforeEach(() => {
        currentInstance = {
            $: jest.fn(),
            selector: {
                selectByIndex: jest.fn(),
            }
        };
        waitForDisplayedFunction = jest.fn();
        isSelectedFunction = jest.fn();
    });

    it('should select by index', async () => {
        const selector = 'select';
        const selectionType = '1';
        const selectionValue = 'optionName';
        currentInstance.$.mockResolvedValue(currentInstance.selector);
        await multiRemoteActions.selectOptionByIndex.call({
            currentInstance,
            waitForDisplayed: waitForDisplayedFunction,
            isSelected: isSelectedFunction
        },
            selector, selectionType, selectionValue);

        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.$).toHaveBeenCalledWith(selector);
        expect(currentInstance.selector.selectByIndex).toHaveBeenCalled();
    });

    // it('should select option by unknown type', async () => {
    //     const selector = 'select';
    //     const selectionType = 'space';
    //     const selectionValue = 'Option Text';
    //     try {
    //         currentInstance.$.mockResolvedValue(currentInstance.selector);
    //         await multiRemoteActions.selectOptionByIndex.call({
    //             currentInstance,
    //             waitForDisplayed: waitForDisplayedFunction,
    //             isSelected: isSelectedFunction
    //         },
    //             selector, selectionType, selectionValue);
    //         expect(global.info).toHaveBeenCalled();
    //         expect(currentInstance.$).toHaveBeenCalledWith(selector);
    //         expect(currentInstance.selector.selectByVisibleText).toHaveBeenCalledWith(selectionValue);
    //     } catch (error) {
    //         let expectError = 'Error: Unknown selection type "space"'
    //         expect(error.toString()).toEqual(expectError)
    //     }

    // });

    it('should handle error if selection fails', async () => {
        const selector = 'select';
        const selectionType = 'text';
        const selectionValue = 'Option Text';
        const errorMessage = 'Failed to select option';
        currentInstance.$.mockResolvedValue(currentInstance.selector);
        currentInstance.selector.selectByIndex.mockRejectedValue(new Error(errorMessage));
        await multiRemoteActions.selectOptionByIndex.call({
            currentInstance,
            waitForDisplayed: waitForDisplayedFunction,
            isSelected: isSelectedFunction
        },
            selector, selectionType, selectionValue);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.$).toHaveBeenCalledWith(selector);
        expect(currentInstance.selector.selectByIndex).toHaveBeenCalled();
    });
});