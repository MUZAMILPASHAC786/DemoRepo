import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('multiRemoteActions', () => {

    let instance;

    beforeEach(() => {
        global.browser = {
            acceptAlert: jest.fn(),
            dismissAlert: jest.fn(),
            getAlertText: jest.fn(),
            waitForDisplayed: jest.fn(),
            isSelected: jest.fn().mockReturnValue(() => { }),
        };
        instance = {
            currentInstance: {
                $: jest.fn(),
            },
        };
    });

    it('should clear the input field if selector is an object', async () => {
        let selector = '#input'
        const mockElement = {
            waitForDisplayed: jest.fn().mockResolvedValue(true),
            clearValue: jest.fn().mockResolvedValue(true),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.clearInputField.call(instance, selector, 'inputField');
        expect(instance.currentInstance.$).toHaveBeenCalledWith(selector);
        expect(mockElement.waitForDisplayed).toHaveBeenCalledWith({ timeout: 10000 });
        expect(mockElement.clearValue).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled();
    });

    it('should clear the input field if selector is a string', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn().mockResolvedValue(true),
            clearValue: jest.fn().mockResolvedValue(true),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.clearInputField.call(instance, 'inputSelector', 'inputField');
        expect(instance.currentInstance.$).toHaveBeenCalledWith('inputSelector');
        expect(mockElement.waitForDisplayed).toHaveBeenCalledWith({ timeout: 10000 });
        expect(mockElement.clearValue).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled();
    });

    it('should log an error if the input field is not cleared', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn().mockRejectedValue(new Error('timeout')),
            clearValue: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.clearInputField.call(instance, 'inputSelector', 'inputField');
        expect(instance.currentInstance.$).toHaveBeenCalledWith('inputSelector');
        expect(mockElement.waitForDisplayed).toHaveBeenCalledWith({ timeout: 10000 });
        expect(mockElement.clearValue).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled();
    });

    it('maximizeWindow', async () => {
        const mockElement = {
            maximizeWindow: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.maximizeWindow.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call maximizeWindow throws error', async () => {
        const mockElement = {
            maximizeWindow: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.maximizeWindow.call(instance);
        expect(mockElement.maximizeWindow).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('getWindowSize', async () => {
        const mockElement = {
            getWindowSize: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getWindowSize.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getWindowSize throws error', async () => {
        const mockElement = {
            getWindowSize: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getWindowSize.call(instance);
        expect(mockElement.getWindowSize).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('launchApp', async () => {
        const mockElement = {
            launchApp: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.launchApp.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call launchApp throws error', async () => {
        const mockElement = {
            launchApp: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getWindowSize.call(instance);
        expect(mockElement.launchApp).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('getWindowHandles', async () => {
        const mockElement = {
            getWindowHandles: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getWindowHandles.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getWindowHandles throws error', async () => {
        const mockElement = {
            getWindowHandles: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getWindowHandles.call(instance);
        expect(mockElement.getWindowHandles).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('clickElement', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn(),
            click: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.clickElement.call(instance, 'click', '#element', 'click');
        expect(mockElement.waitForDisplayed).toHaveBeenCalled();
        expect(mockElement.click).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call clickElement throws error', async () => {
        const mockElement = {
            clickElement: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.clickElement.call(instance, 'click', '#element', 'click');
        expect(mockElement.clickElement).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('click', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn(),
            click: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.click.call(instance, '#element', 'click');
        expect(mockElement.waitForDisplayed).toHaveBeenCalled();
        expect(mockElement.click).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call click throws error', async () => {
        const mockElement = {
            click: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.click.call(instance, '#element', 'click');
        expect(mockElement.click).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('doubleClick', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn(),
            doubleClick: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.doubleClick.call(instance, '#element', 'click');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call doubleClick throws error', async () => {
        const mockElement = {
            doubleClick: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.doubleClick.call(instance, '#element', 'click');
        expect(mockElement.doubleClick).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('waitUntil', async () => {
        const mockElement = {
            waitUntil: jest.fn(() => 'https://www.google.com/'),
            isDisplayed: jest.fn(() => true)
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitUntil.call(instance, '#element', 'element', 2000);
        expect(global.info).toHaveBeenCalled()
    });

    it('switchWindow', async () => {
        const mockElement = {
            switchWindow: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.switchWindow.call(instance, 'https://www.google.com/');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call switchWindow throws error', async () => {
        const mockElement = {
            switchWindow: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.switchWindow.call(instance, 'https://www.google.com/');
        expect(mockElement.switchWindow).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('deleteCookies', async () => {
        const mockElement = {
            deleteCookies: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.deleteCookies.call(instance, 'cookie');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call deleteCookies throws error', async () => {
        const mockElement = {
            deleteCookies: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.deleteCookies.call(instance, 'cookie');
        expect(mockElement.deleteCookies).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('deleteAllCookies', async () => {
        const mockElement = {
            deleteAllCookies: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.deleteAllCookies.call(instance, 'cookie');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call deleteAllCookies throws error', async () => {
        const mockElement = {
            deleteAllCookies: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.deleteAllCookies.call(instance, 'cookie');
        expect(mockElement.deleteAllCookies).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('dragElement', async () => {
        const mockElement = {
            dragElement: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.dragElement.call(instance, 'cookie');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call dragElement throws error', async () => {
        const mockElement = {
            dragElement: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.dragElement.call(instance, 'cookie');
        expect(mockElement.dragElement).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('getProperty', async () => {
        const mockElement = {
            getProperty: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getProperty.call(instance, '#element', 'value', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getProperty throws error', async () => {
        const mockElement = {
            getProperty: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getProperty.call(instance, '#element', 'value', 'element');
        expect(mockElement.getProperty).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('getText', async () => {
        const mockElement = {
            getText: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getText.call(instance, '#element', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getText throws error', async () => {
        const mockElement = {
            getText: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getText.call(instance, '#element', 'element');
        expect(mockElement.getText).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('getValue', async () => {
        const mockElement = {
            getValue: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getValue.call(instance, '#element', 'element');
        expect(mockElement.getValue).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getValue throws error', async () => {
        const mockElement = {
            getValue: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getValue.call(instance, '#element', 'element');
        expect(mockElement.getValue).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('getAttribute', async () => {
        const mockElement = {
            getAttribute: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getAttribute.call(instance, '#element', 'name', 'element');
        expect(mockElement.getAttribute).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call getAttribute throws error', async () => {
        const mockElement = {
            getAttribute: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getAttribute.call(instance, '#element', 'name', 'element');
        expect(mockElement.getAttribute).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('handleModal : alertbox', async () => {
        await multiRemoteActions.handleModal('accept', 'alertbox');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('handleModal : confirmbox', async () => {
        await multiRemoteActions.handleModal('accept', 'confirmbox');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('handleModal : prompt', async () => {
        await multiRemoteActions.handleModal('accept', 'prompt');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('handleModal : error', async () => {
        global.browser.acceptAlert.mockImplementation(() => { throw new Error('Failed acceptAlert') })
        await multiRemoteActions.handleModal('accept', 'alertbox');
        expect(global.browser.acceptAlert).toHaveBeenCalledTimes(1);
        expect(global.browser.dismissAlert).not.toHaveBeenCalled();
        expect(global.browser.getAlertText).not.toHaveBeenCalled();
        expect(global.browser.acceptAlert).toThrow('Failed acceptAlert')
        expect(global.error).toHaveBeenCalled()
    });

    it('moveTo', async () => {
        const mockElement = {
            moveTo: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.moveTo.call(instance, '#element', 1, 2, 'element');
        expect(mockElement.moveTo).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('should call moveTo throws error', async () => {
        const mockElement = {
            moveTo: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.moveTo.call(instance, '#element', 1, 2, 'element');
        expect(mockElement.moveTo).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('pressButton', async () => {
        const mockElement = {
            keys: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.pressButton.call(instance, 'Enter');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call pressButton throws error', async () => {
        const mockElement = {
            keys: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.pressButton.call(instance, 'Enter');
        expect(global.error).toHaveBeenCalled()
    });

    it('scroll', async () => {
        const mockElement = {
            scrollIntoView: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.scroll.call(instance, '#element', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('should call scroll throws error', async () => {
        const mockElement = {
            scrollIntoView: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.scroll.call(instance, '#element', 'element');
        expect(mockElement.scrollIntoView).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('setCookie', async () => {
        const mockElement = {
            setCookies: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setCookie.call(instance, 'cookie1', 'cookie2');
        expect(global.info).toHaveBeenCalled()
    });

    it('setCookie : error', async () => {
        const mockElement = {
            setCookies: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setCookie.call(instance, 'cookie1', 'cookie2');
        expect(mockElement.setCookies).not.toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled()
    });

    it('setInputField', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setInputField.call(instance, 'addValue', 'Name', '#element', 'element');
        expect(mockElement.waitForDisplayed).toHaveBeenCalled();
        expect(mockElement.waitForDisplayed).toHaveBeenCalledWith({ "timeout": 10000 });
        expect(global.info).toHaveBeenCalled()
    });

    it('setInputField : error', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setInputField.call(instance, 'addValue', 'Name', '#element', 'element');
        expect(global.error).toHaveBeenCalled()
    });

    it('setValue', async () => {
        const mockElement = {
            setValue: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setValue.call(instance, 'Name', '#element', 'element');
        expect(mockElement.setValue).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('setValue : error', async () => {
        const mockElement = {
            setValue: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setValue.call(instance, 'Name', '#element', 'element');
        expect(global.error).toHaveBeenCalled()
    });

    it('addValue', async () => {
        const mockElement = {
            addValue: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.addValue.call(instance, 'Name', '#element', 'element');
        expect(mockElement.addValue).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });

    it('addValue : error', async () => {
        const mockElement = {
            addValue: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.addValue.call(instance, 'Name', '#element', 'element');
        expect(global.error).toHaveBeenCalled()
    });

    it('setPromptText', async () => {
        const mockElement = {
            sendAlertText: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setPromptText.call(instance, 'Name', 'Name Field prompt');
        expect(global.info).toHaveBeenCalled()
    });

    it('setPromptText : error', async () => {
        const mockElement = {
            sendAlertText: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.setPromptText.call(instance, 'Name', 'Name Field prompt');
        expect(global.error).toHaveBeenCalled()
    });

    it('switchToFrame', async () => {
        const mockElement = {
            switchToFrame: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.switchToFrame.call(instance, '#element', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('switchToFrame : error', async () => {
        const mockElement = {
            switchToFrame: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.switchToFrame.call(instance, '#element', 'element');
        expect(global.error).toHaveBeenCalled()
    });

    it('switchToParentFrame', async () => {
        const mockElement = {
            switchToParentFrame: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.switchToParentFrame.call(instance, 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('switchToParentFrame : error', async () => {
        const mockElement = {
            switchToParentFrame: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.switchToParentFrame.call(instance, 'element');
        expect(global.error).toHaveBeenCalled()
    });

    it('waitFor', async () => {
        const mockElement = {
            waitForExist: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitFor.call(instance, 'element', 2000, '', 'displayed', 'checkbox');
        expect(global.info).toHaveBeenCalled()
    });

    it('waitFor : falsestate is undefined', async () => {
        const mockElement = {
            waitForExist: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitFor.call(instance, 'element', 2000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForExist', async () => {
        const mockElement = {
            waitForExist: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForExist.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForExist : error', async () => {
        const mockElement = {
            waitForExist: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForExist.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForClickable', async () => {
        const mockElement = {
            waitForClickable: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForClickable.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForClickable : error', async () => {
        const mockElement = {
            waitForClickable: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForClickable.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForDisplayed :3 arguments', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn(),
            isDisplayed: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForDisplayed.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForDisplayed: 2 arguments', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn(),
            isDisplayed: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForDisplayed.call(instance, '#element', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForDisplayed : error', async () => {
        const mockElement = {
            waitForDisplayed: jest.fn().mockRejectedValue(new Error('timeout')),
            isDisplayed: jest.fn()
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForDisplayed.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForEnabled', async () => {
        const mockElement = {
            waitForEnabled: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForEnabled.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('waitForEnabled : error', async () => {
        const mockElement = {
            waitForEnabled: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.waitForEnabled.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isClickable', async () => {
        const mockElement = {
            isClickable: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isClickable.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isClickable : error', async () => {
        const mockElement = {
            isClickable: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isClickable.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isDisplayed', async () => {
        const mockElement = {
            isDisplayed: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isDisplayed.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isDisplayed : error', async () => {
        const mockElement = {
            isDisplayed: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isDisplayed.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isEnabled', async () => {
        const mockElement = {
            isEnabled: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isEnabled.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isEnabled : error', async () => {
        const mockElement = {
            isEnabled: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isEnabled.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isExisting', async () => {
        const mockElement = {
            isExisting: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isExisting.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isExisting : error', async () => {
        const mockElement = {
            isExisting: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isExisting.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isSelected', async () => {
        const mockElement = {
            isSelected: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isSelected.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isSelected : error', async () => {
        const mockElement = {
            isSelected: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isSelected.call(instance, '#element', 'element', 1000);
        expect(global.info).toHaveBeenCalled()
    });

    it('isDisplayedViewport', async () => {
        const mockElement = {
            isDisplayedViewport: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isDisplayedViewport.call(instance, '#element', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('isDisplayedViewport : error', async () => {
        const mockElement = {
            isDisplayedViewport: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.isDisplayedViewport.call(instance, '#element', 'element');
        expect(global.info).toHaveBeenCalled()
    });

    it('getTitle', async () => {
        const mockElement = {
            getTitle: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getTitle.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('getTitle : error', async () => {
        const mockElement = {
            getTitle: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.getTitle.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('pause', async () => {
        const mockElement = {
            pause: jest.fn(),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.pause.call(instance);
        expect(global.info).toHaveBeenCalled()
    });

    it('pause : error', async () => {
        const mockElement = {
            pause: jest.fn().mockRejectedValue(new Error('timeout')),
        };
        instance.currentInstance.$.mockResolvedValue(mockElement);
        await multiRemoteActions.pause.call(instance);
        expect(global.info).toHaveBeenCalled()
    });
})