import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('selectOption', () => {
    let currentInstance;
    let waitForDisplayedFunction;
    let isSelectedFunction;

    beforeEach(() => {
        currentInstance = {
            $: jest.fn(),
            selector: {
                selectByAttribute: jest.fn(),
                selectByVisibleText: jest.fn()
            }
        };
        waitForDisplayedFunction = jest.fn();
        isSelectedFunction = jest.fn();
    });

    it('should select option by name', async () => {
        const selector = 'select';
        const selectionType = 'name';
        const selectionValue = 'optionName';
        currentInstance.$.mockResolvedValue(currentInstance.selector);
        await multiRemoteActions.selectOption.call({
            currentInstance,
            waitForDisplayed: waitForDisplayedFunction,
            isSelected: isSelectedFunction
        },
            selector, selectionType, selectionValue);

        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.$).toHaveBeenCalledWith(selector);
        expect(currentInstance.selector.selectByAttribute).toHaveBeenCalledWith('name', selectionValue);
    });

    it('should select option by value', async () => {
        const selector = 'select';
        const selectionType = 'value';
        const selectionValue = 'optionValue';
        currentInstance.$.mockResolvedValue(currentInstance.selector);
        await multiRemoteActions.selectOption.call({
            currentInstance,
            waitForDisplayed: waitForDisplayedFunction,
            isSelected: isSelectedFunction
        },
            selector, selectionType, selectionValue);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.$).toHaveBeenCalledWith(selector);
        expect(currentInstance.selector.selectByAttribute).toHaveBeenCalledWith('value', selectionValue);
    });

    it('should select option by text', async () => {
        const selector = 'select';
        const selectionType = 'text';
        const selectionValue = 'Option Text';
        currentInstance.$.mockResolvedValue(currentInstance.selector);
        await multiRemoteActions.selectOption.call({
            currentInstance,
            waitForDisplayed: waitForDisplayedFunction,
            isSelected: isSelectedFunction
        },
            selector, selectionType, selectionValue);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.$).toHaveBeenCalledWith(selector);
        expect(currentInstance.selector.selectByVisibleText).toHaveBeenCalledWith(selectionValue);
    });

    it('should select option by unknown type', async () => {
        const selector = 'select';
        const selectionType = 'space';
        const selectionValue = 'Option Text';
        try {
            currentInstance.$.mockResolvedValue(currentInstance.selector);
            await multiRemoteActions.selectOption.call({
                currentInstance,
                waitForDisplayed: waitForDisplayedFunction,
                isSelected: isSelectedFunction
            },
                selector, selectionType, selectionValue);
            expect(global.info).toHaveBeenCalled();
            expect(currentInstance.$).toHaveBeenCalledWith(selector);
            expect(currentInstance.selector.selectByVisibleText).toHaveBeenCalledWith(selectionValue);
        } catch (error) {
            let expectError = 'Error: Unknown selection type "space"'
            expect(error.toString()).toEqual(expectError)
        }

    });

    it('should handle error if selection fails', async () => {
        const selector = 'select';
        const selectionType = 'text';
        const selectionValue = 'Option Text';
        const errorMessage = 'Failed to select option';
        currentInstance.$.mockResolvedValue(currentInstance.selector);
        currentInstance.selector.selectByVisibleText.mockRejectedValue(new Error(errorMessage));
        await multiRemoteActions.selectOption.call({
            currentInstance,
            waitForDisplayed: waitForDisplayedFunction,
            isSelected: isSelectedFunction
        },
            selector, selectionType, selectionValue);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.$).toHaveBeenCalledWith(selector);
        expect(currentInstance.selector.selectByVisibleText).toHaveBeenCalledWith(selectionValue);

    });
});