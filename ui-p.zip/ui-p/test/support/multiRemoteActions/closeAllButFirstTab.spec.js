import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('closeAllButFirstTab', () => {
    let currentInstanceMock;
    let mockContext;
    let pauseFunction;

    beforeEach(() => {
        currentInstanceMock = {
            getWindowHandles: jest.fn(),
            switchToWindow: jest.fn(),
            closeWindow: jest.fn()
        };
        pauseFunction =  jest.fn(),

        mockContext = {
            currentInstance: currentInstanceMock,
            pause: pauseFunction
        };
    });

    it('should close all tabs except the first one', async () => {
        currentInstanceMock.getWindowHandles.mockResolvedValueOnce(['tab1', 'tab2', 'tab3']);
        await multiRemoteActions.closeAllButFirstTab.call(mockContext, 'TabName');
        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
        expect(currentInstanceMock.switchToWindow).toHaveBeenCalledTimes(3);
    });

    it('should handle errors gracefully', async () => {
        currentInstanceMock.getWindowHandles.mockRejectedValueOnce(new Error('An error occurred'));
        await multiRemoteActions.closeAllButFirstTab.call(mockContext, 'TabName');
        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
        expect(currentInstanceMock.switchToWindow).not.toHaveBeenCalled();
        expect(currentInstanceMock.closeWindow).not.toHaveBeenCalled();
    });
});