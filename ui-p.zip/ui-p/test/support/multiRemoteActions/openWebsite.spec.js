import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('openWebsite', () => {
    let currentInstance;

    beforeEach(() => {
        currentInstance = {
            url: jest.fn(),
            maximizeWindow: jest.fn(),
            getUrl: jest.fn()
        };
    });

    it('should open the website successfully', async () => {
        const page = 'http://example.com';
        currentInstance.url.mockResolvedValue();
        currentInstance.maximizeWindow.mockResolvedValue();
        currentInstance.getUrl.mockResolvedValue(page);
        await multiRemoteActions.openWebsite.call({ currentInstance }, page);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.url).toHaveBeenCalledWith(page);
        expect(currentInstance.maximizeWindow).toHaveBeenCalled();
        expect(currentInstance.getUrl).toHaveBeenCalled();
    });

    it('should handle error if unable to open the website', async () => {
        const page = 'http://example.com';
        const errorMessage = 'Failed to open website';
        currentInstance.url.mockRejectedValue(new Error(errorMessage));
        await multiRemoteActions.openWebsite.call({ currentInstance }, page);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.url).toHaveBeenCalledWith(page);
    });
});