import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('focusLastOpenedWindow', () => {
    let currentInstance;
    let focusLastOpenedWindowFunction;

    beforeEach(() => {
        currentInstance = {
            getWindowHandles: jest.fn(),
            switchToWindow: jest.fn()
        };
        focusLastOpenedWindowFunction = multiRemoteActions.focusLastOpenedWindow.bind({ currentInstance });
    });

    it('should focus on the last opened window successfully', async () => {
        const page = 'example.com/page';
        const handles = ['window1', 'window2', 'window3'];
        currentInstance.getWindowHandles.mockResolvedValue(handles);
        await focusLastOpenedWindowFunction(page);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.getWindowHandles).toHaveBeenCalled();
        expect(currentInstance.switchToWindow).toHaveBeenCalledWith('window3');
    });

    it('should handle error if unable to switch to the last opened window', async () => {
        const page = 'example.com/page';
        const handles = ['window1', 'window2', 'window3'];
        const errorMessage = 'Switch window error';
        currentInstance.getWindowHandles.mockResolvedValue(handles);
        currentInstance.switchToWindow.mockRejectedValue(new Error(errorMessage));
        await focusLastOpenedWindowFunction(page);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.getWindowHandles).toHaveBeenCalled();
        expect(currentInstance.switchToWindow).toHaveBeenCalledWith('window3');
    });
});