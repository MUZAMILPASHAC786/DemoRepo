import multiRemoteActions from '../../../src/support/multiRemoteActions';
import Check from '../../../src/support/validations';

describe('newWindow', () => {
    let currentInstance;
    let focusLastOpenedWindowFunction;
    let checkURLFunction;
    let newWindowFunction;

    beforeEach(() => {
        currentInstance = {
            newWindow: jest.fn()
        };
        focusLastOpenedWindowFunction = jest.fn();
        checkURLFunction = jest.fn(() => Check.checkURL("https://www.google.com/", "Google"));
        newWindowFunction = multiRemoteActions.newWindow.bind({ currentInstance, focusLastOpenedWindow: focusLastOpenedWindowFunction });
    });

    it('should open a new window successfully', async () => {
        const url = 'http://example.com';
        const urlName = 'Example';
        await newWindowFunction(url, urlName);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.newWindow).toHaveBeenCalledWith(url);
        expect(focusLastOpenedWindowFunction).toHaveBeenCalledWith(urlName);
    });

    it('should handle error if new window cannot be opened', async () => {
        const url = 'http://example.com';
        const urlName = 'Example';
        const errorMessage = 'Failed to open new window';
        currentInstance.newWindow.mockRejectedValue(new Error(errorMessage));
        await newWindowFunction(url, urlName);
        expect(global.info).toHaveBeenCalled();
        expect(currentInstance.newWindow).toHaveBeenCalledWith(url);
    });
});