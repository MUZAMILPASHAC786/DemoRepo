import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('closeLastOpenedWindow', () => {
    let currentInstanceMock;
    let mockContext;

    beforeEach(() => {
        currentInstanceMock = {
            getWindowHandles: jest.fn(),
            switchToWindow: jest.fn(),
            closeWindow: jest.fn()
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('should close last opened window', async () => {
        currentInstanceMock.getWindowHandles.mockResolvedValueOnce(['tab1', 'tab2', 'tab3']);
        await multiRemoteActions.closeLastOpenedWindow.call(mockContext, 'TabName');
        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
        expect(currentInstanceMock.switchToWindow).toHaveBeenCalledTimes(1);
    });

    it('should handle errors gracefully', async () => {
        currentInstanceMock.getWindowHandles.mockRejectedValueOnce(new Error('An error occurred'));
        await multiRemoteActions.closeLastOpenedWindow.call(mockContext, 'TabName');
        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
        expect(currentInstanceMock.switchToWindow).not.toHaveBeenCalled();
        expect(currentInstanceMock.closeWindow).not.toHaveBeenCalled();
    });
});