import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('scrollToElement', () => {
    let currentInstanceMock;
    let elementMock;

    beforeEach(() => {
        elementMock = {
            isDisplayed: jest.fn()
        };

        currentInstanceMock = {
            getWindowSize: jest.fn(),
            $: jest.fn(() => elementMock),
            touchAction: jest.fn()
        };
    });

    it('should scroll to the element until it is visible', async () => {
        currentInstanceMock.getWindowSize.mockResolvedValueOnce({ width: 800, height: 600 });
        elementMock.isDisplayed.mockResolvedValueOnce(false).mockResolvedValueOnce(true);
        await multiRemoteActions.scrollToElement.call({ currentInstance: currentInstanceMock }, 'selector');
        expect(currentInstanceMock.getWindowSize).toHaveBeenCalled();
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.isDisplayed).toHaveBeenCalledTimes(2);
        expect(currentInstanceMock.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 400, y: 300 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 400, y: 60 },
            'release'
        ]);
    });

    it('should not scroll if the element is already visible', async () => {
        currentInstanceMock.getWindowSize.mockResolvedValueOnce({ width: 800, height: 600 });
        elementMock.isDisplayed.mockResolvedValueOnce(true);
        await multiRemoteActions.scrollToElement.call({ currentInstance: currentInstanceMock }, 'selector');
        expect(currentInstanceMock.getWindowSize).toHaveBeenCalled();
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.isDisplayed).toHaveBeenCalledTimes(1);
        expect(currentInstanceMock.touchAction).not.toHaveBeenCalled();
    });

    it('should handle multiple scrolls until the element is visible', async () => {
        currentInstanceMock.getWindowSize.mockResolvedValueOnce({ width: 800, height: 600 });
        elementMock.isDisplayed
            .mockResolvedValueOnce(false)
            .mockResolvedValueOnce(false)
            .mockResolvedValueOnce(true);
        await multiRemoteActions.scrollToElement.call({ currentInstance: currentInstanceMock }, 'selector');
        expect(currentInstanceMock.getWindowSize).toHaveBeenCalled();
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.isDisplayed).toHaveBeenCalledTimes(3);
        expect(currentInstanceMock.touchAction).toHaveBeenCalledTimes(2);
    });
});