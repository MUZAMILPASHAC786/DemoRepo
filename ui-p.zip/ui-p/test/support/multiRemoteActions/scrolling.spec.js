import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('scrolling', () => {
    let currentInstanceMock;
    let mockContext;
 
    beforeEach(() => {
        currentInstanceMock = {
            touchAction: jest.fn()
        };
 
        mockContext = {
            getWindowSize: jest.fn(),
            currentInstance: currentInstanceMock
        };
    });
 
    it('should scroll down', async () => {
        mockContext.getWindowSize.mockResolvedValueOnce({ width: 800, height: 600 });
        await multiRemoteActions.scrolling.call(mockContext, 'down');
        expect(mockContext.getWindowSize).toHaveBeenCalled();
        expect(currentInstanceMock.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 400, y: 540 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 400, y: 300 },
            'release'
        ]);
    });
 
    it('should scroll up', async () => {
        mockContext.getWindowSize.mockResolvedValueOnce({ width: 800, height: 600 });
        await multiRemoteActions.scrolling.call(mockContext, 'up');
        expect(mockContext.getWindowSize).toHaveBeenCalled();
        expect(currentInstanceMock.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 400, y: 240 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 400, y: 540 },
            'release'
        ]);
    });
});