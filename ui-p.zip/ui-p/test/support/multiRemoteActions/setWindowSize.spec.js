import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('setWindowSize', () => {
    let currentInstanceMock;
    let mockContext;

    beforeEach(() => {
        currentInstanceMock = {
            setWindowSize: jest.fn(),
            getWindowSize: jest.fn()
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('should set the window size and verify the new size', async () => {
        currentInstanceMock.setWindowSize.mockResolvedValueOnce();
        currentInstanceMock.getWindowSize.mockResolvedValueOnce({ width: 802, height: 602 });
        await multiRemoteActions.setWindowSize.call(mockContext, '800', '600');
        expect(global.info).toHaveBeenCalled();
        expect(currentInstanceMock.setWindowSize).toHaveBeenCalledWith(800, 600);
        expect(currentInstanceMock.getWindowSize).toHaveBeenCalled();
    });

    it('should log a warning if setting the window size fails', async () => {
        const errorMessage = 'Failed to set window size';
        currentInstanceMock.setWindowSize.mockRejectedValueOnce(new Error(errorMessage));
        await multiRemoteActions.setWindowSize.call(mockContext, '800', '600');
        expect(global.info).toHaveBeenCalled();
    });
});