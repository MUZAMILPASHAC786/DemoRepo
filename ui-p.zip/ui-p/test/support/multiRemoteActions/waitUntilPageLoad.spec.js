import multiRemoteActions from '../../../src/support/multiRemoteActions';

describe('waitUntilPageLoad', () => {
    let currentInstanceMock;
    let mockContext;

    beforeEach(() => {
        currentInstanceMock = {
            waitUntil: jest.fn(),
            execute: jest.fn()
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('should wait until the page is fully loaded', async () => {
        currentInstanceMock.execute.mockResolvedValueOnce('complete');
        await multiRemoteActions.waitUntilPageLoad.call(mockContext, 'pageName');
        expect(currentInstanceMock.execute).not.toHaveBeenCalled();
        expect(currentInstanceMock.waitUntil).toHaveBeenCalledWith(expect.any(Function), {
            timeout: 240000,
            timeoutMsg: 'Oops! Check your internet connection'
        });
    });
});