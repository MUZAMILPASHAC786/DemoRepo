import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkURLPath', () => {
    let currentInstanceMock;
    let mockContext;

    beforeEach(() => {
        currentInstanceMock = {
            getUrl: jest.fn()
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('checkURLPath : true', async () => {
        currentInstanceMock.getUrl.mockResolvedValueOnce('https://www.google.com/');
        await multiRemoteCheck.checkURLPath.call(mockContext, 'https://www.google.com/', 'Google', true);
        expect(currentInstanceMock.getUrl).toHaveBeenCalled();
    });

    it('checkURLPath : false', async () => {
        currentInstanceMock.getUrl.mockResolvedValueOnce('https://www.google.com/test');
        await multiRemoteCheck.checkURLPath.call(mockContext, 'https://www.google.com/', 'Google', false);
        expect(currentInstanceMock.getUrl).toHaveBeenCalled();
    });
});