import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('isClickable', () => {
    let currentInstanceMock;
    let objMock;
 
    beforeEach(() => {
        objMock = {
            isClickable: jest.fn()
        };
 
        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });
 
    it('should verify if the element is clickable', async () => {
        objMock.isClickable.mockResolvedValueOnce(true);
        await multiRemoteCheck.isClickable.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isClickable).toHaveBeenCalled();
    });
 
    it('should verify if the element is not clickable when falseCase is true', async () => {
        objMock.isClickable.mockResolvedValueOnce(false);
        await multiRemoteCheck.isClickable.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isClickable).toHaveBeenCalled();
    });
});