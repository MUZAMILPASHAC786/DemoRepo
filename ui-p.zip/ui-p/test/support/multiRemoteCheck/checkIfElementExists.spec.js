import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkIfElementExists', () => {
    let currentInstanceMock;
 
    beforeEach(() => {
        currentInstanceMock = {
            $$: jest.fn()
        };
    });
 
    it('should verify if the element exists', async () => {
        currentInstanceMock.$$.mockResolvedValueOnce([{}]);
        await multiRemoteCheck.checkIfElementExists.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(currentInstanceMock.$$).toHaveBeenCalledWith('selector');
    });
 
    it('should verify if the element does not exist when falseCase is true', async () => {
        currentInstanceMock.$$.mockResolvedValueOnce([]);
        await multiRemoteCheck.checkIfElementExists.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(currentInstanceMock.$$).toHaveBeenCalledWith('selector');
    });
});