import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkSelected', () => {
    let currentInstanceMock;
    let elementMock;
    let mockContext;

    beforeEach(() => {
        elementMock = {
            isSelected: jest.fn(),
        };

        currentInstanceMock = {
            $: jest.fn(() => elementMock)
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('isSelected : true', async () => {
        elementMock.isSelected.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkSelected.call(mockContext, 'selector', 'Selector Name', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.isSelected).toHaveBeenCalledWith();
    });

    it('isSelected : false', async () => {
        elementMock.isSelected.mockResolvedValueOnce('value');
        await multiRemoteCheck.checkSelected.call(mockContext, 'selector', 'Selector Name', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.isSelected).toHaveBeenCalledWith();
    });
});