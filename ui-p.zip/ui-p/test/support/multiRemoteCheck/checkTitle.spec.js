import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkTitle', () => {
    let currentInstanceMock;
    let mockContext;

    beforeEach(() => {
        currentInstanceMock = {
            getTitle: jest.fn()
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('getTitle : true', async () => {
        currentInstanceMock.getTitle.mockResolvedValueOnce('Expected Title');
        await multiRemoteCheck.checkTitle.call(mockContext, 'Expected Title', 'Title Info', true);
        expect(currentInstanceMock.getTitle).toHaveBeenCalled();
    });

    it('getTitle : false', async () => {
        currentInstanceMock.getTitle.mockResolvedValueOnce('Expected Title');
        await multiRemoteCheck.checkTitle.call(mockContext, 'Expected Title', 'Title Info', false);
        expect(currentInstanceMock.getTitle).toHaveBeenCalled();
    });
});