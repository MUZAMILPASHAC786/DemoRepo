import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkModal', () => {
    let currentInstanceMock;

    beforeEach(() => {
        currentInstanceMock = {
            getAlertText: jest.fn()
        };
    });

    it('checkModal : true', async () => {
        currentInstanceMock.getAlertText.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkModal.call({ currentInstance: currentInstanceMock }, 'alertbox', true);
        expect(currentInstanceMock.getAlertText).toHaveBeenCalled();
    });

    it('checkModal : false', async () => {
        currentInstanceMock.getAlertText.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkModal.call({ currentInstance: currentInstanceMock }, 'alertbox', false);
        expect(currentInstanceMock.getAlertText).toHaveBeenCalled();
    });

    it('checkModal : error', async () => {
        const errorMessage = 'Failed checkModal';
        currentInstanceMock.getAlertText.mockRejectedValueOnce(new Error(errorMessage));
        await multiRemoteCheck.checkModal.call({ currentInstance: currentInstanceMock }, 'alertbox', false);
        expect(currentInstanceMock.getAlertText).toHaveBeenCalled();
        expect(global.info).toHaveBeenCalled()
    });
});