import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkDimension', () => {
    let currentInstanceMock;
    let elementMock;
    let mockContext;

    beforeEach(() => {
        elementMock = {
            getSize: jest.fn()
        };

        currentInstanceMock = {
            $: jest.fn(() => elementMock)
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('checkDimension : true', async () => {
        elementMock.getSize.mockResolvedValueOnce({ height: 100, width: 50 });
        await multiRemoteCheck.checkDimension.call(mockContext, 'selector', '100', 'height', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getSize).toHaveBeenCalled();
    });

    it('checkDimension : false', async () => {
        elementMock.getSize.mockResolvedValueOnce({ height: 50, width: 100 });
        await multiRemoteCheck.checkDimension.call(mockContext, 'selector', '100', 'broad', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getSize).toHaveBeenCalled();
    });

    it('checkDimension : false -  dimension is not as expected', async () => {
        elementMock.getSize.mockResolvedValueOnce({ height: 50, width: 100 });
        await multiRemoteCheck.checkDimension.call(mockContext, 'selector', '100', 'height', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getSize).toHaveBeenCalled();
    });
});