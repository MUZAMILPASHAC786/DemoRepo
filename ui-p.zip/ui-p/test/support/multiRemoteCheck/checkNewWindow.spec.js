import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkNewWindow', () => {
    let currentInstanceMock;

    beforeEach(() => {
        currentInstanceMock = {
            getWindowHandles: jest.fn(),
        };
    });

    it('checkNewWindow : true', async () => {
        const windowHandles = ['window1', 'window2'];
        currentInstanceMock.getWindowHandles.mockResolvedValueOnce(windowHandles);
        await multiRemoteCheck.checkNewWindow.call({ currentInstance: currentInstanceMock }, 'example.com/page', true);
        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
    });

    it('checkNewWindow : false', async () => {
        const windowHandles = ['window1', 'window2'];
        currentInstanceMock.getWindowHandles.mockResolvedValueOnce(windowHandles);
        await multiRemoteCheck.checkNewWindow.call({ currentInstance: currentInstanceMock }, 'example.com/page', false);
        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
    });
});