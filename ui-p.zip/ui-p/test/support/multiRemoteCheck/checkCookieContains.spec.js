import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkCookieContains', () => {
    let currentInstanceMock;

    beforeEach(() => {
        currentInstanceMock = {
            getCookies: jest.fn()
        };
    });

    it('should verify if the cookie exists', async () => {
        currentInstanceMock.getCookies.mockResolvedValueOnce([{ name: 'testCookie', value: 'cookiename' }]);
        await multiRemoteCheck.checkCookieContains.call({ currentInstance: currentInstanceMock }, 'testCookie', 'cookiename', false);
        expect(currentInstanceMock.getCookies).toHaveBeenCalledWith('testCookie');
        expect(() => multiRemoteCheck.checkCookieContains).not.toThrow();
    });

    it('should verify if the cookie does not exist when falseCase is true', async () => {
        currentInstanceMock.getCookies.mockResolvedValueOnce([{ name: 'testCookie', value: 'some other value' }]);
        await multiRemoteCheck.checkCookieContains.call({ currentInstance: currentInstanceMock }, 'testCookie', 'expected value', true);
        expect(currentInstanceMock.getCookies).toHaveBeenCalledWith('testCookie');
        expect(() => multiRemoteCheck.checkCookieContains).not.toThrow();
    });
})