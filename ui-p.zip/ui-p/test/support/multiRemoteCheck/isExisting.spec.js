import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('isExisting', () => {
    let currentInstanceMock;
 
    beforeEach(() => {
        currentInstanceMock = {
            $$: jest.fn()
        };
    });
 
    it('should verify if the element is existing', async () => {
        currentInstanceMock.$$.mockResolvedValueOnce([{}]);
        await multiRemoteCheck.isExisting.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(currentInstanceMock.$$).toHaveBeenCalledWith('selector');
    });
 
    it('should verify if the element is not existing when falseCase is true', async () => {
        currentInstanceMock.$$.mockResolvedValueOnce([]);
        await multiRemoteCheck.isExisting.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(currentInstanceMock.$$).toHaveBeenCalledWith('selector');
    });
});