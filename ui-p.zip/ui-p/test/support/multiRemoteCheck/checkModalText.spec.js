import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkModalText', () => {
    let currentInstanceMock;

    beforeEach(() => {
        currentInstanceMock = {
            getAlertText: jest.fn()
        };
    });

    it('checkModalText : true', async () => {
        currentInstanceMock.getAlertText.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkModalText.call({ currentInstance: currentInstanceMock }, 'alertbox', 'Hello user', true);
        expect(currentInstanceMock.getAlertText).toHaveBeenCalled();
    });

    it('checkModalText : false', async () => {
        currentInstanceMock.getAlertText.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkModalText.call({ currentInstance: currentInstanceMock }, 'alertbox', 'Hello user', false);
        expect(currentInstanceMock.getAlertText).toHaveBeenCalled();
    });
});