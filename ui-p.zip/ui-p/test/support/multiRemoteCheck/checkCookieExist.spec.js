import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkCookieExists', () => {
    let currentInstanceMock;

    beforeEach(() => {
        currentInstanceMock = {
            getCookies: jest.fn()
        };
    });

    it('should verify if the cookie exists', async () => {
        currentInstanceMock.getCookies.mockResolvedValueOnce([{ name: 'testCookie' }]);
        await multiRemoteCheck.checkCookieExists.call({ currentInstance: currentInstanceMock }, 'testCookie', false);
        expect(currentInstanceMock.getCookies).toHaveBeenCalledWith('testCookie');
        expect(() => multiRemoteCheck.checkCookieExists).not.toThrow();
    });

    it('should verify if the cookie does not exist when falseCase is true', async () => {
        currentInstanceMock.getCookies.mockResolvedValueOnce([]);
        await multiRemoteCheck.checkCookieExists.call({ currentInstance: currentInstanceMock }, 'testCookie', true);
        expect(currentInstanceMock.getCookies).toHaveBeenCalledWith('testCookie');
        expect(() => multiRemoteCheck.checkCookieExists).not.toThrow();
    });
})