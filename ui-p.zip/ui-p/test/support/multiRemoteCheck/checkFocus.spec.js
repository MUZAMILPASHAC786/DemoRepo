import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkFocus', () => {
    let currentInstanceMock;
    let objMock;
 
    beforeEach(() => {
        objMock = {
            isFocused: jest.fn()
        };
 
        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });
 

    it('verify if the element is focused', async () => {
        objMock.isFocused.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkFocus.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isFocused).toHaveBeenCalled();
    });

    it('verify if the element is not focused when falseCase is true', async () => {
        objMock.isFocused.mockResolvedValueOnce(false);
        await multiRemoteCheck.checkFocus.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isFocused).toHaveBeenCalled();
    });
})