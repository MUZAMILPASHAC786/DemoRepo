import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkContainsAnyText', () => {
    let currentInstanceMock;
    let objMock;

    beforeEach(() => {
        objMock = {
            getAttribute: jest.fn(),
            getValue: jest.fn(),
            getText: jest.fn()
        };

        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });

    it('should verify if selector contains expected text when attribute value is null', async () => {
        objMock.getAttribute.mockResolvedValueOnce(null);
        objMock.getText.mockResolvedValueOnce('expected text here');
        await multiRemoteCheck.checkContainsAnyText.call({ currentInstance: currentInstanceMock }, 'selector', 'expected text', false, 'SelectorName');
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getText).toHaveBeenCalled();
        expect(() => multiRemoteCheck.checkContainsAnyText).not.toThrow();
    });

    it('should verify if selector does not contain expected text when attribute value is not empty', async () => {
        objMock.getAttribute.mockResolvedValueOnce('some value');
        objMock.getValue.mockResolvedValueOnce('some value');
        await multiRemoteCheck.checkContainsAnyText.call({ currentInstance: currentInstanceMock }, 'selector', 'expected text', true, 'SelectorName');
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getValue).not.toHaveBeenCalled();
        expect(() => multiRemoteCheck.checkContainsAnyText).not.toThrow();
    });

    it('should verify if selector contains expected text when attribute value is empty string', async () => {
        objMock.getAttribute.mockResolvedValueOnce('');
        objMock.getText.mockResolvedValueOnce('expected text here');
        await multiRemoteCheck.checkContainsAnyText.call({ currentInstance: currentInstanceMock }, 'selector', 'expected text', false, 'SelectorName');
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getText).toHaveBeenCalled();
        expect(() => multiRemoteCheck.checkContainsAnyText).not.toThrow();
    });

    it('should verify if selector does not contain expected text when attribute value is empty string and falseCase is true', async () => {
        objMock.getAttribute.mockResolvedValueOnce('');
        objMock.getText.mockResolvedValueOnce('some other text');
        await multiRemoteCheck.checkContainsAnyText.call({ currentInstance: currentInstanceMock }, 'selector', 'expected text', true, 'SelectorName');
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getText).toHaveBeenCalled();
        expect(() => multiRemoteCheck.checkContainsAnyText).not.toThrow();
    });
});