import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkOffset', () => {
    let currentInstanceMock;
    let objMock;

    beforeEach(() => {
        objMock = {
            getLocation: jest.fn()
        };
        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });

    it('checkOffset : true', async () => {
        objMock.getLocation.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkOffset.call({ currentInstance: currentInstanceMock }, '#selector', '1080', '1020', 'selectorName', true);
        expect(objMock.getLocation).toHaveBeenCalled();
    });

    it('checkOffset : false', async () => {
        objMock.getLocation.mockResolvedValueOnce(false);
        await multiRemoteCheck.checkOffset.call({ currentInstance: currentInstanceMock }, '#selector', '1080', '1020', 'selectorName', false);
        expect(objMock.getLocation).toHaveBeenCalled();
    });
});