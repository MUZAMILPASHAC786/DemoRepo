import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('isDisplayed', () => {
    let currentInstanceMock;
    let objMock;
 
    beforeEach(() => {
        objMock = {
            isDisplayed: jest.fn()
        };
 
        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });
 
    it('should verify if the element is displayed', async () => {
        objMock.isDisplayed.mockResolvedValueOnce(true);
        await multiRemoteCheck.isDisplayed.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isDisplayed).toHaveBeenCalled();
    });
 
    it('should verify if the element is not displayed when falseCase is true', async () => {
        objMock.isDisplayed.mockResolvedValueOnce(false);
        await multiRemoteCheck.isDisplayed.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isDisplayed).toHaveBeenCalled();
    });
});