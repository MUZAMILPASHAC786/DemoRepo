import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('isEnabled', () => {
    let currentInstanceMock;
    let objMock;
 
    beforeEach(() => {
        objMock = {
            isEnabled: jest.fn()
        };
 
        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });
 
    it('should verify if the element is enabled', async () => {
        objMock.isEnabled.mockResolvedValueOnce(true);
        await multiRemoteCheck.isEnabled.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(objMock.isEnabled).toHaveBeenCalled();
    });
 
    it('should verify if the element is not enabled when falseCase is true', async () => {
        let selector = '$selector'
        objMock.isEnabled.mockResolvedValueOnce(false);
        await multiRemoteCheck.isEnabled.call({ currentInstance: currentInstanceMock }, selector, 'SelectorName', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith(selector);
        expect(objMock.isEnabled).toHaveBeenCalled();
    });
});