import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkURL', () => {
    let currentInstanceMock;
    let mockContext;

    beforeEach(() => {
        currentInstanceMock = {
            getUrl: jest.fn()
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('checkURL : true', async () => {
        currentInstanceMock.getUrl.mockResolvedValueOnce('https://www.google.com/');
        await multiRemoteCheck.checkURL.call(mockContext, 'https://www.google.com/', 'Google', true);
        expect(currentInstanceMock.getUrl).toHaveBeenCalled();
    });

    it('checkURL : false', async () => {
        currentInstanceMock.getUrl.mockResolvedValueOnce('https://www.google.com/test');
        await multiRemoteCheck.checkURL.call(mockContext, 'https://www.google.com/', 'Google', false);
        expect(currentInstanceMock.getUrl).toHaveBeenCalled();
    });
});