import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

const mockSelectorInstance = {
    getAttribute: jest.fn(),
    getText: jest.fn()
};

const mockCurrentInstance = {
    selector: mockSelectorInstance,
    $: jest.fn().mockReturnValue(mockSelectorInstance)
};

const mockContext = {
    currentInstance: mockCurrentInstance
};

describe('multiRemoteCheck', () => {

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('checkClass : have class attribute', async () => {
        mockSelectorInstance.getAttribute.mockResolvedValue('someClass anotherClass');
        const selector = '.some-selector';
        const expectedClassValue = 'someClass';
        const selectorName = 'some-selector';
        const expectedResult = true;
        const result = await multiRemoteCheck.checkClass.call(mockContext, selector, expectedClassValue, selectorName, expectedResult);
        expect(mockCurrentInstance.$).toHaveBeenCalledWith(selector);
        expect(mockSelectorInstance.getAttribute).toHaveBeenCalledWith('class');
        expect(result).toBe('someClass anotherClass');
    });

    test('checkClass: doesnot have class attribute', async () => {
        mockSelectorInstance.getAttribute.mockResolvedValue('anotherClass');
        const selector = '.some-selector';
        const expectedClassValue = 'someClass';
        const selectorName = 'some-selector';
        const expectedResult = false;
        const result = await multiRemoteCheck.checkClass.call(mockContext, selector, expectedClassValue, selectorName, expectedResult);
        expect(mockCurrentInstance.$).toHaveBeenCalledWith(selector);
        expect(mockSelectorInstance.getAttribute).toHaveBeenCalledWith('class');
        expect(result).toBe('anotherClass');
    });
})