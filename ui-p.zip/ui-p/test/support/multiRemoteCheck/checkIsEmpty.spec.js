import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('CheckIsEmpty', () => {
    let currentInstanceMock;
    let objMock;

    beforeEach(() => {
        objMock = {
            getAttribute: jest.fn(),
            getValue: jest.fn(),
            getText: jest.fn()
        };

        currentInstanceMock = {
            $: jest.fn(() => objMock),
            selector: objMock
        };
    });

    it('should verify if selector is empty when attribute value is null', async () => {
        objMock.getAttribute.mockResolvedValueOnce(null);
        objMock.getText.mockResolvedValueOnce('');
        const result = await multiRemoteCheck.checkIsEmpty.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getText).toHaveBeenCalled();
        expect(result).toBe('');
    });

    it('should verify if selector is not empty when attribute value is not empty', async () => {
        objMock.getAttribute.mockResolvedValueOnce('not empty');
        objMock.getValue.mockResolvedValueOnce('some value');
        const result = await multiRemoteCheck.checkIsEmpty.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getValue).toHaveBeenCalled();
        expect(result).toBe('some value');
    });

    it('should verify if selector is empty when attribute value is empty string', async () => {
        objMock.getAttribute.mockResolvedValueOnce('');
        objMock.getText.mockResolvedValueOnce('');
        const result = await multiRemoteCheck.checkIsEmpty.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', true);
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getText).toHaveBeenCalled();
        expect(result).toBe('');
    });

    it('should verify if selector is not empty when attribute value is empty string and falseCase is false', async () => {
        objMock.getAttribute.mockResolvedValueOnce('');
        objMock.getText.mockResolvedValueOnce('not empty');
        const result = await multiRemoteCheck.checkIsEmpty.call({ currentInstance: currentInstanceMock }, 'selector', 'SelectorName', false);
        expect(objMock.getAttribute).toHaveBeenCalledWith('value');
        expect(objMock.getText).toHaveBeenCalled();
        expect(result).toBe('not empty');
    });
});