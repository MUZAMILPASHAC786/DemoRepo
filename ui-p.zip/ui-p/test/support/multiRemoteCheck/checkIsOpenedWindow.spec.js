import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkIsOpenedInNewWindow', () => {
    let currentInstanceMock;

    beforeEach(() => {
        currentInstanceMock = {
            getWindowHandles: jest.fn(),
            switchToWindow: jest.fn(),
            getUrl: jest.fn(),
            closeWindow: jest.fn()
        };
    });

    it('should verify if a new window is opened with the correct URL', async () => {
        const windowHandles = ['window1', 'window2'];
        currentInstanceMock.getWindowHandles.mockResolvedValueOnce(windowHandles);
        currentInstanceMock.getUrl.mockResolvedValueOnce('https://example.com/page');

        await multiRemoteCheck.checkIsOpenedInNewWindow.call({ currentInstance: currentInstanceMock }, 'example.com/page');

        expect(currentInstanceMock.getWindowHandles).toHaveBeenCalled();
        expect(currentInstanceMock.switchToWindow).toHaveBeenCalledWith('window2');
        expect(currentInstanceMock.getUrl).toHaveBeenCalled();
        expect(currentInstanceMock.closeWindow).toHaveBeenCalled();
    });
});