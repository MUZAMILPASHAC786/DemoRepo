import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkProperty', () => {
    let currentInstanceMock;
    let elementMock;
    let mockContext;

    beforeEach(() => {
        elementMock = {
            getCSSProperty: jest.fn(),
            getAttribute: jest.fn()
        };

        currentInstanceMock = {
            $: jest.fn(() => elementMock)
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('should validate the CSS property correctly', async () => {
        elementMock.getCSSProperty.mockResolvedValueOnce({ value: 'red' });
        await multiRemoteCheck.checkProperty.call(mockContext, true, 'selector', 'color', '100px', 'Selector Name', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getCSSProperty).toHaveBeenCalledWith('color');
    });

    it('should validate the attribute correctly', async () => {
        elementMock.getAttribute.mockResolvedValueOnce('value');
        await multiRemoteCheck.checkProperty.call(mockContext, false, 'selector', 'attrName', 'value', 'Selector Name', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getAttribute).toHaveBeenCalledWith('attrName');
    });

    it('should handle falseCase correctly for CSS property when values do not match', async () => {
        elementMock.getCSSProperty.mockResolvedValueOnce({ value: '200px' });
        await multiRemoteCheck.checkProperty.call(mockContext, true, 'selector', 'width', '100px', 'Selector Name', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getCSSProperty).toHaveBeenCalledWith('width');
    });

    it('should handle falseCase correctly for attribute when values do not match', async () => {
        elementMock.getAttribute.mockResolvedValueOnce('differentValue');
        await multiRemoteCheck.checkProperty.call(mockContext, false, 'selector', 'attrName', 'value', 'Selector Name', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
        expect(elementMock.getAttribute).toHaveBeenCalledWith('attrName');
    });
});