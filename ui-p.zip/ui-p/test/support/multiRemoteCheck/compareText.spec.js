import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('compareText', () => {
    let currentInstanceMock;
    let elementMock1;
    let elementMock2;
    let mockContext;

    beforeEach(() => {
        elementMock1 = {
            getText: jest.fn()
        };

        elementMock2 = {
            getText: jest.fn()
        };

        currentInstanceMock = {
            $: jest.fn((selector) => {
                if (selector === 'selector1') {
                    return elementMock1;
                } else if (selector === 'selector2') {
                    return elementMock2;
                }
            })
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('compareText: when texts are equal', async () => {
        elementMock1.getText.mockResolvedValueOnce('Text1');
        elementMock2.getText.mockResolvedValueOnce('Text1');
        const result = await multiRemoteCheck.compareText.call(mockContext, 'selector1', 'selector2');
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector1');
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector2');
        expect(elementMock1.getText).toHaveBeenCalled();
        expect(elementMock2.getText).toHaveBeenCalled();
        expect(result).toBe(true);
    });

    it('compareText: when texts are not equal', async () => {
        elementMock1.getText.mockResolvedValueOnce('Text1');
        elementMock2.getText.mockResolvedValueOnce('Text2');
        const result = await multiRemoteCheck.compareText.call(mockContext, 'selector1', 'selector2');
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector1');
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector2');
        expect(elementMock1.getText).toHaveBeenCalled();
        expect(elementMock2.getText).toHaveBeenCalled();
        expect(result).toBe(false);
    });

    it('compareText : true when texts are equal', async () => {
        elementMock1.getText.mockResolvedValueOnce('Text1');
        elementMock2.getText.mockResolvedValueOnce('Text1');
        const result = await multiRemoteCheck.compareText.call(mockContext, 'selector1', 'selector2', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector1');
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector2');
        expect(elementMock1.getText).toHaveBeenCalled();
        expect(elementMock2.getText).toHaveBeenCalled();
        expect(result).toBe(true);
    });

    it('compareText: false when texts are not equal', async () => {
        elementMock1.getText.mockResolvedValueOnce('Text1');
        elementMock2.getText.mockResolvedValueOnce('Text2');
        const result = await multiRemoteCheck.compareText.call(mockContext, 'selector1', 'selector2', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector1');
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector2');
        expect(elementMock1.getText).toHaveBeenCalled();
        expect(elementMock2.getText).toHaveBeenCalled();
        expect(result).toBe(false);
    });
});