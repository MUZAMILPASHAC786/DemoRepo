import multiRemoteCheck from '../../../src/support/multiRemoteCheck';

describe('checkWithinViewport', () => {
    let currentInstanceMock;
    let elementMock;
    let mockContext;

    beforeEach(() => {
        elementMock = {
            isDisplayedInViewport: jest.fn()
        };

        currentInstanceMock = {
            $: jest.fn(() => elementMock)
        };

        mockContext = {
            currentInstance: currentInstanceMock
        };
    });

    it('checkWithinViewport: true', async () => {
        elementMock.isDisplayedInViewport.mockResolvedValueOnce(true);
        await multiRemoteCheck.checkWithinViewport.call(mockContext, 'selector', 'Selector Name', true);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
    });

    it('checkWithinViewport : false', async () => {
        elementMock.isDisplayedInViewport.mockResolvedValueOnce(false);
        await multiRemoteCheck.checkWithinViewport.call(mockContext,'selector', 'Selector Name', false);
        expect(currentInstanceMock.$).toHaveBeenCalledWith('selector');
    });
});