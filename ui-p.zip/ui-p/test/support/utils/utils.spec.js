import utils from "../../../src/support/utils";

describe('utils', () => {

    it('filterJsonArray', async () => {
        const mockfn = jest.fn(await utils.filterJsonArray(['anyValue1', 'anyValue2', 'anyValue3'], 'anyValue2'))
        mockfn.mockImplementation(() => { })
        mockfn(['anyValue1', 'anyValue2', 'anyValue3'], 'anyValue2')
        expect(mockfn).toHaveBeenCalled()
        expect(mockfn).toHaveBeenCalledTimes(1)
        expect(mockfn).toHaveBeenCalledWith(['anyValue1', 'anyValue2', 'anyValue3'], 'anyValue2')
    });

})