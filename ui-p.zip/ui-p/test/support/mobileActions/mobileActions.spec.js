import mobileActions from "../../../src/support/mobileActions";

const scrolling = jest.fn();
let isDisplayedMock;

describe('mobileActions', () => {

    beforeEach(() => {
        global.browser = {
            getWindowSize: jest.fn(),
            touchAction: jest.fn(),
        };
        isDisplayedMock = jest.fn();
        global.$ = jest.fn().mockReturnValue({
            isDisplayed: isDisplayedMock,
        });;
    });

    it('scrolling : left', async () => {
        global.browser.getWindowSize.mockResolvedValue({ width: 1000, height: 500 });
        await mobileActions.scrolling('left');
        expect(global.browser.getWindowSize).toHaveBeenCalled();
        expect(global.browser.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 900, y: 250 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 100, y: 250 },
            'release',
        ]);
        expect(global.info).toHaveBeenCalled();
    });

    it('scrolling : right', async () => {
        global.browser.getWindowSize.mockResolvedValue({ width: 1000, height: 500 });
        await mobileActions.scrolling('right');
        expect(global.browser.getWindowSize).toHaveBeenCalled();
        expect(global.browser.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 100, y: 250 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 900, y: 250 },
            'release',
        ]);
        expect(global.info).toHaveBeenCalled();
    });

    it('scrolling : up', async () => {
        global.browser.getWindowSize.mockResolvedValue({ width: 1000, height: 500 });
        await mobileActions.scrolling('up');
        expect(global.browser.getWindowSize).toHaveBeenCalled();
        expect(global.browser.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 500, y: 50 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 500, y: 450 },
            'release',
        ]);
        expect(global.info).toHaveBeenCalled();
    });

    it('scrolling : down', async () => {
        global.browser.getWindowSize.mockResolvedValue({ width: 1000, height: 500 });
        await mobileActions.scrolling('down');
        expect(global.browser.getWindowSize).toHaveBeenCalled();
        expect(global.browser.touchAction).toHaveBeenCalledWith([
            { action: 'press', x: 500, y: 450 },
            { action: 'wait', ms: 2000 },
            { action: 'moveTo', x: 500, y: 50 },
            'release',
        ]);
        expect(global.info).toHaveBeenCalled();
    });

    it('should log an error if an invalid direction is given', async () => {
        const invalidDirection = 'diagonal';
        const errorMessage = `Unable to scroll to the ${invalidDirection}`;

        try {
            await mobileActions.scrolling(invalidDirection);
        } catch (error) {
            expect(global.warn).toHaveBeenCalledWith(expect.stringContaining('Cannot read property'));
            expect(global.error).toHaveBeenCalledWith(errorMessage);
        }
    });

    it('should scroll until the element is visible', async () => {
        const selector = 'mock-selector';
        const selectorName = 'Mock Element';
        isDisplayedMock.mockResolvedValueOnce(false)
            .mockResolvedValueOnce(false)
            .mockResolvedValueOnce(true);
        await mobileActions.scrollToElement.call({ scrolling }, selector, selectorName);;
        expect(global.info).toHaveBeenCalled();
        expect(isDisplayedMock).toHaveBeenCalledTimes(3);
        expect(scrolling).toHaveBeenCalledTimes(2);
    });

    it('should log an error if unable to scroll to the element', async () => {
        const selector = 'mock-selector';
        const selectorName = 'Mock Element';
        const errorMessage = 'Test Error';
        isDisplayedMock.mockRejectedValue(new Error(errorMessage));
        await mobileActions.scrollToElement.call({ scrolling }, selector, selectorName);
        expect(global.info).toHaveBeenCalled();
        expect(global.error).toHaveBeenCalled();
    });

    it('calendarScroll', async () => {
        const mockfn = jest.fn(await mobileActions.calendarScroll('Year calendar'))
        await mockfn('Year calendar')
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith('Year calendar');
    });

    it('calendarScroll : error', async () => {
        global.$ = $;
        const errorMessage = 'Scroll failed';
        $.mockRejectedValueOnce(new Error(errorMessage));
        await mobileActions.calendarScroll('Test Calendar');
        expect(global.info).toHaveBeenCalled();
        expect($).toHaveBeenCalledWith('android=new UiScrollable(new UiSelector().scrollable(true)).scrollBackward()');
        expect(global.error).toHaveBeenCalled();
    });

    it('startActivity', async () => {
        const mockfn = jest.fn(await mobileActions.startActivity('com.android.chrome', 'com.google.android.apps.chrome.Main', 'Chrome home Page'))
        await mockfn('com.android.chrome', 'com.google.android.apps.chrome.Main', 'Chrome home Page')
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith('com.android.chrome', 'com.google.android.apps.chrome.Main', 'Chrome home Page');
    });

    it('switchContext', async () => {
        const mockfn = jest.fn(await mobileActions.switchContext('WEBVIEW_chrome'))
        await mockfn('WEBVIEW_chrome')
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith('WEBVIEW_chrome');
    });

    it('getContexts', async () => {
        const mockfn = jest.fn(await mobileActions.getContexts())
        await mockfn()
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith();
    });


    it('closeApp', async () => {
        const mockfn = jest.fn(await mobileActions.closeApp())
        await mockfn()
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith();
    });

    it('clickonText', async () => {
        const mockfn = jest.fn(await mobileActions.clickonText('ClaimMyPoints'))
        await mockfn('ClaimMyPoints')
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith('ClaimMyPoints');
    });

    it('scrollToText', async () => {
        const mockfn = jest.fn(await mobileActions.scrollToText('ClaimMyPoints'))
        await mockfn('ClaimMyPoints')
        expect(mockfn).toHaveBeenCalled();
        expect(mockfn).toHaveBeenCalledTimes(1);
        expect(mockfn).toHaveBeenCalledWith('ClaimMyPoints');
    });

    it('scrollToText : error', async () => {
        global.$ = $;
        const errorMessage = 'scrollToText failed';
        $.mockRejectedValueOnce(new Error(errorMessage));
        await mobileActions.scrollToText('ClaimMyPoints');
        expect(global.info).toHaveBeenCalled();
        expect($).toHaveBeenCalledWith('android=new UiScrollable(new UiSelector().scrollable(true)).scrollTextIntoView("ClaimMyPoints")');
        expect(global.error).toHaveBeenCalled();
    });
})