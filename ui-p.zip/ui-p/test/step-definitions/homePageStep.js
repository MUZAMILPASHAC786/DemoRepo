import { Given, When, Then } from '@cucumber/cucumber';
import homePage from '../page-objects/homePageObject';
import datalayer from '../../src/support/actions';
import g4PortalPage from '../page-objects/g4PortalPageObject';
let departureDate;

Given(/^I open the UI application url "([^"]*)"$/, async (url) => {
    await homePage.openURL(url);
});

Then(/^I validate datalayer on "([^"]*)" for "([^"]*)"$/, async (name, value) => {
    let info = { event: 'promotionImpression', booking_channel: 'Home' }; //as an Obj
    //let info = "promotionImpression" //as a string
    let output = await datalayer.getEventsDetails(await datalayer.fetctDataLayer(), info);
    console.log(await output.length, 'matching values');
    console.log(output);
});

Then(/^I open a new window "([^"]*)"$/, async (url) => {
    await homePage.newWindowURL(url);
});

Then(/^I close all but first tab$/, async () => {
    await homePage.closeFirstTab();
});
Then(/^I close all but current tab$/, async () => {
    await homePage.closeCurrentTab();
});
When(/^I click on the button for closing the popup$/, async () => {
    await homePage.popupClosing();
});

Then(/^I select the trip type as one way$/, async () => {
    await homePage.oneway();
});

When(/^I click on the login-button$/, async () => {
    await homePage.loginlink();
});

When(/^I set "([^"]*)" to the inputfield of e-mail$/, async (value) => {
    await homePage.loginlink(value);
});

When(/^I set "([^"]*)" to the inputfield of pwd$/, async (value) => {
    await homePage.pwd(value);
});

Then(/^I click on the sign-in button$/, async () => {
    await homePage.submit();
});

When(/^I select the "([^"]*)" for the origin$/, async (value) => {
    await homePage.selectingorigin(value);
});
When(/^I select the "([^"]*)" for the destination$/, async (value) => {
    await homePage.selectingdestination(value);
});

When(/^I choose the departure date "([^"]*)" days from current day$/, async (number) => {
    departureDate = await homePage.chooseDepartingDate(number);
    await browser.pause(3000);
    console.log('depart date');
});

When(/^I choose the returning date "(.+)" days from departure$/, async (number) => {
    await homePage.chooseReturningDate(number, departureDate);
});

Then(/^I click on the search button$/, async () => {
    await homePage.submithomepage();
    await browser.pause(4000);
});
When(/^I navigate to G4 portal for FMM$/, async function () {
    await g4PortalPage.navigateToG4Fmm();
});
Given(/^I select the "(.+)" application$/, async function (app) {
    await g4PortalPage.selectAppFromG4Portal(app);
});
Given(/^I select Flight Maintenance in new Window$/, async function () {
    await g4PortalPage.selectFlightMaintenance();
});
Given(/^I switch back to G4 Portal$/, async function () {
    await g4PortalPage.switchBackToG4Portal();
});
