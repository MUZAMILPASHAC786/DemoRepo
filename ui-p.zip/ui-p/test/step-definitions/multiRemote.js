import { Given, When, Then } from '@cucumber/cucumber';
import mobileMethods from '../page-objects/multi-Remote';

Given(/^I open allegiant application from the web$/, async () => {
    await mobileMethods.launchWWWApplication();
});

When(/^I close all pop-ups from web app$/, async () => {
    await mobileMethods.popUps();
});

Then(/^I launch the Allegiant mobile app from mobile$/, async () => {
    console.log('Starting tests in Mobile apps ..');
    let device = myMobile.capabilities.platformName;
    if (device.toLowerCase().includes('android')) {
        await mobileMethods.selectEnvironment();
    } else {
        await mobileMethods.iOSValidation();
    }
});
Then(/^I am on homepage I click Add New Trip$/, async () => {
    await mobileMethods.clickAddNewTrip();
});
Then(/^I am on Add New Trip page I Enter First name$/, async () => {
    await mobileMethods.EnterFirstName('QA');
});
Then(/^I hide the keyBoard$/, async () => {
    await mobileMethods.hideTheKeyboard();
});
