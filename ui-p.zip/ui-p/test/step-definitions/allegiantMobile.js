import { Given, Before, Then } from '@cucumber/cucumber'
import mobileMethods from '../page-objects/allegiantMobilePage'

// Before({ tags: "" }, function ({ pickle }) {
//     const scenarioName = pickle.name;
//     console.log("Executing setup for scenario");
//     console.log(` ${scenarioName}`);
//     driver.execute(`lambda =${scenarioName}`);
// });

Given(/^I launch the Allegiant mobile apps$/, async () => {
    console.log("Starting tests in Mobile apps ..");
    await mobileMethods.selectEnvironment();
});

Given(/^I launch Allegiant app in Mobile$/, async () => {
    await mobileMethods.launchingAppinMob();
});

Then(/^I validated the app$/, async () => {
    await mobileMethods.appValidation()
});