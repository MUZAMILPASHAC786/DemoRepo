import qTestAPI from './common/qTestAPI'
import askBearerToken from './common/getCredentials'
import {
    getFiles
} from './utils'
import chalk from 'chalk';
import {schemaValidator} from './common/qTestJsonValidator'
import validateFeatureFile from './common/featureFileValidator'

export const pushTestCasesqTest = async (qTestConfig) => {
    let projectName;
    let folderPath;
    let featurePath;
    let qTestFlag;
    let teamName;
    let endpoint;
    let testCaseID;
    const returnAddTestCaseOutput = {};

    await askBearerToken()
    let bearerResponse = await qTestAPI.passBearerCode(process.env.bearerToken)
    if (bearerResponse) {
        returnAddTestCaseOutput.error = bearerResponse
    } else {
        try {
            let validConfig = await schemaValidator(qTestConfig)
            if (validConfig) {
                throw new Error(`${validConfig} in qTestConfig.json file`)
            }

            for (let i = 0; i < Object.values(qTestConfig).length; i++) {
                projectName = Object.keys(qTestConfig)[i];
                if (projectName === '') {
                    throw new Error(`The project Name is Empty:`)
                }
                console.log(chalk.yellow('qTest Project Name'), projectName);
                for (let j = 0; j < Object.values(qTestConfig)[i].length; j++) {
                    folderPath = Object.values(qTestConfig)[i][j].qTestFolderPath;
                    if (folderPath === '') {
                        throw new Error(`The qTest Folder Path is Empty:`)
                    }
                    console.log(chalk.yellow('qTest folder Path is'), folderPath);

                    featurePath = Object.values(qTestConfig)[i][j].repoFeaturePath;
                    if (featurePath.includes('*')) {
                        throw new Error(`The '*' is Not allowed in feature path!:->${featurePath}`)
                    }

                    const filesList = await getFiles(featurePath);
                    if (!filesList || !filesList.length) {
                        throw new Error(`No feature files found with featurePath: ${featurePath}`);
                    }

                    let validFeature = await validateFeatureFile(featurePath)
                    if (validFeature) {
                        throw new Error(`${validFeature}`)
                    }
                    console.log(chalk.yellow('repo feature Path is'), featurePath);

                    teamName = Object.values(qTestConfig)[i][j].persistenceTeam
                    if (teamName === '') {
                        throw new Error(`The Persistence team Name is Empty:`)
                    }
                    console.log(chalk.yellow('Persistence Team Name is'), teamName);

                    qTestFlag = Object.values(qTestConfig)[i][j].pushToQTest;
                    console.log(chalk.yellow('qTest Flag is'), qTestFlag);

                    let projectID;
                    let folderID;
                    endpoint = 'https://allegiantair.qtestnet.com/api/v3/projects';
                    const responseData = await qTestAPI.getAPI(endpoint);
                    for (let k = 0; k < responseData.length; k++) {
                        if (projectName === responseData[k].name) {
                            projectID = responseData[k].id;
                            console.log(chalk.yellow('projectID'), chalk.green(projectID));
                        }
                    }
                    let folderName;
                    if (projectID !== undefined) {
                        if (folderPath.includes('/')) {
                            folderName = folderPath.split('/');
                            let mainFolderName = folderName[0]
                            if (folderName.length > 1 && folderName[1] !== '') {
                                endpoint = `${'https://allegiantair.qtestnet.com/api/v3/projects/'}${projectID}/modules`;
                                const responseData = await qTestAPI.getAPI(endpoint);
                                responseData.forEach((resName) => {
                                    if (resName.name === mainFolderName) {
                                        folderID = resName.id
                                    }
                                })
                                if (folderID) {
                                    let tempId
                                    console.log(chalk.yellow('Main Folder Id'), chalk.green(folderID));
                                    for (let n = 1; n < folderName.length; n++) {
                                        tempId = folderID
                                        endpoint = `${'https://allegiantair.qtestnet.com/api/v3/projects/'}${projectID}/modules?parentId=${folderID}&size=500`;
                                        const response = await qTestAPI.getAPI(endpoint);
                                        let folderPartName = folderName[n]
                                        for (let res = 0; res < response.length; res++) {
                                            let name = response[res].name
                                            if (folderPartName === name) {
                                                folderID = response[res].id;
                                            }
                                        }
                                    }
                                    if (tempId === folderID) {
                                        throw new Error(`qTestFolderPath: ${folderPath} is incorrect!`)
                                    } else {
                                        console.log(chalk.yellow('Last folder ID'), chalk.green(folderID));
                                    }
                                } else {
                                    throw new Error(`The mainfolderName: ${mainFolderName} is incorrect! in qTestFolderPath: ${folderPath}`);
                                }
                            } else {
                                throw new Error(`Cannot Add TestCases to Main Folder!->${folderPath}`);
                            }
                        } else {
                            throw new Error(`Cannot Add TestCases to Main Folder!->${folderPath}`);
                        }

                        const {
                            finalData,
                            scenarioNames,
                        } = await qTestAPI.getScenariosQtest(featurePath, folderID, projectID, teamName);
                        console.log('scenarioNames from feature file', scenarioNames);

                        endpoint = `${'https://allegiantair.qtestnet.com/api/v3/projects/'}${projectID}/test-cases?parentId=${folderID}&size=500`;
                        const response = await qTestAPI.getAPI(endpoint);
                        const scenarioNamesList = [];
                        for (let x = 0; x < response.length; x++) {
                            scenarioNamesList.push(response[x].name);
                        }
                        console.log('scenarioNames from qTest', scenarioNamesList);

                        for (let y = 0; y < scenarioNames.length; y++) {
                            if (scenarioNamesList.includes(scenarioNames[y])) {
                                if (qTestFlag === true) {
                                    const testCaseName = scenarioNames[y];
                                    console.log('** The Scenario is already Present, Hence updating the TestCase ->', chalk.magenta(testCaseName));
                                    endpoint = `${'https://allegiantair.qtestnet.com/api/v3/projects/'}${projectID}/test-cases?parentId=${folderID}&size=500`;
                                    const testCaseResponse = await qTestAPI.getAPI(endpoint);
                                    const resArray = [];
                                    for (let m = 0; m < testCaseResponse.length; m++) {
                                        if (testCaseName !== undefined || testCaseName !== '') {
                                            if (testCaseName === testCaseResponse[m].name) {
                                                testCaseID = testCaseResponse[m].id;
                                                console.log(chalk.yellow('TestCaseID'), chalk.green(testCaseID));
                                                break;
                                            }
                                        } else {
                                            throw new Error('Test Case Name was not provided!');
                                        }
                                    }
                                    endpoint = `https://allegiantair.qtestnet.com/api/v3/projects/${projectID}/test-cases/${testCaseID}`;
                                    const response = await qTestAPI.updateAPI(endpoint, finalData[y]);
                                    if (response.name) {
                                        resArray.push(response);
                                    } else {
                                        console.log(chalk.red('Test Case doesnt exist!'));
                                        let message = response.message;
                                        if (message.includes("Unrecognized token")) {
                                            throw new Error("Your Token don't have an Access to Modify testcases under the project mentioned")
                                        } else {
                                            throw new Error(message)
                                        }
                                    }
                                    if (resArray.length !== 0) {
                                        for (let p = 0; p < resArray.length; p++) {
                                            endpoint = `https://allegiantair.qtestnet.com/api/v3/projects/${projectID}/test-cases/${resArray[p].id}`;
                                            const response = await qTestAPI.getAPI(endpoint);
                                            if (response.name) {
                                                returnAddTestCaseOutput.result = 'The Test Case is modified in qtest';
                                            } else {
                                                throw new Error('Test Cases was not modified!');
                                            }
                                        }
                                    }
                                } else {
                                    console.log(chalk.red('The Scenario is already Present, But Not Updating the Test Case as Flag is set to false'))
                                }
                            } else {
                                if (qTestFlag === true) {
                                    console.log('** The Scenario is New, Hence Adding the TestCase ->', chalk.magenta(scenarioNames[y]));
                                    endpoint = `https://allegiantair.qtestnet.com/api/v3/projects/${projectID}/test-cases`;
                                    const resArray = [];
                                    const response = await qTestAPI.postAPI(endpoint, finalData[y]);
                                    resArray.push(response);
                                    if (resArray[0].message) {
                                        let message = resArray[0].message
                                        if (message.includes("Unrecognized token")) {
                                            throw new Error("Your Token don't have an Access to Upload/Add testcases under the project mentioned")
                                        } else {
                                            throw new Error(message)
                                        }
                                    }

                                    if (resArray.length !== 0) {
                                        for (let q = 0; q < resArray.length; q++) {
                                            endpoint = `https://allegiantair.qtestnet.com/api/v3/projects/${projectID}/test-cases/${resArray[q].id}`;
                                            const response = await qTestAPI.getAPI(endpoint);
                                            try {
                                                if (response.name) {
                                                    returnAddTestCaseOutput.result = 'The Test Case is Added in qtest';
                                                }
                                            } catch (err) {
                                                throw new Error('Test Cases was not added!');
                                            }
                                        }
                                        returnAddTestCaseOutput.result = 'Added test case(s) to qtest';
                                    } else {
                                        throw new Error(`The folderPath: ${folderPath} is incorrect!`);
                                    }
                                } else {
                                    console.log(chalk.red('The Scenario is New, But Still Not Adding the Test Case as Flag is set to false'))
                                }
                            }
                        }
                    } else {
                        throw new Error(`Project name: ${projectName} was incorrect!`);
                    }
                }
            }
        } catch (err) {
            returnAddTestCaseOutput.error = err.message;
        }
    }
    return returnAddTestCaseOutput;
};