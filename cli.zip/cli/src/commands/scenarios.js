import _ from 'lodash';
import chalk from 'chalk';
import Gherkin from 'gherkin';
import {
    getFeatureInfo,
} from '../utils';
import {
    CLI_EPILOGUE,
} from '../constants';

export const command = 'scenarios';
export const desc = 'Displays all scenarios';

export const cmdArgs = {
    tag: {
        desc: 'List scenarios of a tag',
        type: 'string',
    },
    'not-having-tag': {
        desc: "List scenarios that don't have a specific tag",
        type: 'string',
    },
    path: {
        desc: 'path of specified file',
        type: 'string',
    },

};

export const builder = async (yargs) => {
    yargs.options(cmdArgs).epilogue(CLI_EPILOGUE).help();

    yargs.example('$0 scenarios', 'List all scenarios');
    yargs.example("$0 scenarios --tag='@allegiant'", 'List all scenarios having tag @allegiant');
    yargs.example(
        "$0 scenarios --not-having-tag='@allegiant'",
        "List all scenarios that don't have tag @allegiant",
    );
    yargs.example("$0 scenarios --path='feature/foldername'", 'displays folder');
};

export async function handler(argv) {
    try {
        const featureNameArray = [];
        const sceanrioNameArray = [];
        const allSceanrios = [];
        const featureScenariosAndTags = await getFeatureInfo('features/**/*.feature');
        if (argv.tag) {
            featureScenariosAndTags.forEach((featureInfo) => {
                featureInfo.scenario.forEach((scenarioInfo) => {
                    if (scenarioInfo.scenarioTags.includes(argv.tag)) {
                        sceanrioNameArray.push(scenarioInfo.scenarioName);

                        if (!featureNameArray.includes(featureInfo.featureName)) {
                            featureNameArray.push(featureInfo.featureName);
                        }
                    }
                });
            });
        } else if (argv.notHavingTag) {
            featureScenariosAndTags.forEach((featureInfo) => {
                featureInfo.scenario.forEach((scenarioInfo) => {
                    if (!scenarioInfo.scenarioTags.includes(argv.notHavingTag)) {
                        sceanrioNameArray.push(scenarioInfo.scenarioName);

                        if (!featureNameArray.includes(featureInfo.featureName)) {
                            featureNameArray.push(featureInfo.featureName);
                        }
                    }
                });
            });
        } else {
            featureScenariosAndTags.forEach((featureInfo) => {
                featureNameArray.push(featureInfo.featureName);
                featureInfo.scenario.forEach((scenarioInfo) => {
                    sceanrioNameArray.push(scenarioInfo.scenarioName);
                });
            });
        }

        allSceanrios.push(featureNameArray);
        allSceanrios.push(sceanrioNameArray);

        console.log(allSceanrios);
        const totalFeaturcount = featureNameArray.length;
        const totalScenarios = sceanrioNameArray.length;
        console.log(chalk.cyan(`Total Scenarios count: ${totalScenarios}`));
        console.log(chalk.cyan(`Total Feature count: ${totalFeaturcount}`));
        return totalScenarios;
    } catch (err) {
        console.error(err);
    }
}
