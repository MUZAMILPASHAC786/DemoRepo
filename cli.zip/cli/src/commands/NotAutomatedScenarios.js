import _, {
    forEach,
} from 'lodash';
import chalk from 'chalk';
import Gherkin from 'gherkin';
import {
    getFeatureInfo,
} from '../utils';
import {
    CLI_EPILOGUE,
} from '../constants';

export const command = 'NotAutomatedScenarios';
export const desc = 'Displays all scenarios that are tagged as manual and regression';

export const cmdArgs = {
    NotAutomatedScenarios: {
        desc: 'List scenarios of a tagged as manual and regression',
        type: 'string',
    },

};

export const builder = async (yargs) => {
    yargs.options(cmdArgs).epilogue(CLI_EPILOGUE).help();
    yargs.example('$0 NotAutomatedScenarios', 'List all scenarios that are tagged as Manual and Regression');
};

export async function handler() {
    try {
        const notAutomatedScenarios = [];
        const featureScenariosAndTags = await getFeatureInfo('features/**/*.feature');

        featureScenariosAndTags.forEach((featureInfo) => {
            featureInfo.scenario.forEach((scenarioInfo) => {
                if (featureInfo.featureTags.includes('@manual') && featureInfo.featureTags.includes('@regression')) {
                    notAutomatedScenarios.push(scenarioInfo.scenarioName);
                } else if (featureInfo.featureTags.includes('@manual') && scenarioInfo.scenarioTags.includes('@regression')) {
                    notAutomatedScenarios.push(scenarioInfo.scenarioName);
                } else if (featureInfo.featureTags.includes('@regression') && scenarioInfo.scenarioTags.includes('@manual')) {
                    notAutomatedScenarios.push(scenarioInfo.scenarioName);
                } else if (scenarioInfo.scenarioTags.includes('@manual') && scenarioInfo.scenarioTags.includes('@regression')) {
                    notAutomatedScenarios.push(scenarioInfo.scenarioName);
                }
            });
        });
        console.log(chalk.cyan(`Total Scenarios that are tagged as Manual and Regression: 
   ${notAutomatedScenarios.length}`));
    } catch (err) {
        console.error(err);
    }
}
