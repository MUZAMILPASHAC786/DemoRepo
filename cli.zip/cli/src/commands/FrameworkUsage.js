import { getFiles, streamToArray } from '../utils';

const fs = require('fs');
const { GherkinStreams } = require('@cucumber/gherkin-streams');
const mysql = require('mysql');

export const command = 'FrameworkUsage';
export const desc = 'Generate percentage of using framwork utility like stepdefination for Grafana';
let Vertical = '';
let Domain = '';
let Initiative = '';
let Team = '';
export const builder = async (yargs) => {
    try {
        getPercentage();
    } catch (err) {
        console.error(err);
    }
};

/**
 * StepDefination Reader
 * @returns stepsArary
 */
async function ReadStepDefination() {
    const stepsArary = [];
    const filename = await getFiles('./node_modules/@g4/prova/src/step-definitions/*.js');
    filename.forEach((file) => {
        const files = fs.readFileSync(file, 'UTF-8');
        const lineArray = files.split('\n');
        lineArray.forEach((line) => {
            if (line.includes('Given(') || line.includes('When(') || line.includes('Then(')) {
                const startInd = line.indexOf('/^');
                const endInd = line.indexOf('$/');
                stepsArary.push(line.substring(startInd + 2, endInd));
            }
        });
    });

    return stepsArary;
}

// FeatureFile Reader
async function ReadFeatureFile() {
    const featContentArry = [];
    const options = {
        includeSource: false,
        includeGherkinDocument: false,
        includePickles: true,
    };
    const filesList = await getFiles('features-build/**/*.feature');
    const featureData = await streamToArray(GherkinStreams.fromPaths(filesList, options));
    featureData.forEach((feature) => {
        feature.pickle.steps.forEach((step) => {
            featContentArry.push(step.text);
        });
    });
    return featContentArry;
}

// Function for Validate the regex count 7 ReadFeatureFile
function ValidateRegex(fline, sdsteps) {
    let count = 0;
    fline.forEach((featureLine) => {
        sdsteps.forEach((stepLine) => {
            if (featureLine.match(stepLine)) {
                count++;
            }
        });
    });
    return count;
}

// Reads package.json by default or from infofilepath
function readData() {
    let rawdata;
    let fileExits;
    if (process.env.infofilepath) {
        rawdata = fs.readFileSync(process.env.infofilepath, 'UTF-8');
        fileExits = true;
    } else {
        rawdata = fs.readFileSync('package.json', 'UTF-8');
    }

    const dataInpackage = JSON.parse(rawdata);

    try {
        Vertical = dataInpackage.Vertical;
        Domain = dataInpackage.Domain;
        Team = dataInpackage.Team;
        Initiative = dataInpackage.Initiative;
        if (fileExits) {
            process.env.featurepath = dataInpackage.FeaturesPath;
        }
    } catch (err) {
        console.error(err);
    }
}

async function getPercentage() {
    const sdstep = await ReadStepDefination();
    const fStep = await ReadFeatureFile();
    const matchedCount = ValidateRegex(fStep, sdstep);
    console.log('Total Steps found in Feature files (in features-build folder) :', fStep.length);
    console.log('Total Steps matched with prova step definitions:', matchedCount);
    const percentage = ((matchedCount / fStep.length) * 100).toFixed(4);
    console.log('Framework % Usage : ', `${percentage}%`);
    readData();
    if (process.env.db === 'yes') {
        writeDatabase(Vertical, Domain, Initiative, Team, fStep.length, matchedCount, percentage);
    }
}

// DB Connect and Write Data
function writeDatabase(verticalName, domainName, initiativeName, teamName, featureCount, matchCount, percentage) {
    const connection = mysql.createConnection({
        host: '10.97.41.24',
        user: 'root',
        password: 'LOCKITUP',
        database: 'spaces',
    });
    connection.connect((err) => {
        if (err) {
            return console.log(err);
        }

        // table for Framewor usage
        function updateQuery() {
            const insertQuery = 'INSERT INTO Framework (Vertical, Domain, Team,Initiative, featureCount,matchCount,percentage) VALUES (?,?,?,?,?,?,?)';
            const value = [verticalName, domainName, initiativeName, teamName, featureCount, matchCount, percentage];
            // eslint-disable-next-line no-shadow
            connection.query(insertQuery, value, (err, results) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('New Entry is Made to the FU Database successfully');
                }
                // eslint-disable-next-line no-shadow
                connection.end((err) => {});
            });
        }
        updateQuery();
    });
}
