import spawn from 'cross-spawn';
import chalk from 'chalk';

export const command = 'lint';
export const desc = 'Run eslint';

export const builder = async (yargs) => {
    try {
        console.log(chalk.yellow('Linting files'));

        const env = Object.create(process.env);

        spawn.sync('npm', ['run', 'lint'], {
            stdio: 'inherit',
            env,
        });
    } catch (err) {
        console.error(err);
    }
};
