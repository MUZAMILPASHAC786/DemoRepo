/* eslint-disable indent */
import chalk from 'chalk';
import fs from 'fs';
import { runProvaTestMessage } from '../common/helpers';

export const command = 'results';
export const desc = 'Report Results';

const { Table } = require('console-table-printer');
const xml2js = require('xml2js');
const prettyMilliseconds = require('pretty-ms');

const parser = new xml2js.Parser({ attrkey: 'ATTR' });
const performanceTimes = [];
const allureResultsDir = './allure-results/';
const scenarioStatusCounts = {
    totalScenarios: 0,
    scenariosFailed: 0,
    passed: 0,
    failed: 0,
    skipped: 0,
};

/**
 * Generate the test results
 */
 const generateAllureReportResults = () => {
    if (!fs.existsSync(allureResultsDir)) {
        return runProvaTestMessage('test found');
    }

    fs.readdir(allureResultsDir, (err, files) => {
        if (err) console.log(chalk.red(`Unable to scan directory: ${err}`));

        parseAllureXmlResultsFiles(files);
        generateScenariosFailedPassedTable();
        generatePerformanceTable(performanceTimes);
    });
};

/**
 * Parse Allure XML Result Files
 * @param files
 */
const parseAllureXmlResultsFiles = (files) => {
    files.forEach((file) => {
        if (file.endsWith('xml')) {
            const xmlString = fs.readFileSync(allureResultsDir + file, 'utf8');

            parser.parseString(xmlString, (error, result) => {
                if (error !== null) {
                    return console.log(error);
                }

                const featureName = result['ns2:test-suite'].name[0];
                const featureTestCases = result['ns2:test-suite']['test-cases'][0]['test-case'];

                console.log(chalk.blueBright(`Feature: ${featureName}`));

                parseFeatureFileTestCases(featureTestCases, featureName);
            });
        }
    });
};

/**
 * Parse feature file test cases
 * @param featureTestCases
 * @param featureName
 */
 const parseFeatureFileTestCases = (featureTestCases, featureName) => {
    featureTestCases.forEach((featureTestCasesData) => {
        const scenarioName = featureTestCasesData.name[0];
        const scenarioStatus = featureTestCasesData.ATTR.status;
        const featureTestCaseSteps = featureTestCasesData.steps;
        const performaceTime = featureTestCasesData.ATTR.stop - featureTestCasesData.ATTR.start;

        performanceTimes.push({
            featureName,
            scenario: scenarioName,
            time: performaceTime,
            status: scenarioStatus,
        });

        scenarioStatusCounts.totalScenarios += 1;

        console.log(
            chalk.greenBright(
                `Scenario: ${scenarioName} (Execution time - ${prettyMilliseconds(
                    performaceTime,
                )})`,
            ),
        );

        parseFeatureFileTestCaseSteps(featureTestCaseSteps);
        generateScenariosStatusCountsTable();

        console.log('\n');
    });
};

/**
 * Parse feature file test case steps
 * @param featureTestCaseSteps
 */
const parseFeatureFileTestCaseSteps = (featureTestCaseSteps) => {
    featureTestCaseSteps.forEach((featureTestCaseStepsData) => {
        const scenarioSteps = featureTestCaseStepsData.step;

        parseScenarioSteps(scenarioSteps);
    });
};

const parseScenarioSteps = (scenarioSteps) => {
    let hasScenarioFailed = false;

    scenarioSteps.forEach((scenarioStepsData) => {
        const scenarioStepName = scenarioStepsData.name[0];
        let scenarioStepStatus = scenarioStepsData.ATTR.status;
        const performaceTime = scenarioStepsData.ATTR.stop - scenarioStepsData.ATTR.start;
        const stepFailed = updateScenariosStatusCounts(scenarioStepStatus);
        if (stepFailed && !hasScenarioFailed) {
            hasScenarioFailed = true;
            scenarioStatusCounts.scenariosFailed += 1;
        }

        scenarioStepStatus = setScenarioStepStatus(scenarioStepStatus);

        console.log(
            scenarioStepName,
            `(${scenarioStepStatus} ${prettyMilliseconds(performaceTime)})`,
        );
    });
};

/**
 * Sets the scenario step status with color
 * @param scenarioStepStatus
 */
export const setScenarioStepStatus = (scenarioStepStatus) => {
    scenarioStepStatus =
        scenarioStepStatus === 'passed'
            ? chalk.green(scenarioStepStatus)
            : scenarioStepStatus === 'skipped'
            ? chalk.yellow(scenarioStepStatus)
            : scenarioStepStatus === 'failed'
            ? chalk.red(scenarioStepStatus)
            : scenarioStepStatus === 'broken'
            ? chalk.red('failed')
            : scenarioStepStatus === 'canceled'
            ? chalk.yellow('skipped')
            : chalk.blue(scenarioStepStatus);
    return scenarioStepStatus;
};

/**
 * updates the scenario status counts {scenarioStatusCounts} i.e {passed: 1, failed: 0, skipped: 0}
 * @param scenarioStepStatus
 */
export const updateScenariosStatusCounts = (scenarioStepStatus) => {
    if (scenarioStepStatus === 'passed') {
        scenarioStatusCounts.passed += 1;
    } else if (scenarioStepStatus === 'failed' || scenarioStepStatus === 'broken') {
        scenarioStatusCounts.failed += 1;
        return true;
    } else if (scenarioStepStatus === 'skipped' || scenarioStepStatus === 'canceled') {
        scenarioStatusCounts.skipped += 1;
    }
    return false;
};

export const generatePerformanceTable = (times) => {
    const passedScenarios = times
        .filter((t) => t.status === 'passed')
        .sort((a, b) => (a.time > b.time ? 1 : -1));

    if (passedScenarios.length > 0) {
        const slowFastDeatailsTable = new Table();
        const passedDetailsTable = new Table();
        const min = passedScenarios.reduce((res, obj) => (obj.time < res.time ? obj : res));
        const max = passedScenarios.reduce((res, obj) => (obj.time > res.time ? obj : res));

        console.log(
            `=========================================\n=== ${chalk.blueBright(
                'Scenarios Fastest/Slowest Summary',
            )} ===\n=========================================`,
        );

        slowFastDeatailsTable.addRow({
            'Feature File': min.featureName,
            'Scenario Name': min.scenario,
            'Execution Time': prettyMilliseconds(min.time),
        });

        if (min !== max) {
            slowFastDeatailsTable.addRow({
                'Feature File': max.featureName,
                'Scenario Name': max.scenario,
                'Execution Time': prettyMilliseconds(max.time),
            });
        }

        slowFastDeatailsTable.printTable();

        console.log(
            `=========================================\n=== ${chalk.blueBright(
                'Scenarios passed Summary',
            )} ===\n=========================================`,
        );

        passedScenarios.forEach((scenario) => {
            passedDetailsTable.addRow({
                'Feature File': scenario.featureName,
                'Scenario Name': scenario.scenario,
                'Execution Time': prettyMilliseconds(scenario.time),
            });
        });

        passedDetailsTable.printTable();
    } else {
        console.log('All Scenarios failed. Slowest/Fastest cant be calculate');
    }
};

/**
 * Generates the results for the scenario steps passed/failed/skipped
 */
 const generateScenariosStatusCountsTable = () => {
    const statusCountsTable = new Table();
    statusCountsTable.addRow(
        { steps: 'Passed', count: scenarioStatusCounts.passed },
        { color: 'green' },
    );
    statusCountsTable.addRow(
        { steps: 'Failed', count: scenarioStatusCounts.failed },
        { color: 'red' },
    );
    statusCountsTable.addRow(
        { steps: 'Skipped', count: scenarioStatusCounts.skipped },
        { color: 'yellow' },
    );
    statusCountsTable.printTable();

    scenarioStatusCounts.skipped = 0;
    scenarioStatusCounts.passed = 0;
    scenarioStatusCounts.failed = 0;
};

/**
 * Generates the final results table for scenarios total/passed/failed
 */
 const generateScenariosFailedPassedTable = () => {
    const failedPassedTable = new Table();

    console.log(
        `=========================================\n==== ${chalk.blueBright(
            'Scenarios Passed/Failed Summary',
        )} ====\n=========================================`,
    );

    failedPassedTable.addRow({
        'Total Scenarios': scenarioStatusCounts.totalScenarios,
        'Scenarios Passed':
            scenarioStatusCounts.totalScenarios - scenarioStatusCounts.scenariosFailed,
        'Scenarios Failed': scenarioStatusCounts.scenariosFailed,
    });
    failedPassedTable.printTable();
};

/**
 * Invokes the method that generates the report results that was selected.
 */
export const builder = async () => {
    try {
        generateAllureReportResults();
    } catch (err) {
        console.error(err);
    }
};
