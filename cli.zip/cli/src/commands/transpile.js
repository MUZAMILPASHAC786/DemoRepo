import provaGherkinExtensions from '@g4/prova-gherkin-extensions';

export const command = 'transpile';
export const desc = 'Transpile feature files based on Prova Gherkin Extensions';

export const builder = async (yargs) => {
    try {
        await provaGherkinExtensions.run();
    } catch (err) {
        console.error(err);
    }
};
