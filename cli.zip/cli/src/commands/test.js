import spawn from 'cross-spawn';
import chalk from 'chalk';
import {
    deleteDirectory,
} from '../common/helpers';

export const command = 'test';
export const desc = 'Run tests';

export const builder = async (yargs) => {
    try {
        console.log(chalk.yellow('Running tests'));

        deleteDirectory('./allure-results');
        deleteDirectory('./allure-report');
        deleteDirectory('./cucumberJs-results');
        deleteDirectory('./cucumberJs-report');

        const env = Object.create(process.env);

        spawn.sync('npm', ['run', 'test'], {
            stdio: 'inherit',
            env,
        });
    } catch (err) {
        console.error(err);
    }
};
