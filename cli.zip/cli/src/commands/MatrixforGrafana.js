import {
    table,
} from 'table';
import chalk from 'chalk';
import { getFeatureInfo } from '../utils';

const fs = require('fs');
const mysql = require('mysql');

const propertiesToJSON = require('properties-to-json');

export const command = 'MatrixforGrafana';
export const desc = 'Generate reports for Grafana';

let Vertical = '';
let Domain = '';
let Initiative = '';
let Team = '';
let Sccount = 0;
let Fccount = 0;
let Account = 0;
let Manuccount = 0;
let lowRoiccount = 0;
let highlyComplexccount = 0;
let testDataccount = 0;
let webContentccount = 0;
let missingInfraccount = 0;
let automationDeferredccount = 0;
let secondaryuntaggedccount = 0;
let regressionccount = 0;
let regressionManualccount = 0;
let regressionAutomatedccount = 0;
let Wscount = 0;
let appEndOfLifecount = 0;
let disabledcount = 0;
let deprecatedcount = 0;
let obsoletecount = 0;
let libraryUpgrade = true;
// Reads package.json by default or from infofilepath
function readData() {
    let rawdata;
    let fileExits;
    if (process.env.infofilepath) {
        rawdata = fs.readFileSync(process.env.infofilepath, 'UTF-8');
        fileExits = true;
    } else if (process.env.infoPropertiesName) {
        const infoPropertiesData = fs.readFileSync(process.env.infoPropertiesName, 'UTF-8');
        rawdata = JSON.stringify(propertiesToJSON(infoPropertiesData));
    } else {
        rawdata = fs.readFileSync('package.json', 'UTF-8');
    }

    const dataInpackage = JSON.parse(rawdata);

    try {
        Vertical = dataInpackage.Vertical;
        Domain = dataInpackage.Domain;
        Team = dataInpackage.Team;
        Initiative = dataInpackage.Initiative;
        if (fileExits) {
            process.env.featurepath = dataInpackage.FeaturesPath;
        } else {
            process.env.featurepath = 'features/**/*.feature';
        }
    } catch (err) {
        console.error(err);
    }
}

function readPackageFile() {
    let packageData;

    const fileExist = fs.existsSync('package.json');

    if (fileExist) {
        console.log(
            `${chalk.green('package.json')} file exists, Hence checking Project is Prova-UI`,
        );
        const pkgData = fs.readFileSync('package.json', 'UTF-8');
        packageData = JSON.parse(pkgData);
        const packageFileDependencies = packageData.dependencies;

        const provaLib = packageFileDependencies['@g4/prova'];

        if (provaLib !== undefined) {
            console.log(
                `This current project is using PROVA Library with ${chalk.red(provaLib)} as version`,
                `${chalk.red('WARNING')} Kindly Migrate to PROVA-UI`,
            );
            libraryUpgrade = false;
        }
    } else {
        console.log(
            `${chalk.red('package.json')} file does not exists`,
        );
    }
}

// DB Connect and Write Data
function writeCucumberTableDatabase() {
    const connection = mysql.createConnection({
        host: '10.97.41.24',
        user: 'root',
        password: 'LOCKITUP',
        database: 'spaces',
    });
    connection.connect((err) => {
        if (err) {
            return console.log(err);
        }

        function updateQueryForCucumberTable() { // Updating values for CucumberTable
            const insertQuery = 'INSERT INTO table_cucumberdata (Vertical,Domain,Initiative,Team,FeatureCount,ScenarioCount,AutomatedScenario,ManualTaggedScenario) VALUES (?,?,?,?,?,?,?,?)';
            const value = [Vertical, Domain, Initiative, Team, Fccount, Sccount, Account, Manuccount];
            // eslint-disable-next-line no-shadow
            connection.query(insertQuery, value, (err, results) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('New Entry is Made to Database successfully');
                }
                // eslint-disable-next-line no-shadow
                connection.end((err) => { });
            });
        }
        // updateQueryForCucumberTable(); //commented for new runtime parameter

        function updateQueryForManualCucumberTable() {
            const insertQuery = 'INSERT INTO manualtag_CucumberData (Vertical,Domain,Initiative,Team,is_provaui,highly_complex,low_roi,test_data_limitations,web_content,missing_infra,app_end_of_life,automation_deferred,disable,deprecated,obsolete,secondary_untagged_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
            const value = [Vertical, Domain, Initiative, Team, libraryUpgrade, highlyComplexccount, lowRoiccount, testDataccount, webContentccount, missingInfraccount, appEndOfLifecount, automationDeferredccount, disabledcount, deprecatedcount, obsoletecount, secondaryuntaggedccount];
            // eslint-disable-next-line no-shadow
            connection.query(insertQuery, value, (err, results) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('New Entry is Made to the Manual Database successfully');
                }
                // eslint-disable-next-line no-shadow
                connection.end((err) => { });
            });
        }
        // updateQueryForManualCucumberTable(); //commented for new runtime parameter

        // table for WS
        function updateQueryForWebServicesTable() {
            const insertQuery = 'INSERT INTO table_webservicedata (Vertical,Domain,Initiative,Team,FeatureCount,ScenarioCount,Wscount) VALUES (?,?,?,?,?,?,?)';
            const value = [Vertical, Domain, Initiative, Team, Fccount, Sccount, Wscount];
            // eslint-disable-next-line no-shadow
            connection.query(insertQuery, value, (err, results) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('New Entry is Made to the WS Database successfully');
                }
                // eslint-disable-next-line no-shadow
                connection.end((err) => { });
            });
        }

        // Condition to control API and UI matrix
        if (process.env.ws === 'yes') {
            updateQueryForWebServicesTable();
        } else {
            updateQueryForCucumberTable();
            updateQueryForManualCucumberTable();
            updateQueryForRegressionCucumberTable();
        }

        function updateQueryForRegressionCucumberTable() {
            const insertQuery = 'INSERT INTO table_regressioncucumberdata (Vertical,Domain,Initiative,Team,FeatureCount,ScenarioCount,RegressionScenariosCount,AutomatedRegressionScenarios,ManualRegressionScenarios) VALUES (?,?,?,?,?,?,?,?,?)';
            const value = [Vertical, Domain, Initiative, Team, Fccount, Sccount, regressionccount, regressionAutomatedccount, regressionManualccount];
            // eslint-disable-next-line no-shadow
            connection.query(insertQuery, value, (err, results) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('New Entry is Made to the Regression Database successfully');
                }
                // eslint-disable-next-line no-shadow
                connection.end((err) => { });
            });
        }
        // updateQueryForRegressionCucumberTable(); //commented for new runtime parameter
    });
}
export const builder = async () => {
    readData();
    readPackageFile();
    const tagCountMap = [
        ['Vertical', 'Domain', 'Initiative', 'Team', 'FeatureCount', 'ScenarioCount', 'AutomatedScenario', 'ManualTaggedCount', 'Wscount'],
    ];
    const manualTagCountMap = [
        ['Vertical', 'Domain', 'Initiative', 'Team', '@highly-\ncomplex', '@low-\nroi', '@test-\ndata-\nlimitations', '@web-\ncontent', '@missing-\ninfra', '@automation-\ndeferred', '@secondary_\nuntagged_count'],
    ];
    const regressionTagCountMap = [
        ['Vertical', 'Domain', 'Initiative', 'Team', 'FeatureCount', 'Scenario\nCount', 'Regression\nScenariosCount', 'Automated\nRegressionScenarios', 'Manual\nRegressionScenarios'],
    ];

    const wsCountMap = [
        ['Vertical', 'Domain', 'Initiative', 'Team', 'FeatureCount', 'Scenario\nCount', 'Wscount'],
    ];
    const endOfLifeMap = [['Vertical', 'Domain', 'Initiative', 'Team', '@app-\nend-of-life', '@disabled', '@deprecated', '@obsolete']];
    const LibraryUpgradeMap = [['Vertical', 'Domain', 'Initiative', 'Team', 'libraryUpgrade']];
    const featureScenariosAndTags = await getFeatureInfo(process.env.featurepath);

    // get feature count
    Fccount = featureScenariosAndTags.length;

    // get scenario count
    featureScenariosAndTags.forEach((featInfo) => {
        featInfo.scenario.forEach(() => {
            Sccount++;
        });
    });

    // get specific scenario tag count
    featureScenariosAndTags.forEach((featInfo) => {
        featInfo.scenario.forEach((scenInfo) => {
            if (scenInfo.scenarioTags.includes('@manual')) {
                Manuccount++;
                if (scenInfo.scenarioTags.includes('@app-end-of-life') || scenInfo.scenarioTags.includes('@disabled') || scenInfo.scenarioTags.includes('@deprecated') || scenInfo.scenarioTags.includes('@obsolete') || scenInfo.scenarioTags.includes('@webservice')) {
                    Manuccount--;
                }else{
            if (scenInfo.scenarioTags.includes('@low-roi')) {
                lowRoiccount++;
            }
            if (scenInfo.scenarioTags.includes('@highly-complex')) {
                highlyComplexccount++;
            }
            if (scenInfo.scenarioTags.includes('@test-data-limitations')) {
                testDataccount++;
            }
            if (scenInfo.scenarioTags.includes('@web-content')) {
                webContentccount++;
            }
            if (scenInfo.scenarioTags.includes('@missing-infra')) {
                missingInfraccount++;
            }
            if (scenInfo.scenarioTags.includes('@automation-deferred')) {
                automationDeferredccount++;
            }
        }
        }
            if (scenInfo.scenarioTags.includes('@regression')) {
                regressionccount++;
            }
            if (scenInfo.scenarioTags.includes('@regression') && scenInfo.scenarioTags.includes('@manual') && !(scenInfo.scenarioTags.includes('@app-end-of-life'))) {
                regressionManualccount++;
            }
            if (scenInfo.scenarioTags.includes('@webservice') && !scenInfo.scenarioTags.includes('@disabled') && !scenInfo.scenarioTags.includes('@deprecated') && !scenInfo.scenarioTags.includes('@obsolete') && !scenInfo.scenarioTags.includes('@manual') && !scenInfo.scenarioTags.includes('@app-end-of-life')) {
                Wscount++;
            }
            if (scenInfo.scenarioTags.includes('@app-end-of-life')) {
                appEndOfLifecount++;
            }
            if (scenInfo.scenarioTags.includes('@disabled')) {
                disabledcount++;
            }
            if (scenInfo.scenarioTags.includes('@deprecated')) {
                deprecatedcount++;
            }
            if (scenInfo.scenarioTags.includes('@obsolete')) {
                obsoletecount++;
            }
        });
    });

    Sccount -= (appEndOfLifecount + disabledcount + deprecatedcount + obsoletecount);

    Account = (Sccount - Manuccount);
    regressionAutomatedccount = (regressionccount - regressionManualccount);
    secondaryuntaggedccount = (Manuccount -
        (highlyComplexccount +
            lowRoiccount +
            testDataccount +
            webContentccount +
            missingInfraccount +
            automationDeferredccount));

    tagCountMap.push([Vertical, Domain, Initiative, Team, Fccount, Sccount, Account, Manuccount, Wscount]);
    const output = table(tagCountMap, {
        border: {
            topBody: '─',
            topJoin: '┬',
            topLeft: '┌',
            topRight: '┐',
            bottomBody: '─',
            bottomJoin: '┴',
            bottomLeft: '└',
            bottomRight: '┘',
            bodyLeft: '│',
            bodyRight: '│',
            bodyJoin: '│',
            joinBody: '─',
            joinLeft: '├',
            joinRight: '┤',
            joinJoin: '┼',
        },
    });

    console.log(output);

    manualTagCountMap.push([Vertical, Domain, Initiative, Team, highlyComplexccount, lowRoiccount, testDataccount, webContentccount, missingInfraccount, automationDeferredccount, secondaryuntaggedccount]);

    const Manuoutput = table(manualTagCountMap, {
        border: {
            topBody: '─',
            topJoin: '┬',
            topLeft: '┌',
            topRight: '┐',
            bottomBody: '─',
            bottomJoin: '┴',
            bottomLeft: '└',
            bottomRight: '┘',
            bodyLeft: '│',
            bodyRight: '│',
            bodyJoin: '│',
            joinBody: '─',
            joinLeft: '├',
            joinRight: '┤',
            joinJoin: '┼',
        },
    });
    console.log(Manuoutput);
    //
    wsCountMap.push([Vertical, Domain, Initiative, Team, Fccount, Sccount, Wscount]);

    const wsoutput = table(wsCountMap, {
        border: {
            topBody: '─',
            topJoin: '┬',
            topLeft: '┌',
            topRight: '┐',
            bottomBody: '─',
            bottomJoin: '┴',
            bottomLeft: '└',
            bottomRight: '┘',
            bodyLeft: '│',
            bodyRight: '│',
            bodyJoin: '│',
            joinBody: '─',
            joinLeft: '├',
            joinRight: '┤',
            joinJoin: '┼',
        },
    });
    console.log(wsoutput);
    //
    regressionTagCountMap.push([Vertical, Domain, Initiative, Team, Fccount, Sccount, regressionccount, regressionAutomatedccount, regressionManualccount]);
    const regOutput = table(regressionTagCountMap, {
        border: {
            topBody: '─',
            topJoin: '┬',
            topLeft: '┌',
            topRight: '┐',
            bottomBody: '─',
            bottomJoin: '┴',
            bottomLeft: '└',
            bottomRight: '┘',
            bodyLeft: '│',
            bodyRight: '│',
            bodyJoin: '│',
            joinBody: '─',
            joinLeft: '├',
            joinRight: '┤',
            joinJoin: '┼',
        },
    });

    console.log(regOutput);
    endOfLifeMap.push([Vertical, Domain, Initiative, Team, appEndOfLifecount, disabledcount, deprecatedcount, obsoletecount]);
    const endOfLifeOutput = table(endOfLifeMap, {
        border: {
            topBody: '─',
            topJoin: '┬',
            topLeft: '┌',
            topRight: '┐',
            bottomBody: '─',
            bottomJoin: '┴',
            bottomLeft: '└',
            bottomRight: '┘',
            bodyLeft: '│',
            bodyRight: '│',
            bodyJoin: '│',
            joinBody: '─',
            joinLeft: '├',
            joinRight: '┤',
            joinJoin: '┼',
        },
    });

    console.log(endOfLifeOutput);

    LibraryUpgradeMap.push([Vertical, Domain, Initiative, Team, libraryUpgrade]);
    const LibraryUpgradeOutput = table(LibraryUpgradeMap, {
        border: {
            topBody: '─',
            topJoin: '┬',
            topLeft: '┌',
            topRight: '┐',
            bottomBody: '─',
            bottomJoin: '┴',
            bottomLeft: '└',
            bottomRight: '┘',
            bodyLeft: '│',
            bodyRight: '│',
            bodyJoin: '│',
            joinBody: '─',
            joinLeft: '├',
            joinRight: '┤',
            joinJoin: '┼',
        },
    });

    console.log(LibraryUpgradeOutput);

    if (process.env.db === 'yes') {
        writeCucumberTableDatabase();
    }
    return Fccount;
};
