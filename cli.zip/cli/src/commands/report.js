import chalk from 'chalk';
import inquirer from 'inquirer';
import Promise from 'bluebird';
import multipleCCHtmlReporter from 'multiple-cucumber-html-reporter';
import fs from 'fs';
import {
    generatingReportMessage,
    openReportInBrowser,
    runProvaTestMessage,
} from '../common/helpers';

export const command = 'report';
export const desc = 'Generate reports';

let reportTypeSelected = '';

/**
 * Generates a Multiple Cucumber HTML Report and launches the browser
 */
const generateMultipleCCHtmlReports = () => {
    const cucumberJsResultsDir = './cucumberJs-results/';
    const cucumberJsReportDir = './cucumberJs-report/';

    if (fs.existsSync(cucumberJsResultsDir)) {
        generatingReportMessage(reportTypeSelected);

        multipleCCHtmlReporter.generate({
            jsonDir: cucumberJsResultsDir,
            reportPath: cucumberJsReportDir,
        });

        openReportInBrowser('cucumberJs', `${cucumberJsReportDir}/index.html`);
    } else {
        runProvaTestMessage(reportTypeSelected);
    }
};

/**
 * Generates a Allure Report and launches the browser
 */
const generateAllureReports = () => {
    const allureResultsDir = './allure-results';

    if (fs.existsSync(allureResultsDir)) {
        generatingReportMessage(reportTypeSelected);

        console.log(chalk.green('Ctrl + C to exit'));

        openReportInBrowser('allure');
    } else {
        runProvaTestMessage(reportTypeSelected);
    }
};

/**
 * Runs the report type that is selected
 * @returns {Promise}
 */
const getReportType = async () =>
    new Promise((resolve, reject) => {
        inquirer
            .prompt([
                {
                    type: 'list',
                    name: 'reportType',
                    message: 'Report Type:',
                    choices: ['Allure Report', 'Multiple Cucumber HTML Report'],
                    default: 0,
                },
            ])
            .then((answers) => {
                reportTypeSelected = answers.reportType;
                resolve(answers.reportType);
            })
            .catch((err) => reject(err));
    });

/**
 *  Invokes the method that generates the report that was selected.
 * @returns {Promise<void>}
 */
export const builder = async () => {
    try {
        const reportType = await getReportType();

        if (reportType === 'Multiple Cucumber HTML Report') {
            generateMultipleCCHtmlReports();
        }

        if (reportType === 'Allure Report') {
            generateAllureReports();
        }
    } catch (err) {
        console.error(err);
    }
};
