import _ from 'lodash';
import chalk from 'chalk';
// import Gherkin from 'gherkin';
import clear from 'clear';
import {
    getFeatureInfo,
} from '../utils';
import {
    CLI_EPILOGUE,
} from '../constants';
import {
    printBanner,
} from '../index';

export const command = 'tag-count';
export const desc = 'Check the number of scenarios with tag';

clear();
printBanner();

export const cmdArgs = {
    tag: {
        desc: 'The tag',
        type: 'string',
    },
};

export const builder = async (yargs) => {
    yargs.options(cmdArgs).epilogue(CLI_EPILOGUE).help();
    yargs.example(
        '$0 tag-count --tag=@allegiant',
        'List the number of scenarios with tag @allegiant',
    );
};

export async function handler(argv) {
    if (!argv.tag) {
        console.log(chalk.cyan('Please specify a tag'));
        console.log(`Example: ${argv.$0} tag-count --tag=@allegiant`);
        return;
    }

    let tagCounts = 0;
    try {
        const featureScenariosAndTags = await getFeatureInfo('features/**/*.feature');

        featureScenariosAndTags.forEach((featInfo) => {
            featInfo.scenario.forEach((scenInfo) => {
                if (scenInfo.scenarioTags.includes(argv.tag)) {
                    tagCounts += 1;
                }
            });
        });
        console.log(
            `${chalk.green(tagCounts)} scenario(s) are found for tag ${chalk.cyan(argv.tag)}`,
        );
        return tagCounts;
    } catch (err) {
        console.error(err);
    }
}
