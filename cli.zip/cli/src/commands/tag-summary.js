import _ from 'lodash';
import chalk from 'chalk';
import Gherkin from 'gherkin';
import {
    table,
} from 'table';
import {
    getFeatureInfo,
} from '../utils';
import {
    CLI_EPILOGUE,
} from '../constants';

export const command = 'tag-summary';
export const desc = 'Display tag summary';

export const builder = async (yargs) => {
    yargs.epilogue(CLI_EPILOGUE).help();

    yargs.example('$0 tag-summary', 'Display the tag summary');
};

export async function handler() {
    try {
        const featureScenariosAndTags = await getFeatureInfo('features/**/*.feature');

        let getAllTags;
        let totalTags = 0;
        const tagCountMap = [
            ['Tag', 'Scenario count'],
        ];

        featureScenariosAndTags.forEach((featInfo) => {
            featInfo.scenario.forEach((scenInfo) => {
                getAllTags = scenInfo.scenarioTags;
                totalTags += getAllTags.length;
                getAllTags.forEach((tags) => {
                    if (tagCountMap[tags]) {
                        tagCountMap[tags] += 1;
                    } else {
                        tagCountMap[tags] = 1;
                    }
                });
            });
        });

        const output = table(tagCountMap, {
            border: {
                topBody: '─',
                topJoin: '┬',
                topLeft: '┌',
                topRight: '┐',

                bottomBody: '─',
                bottomJoin: '┴',
                bottomLeft: '└',
                bottomRight: '┘',

                bodyLeft: '│',
                bodyRight: '│',
                bodyJoin: '│',

                joinBody: '─',
                joinLeft: '├',
                joinRight: '┤',
                joinJoin: '┼',
            },
        });
        console.log(tagCountMap);
        console.log(chalk.green(`Total tags: ${totalTags}`));
        return totalTags;
    } catch (err) {
        console.error(err);
    }
}
