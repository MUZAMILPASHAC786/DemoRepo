import chalk from 'chalk';
import fs from 'fs';
import {
    pushTestCasesqTest,
} from '../qTestUtil';

export const command = 'push2qtest';
export const desc = 'Add/Modify the Test cases to qTest';

export const builder = async (yargs) => {
    try {
        console.log(chalk.green('Started adding test cases'));

        const rawdata = fs.readFileSync('qTestConfig.json', 'UTF-8');
        const dataInConfig = JSON.parse(rawdata);
        const returnAddTestCaseOutput = await pushTestCasesqTest(dataInConfig);
        if (returnAddTestCaseOutput.result) {
            console.log(chalk.green('status of adding test cases->'), returnAddTestCaseOutput, chalk.magenta('Please Verify same from Qtest'));
        } else {
            console.log(chalk.green('status of adding test cases->'), returnAddTestCaseOutput);
        }
    } catch (err) {
        console.error(err);
    }
};
