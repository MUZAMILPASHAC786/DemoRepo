import _ from 'lodash';
import chalk from 'chalk';
import Gherkin from 'gherkin';
import { SSL_OP_TLS_BLOCK_PADDING_BUG } from 'constants';
import { title } from 'process';
import { getFeatureInfo } from '../utils';
import { CLI_EPILOGUE } from '../constants';

const fs = require('fs');

export const command = 'manifest';
export const desc = 'Displays all scenarios';

export const cmdArgs = {
    tag: {
        desc: 'List scenarios of a tag',
        type: 'string',
    },
    'not-having-tag': {
        desc: "List scenarios that don't have a specific tag",
        type: 'string',
    },
};

const manifest = {
    domain: 'commercial',
    initiative: 'Initiative Value',
    stories: [],
};

export const builder = async (yargs) => {
    yargs.options(cmdArgs).epilogue(CLI_EPILOGUE).help();

    yargs.example('$0 scenarios', 'List all scenarios');
    yargs.example("$0 scenarios --tag='@allegiant'", 'List all scenarios having tag @allegiant');
    yargs.example(
        "$0 scenarios --not-having-tag='@allegiant'",
        "List all scenarios that don't have tag @allegiant",
    );
};

function checkFeatureScenarioTags(featureInfo, featInfo, scenarioInfo, scenarioArray) {
    featureInfo.featurePath = featInfo.featurePath;
    featureInfo.featureName = featInfo.featureName;
    featureInfo.featureTags = featInfo.featureTags;

    featInfo.scenario.forEach((scenInfo) => {
        scenarioInfo.scenarioTitle = scenInfo.scenarioName;
        scenarioInfo.tags = scenInfo.scenarioTags;
        scenarioArray.push(scenarioInfo);
        scenarioInfo = {};
    });
    featureInfo.scenarios = scenarioArray;
    scenarioArray = [];
    return featureInfo;
}

function checkScenarioTags(featureInfo, featInfo, scenarioInfo, scenInfo, scenarioArray) {
    featureInfo.featurePath = featInfo.featurePath;
    featureInfo.featureName = featInfo.featureName;
    featureInfo.featureTags = featInfo.featureTags;

    scenarioInfo.scenarioTitle = scenInfo.scenarioName;
    scenarioInfo.tags = scenInfo.scenarioTags;
    scenarioArray.push(scenarioInfo);
    scenarioInfo = {};

    featureInfo.scenarios = scenarioArray;
    scenarioArray = [];
    return featureInfo;
}

export async function handler(argv) {
    try {
        const featureScenariosAndTags = await getFeatureInfo('features/**/*.feature');

        featureScenariosAndTags.forEach((featInfo) => {
            const featureInfo = {};
            const scenarioArray = [];
            const scenarioInfo = {};

            if (argv.tag) {
                if (featInfo.featureTags.includes(argv.tag)) {
                    manifest.stories.push(checkFeatureScenarioTags(featureInfo, featInfo, scenarioInfo, scenarioArray));
                } else {
                    featInfo.scenario.forEach((scenInfo) => {
                        if (scenInfo.scenarioTags.includes(argv.tag)) {
                            manifest.stories.push(checkScenarioTags(featureInfo, featInfo, scenarioInfo, scenInfo, scenarioArray));
                        }
                    });
                }
            } else if (argv.notHavingTag) {
                if (!featInfo.featureTags.includes(argv.notHavingTag)) {
                    manifest.stories.push(checkFeatureScenarioTags(featureInfo, featInfo, scenarioInfo, scenarioArray));
                } else {
                    featInfo.scenario.forEach((scenInfo) => {
                        if (!scenInfo.scenarioTags.includes(argv.notHavingTag)) {
                            manifest.stories.push(checkScenarioTags(featureInfo, featInfo, scenarioInfo, scenInfo, scenarioArray));
                        }
                    });
                }
            } else {
                manifest.stories.push(checkFeatureScenarioTags(featureInfo, featInfo, scenarioInfo, scenarioArray));
            }
        });

        return fs.writeFile('manifest.json', JSON.stringify(manifest), (err, result) => {
            if (err) console.log('error', err);
        });
    } catch (err) {
        console.error(err);
    }
}
