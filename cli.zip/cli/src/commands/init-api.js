import fs from 'fs-extra';
import path from 'path';
import inquirer from 'inquirer';
import spawn from 'cross-spawn';
import chalk from 'chalk';

export const command = 'init-api';
export const desc = 'Setup a test suite using Prova-API';

// const getTestsFolderName = async () =>
//     new Promise((resolve, reject) => {
//         inquirer
//             .prompt([
//                 {
//                     type: 'list',
//                     name: 'location',
//                     message: 'Select the name of you are tests location',
//                     choices: ['test', 'tests', 'e2e'],
//                     default: 0,
//                 },
//             ])
//             .then((answers) => resolve(answers.location))
//             .catch((err) => reject(err));
//     });

// const getAutoNextGenBindingsRequirement = async () =>
//     new Promise((resolve, reject) => {
//         inquirer
//             .prompt([
//                 {
//                     type: 'list',
//                     name: 'installAutoNextGenBindings',
//                     message:
//                         'Do you want to install prova-autonextgen bindings (For accessing methods supported by BDD JAR, Need Java8 to be installed)',
//                     choices: ['no', 'yes'],
//                     default: 'yes',
//                 },
//             ])
//             .then((answers) => resolve(answers.installAutoNextGenBindings))
//             .catch((err) => reject(err));
//     });

export const builder = async (yargs) => {
    try {
        console.log(chalk.yellow('Setup Prova-API Test Suite'));

        // const installAutoNextGenBindings = await getAutoNextGenBindingsRequirement();
        const testsFolderName = 'e2e';
        const templateDir = path.join(__dirname, '../templates/test-api');
        const testsDir = path.join('.', testsFolderName);

        await fs.copy(templateDir, testsDir);

        console.log(chalk.green('✓ Copied all files for setting up test suite'));

        const currentPath = process.cwd();
        const fqTestDir = path.join(currentPath, testsDir);

        console.log(chalk.green(`✓ Entering ${testsFolderName} directory`));

        process.chdir(fqTestDir);

        const result = spawn.sync('npm', ['install', '--unsafe-perm'], { stdio: 'inherit' });

        if (result && !result.error) {
            console.log(chalk.green('✓ Node modules installed successfully'));

            // if (installAutoNextGenBindings === 'yes') {
            //     console.log(chalk.yellow('Attempting to install prova-autonextgen-bindings'));

            //     spawn.sync(
            //         'npm',
            //         [
            //             'install',
            //             'git+ssh://git@git.allegiantair.com:7999/gqa/prova-autonextgen-bindings.git#master',
            //             '--unsafe-perm',
            //         ],
            //         { stdio: 'inherit' },
            //     );
            // }

            console.log(
                chalk.green(`✓ All set !! Go to ${testsFolderName} directory and run `) +
                    chalk.cyan('prova-API test'),
            );
            console.log(chalk.cyan('Kindy update the chromedriver to the latest version'));
        }
    } catch (err) {
        console.error(err);
    }
};
