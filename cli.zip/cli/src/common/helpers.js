import cmd from 'node-cmd';
import fs from 'fs';
import chalk from 'chalk';

const os = require('os').platform();

/**
 * Todo: should be doing this in wdio.conf hook. This is temporary for now.
 * ./Report needs to be removed and recreated every time prova test is ran.
 *
 * https://webdriver.io/docs/wdio-cucumberjs-json-reporter.html
 */
export const deleteDirectory = (path) => {
    let deleteCommand = 'rm -rf';

    switch (os) {
        case 'darwin':
            deleteCommand = 'rm -rf';
            break;
        case 'win32':
            deleteCommand = 'rmdir /Q/S';
            break;
        default:
            deleteCommand = 'rm -rf';
    }

    if (fs.existsSync(path)) {
        cmd.run(`${deleteCommand} ${path}`);

        if (fs.existsSync(path) && os === 'win32') {
            deleteCommand = 'rm -r';

            cmd.run(`${deleteCommand} ${path}`);
        }
    }
};

/**
 * Opens report in browser
 * @param path
 */
export const openReportInBrowser = (reportType, path = '') => {
    if (reportType === 'allure' && os === 'win32') {
        cmd.run(
            'start ./node_modules/.bin/allure generate ./ allure-results --clean && allure open',
        );
    } else if (reportType === 'allure' && os !== 'win32') {
        cmd.run(
            './node_modules/.bin/allure generate ./allure-results --clean && ./node_modules/.bin/allure open',
        );
    }

    if (reportType === 'cucumberJs' && os === 'win32') {
        cmd.run(`start ${path}`);
    } else if (reportType === 'cucumberJs' && os !== 'win32') {
        cmd.run(`open ${path}`);
    }
};

/**
 * Run 'prova test' message
 * @param reportTypeSelected
 */
export const runProvaTestMessage = (reportTypeSelected) => {
    console.log(chalk.red(`\nNo ${reportTypeSelected} found. Please run 'prova test' 👎 ⚠️`));
};

/**
 * Report generating and chrome launching message
 * @param reportTypeSelected
 */
export const generatingReportMessage = (reportTypeSelected) => {
    console.log(chalk.green(`\nGenerating ${reportTypeSelected} and launching browser 👌 🔥`));
};
