import {
    getFeatureInfo
} from '../utils'
import fetch from 'node-fetch';
import chalk from 'chalk'

class qTestAPI {

    constructor() {
        this.token
    }
    async passBearerCode(bearerCode) {
        let uri = 'https://allegiantair.qtestnet.com/oauth/status'
        const request = await this.getLoginStatus(uri, bearerCode)
        if (request.error) {
            let BearerError = request.error + '->' + request.error_description
            console.log(chalk.yellow('The Bearer token is Invalid'), chalk.magenta(bearerCode))
            return BearerError
        } else {
            console.log(chalk.green('The Bearer token is Valid'), chalk.magenta(bearerCode))
            this.token = bearerCode
        }
    }

     async getAPI(endpoint) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    const request = fetch(endpoint, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${this.token}`,
            'Cache-Control': 'no-cache',
        },
    });
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 1;
    return request.then((res) => res.json());
}

    async getAdminAPI(endpoint) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    const request = fetch(endpoint, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer fcaee031-7a3b-4039-9a61-73a5a79b75b5`,
            'Cache-Control': 'no-cache',
        },
    });
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 1;
    return request.then((res) => res.json());
}

    async postAPI(endpoint, data) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    const request = fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${this.token}`,
            'Cache-Control': 'no-cache',
        },
        body: data,
    });
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 1;
    return request.then((res) => res.json());
};

    async updateAPI(endpoint, data) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    const request = fetch(endpoint, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${this.token}`,
            'Cache-Control': 'no-cache',
        },
        body: data,
    });
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 1;
    return request.then((res) => res.json());
};

    async getLoginStatus(endpoint, bearerCode) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    const request = fetch(endpoint, {
        method: 'GET',
        headers: {
            Authorization: `Bearer ${bearerCode}`
        },
    });
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 1;
    return request.then((res) => res.json());
}

    async getScenariosQtest(featurePath, folderID, projectID, teamName) {
    const featureScenariosAndTags = await getFeatureInfo(featurePath);

    const featuresCount = featureScenariosAndTags.length;
    console.log(' ***************$ featuresCount $*************** => ', featuresCount);
    const finalData = [];
    const scenarioNames = [];

    for (let k = 0; k < featuresCount; k++) {
        const featureFilePath = featureScenariosAndTags[k].featurePath.split('/');
        const featureFileName = featureFilePath[(featureFilePath.length) - 1];
        console.log('featureFileName ---- => ', featureFileName);
        const scenariosDetails = featureScenariosAndTags[k].scenario;
        const singleScenarioCount = scenariosDetails.length;
        let tempScenarioName;
        let count = 1;

        for (let i = 0; i < singleScenarioCount; i++) {
            const dataCollected = [];
            const otherDataObject = {};
            const otherData = [];
            let {
                scenarioName
            } = scenariosDetails[i];
            if (tempScenarioName) {
                if (tempScenarioName.includes(scenarioName)) {
                    if (tempScenarioName === scenarioName) {
                        scenarioName = `${scenarioName}_${count}`;
                        count += 1;
                    }
                } else {
                    tempScenarioName = scenarioName;
                    count = 1;
                }
            } else {
                tempScenarioName = scenarioName;
            }

            const scenarioSteps = scenariosDetails[i].sceanarioSteps;
            const AllTags = scenariosDetails[i].scenarioTags;

            let endpoint = `https://allegiantair.qtestnet.com/api/v3/projects/${projectID}/settings/test-cases/fields`
            const fieldsResponse = await this.getAdminAPI(endpoint)
            for (let x = 0; x < fieldsResponse.length; x++) {
                if (fieldsResponse[x].label === "Persistence Team") {
                    let teamFieldId = fieldsResponse[x].id
                    otherDataObject.teamFieldId = teamFieldId
                    let teamAllowedNames = fieldsResponse[x].allowed_values
                    for (let x1 = 0; x1 < teamAllowedNames.length; x1++) {
                        if (teamAllowedNames[x1].label === teamName) {
                            let teamValueId = teamAllowedNames[x1].value
                            otherDataObject.teamValueId = teamValueId
                            let teamValueName = teamAllowedNames[x1].label
                            otherDataObject.teamValueName = teamValueName
                        }
                    }

                } else if (fieldsResponse[x].label === "Type") {
                    let typeFieldId = fieldsResponse[x].id
                    otherDataObject.typeFieldId = typeFieldId
                    let testcaseType;
                    let typeFieldValue;
                    if (AllTags.includes('@manual') || AllTags.includes('@Manual')) {
                        testcaseType = 'Manual';
                        typeFieldValue = 701;
                    } else {
                        testcaseType = 'Automation';
                        typeFieldValue = 702;
                    }
                    otherDataObject.typeFieldValue = typeFieldValue
                    otherDataObject.testcaseType = testcaseType

                } else if (fieldsResponse[x].label === "Sub Type") {
                    let subTypeFieldId = fieldsResponse[x].id
                    otherDataObject.subTypeFieldId = subTypeFieldId
                    let subType;
                    let subTypeFieldValue;
                    let subTypeAllowedValues = fieldsResponse[x].allowed_values
                    for (let x3 = 0; x3 < subTypeAllowedValues.length; x3++) {
                        if (AllTags.includes('@regression') || AllTags.includes('@Regression')) {
                            if (subTypeAllowedValues[x3].label === "Regression") {
                                subTypeFieldValue = `[${subTypeAllowedValues[x3].value}]`
                                subType = `[${subTypeAllowedValues[x3].label}]`
                            }
                        } else {
                            if (subTypeAllowedValues[x3].label === "Functional") {
                                subTypeFieldValue = `[${subTypeAllowedValues[x3].value}]`
                                subType = `[${subTypeAllowedValues[x3].label}]`
                            }
                        }
                    }
                    otherDataObject.subTypeFieldValue = subTypeFieldValue
                    otherDataObject.subType = subType

                } else if (fieldsResponse[x].label === "Description") {
                    let descriptionFieldId = fieldsResponse[x].id
                    otherDataObject.descriptionFieldId = descriptionFieldId

                } else if (fieldsResponse[x].label === "Tag") {
                    let tagFieldId = fieldsResponse[x].id
                    otherDataObject.tagFieldId = tagFieldId

                } else if (fieldsResponse[x].label === "P1 Regression") {
                    let pOneFieldId = fieldsResponse[x].id
                    otherDataObject.pOneFieldId = pOneFieldId
                    let pOneFieldValue
                    let pOneFieldValueName
                    let pOneAllowedValues = fieldsResponse[x].allowed_values
                    for (let x4 = 0; x4 < pOneAllowedValues.length; x4++) {
                        if (AllTags.includes('@regression') && AllTags.includes('@regressionpone')) {
                            if (pOneAllowedValues[x4].label === "True") {
                                pOneFieldValue = `[${pOneAllowedValues[x4].value}]`
                                pOneFieldValueName = `[${pOneAllowedValues[x4].label}]`
                            }
                        } else {
                            if (pOneAllowedValues[x4].label === "False") {
                                pOneFieldValue = `[${pOneAllowedValues[x4].value}]`
                                pOneFieldValueName = `[${pOneAllowedValues[x4].label}]`
                            }
                        }
                    }
                    otherDataObject.pOneFieldValue = pOneFieldValue
                    otherDataObject.pOneFieldValueName = pOneFieldValueName
                }
            }

            otherDataObject.scenarioTags = Object.keys(AllTags).map((i) => AllTags[i]).join(' ');
            otherData.push(otherDataObject);
            scenarioNames.push(scenarioName);
            for (let j = 0; j < scenarioSteps.length; j++) {
                const dataObject = {};
                dataObject.description = scenarioSteps[j];
                dataObject.expected = '';
                dataCollected.push(dataObject);
            }

            let testCase = `{
                        "id": 2,
                        "name": "${scenarioName}",
                        "order": 1,
                        "pid": "TC-1",
                        "created_date": "2023-12-11T10:59:37.136Z",
                        "last_modified_date": "2023-12-11T10:59:37.136Z",
                        "parent_id":  "${folderID}",
                        "properties": [
                            {
                                "field_id": ${otherDataObject.typeFieldId},
                                "field_name": "Type",
                                "field_value": "${otherDataObject.typeFieldValue}",
                                "field_value_name": "${otherDataObject.testcaseType}"
                            },
                            {
                                "field_id": ${otherDataObject.descriptionFieldId},
                                "field_name": "Description",
                                "field_value": "${scenarioName}"
                            },
                            {"field_name": "Tag",
                                "field_value": "${otherDataObject.scenarioTags}",
                                 "field_id": ${otherDataObject.tagFieldId}
                            },
                            {
                                "field_id": ${otherDataObject.subTypeFieldId},
                                "field_name": "Sub Type",
                                "field_value": "${otherDataObject.subTypeFieldValue}",
                                "field_value_name":  "${otherDataObject.subType}"
                            },
                            {
                                "field_id": ${otherDataObject.teamFieldId},
                                "field_name": "Persistence Team",
                                "field_value": "${otherDataObject.teamValueId}",
                                "field_value_name": "${otherDataObject.teamValueName}"
                            },
                            {
                                "field_id": ${otherDataObject.pOneFieldId},
                                "field_name": "P1 Regression",
                                "field_value": "${otherDataObject.pOneFieldValue}",
                                "field_value_name": "${otherDataObject.pOneFieldValueName}"
                            }
                           ],
                        "test_steps":${JSON.stringify(dataCollected)}
                    }`;
            finalData.push(testCase);
        }
    }
    return {
        finalData,
        scenarioNames,
    };
};
}
export default new qTestAPI()