import Ajv from 'ajv'
import chalk from 'chalk'

module.exports.schemaValidator = async function schemaValidator(dataToValidate) {

    // Define your JSON schema
    const schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "additionalProperties": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "qTestFolderPath": { "type": "string" },
              "repoFeaturePath": { "type": "string" },
              "persistenceTeam": { "type": "string" },
              "pushToQTest": { "type": "boolean" }
            },
            "required": ["qTestFolderPath", "repoFeaturePath", "persistenceTeam"]
          }
        }
      }

    // Create an instance of Ajv
    const ajv = new Ajv();

    // Compile the schema
    const validate = ajv.compile(schema);

    // Validate the data
    const valid = validate(dataToValidate);
    if (!valid) {
       console.log(chalk.red('Data in qTestConfig.json is In-valid'));
        return validate.errors[0].message
    } else {
        console.log(chalk.green('Data in qTestConfig.json is valid'));
    }
}