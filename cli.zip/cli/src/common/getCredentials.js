const readline = require('readline');

// module.exports = async function askCredentials() {
//     const rl = readline.createInterface({
//         input: process.stdin,
//         output: process.stdout
//     });

//     try {
//         process.env.qTestUsername = await new Promise((resolve, reject) => {
//             rl.question('Enter your username(Ex: john.milan@allegiantair.com): ', (userInput) => {
//                 resolve(userInput);
//             });
//         });

//         process.stdout.write('Enter your password: ');

//         process.env.qTestPassword = await new Promise((resolve, reject) => {
//             const stdin = process.stdin;
//             stdin.setRawMode(true);
//             stdin.resume();
//             stdin.setEncoding('utf8');

//             let inputPassword = '';

//             stdin.on('data', function (ch) {
//                 ch = ch.toString('utf8');
//                 switch (ch) {
//                     case '\n':
//                     case '\r':
//                     case '\u0004':
//                         stdin.setRawMode(false);
//                         process.stdout.write('\n');
//                         resolve(inputPassword);
//                         rl.close();
//                         break;
//                     case '\u0003':
//                         process.exit();
//                         break;
//                     default:
//                         process.stdout.cursorTo(21);
//                         inputPassword += ch;
//                         break;
//                 }
//             });
//         });

//     } catch (err) {
//         console.error('Error:', err);
//     } finally {
//         rl.close();
//     }
// }


module.exports = async function askBearerToken() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    try {
        process.env.bearerToken = await new Promise((resolve, reject) => {
                        rl.question('Enter your Bearer Token: ', (userInput) => {
                            resolve(userInput);
                        });
                    });

    } catch (err) {
        console.error('Error:', err);
    } finally {
        rl.close();
    }
}