import {
    GherkinStreams,
} from '@cucumber/gherkin-streams';
const fs = require('fs');
import chalk from 'chalk'
module.exports = async function validateFeatureFile(filePath) {
    try {
        const gherkinStream = GherkinStreams.fromPaths([filePath], {
            defaultDialect: 'en'
        })
        for await (const messages of gherkinStream) {
            if (messages.parseError) {
                console.log(chalk.red('Feature file is not in the correct format.'));
                return messages.parseError.message
            }
        }
        console.log(chalk.green('Feature file is in the correct format.'));
    } catch (error) {
    console.log(error.message);
    }
}