import yargs from 'yargs';
import chalk from 'chalk';
import figlet from 'figlet';

import { CLI_EPILOGUE, CLI_VERSION } from './constants';

export const printBanner = () =>
    console.log(
        chalk.yellow(figlet.textSync(`Prova CLI ${CLI_VERSION}`, { horizontalLayout: 'fitted' })),
    );

export const run = async () => {
    const argLength = process.argv.length;
    const commandsToPrintBanner = ['--help', '-h'];

    if (argLength <= 2 || process.argv.find((arg) => commandsToPrintBanner.includes(arg))) {
        printBanner();
    }
    const { argv } = yargs
        .strict()
        .commandDir('commands')
        .usage('Usage: $0 <command> [options]')
        .epilogue(CLI_EPILOGUE)
        .demandCommand(1, "Let's make BDD fun !!")
        .help('h')
        .alias('h', 'help');
};
