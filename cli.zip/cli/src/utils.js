import glob from 'glob';
import chalk from 'chalk';
import {
  GherkinStreams,
} from '@cucumber/gherkin-streams';

export const getFiles = async (path) => new Promise((resolve, reject) => {
  glob(path, {}, (err, files) => {
    if (err) {
      return reject(err);
    }
    return resolve(files);
  });
});

export const streamToArray = async (readableStream) => new Promise((resolve, reject) => {
  const items = [];
  readableStream.on('data', items.push.bind(items));
  readableStream.on('error', (err) => reject(err));
  readableStream.on('end', () => resolve(items));
});

export const getFeatureInfo = async (featurePath) => {
  const options = {
    includeSource: false,
    includeGherkinDocument: true,
    includePickles: false,
  };

  const filesList = await getFiles(featurePath);

  if (!filesList || !filesList.length) {
    return console.log(chalk.cyan('No feature files found'));
  }

  const featureData = await streamToArray(GherkinStreams.fromPaths(filesList, options));
  const AllData = [];

  featureData.forEach((ghekingdoc) => {
    const featureInfo = {};
    const featureTags = [];
    const scenario = [];

    // collecting feature Details
    featureInfo.featureName = ghekingdoc.gherkinDocument.feature.name;
    featureInfo.featurePath = ghekingdoc.gherkinDocument.uri;
    ghekingdoc.gherkinDocument.feature.tags.forEach((tagsInfo) => {
      featureTags.push(tagsInfo.name);
    });

    featureInfo.featureTags = featureTags;

    // collecting background Details
    let startIndex = 0;
    let addBackGroundSteps = false;
    if (ghekingdoc.gherkinDocument.feature.children[0].hasOwnProperty('background')) {
      startIndex = 1;
      addBackGroundSteps = true;
    } else {
      startIndex = 0;
    }

    // collecting scenario Details
    for (let i = startIndex; i < ghekingdoc.gherkinDocument.feature.children.length; i++) {
      let tableHeaderArray = []
      let tableBodyArray = []
      let exampleTagFlag = 0
      let exampleTag = 0;
      let flag = 0;
      var indexno = 0;
      let checkRepeat = 0;
      let exampleCount = 0;
      let exampleArray = []
      let sceanrioSteps = []
      let backGroundAndStepsCount
      if (addBackGroundSteps) {
        ghekingdoc.gherkinDocument.feature.children[0].background.steps.forEach((stepsArray) => {
          sceanrioSteps.push(stepsArray.keyword + stepsArray.text);
        });
      }
      let scenarioStepCount = ghekingdoc.gherkinDocument.feature.children[i].scenario.steps.length

      let scenarioRepeat = 0
      while (scenarioRepeat === 0) {
        if (addBackGroundSteps) {
          backGroundAndStepsCount = ghekingdoc.gherkinDocument.feature.children[0].background.steps.length
          scenarioStepCount = (ghekingdoc.gherkinDocument.feature.children[i].scenario.steps.length) + backGroundAndStepsCount
        } else {
          scenarioStepCount = ghekingdoc.gherkinDocument.feature.children[i].scenario.steps.length
        }
        const sceanrioData = {};
        const scenarioTags = [];
        if (!addBackGroundSteps) {
          sceanrioSteps = [];
        }
        ghekingdoc.gherkinDocument.feature.children[i].scenario.steps.forEach((stepsArray) => {

          let ExampleStep = stepsArray.text
          let ExampleOriginal = stepsArray.text
          let regex = /<([^>]+)>/g
          let exampleValue = ExampleStep.match(regex)
          if (ghekingdoc.gherkinDocument.feature.children[i].scenario.examples.length != 0) {
            if (flag === 0) {
              for (let j = 0; j < ghekingdoc.gherkinDocument.feature.children[i].scenario.examples.length; j++) {
                for (let k = 0; k < ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[j].tableBody.length; k++) {
                  tableHeaderArray.push(ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[j].tableHeader.cells)
                  tableBodyArray.push(ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[j].tableBody[k].cells)
                }

              }
              for (let c = 0; c < tableBodyArray.length; c++) {
                let exampleValuesObject = {}
                tableHeaderArray[c].map((header, index) => {
                  exampleValuesObject[header.value] = tableBodyArray[c][index].value
                })
                exampleArray.push(exampleValuesObject)
              }
              flag = 1;
            }

            if (exampleValue !== null) {
            for (let l = 0; l < exampleValue.length; l++) {
              let replacedValue = exampleValue[l]
              let comparingValue = replacedValue.split('<')[1].split('>')[0]
              let object = exampleArray[checkRepeat]
              let objectValue = object[comparingValue]
              ExampleStep = ExampleStep.replace(replacedValue, objectValue)
            }
            sceanrioSteps.push(stepsArray.keyword + ExampleStep);
          }
          }
          
          if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.steps[indexno].dataTable) !== undefined) {
            let jsonData = '';
            for (let m = 0; m < stepsArray.dataTable.rows.length; m++) {
              let Parametervalue = stepsArray.dataTable.rows[m].cells[1].value

              if (Parametervalue.includes('<')) {
                if (Parametervalue.includes('>')) {
                    ExampleStep = ExampleStep + ',' + "' '"
                }
              }
              for (let k = 0; k < stepsArray.dataTable.rows[m].cells.length; k++) {
                if (!Parametervalue.includes('<')) {
                  jsonData = jsonData + "|" + stepsArray.dataTable.rows[m].cells[k].value
                }
              }
              if (jsonData.includes('|')) {
                jsonData = jsonData + "|"
              }
            }
            if (jsonData !== '') {
              sceanrioSteps.push(stepsArray.keyword + stepsArray.text + jsonData);
            } else {
              sceanrioSteps.push(stepsArray.keyword + ExampleStep);
            }
          }
          if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.steps[indexno].docString) !== undefined) {
            let jsonBody = (ghekingdoc.gherkinDocument.feature.children[i].scenario.steps[indexno].docString)
            sceanrioSteps.push(stepsArray.keyword + stepsArray.text + jsonBody.content);
          }

          if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.steps[indexno].dataTable) === undefined && (ghekingdoc.gherkinDocument.feature.children[i].scenario.steps[indexno].docString) === undefined && stepsArray.dataTable == undefined && ExampleOriginal.match(regex) === null) {
            sceanrioSteps.push(stepsArray.keyword + stepsArray.text);
          }
          indexno++;

        });
        if (sceanrioSteps.length === scenarioStepCount) {
          featureTags.forEach((featureTag) => {
            scenarioTags.push(featureTag);
          });

          ghekingdoc.gherkinDocument.feature.children[i].scenario.tags.forEach((tagsInfo) => {
            scenarioTags.push(tagsInfo.name);
          });

          let exampleLength = ghekingdoc.gherkinDocument.feature.children[i].scenario.examples.length
          if (exampleLength != 0) {
            if (exampleLength <= checkRepeat) {
              exampleTagFlag++;
              exampleTag = checkRepeat - exampleTagFlag;
              if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[exampleTag]) !== undefined) {
                if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[exampleTag].tags.length) !== 0) {
                  for (let e = 0; e < (ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[exampleTag].tags.length); e++) {
                    scenarioTags.push(ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[exampleTag].tags[e].name)
                  }
                }
              }
            } else {
              if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[checkRepeat]) !== undefined) {
                if ((ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[checkRepeat].tags.length) !== 0) {
                  for (let e = 0; e < (ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[checkRepeat].tags.length); e++) {
                    scenarioTags.push(ghekingdoc.gherkinDocument.feature.children[i].scenario.examples[checkRepeat].tags[e].name)
                  }
                }
              }
            }
          }

          sceanrioData.scenarioName = ghekingdoc.gherkinDocument.feature.children[i].scenario.name;
          sceanrioData.scenarioTags = scenarioTags;
          sceanrioData.sceanarioSteps = sceanrioSteps;
          scenario.push(sceanrioData);
          featureInfo.scenario = scenario;

          if (ghekingdoc.gherkinDocument.feature.children[i].scenario.examples.length != 0) {
            exampleCount = exampleCount + 1;
            if (exampleCount < exampleArray.length) {
              checkRepeat = checkRepeat + 1;
              scenarioRepeat = 0;
              indexno = 0;
              if (addBackGroundSteps) {
                sceanrioSteps = []
                ghekingdoc.gherkinDocument.feature.children[0].background.steps.forEach((stepsArray) => {
                  sceanrioSteps.push(stepsArray.keyword + stepsArray.text);
                });
              }
            } else {
              scenarioRepeat = 1;
            }
          } else {
            scenarioRepeat = 1;
          }
        }
      }
    }

    AllData.push(featureInfo);
  });
  return AllData;
};
