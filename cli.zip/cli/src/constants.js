import { version } from '../package.json';

export const CLI_EPILOGUE = `Documentation: https://git.allegiantair.com:8443/projects/GQA/repos/prova/browse (v${version})`;
export const CLI_VERSION = version;
