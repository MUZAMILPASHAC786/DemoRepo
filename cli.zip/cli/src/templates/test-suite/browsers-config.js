module.exports = {
	chrome: [{
		browserName: 'chrome',
		maxInstances: 5,
		acceptInsecureCerts: true,
		'goog:chromeOptions': {
			args: ['--ignore-certificate-errors']
		},

		path: '/wd/hub'
	}],
	firefox: [{
		browserName: 'firefox',
		maxInstances: 5

	}],
	safari: [{
		browserName: 'safari',
		maxInstances: 5
	}],
	ie: [{
		browserName: 'internet explorer'
	}],
	edge: [{
		browserName: 'MicrosoftEdge',
		maxInstances: 1 // must be 1 for EdgeHtml, can be more for ChromiumEdge.
	}],
	phantomjs: [{
		browserName: 'phantomjs',
		platform: '',
		version: '',
		maxInstances: 5
	}],
	chromeFirefox: [{
		browserName: 'chrome',
		maxInstances: 5
	}, {
		browserName: 'firefox',
		maxInstances: 5
	}],
	chromeFirefoxSafari: [{
		browserName: 'chrome',
		maxInstances: 5
	}, {
		browserName: 'firefox',
		maxInstances: 5
	}, {
		browserName: 'safari',
		maxInstances: 5
	}],
	remoteFirefox: [{
		browserName: 'firefox',
		port: 4444
	}]
};
