import { Then } from '@cucumber/cucumber'
import HotelPage from '../page-objects/hotelPageObject'

Then(/^I am on hotels page I select a hotel$/, async () => {
    await HotelPage.collectHotelPageDetailsForConfirmationPage()
    await HotelPage.hotelselection();
})

Then(/^I am on hotels page I select a room$/, async () => {
    await HotelPage.collectHotelDetailsPageDetailsForConfirmationPage()
    await HotelPage.roomselection();
})

Then(/^I click on the Hotels details Page Continue Button$/, async () => {
    await HotelPage.hotelContinueBtn();
})