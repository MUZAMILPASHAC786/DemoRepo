import { Then } from '@cucumber/cucumber'
import ConfirmationPage from '../page-objects/confPageObject'

Then(/^I am on the confirmation page I expect confirmation number to be displayed$/, async () => {
    await ConfirmationPage.confirmationNumber()
})