import { Given, When } from '@cucumber/cucumber';
import PaymentPage from '../page-objects/paymentPageObj';
import HotelsPage from '../page-objects/hotelPageObject';
import BagsPage from '../page-objects/bagsPageObject';
import CarsPage from '../page-objects/carsPageObject'

Given(/^I am on payment page I verify decline amount adding extras$/, { timeout: 180 * 1000 },
    async () => {
        var IsDeclined = await PaymentPage.validateDeclinedAmount();
        if (IsDeclined) {
            console.log("Its declined amount!!!!")
            await browser.pause(5000)
            await BagsPage.addExtras();
            await BagsPage.clickContinueButton();
            await HotelsPage.hotelContinueBtn();
            await CarsPage.carspageContinueBtn();
        }
    })

    Given(/^I am on payment page I enter all required card details$/, async () => {
        try {
            await PaymentPage.popupClosing()
            await PaymentPage.cardDetails()
        } catch (er) { }
    })

    Given(/^I am on Payment page I enter all required billing address details$/, async () => {
        await PaymentPage.billingaddress()
    })

    Given(/^I am on Payment page I select Purchase my trip button$/, async () => {
        await PaymentPage.purchasemytrip()
    })