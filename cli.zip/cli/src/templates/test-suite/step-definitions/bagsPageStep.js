import { When, Then } from '@cucumber/cucumber'
import BagsPage from '../page-objects/bagsPageObject'

Then(/^I am on Bags page I select CarryOn "([^"]*)"$/, async (params) => {
    await browser.pause(5000)
    await BagsPage.selectCarryOnBagByParams(params)
    await browser.pause(5000)
})

Then(/^I am on Bags page I select Checked Bag "([^"]*)"$/, async (params) => {
    await BagsPage.selectCheckedBagByParams(params)
})

Then(/^I am on Bags page I select tripflex "([^"]*)"$/, async (params) => {
    await BagsPage.selectTripflex(params)
})

Then(/^I am on Bags page I select priority "([^"]*)"$/, async (params) => {
    await BagsPage.selectPriorityByParams(params)
})

Then(/^I am on Bags page I click continue button$/, async () => {
    await BagsPage.clickContinueButton()
})