# Prova-UI-Test-Suite

This is BoilerPlate for Prova-UI Test-Suite

### Goals

-   Provide a complete code base of Prova-UI where we can execute the Web application.
-   Provide a comprehensive set of rich and easy-to-use Glossaries.
-   Provide a methods to debug the errors easily.
-   Provide Generic Page Objects and other helper utilites.

### Dependencies

-   Node >= v14
-   Npm >= v6
-   Install python (if you are new installation)

## Install

```bash

# install Prova-UI latest version if it contains
npm install @g4/prova-ui

# Note:  check latest version of prova-ui from below bitbucket link
(https://git.allegiantair.com:8443/projects/GQA/repos/prova-ui/browse/package.json)

# Note: This suite contains a list of examples demonstrating how to write tests in Prova-UI. You may go ahead and delete them.
```
<br />

### Usage

```bash
# See all available options
prova --help

# Setup a test suite using Prova-UI
prova init

# Run tests 
ENV=.stg prova test

# Specify tags in Run tests
ENV=.stg tag=@HLO prova test

# Run lint
prova lint

```
<br />

### Learn Prova-UI

-   [Prova-UI](https://git.allegiantair.com:8443/projects/GQA/repos/prova-ui/browse)
    <!-- Prova-UI Glossaries are as same as Prova GLosaries -->
-   [Prova BDD Glossary](https://git.allegiantair.com:8443/projects/GQA/repos/prova/browse/docs/bdd-glossary.md)

### Documentation

-   [Prova-UI](https://allegiantair0.sharepoint.com/sites/QAA/SitePages/Prova-UI-Library.aspx)

### Contribute

Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License

Copyright (c) Allegiant Travel Company
