import actions from '@g4/prova-ui/src/support/actions'
import Check from '@g4/prova-ui/src/support/validations'
import { assert } from 'chai';

const topOfPage = "//button[@class='CarsPage__ScrollToTop-ro84g9-3 fbFOeE']"
const carskip = "[data-hook='cars-page_skip']"
const scrollcartype = "//*[text()='Car Type']"
const carselection = "//*[contains(@class,'PriceSelectionButton-ayz81e-3 kZTAAf')]"
const carsPageContinueButton = "[data-hook='cars-page_continue']"
const noCarsResultMessage = "[data-hook='cars-page-no-result-message']"
const priceButton = "(//*[contains(@class,'CarVendorPrices__PriceSelectionButton')])[1]"
const dropOffDateField = '(//span[contains(@class,"Text-sc-1o5ubbx-0 hSCplp")])[2]'
const pickUpDateField = '(//span[contains(@class,"Text-sc-1o5ubbx-0 hSCplp")])[1]'
const vehicletype = '(//span[contains(@class,"Text-sc-1o5ubbx-0 bltVao")])[1] | (//span[contains(@class,"Text-sc-1o5ubbx-0 kiUQmq")])[1]'
const addedToCard = '//span[text()="Added to cart"] | //span[text()="Added"]'
const carPageHeader = "//*[text()='Car Selection']"
const addToCartText = "//*[text()='Added to cart']"
const icePopup = "[data-hook='payment-page_ice-popup_close']"

var CarsPageCollectorCP = new Map();

class CarPage {

  async addToCart() {
    await actions.pause(10000)
    await actions.waitForDisplayed(priceButton, 'priceButton', 60000)
    let noCarsResultMessageVisbility = await actions.isDisplayed(noCarsResultMessage, 'No cars Message')
    console.log("noCarsResultMessageVisbility: ", noCarsResultMessageVisbility)
    if (noCarsResultMessageVisbility) {
      // assert.fail("Cars are not available, Cars required for the scenario");
    } else {
      await actions.waitForDisplayed(priceButton, 'price button', 10000)
      await actions.scroll(priceButton)
      await actions.waitForClickable(priceButton, 'price button')
      await actions.clickElement('click', priceButton, 'Price Button')
      await browser.pause(15000)
      await actions.waitForDisplayed(addToCartText, 'addToCartText', 10000)
    }
  }

  async addedToCart() {
    // await browser.pause(3000)
    await actions.waitForDisplayed(addedToCard, "added to cart")
    assert.equal(
      await actions.isDisplayed(addedToCard, 'Added to the cart'),
      true,
      'Car should be added to cart'
    );
  }

  async collectCarsPageDetailsCP() {
    CarsPageCollectorCP.set(
      'pickUpDateFieldCP',
      (await actions.getText(pickUpDateField, 'Date information for pickup')).slice(5, 11));
    await browser.pause(2000);
    CarsPageCollectorCP.set(
      'dropOffDateFieldCP',
      (await actions.getText(dropOffDateField, 'Date information for dropping off')).slice(5, 11));
    await browser.pause(2000);
    CarsPageCollectorCP.set(
      'vehicletypeCP',
      await actions.getText(vehicletype, 'Type of the vehicle'));
    await browser.pause(2000);
  }

  async carspageContinueBtn() {
    await actions.pause(5000)
    await actions.waitForDisplayed(carPageHeader, 'carPageHeader', 30000)
    let carsHeaderVisibilty = await actions.isDisplayed(carPageHeader, 'carPageHeader')
    if (carsHeaderVisibilty) {
      await actions.pause(3000)
      await actions.waitForDisplayed(carsPageContinueButton, 'continue button in carspage', 20000)
      await actions.scroll(carsPageContinueButton);
      await actions.waitForClickable(carsPageContinueButton, 'continue button in carspage')
      await actions.pause(5000)
      await actions.clickElement('click', carsPageContinueButton, "Cars page Continue Button");
    }
  }
}
export { CarsPageCollectorCP }
export default new CarPage()