import actions from '@g4/prova-ui/src/support/actions'

const iframe1 = "[title='Rokt placement']"
const iframe2 = "[title='Rokt offer']"
const buttonselector = "[data-e2e='lightboxClose']"
const scrollitn = "[data-hook='confirmation-page-section_customer-info_title']"
const itnNumber = "[data-hook='confirmation-number_text']"

class ConfirmationPage {

    async manageframes() {
		await browser.pause(5000)
		let iframeVisibility = await actions.isDisplayed(iframe1, "first iframe")
		if (iframeVisibility) {
			await actions.switchToFrame(iframe1, "first iframe")
			await actions.switchToFrame(iframe2, "second iframe")
			await actions.waitForDisplayed(buttonselector, 'buttonselector', 10000)
			await actions.waitForClickable(buttonselector, 'buttonselector')
			await actions.clickElement('click', buttonselector, "button to close the Rocketer pop-up")
			await actions.switchToParentFrame()
			await actions.switchToParentFrame()
		}
		else {
			console.log("COOL!, No such Rocketer popup got displayed")
		}
	}

    async confirmationNumber() {
		await this.manageframes()
		await actions.scroll(scrollitn)
		let itinerary = await actions.getText(itnNumber, 'itnNumber')
		console.log("Generated ITN no is: " + itinerary);
		// process.env.confirmationNumber = itinerary
		// return itinerary
	}


}
export default new ConfirmationPage()