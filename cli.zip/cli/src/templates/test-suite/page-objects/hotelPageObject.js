import check from '@g4/prova-ui/src/support/validations'
import actions from '@g4/prova-ui/src/support/actions'

const heading = "//span[@data-hook='hotels-page_page-heading']";
const hotelText = "//span[contains(text(),'Bundle Air + Hotel and Save!')]"
const hotelTitle = "[data-hook='hotels-page_page-heading']"
const hotelPageTitle = '//title';
const hotelsPageHeadingTitle = "[data-hook='hotels-page_page-heading']";
const checkInDate = "[data-hook='hotels-page-search-criteria-check-in-date']";
const checkOutDate = "[data-hook='hotels-page-search-criteria-check-out-date']";
const hotelNoofRoom = "[data-hook='hotels-page-search-criteria-rooms-nights-count']";
const hoteldetailsPageRoom = '(//span[contains(@class,"Text-sc-1o5ubbx-0 bltVao")])[1]';
const hoteldetailsPageName = "[data-hook='hotel-details-page_name']";
const hoteldetailsPageAddress = "[data-hook='hotel-details-page_address']"
const hoteldetailsPagePrice = "[data-hook='room-pod_price']";
const hotelinfo = "[class='Text-sc-1o5ubbx-0 hCxZJY']"
const scroollist = "//*[text()='List View']"
const roomsnrates = "//*[text()='Rooms and rates']"
const scrollrooms = "//*[text()='Rooms & Rates']"
const roombooking = "[data-hook='room-pod_hotel-book-button']"
const addtocart = "[data-hook='room-pod_hotel-added-to-cart-label']"
const scrolldisclaimer = "[data-hook='hotels-page-disclaimer']"
const continueButton = "[data-hook='hotels-page_continue']"
// const cbutton = "[data-hook='hotel-details-page_continue']"
const cbutton = "//*[contains(text(),'Continue')]"
const skipHotel = "[data-hook='hotels-page_skip']"
const carsPageHeader = "[data-hook='cars-page_page-heading']"
var hotelsDetailsPageCollectorCP = new Map();
var hotelsPageCollectorCP = new Map();
var hotelsPageCollector = new Map();
var hotelsDetailsPageCollector = new Map();

class HotelPage {

    async collectHotelPageDetailsForConfirmationPage() {
        await actions.pause(10000)
        await browser.waitUntil(async () => {
            return (await actions.isDisplayed(hotelsPageHeadingTitle, "hotelsPageHeadingTitle") === true)
        }, {
            timeout: 60000,
            timeoutMsg: 'hotelsPageHeadingTitle is not displayed after 60s'
        })
        await actions.waitForDisplayed(hotelsPageHeadingTitle, 'Hotel page heading');
        hotelsPageCollectorCP.set(
            'checkInDateCP',
            await actions.getText(checkInDate, 'checkInDate'));

        hotelsPageCollectorCP.set(
            'checkOutDateCP',
            await actions.getText(checkOutDate, 'checkOutDate'));

        hotelsPageCollectorCP.set(
            'noOfRoomsCP',
            (await $(hotelNoofRoom).getText()).split[(" ", 1)]);

        var hotelRoom = await $(hotelNoofRoom).getText();
        hotelsPageCollectorCP.set(
            'noOfNightsCP',
            hotelRoom.slice(hotelRoom.indexOf(",") + 1, hotelRoom.indexOf("-")).trim());
    }

    async hotelselection() {
        await actions.waitForDisplayed(scroollist, 'scroollist', 400000)
        await actions.scroll(scroollist);
        await actions.waitForDisplayed(roomsnrates, 'roomsnrates button')
        await actions.waitForClickable(roomsnrates, 'roomsnrates button')
        await actions.clickElement('click', roomsnrates, "Button of rooms and rates");
    }

    async collectHotelDetailsPageDetailsForConfirmationPage() {
        hotelsDetailsPageCollectorCP.set(
            "hoteldetailsPageNameCP", await $(hoteldetailsPageName).getText());
        // await browser.pause(2000);
        hotelsDetailsPageCollectorCP.set(
            "hoteldetailsPageAddressCP", (await $(hoteldetailsPageAddress).getText()).trim());
        // await browser.pause(2000);
        hotelsDetailsPageCollectorCP.set(
            'hoteldetailsPageRoomCP', (await $(hoteldetailsPageRoom).getText()).trim().replace(/[&@*^%]/g, '/'));
        // await browser.pause(2000);
    }

    async roomselection() {
        await actions.waitForDisplayed(scrollrooms, 'scrollrooms')
        await actions.scroll(scrollrooms);
        await actions.waitForDisplayed(roombooking, 'roombooking button')
        await actions.waitForClickable(roombooking, 'roombooking button')
        await actions.clickElement('click', roombooking, "Button to book the rooms");
        await browser.pause(5000)
    }

    async hotelContinueBtn() {
        await actions.pause(5000)
        await actions.waitForDisplayed(cbutton, 'cbutton button', 30000)
        await actions.scroll(cbutton);
        await actions.waitForClickable(cbutton, 'cbutton button')
        await actions.clickElement('click', cbutton, "Hotel's Page Continue Button");
        await actions.waitForDisplayed(carsPageHeader, 'carsPageHeader', 30000)
    }
}
export { hotelsPageCollector }
export { hotelsDetailsPageCollector }
export { hotelsPageCollectorCP }
export { hotelsDetailsPageCollectorCP }
export default new HotelPage()