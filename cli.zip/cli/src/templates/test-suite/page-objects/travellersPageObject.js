import actions from '@g4/prova-ui/src/support/actions'
import TravelersPage from './TravelersPage'
import { departDate, returnDate } from './flightsPageObject'
import { faker } from '@faker-js/faker'
var firstName
var lastName
let countTraveler
const travelerType = "//span[contains(@data-hook,'_title')][contains(@data-hook,'travelers-form_')]"
const infantInLap = "//span[contains(@data-hook,'travelers-form_infantsInLap_0_title')]"
const infantInLapMonth = "[data-hook='travelers-form_infantsInLap_0_dob-month']"
const infantInLapDay = "[data-hook='travelers-form_infantsInLap_0_dob-day']"
const infantInLapYear = "[data-hook='travelers-form_infantsInLap_0_dob-year']"
const designatedLapField = "//div[@data-hook='travelers-form_TYPE_X_designated-lap']//div//div//div"
const designatedLapDropDownOptionSelection = "//div[contains(@id,'react-select-infantsInLap.X.designated-lap-option-Y')]"
const nameValidation = "[data-hook='travelers-form_adults_0_first-name']"
const lname = "[data-hook='travelers-form_adults_0_last-name']"
const month = "[data-hook='travelers-form_adults_0_dob-month']"
const settingmonth = "[data-hook='travelers-form_adults_0_dob-month'] input"
const day = "[data-hook='travelers-form_adults_0_dob-day']"
const selectingdate = "[data-hook='travelers-form_adults_0_dob-day'] input"
const year = "[data-hook='travelers-form_adults_0_dob-year']"
const namescroll = "[data-hook='travelers-form_adults_0_title']"
const selectinggender = "[data-hook='travelers-form_adults_0_gender_MALE']"
const ssrscrolling = "[data-hook='travelers-form_adults_0_ssrs-section_open-button']"
const travelerCount = "//*[@data-hook='header-flight-info_seated']"
const continuetrav = "[data-hook='travelers-page_continue']"
const spinnerBar = "//span[contains(@data-hook,'spinner')]"
const addButtonSSR = "[data-hook='travelers-form_adults_X_ssrs-section_label']"
const addButtonSSRChild = "//*[@data-hook='travelers-form_children_X_ssrs-section_label']"
const wheelchairAssistance = "//label[@data-hook='travelers-form_adults_X_LEG_airport-provided-wheelchair_label']//div[contains(@class,'Checkbox')]";
const wheelchairAssistanceChild = "//label[@data-hook='travelers-form_children_X_LEG_airport-provided-wheelchair_label']//div[contains(@class,'Checkbox')]";
const personalWheelChairScooter = "//label[@data-hook='travelers-form_adults_X_LEG_wheelchair_label']//div[contains(@class,'Checkbox')]"
const personalWheelChairScooterChild = "//label[@data-hook='travelers-form_children_X_LEG_wheelchair_label']//div[contains(@class,'Checkbox')]"
const departingPersonalWheelchairOrScooter = "[data-hook='travelers-form_adults_0_departing_wheelchair_label']";
const returningPersonalWheelchairOrScooter = "[data-hook='travelers-form_adults_0_returning_wheelchair_label']";
const departingWheelchairWCHS = "[data-hook='travelers-form_adults.0.departing_WCHS']";
const returningWheelchairWCHS = "[data-hook='travelers-form_adults.0.returning_WCHS']";
const wheelchairType = "[data-hook='travelers-form_adults.X.LEG_SSRTYPE']";
const departingPersonalWheelchairWCBW = "[data-hook='travelers-form_adults.0.departing_WCBW']";
const returningPersonalWheelchairWCBW = "[data-hook='travelers-form_adults.0.returning_WCBW']";
const departingOxygenConcentrator = "[data-hook='travelers-form_adults_0_departing_oxygen-concentrator_label']";
const returningOxygenConcentrator = "[data-hook='travelers-form_adults_0_returning_oxygen-concentrator_label']";
const oxygenConcentrator = "//label[@data-hook='travelers-form_adults_X_LEG_oxygen-concentrator_label']//div[contains(@class,'Checkbox')]";
const oxygenConcentratorChild = "//label[@data-hook='travelers-form_children_X_LEG_oxygen-concentrator_label']//div[contains(@class,'Checkbox')]";
const departingEmotionalSupport = "(//span[contains(text(),'Emotional Support')])[1]";
const returningEmotionalSupport = "(//span[contains(text(),'Emotional Support')])[2]";
const departingDeaf = "(//span[contains(text(),'Deaf')])[1]";
const returningDeaf = "(//span[contains(text(),'Deaf')])[2]";
const deafSSR = "//label[@data-hook='travelers-form_adults_X_LEG_deaf-hard-of-hearing_label']//div[contains(@class,'Checkbox')]"
const deafSSRChild = "//label[@data-hook='travelers-form_children_X_LEG_deaf-hard-of-hearing_label']//div[contains(@class,'Checkbox')]"
const serviceAnimal = "//label[@data-hook='travelers-form_adults_X_LEG_service-animal_label']//div[contains(@class,'Checkbox')]"
const serviceAnimalChild = "//label[@data-hook='travelers-form_children_X_LEG_service-animal_label']//div[contains(@class,'Checkbox')]"
const blindSSR = "//label[@data-hook='travelers-form_adults_X_LEG_visually-impaired_label']//div[contains(@class,'Checkbox')]"
const intellectualSSR = "//label[@data-hook='travelers-form_adults_X_LEG_intellectual-or-developmental-disability_label']//div[contains(@class,'Checkbox')]"
const blindSSRChild = "//label[@data-hook='travelers-form_children_X_LEG_visually-impaired_label']//div[contains(@class,'Checkbox')]"
const intellectualSSRChild = "//label[@data-hook='travelers-form_children_X_LEG_intellectual-or-developmental-disability_label']//div[contains(@class,'Checkbox')]"
const lapInfantheader = "[data-hook='travelers-form_infantsInLap_0_title']"
const tofromGate = "//label[@data-hook='travelers-form_adults.X.LEG_WCHR']/div[2]"
const tofromGateChild = "//label[@data-hook='travelers-form_children.X.LEG_WCHR']/div[2]"
const manualWheelChairScooter = "//label[@data-hook='travelers-form_adults.X.LEG_WCMP']/div[2]"
const manualWheelChairScooterChild = "//label[@data-hook='travelers-form_children.X.LEG_WCMP']/div[2]"
const infantInLapFirstName = "//input[@data-hook='travelers-form_infantsInLap_0_first-name']"
const infantInLapLastName = "//input[@data-hook='travelers-form_infantsInLap_0_last-name']"
const infantInLapGender = "//label[@data-hook='travelers-form_infantsInLap_0_gender_FEMALE']"
const departingText = "(//*[@class='Text-sc-1o5ubbx-0 bUDeQp'])[1]"

class TravellersPage {
    async fillAlltravelerDetails(travelerCount) {
        var LapInfantCheck = travelerCount
        // await actions.waitFor(travelerType,30000)
        await actions.waitUntil(travelerType, 'traveller form')
        await actions.waitForDisplayed(travelerType, 'traveller form')
        var paxType = await browser.$$(travelerType)
        console.log("paxType.length: " + paxType.length)
        if (travelerCount === "all") {
            travelerCount = paxType.length
            // if (await actions.isDisplayed(infantInLap, 'infant in lap form')) {
            //     travelerCount = paxType.length - 1
            // }
        }
        for (var i = 0; i < paxType.length; i++) {
            console.log("paxType[i].getText(): " + (await actions.getText(paxType[i], 'paxType')))
        }
        var Fname = "";
        var Lname = "";
        var Mail;
        if (process.env.ENV.includes("prod")) {
            Fname = "QAPROD"
            Lname = "PLZIGNORE"
            Mail = "bat@allegiantair.com"
        } else {
            Fname = "QA"
            Lname = "Automation"
            Mail = "someone@invalidemail.com"
        }
        var randomFname
        var randomLname
        var randomGender
        var randomDOB
        var FakeDOB
        var gen = "male"
        var dateOfBirth = "10-10-1990"
        var infantCount = 0;

        for (var i = 1; i < travelerCount; i++) {
            randomFname = await faker.name.firstName();
            Fname = Fname + "|" + randomFname
            randomLname = await faker.name.lastName();
            Lname = Lname + "|" + randomLname
            //FakeDOB = faker.date.between('01-10-1970', '01-10-1990');
            let travellertype = (await paxType[i].getText()).split(':')[1]
            if (travellertype.toLowerCase().trim().includes("infant")) {
                infantCount = infantCount + 1;
            }
            FakeDOB = await this.getDOB(travellertype.toLowerCase().trim())
            var month = FakeDOB.getMonth() + 1
            var fakeDate = FakeDOB.getDate()
            if (month < 10) {
                month = "0" + month;
            }
            if (fakeDate < 10) {
                fakeDate = "15";
            }
            randomDOB = fakeDate + "-" + month + "-" + FakeDOB.getFullYear()
            dateOfBirth = dateOfBirth + "|" + randomDOB
            randomGender = "male"
            gen = gen + "|" + randomGender
        }
        await TravelersPage.enterTravelerFirstName(Fname);
        await TravelersPage.enterTravelerLastName(Lname);
        await TravelersPage.selectTravelerDOB(dateOfBirth);
        await TravelersPage.selectTravelerGender(gen);
        await TravelersPage.enterTravelerPhone("78456912332");
        await TravelersPage.enterTravelerEmailId(Mail);

        firstName = Fname;
        Fname = "";
        lastName = Lname;
        Lname = "";

        if (infantCount > 0) {
            let infantInLapVisibility = await actions.isDisplayed(infantInLap, 'LapInfant form')
            if (infantInLapVisibility) {
                await actions.scroll(lapInfantheader)
                await actions.clickElement('click', designatedLapField.replace("TYPE", 'infantsInLap').replace("X", 0), "designated lap dropdown")
                await actions.clickElement('click', designatedLapDropDownOptionSelection.replace("X", 0).replace("Y", 0), "designated lap dropdown")
            }
        }
    }

    async getDOB(DOB) {
        var newDOB = new Date(departDate);
        console.log("departDate: ", departDate)

        if (DOB.includes("adult")) {
            newDOB.setDate(newDOB.getDate() - 12000);
        }
        if (DOB.includes("child")) {
            await browser.pause(3000)
            newDOB.setDate(newDOB.getDate() - 5000);
        }
        if (DOB.trim().includes("infant")) {
            newDOB.setDate(newDOB.getDate() - 300);
        }
        if (DOB === "currentDate") {
            newDOB.setDate(newDOB.getDate() - 0);
        }
        if (DOB === "yearInFuture") {
            newDOB.setDate(newDOB.getDate() + 366);
        }
        if (DOB === ">2yrsForRetrunflight") {
            newDOB = new Date(returnDate);
            newDOB.setDate(newDOB.getDate() - 732);
        }
        return newDOB
    }

    async continuebuttontravellers() {
        console.log("process.env.timeline : ", process.env.timeline)
        await browser.pause(3000)
        await actions.scroll(continuetrav)
        await actions.waitForClickable(continuetrav, "travellers page continue button")
        await actions.pause(3000)
        await actions.clickElement('click', continuetrav, "travellers page continue button")
        await browser.pause(10000)
    }
}

export { firstName, lastName }
export default new TravellersPage()