import { fail } from "yargs";
import { handler } from "../../src/commands/NotAutomatedScenarios.js";

describe('TC01-Validating prova-CLI NotAutomatedScenarios commands', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('TC01.1.validate NotAutomatedScenarios count using regression-test-suite', async () => {
        const actualValue = await handler()
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(0);
        const expectedValue = 3;
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test with NotAutomatedScenarios is passed")
                return { actualValue }
            }else{
                console.log("test with NotAutomatedScenarios is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);

});