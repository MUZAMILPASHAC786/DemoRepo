import { fail } from "yargs";
import { handler } from "../../src/commands/tag-count.js";

describe('TC01-Validating prova-CLI tag-count commands', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('TC01.1.validate for "@regression" tag using regression-test-suite', async () => {
        let inputObject = {tag: '@regression'}
        const actualValue = await handler(inputObject)
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(0);
        const expectedValue = 409;
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test with tag=@regression is passed")
                return { actualValue }
            }else{
                console.log("test with tag=@regression is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);

    it('TC01.2.validate for "@hd" tag using regression-test-suite', async () => {
        let inputObject = {tag: '@hd'}
        const actualValue = await handler(inputObject)
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(0);
        const expectedValue = 97;
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test with tag=@hd is passed")
                return { actualValue }
            }else{
                console.log("test with tag=@hd is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);
});