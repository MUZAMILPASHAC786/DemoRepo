import { fail } from "yargs";
import { handler } from "../../src/commands/tag-summary.js";

describe('TC01-Validating prova-CLI MatrixforGrafana command', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('TC01.1.validate total feature count using regression-test-suite', async () => {
        const actualValue = await handler()
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(0);
        const expectedValue = 20;
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test for MatrixforGrafana with feature count is passed")
                return { actualValue }
            }else{
                console.log("test for MatrixforGrafana with feature count is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);

});