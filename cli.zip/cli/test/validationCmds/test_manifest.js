import { fail } from "yargs";
import { handler } from "../../src/commands/manifest.js";

describe('TC01-Validating prova-CLI manifest commands', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('TC01.1.validate manifest without tag using regression-test-suite', async () => {
        const actualValue = await handler()
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(undefined);
        const expectedValue = '../regression-test-suite/manifest.json'
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test with without any tag is passed")
                return { actualValue }
            }else{
                console.log("test with without any tag is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);

    it('TC01.2.validate scenarios with having tag = "@regression" using regression-test-suite', async () => {
        let inputObject = {tag: '@regression'}
        const actualValue = await handler(inputObject)
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(undefined);
        const expectedValue = '../regression-test-suite/manifest.json'
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test with tag=@regression is passed")
                return { actualValue }
            }else{
                console.log("test with tag=@regression is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);

    it('TC01.3.validate scenarios with not having tag = "@regression" using regression-test-suite', async () => {
        let inputObject = {
            'not-having-tag': '@regression',
             notHavingTag: '@regression',
        }
        const actualValue = await handler(inputObject)
        jest.setTimeout(20000);
        expect(actualValue).not.toBe(undefined);
        const expectedValue = '../regression-test-suite/manifest.json'
        jest.fn(() => {
            if (expectedValue === actualValue) {
                console.log("test with tag=@regression is passed")
                return { actualValue }
            }else{
                console.log("test with tag=@regression is Failed")
                return fail
            }
        });
        console.log("actual value is: ",actualValue," and expectedValue is: ",expectedValue)
    }, 60000);
});