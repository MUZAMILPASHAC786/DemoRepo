## Troubleshooting

> The problem with troubleshooting is that trouble shoots back :P

### Common Issues
1. `npm ERR! self signed certificate in certificate chain` <br/>
This is happening because Allegiant Airs self signed certs are not on your system
    * Solution 1
        - Copy the cert [here](../assets/certs/nexus.allegiantair.com) to somewhere on your system
        - npm config set cafile /path/to/your/cert.pem --global

    * Solution 2
        - npm config set strict-ssl false --global

2. `git@allegiantair.com: Permission required (public key)` <br/>
This is happening because you haven't setup ssh keys in your system
    * Solution
        - Set up ssh keys on you system. Refer this [article](https://confluence.atlassian.com/bitbucket/set-up-an-ssh-key-728138079.html)

3. `g4/prova@0.3.0 is not in the npm registry`
   `you should bug the author to publish it( or use the name yourself)`
   `It was specified as a dependency e2e`
   `Note that you have to install from a tarball, folder.....`
   But still you might get
   `Node modules installed successfully`
   `All Set !! Go to e2e directory and run`

   *Solution

    When we do a prova init, it pulls all the documents from prova-cli. There is a file .npmrc file which is in prova cli / src /templates / test suite folder is missed copying to local.

   *Work Around:
   Add a file called .npmrc and add the content "registry=https://nexus3.allegiantair.com/repository/g4npm/ " inside the file and save them
   &&
   Perform "npm install"

   This should download all the required dependencies        

### Windows Issues
1. `prova : File C:\Users\{user}\AppData\Roaming\npm\prova.ps1 cannot be loaded because running scripts is disabled on this` <br/>
This is because PowerShell scripts are unsigned . Reference (https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.security/set-executionpolicy?view=powershell-6#parameters)

    * Solution
        - Open PowerShell as Adminstrator.
        - Run `Set-ExecutionPolicy -ExecutionPolicy Unrestricted`
2. Getting error 'appEnv' is not recognized as an internal or external command, when I run the command <br/>
   <code>
     appEnv='https://www-dev-proj-rebr.okd.allegiantair.com' tag='@allegiant' prova test
   </code>
   
   * Solution
       You need to install Windows Build Tools <br/>
       <code>
           npm install --global --production windows-build-tools
       </code>

### Mac Issues
1. No XCode or CLT Version detected <br/>
    * Solution <br/>
        [Medium Article describing how to solve](https://medium.com/flawless-app-stories/gyp-no-xcode-or-clt-version-detected-macos-catalina-anansewaa-38b536389e8d) <br/>
        <code>
            sudo rm -rf $(xcode-select -print-path)  <br/>
            xcode-select --install
        </code>

### Contribute
If you faced an issue, and would like to add the solution to this page, please raise a PR or get in touch with QA team.
