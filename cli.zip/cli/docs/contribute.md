## Prova CLI Development
----
#### Lets make prova cli better, together !!

We are thrilled that you chose to contibute !! Welcome aboard !!

### Dependencies
* Node >= v10 (This lib was tested with v10.16.0)
* Npm >= v6 (This lib was tested with v6.9.0)

### Installation
```bash
# Clone repo
git clone ssh://git@git.allegiantair.com:7999/gqa/prova-cli.git

# Install deps
npm install --unsafe-perm
```

### Linting
```bash
npm run lint
```

### Build
```bash
npm run build
```

### Publishing to Nexus
```bash
# Login to Nexu Repo using your AD credentials
npm login --registry=https://nexus3.allegiantair.com/repository/g4npm_hosted/

# Publish
npm publish
```

### Contribute
Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License
Copyright (c) Allegiant Travel Company
