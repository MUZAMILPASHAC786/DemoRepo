const { validateFeatureFile } = require('../../src/common/featureFileValidator')
const {askBearerToken} = require('../../src/common/getCredentials')

const helper = require('../../src/common/helpers')
describe('I)TagSummary', () => {
    test('1)mockName-Helper-Delete Directory', async () => {
        const mockFn = jest.fn()
        mockFn.mockImplementation(helper.deleteDirectory)
        await mockFn()
        jest.setTimeout(6000)
        expect(mockFn).toHaveBeenCalled();
    },6000);
  
});
