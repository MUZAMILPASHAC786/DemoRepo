const { default: qTestAPI } = require('../../src/common/qTestAPI');
const {schemaValidator}=require('../../src/common/qTestJsonValidator')
const utils=require('../../src/utils')



describe('I)Manifest', () => {
   
    test('1)mockName-streamToArray', async () => {
        const mockFn = jest.fn(utils.streamToArray)
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
    test('4)mockName-pushTestCasesqTest', async () => {
        const mockFn = jest.fn(schemaValidator({
            "Allegiant-Automation-POC": [
                {
                    "qTestFolderPath": "Sample-Folder/Demo-folder",
                    "repoFeaturePath": "test/regression-test-suite/features/booking/CCBooking.feature",
                     "persistenceTeam": "Mad Dogs",
                    "pushToQTest": true
                }
            ]
         }))
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
});

