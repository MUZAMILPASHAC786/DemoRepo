const scenarios = require('../../src/commands/scenarios')
describe('I)Scenarios', () => {
    test('1)mockName-Build-cmdArgs', async () => {
        const mockFn = jest.fn(scenarios.cmdArgs)
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
    test('2)mockName-Build-handler', async () => {
        const mockFn = jest.fn(scenarios.handler({ _: [ 'scenarios' ], '$0': '..\\..\\bin\\prova.js' }))
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
});

jest.mock('../../src/utils', () => ({
    getFeatureInfo: jest.fn().mockResolvedValue([
        {
          featureName: 'This feature file is to run all CC booking and modification scenarios',
          featurePath: 'features/booking/CCBooking.feature',
          featureTags: [
            '@commercial',
            '@digital-customer',
            '@ccbooking',
            '@manual',
            '@regression'
          ],
          scenario: ['I navigate to G4 portal',
            'I select "BOOK" tab',
            'I am on booking page I select "ABE" for the departure airport',
            'I am on booking page I select "SFB" for the destination airport',
            'I am on booking page I select "roundTrip"',
            'I am on booking page I choose the departure date "2" days from current day',
            'I am on booking page I choose the returning date "2" days from departure day',
            'I am on booking page I select "1" adult travelers count',
            'I click on search in booking page',
            'I click on Continue in flights page',
            'I click on Continue in Bundles page',
            'I click on Continue in Hotels page',
            'I click on Continue in Special rental Page',
            'I click on Ok in SSR popup',
            'I click on Continue in seats page',
            'I click on continue button in Bags page',
            'I enter Travelers details in Travelers page',
            'I click on Continue in Travelers page',
            'I enter required Card Details in Payment page',
            'I select "true" in payment page',
            'I enter required Billing Address in Payment page',
            'I click on Purchase Mytrip in Payment page',
            'I am on the confirmation page, I expect confirmation number to be displayed',
            'I navigate to www application',
            'I click on ManageTrip Button',
            'I retrieve booked itinerary in ManageTravel application',
            'I am on Manage Travel page, I expect flight details are displayed correctly',
            'I add "PETC" in Trip Summary',
            'I am on Manage Travel seats page, I select a Seat Randomly',
            'I am on Manage Travel seats page, I click on Continue button',
            "I am on Manage Travel page, Bag's page I add Bags",
            "I am on Manage Travel page, Bag's page I click on Continue button",
            'I am on Manage Travel page, Hotel’s page I click on continue button',
            'I am on Manage Travel page, Car’s page I click on continue button',
            'I am on Manage Travel page, Payment page I complete payment',
            'I navigate to G4 portal',
            'I select "MOD"',
            'I retrieve booked itinerary in CCMOD application',
            'I expect "Departure Date" trip summary details to be displayed in CCMod correctly',
            'I expect "Departure City" trip summary details to be displayed in CCMod correctly',
            'I expect "Destination City" trip summary details to be displayed in CCMod correctly',
            'I expect "1" pax count to be displayed in CCMod correctly',
            'I expect "Flights" trip summary details to be displayed in CCMod correctly',
            'I expect "Taxes & Govt Fees" trip summary details to be displayed in CCMod correctly',
            'I navigate to G4 portal',
            'I select "BOOK" tab',
            'I am on booking page I select "ABE" for the departure airport',
            'I am on booking page I select "SFB" for the destination airport',
            'I am on booking page I select "roundTrip"',
            'I am on booking page I choose the departure date "2" days from current day',
            'I am on booking page I choose the returning date "2" days from departure day',
            'I am on booking page I select "1" adult travelers count',
            'I click on search in booking page',
            'I click on Continue in flights page',
            'I click on Continue in Bundles page',
            'I click on Continue in Hotels page',
            'I click on Continue in Special rental Page',
            'I select "PETC" and click on Ok in SSR popup',
            'I select a seat Randomly on Seats page',
            'I click on Continue in seats page after selecting seats',
            'I add "1" Carryon Bag and Priority Access in Bags page',
            'I click continue button in Bags page',
            'I enter Travelers details in Travelers page',
            'I click on Continue in Travelers page',
            'I enter required Card Details in Payment page',
            'I select "true" in payment page',
            'I enter required Billing Address in Payment page',
            'I click on Purchase Mytrip in Payment page',
            'I am on the confirmation page, I expect confirmation number to be displayed',
            'I navigate to G4 portal',
            'I select "MOD"',
            'I retrieve booked itinerary in CCMOD application',
            'I expect "Departure Date" trip summary details to be displayed in CCMod correctly',
            'I expect "Departure City" trip summary details to be displayed in CCMod correctly',
            'I expect "Destination City" trip summary details to be displayed in CCMod correctly',
            'I expect "1" pax count to be displayed in CCMod correctly',
            'I expect "Flights" trip summary details to be displayed in CCMod correctly',
            'I expect "Taxes & Govt Fees" trip summary details to be displayed in CCMod correctly',
            'I select checked bag 1 for traveler 1 for both segments',
            'I select Accept and Continue button',
            'I enter Payment details',
            'I enter received from',
            'I click submit button',
            'I click Confirm & Redisplay button',
            'I expect "3" Checked Bags for traveler 1 for departing segment to be displayed in CCMod',
            'I navigate to www application',
            'I click on ManageTrip Button',
            'I retrieve booked itinerary in ManageTravel application',
            'I am on Manage Travel page, I expect flight details are displayed correctly',
            "I navigate to Manage Travel Bag's page, I click on Continue button",
            'I am on Manage Travel seats page, I click on Continue Button',
            'I am on Manage Travel page, Hotel’s page I click on continue button',
            'I am on Manage Travel page, Car’s page I click on continue button',
            'I am on Manage Travel page, Payment page I complete payment',
            'I navigate to G4 portal',
            'I select "BOOK" tab',
            'I am on booking page I select "ABE" for the departure airport',
            'I am on booking page I select "SFB" for the destination airport',
            'I am on booking page I select "roundTrip"',
            'I am on booking page I choose the departure date "2" days from current day',]
        }
        // Add more mocked feature info as needed
      ])
}));

describe('5)handler function', () => {
    it('should filter scenarios by tag when tag is provided', async () => {
        const argv ={ _: [ 'scenarios' ], '$0': '..\\..\\bin\\prova.js' };
        const totalScenarios = await scenarios.handler(argv);
        expect(totalScenarios).toBe(100);
        // Add more assertions as needed
    });

    it('should filter scenarios by notHavingTag when notHavingTag is provided', async () => {
        const argv = { _: [ 'scenarios' ], '$0': '..\\..\\bin\\prova.js' };
        const totalScenarios = await scenarios.handler(argv);
        expect(totalScenarios).toBe(100);
        // Add more assertions as needed
    });

    it('should include all scenarios when neither tag nor notHavingTag is provided', async () => {
        const argv = {};
        const totalScenarios = await scenarios.handler(argv);
        expect(totalScenarios).toBe(100);
        // Add more assertions as needed
    });

    // Add more test cases as needed
});




