const tagSummary = require('../../src/commands/tag-summary')

jest.mock('../../src/utils', () => ({
    getFeatureInfo: jest.fn().mockResolvedValue([
      { scenario: [{ scenarioTags: ['tag1', 'tag2'] }] },
      { scenario: [{ scenarioTags: ['tag2', 'tag3'] }] },
      // Add more sample data as needed
    ]),
  }));
  
  // Now, you can write your test case for the handler function
  describe('2)handler', () => {
    it('should calculate total tags correctly', async () => {
      const totalTags = await tagSummary.handler();
      // Write your assertions here to check if the totalTags are calculated correctly
      // For example:
      expect(totalTags).toBe(4); // Assuming there are 4 total tags in the sample data
    });
  });
