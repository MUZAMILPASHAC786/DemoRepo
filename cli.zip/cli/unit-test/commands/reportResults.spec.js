const { setScenarioStepStatus,updateScenariosStatusCounts}=require('../../src/commands/report-results')
describe('1)setScenarioStepStatus', () => {
    it('should return green color for "passed"', async() => {
        const status = setScenarioStepStatus('passed');
        expect(status).toContain('passed');
    });

    it('should return yellow color for "skipped"', async() => {
        const status = setScenarioStepStatus('skipped');
        expect(status).toContain('skipped');
    });

    it('should return red color for "failed"', async() => {
        const status = setScenarioStepStatus('failed');
        expect(status).toContain('failed');
    })
    it('should return yellow color for "skipped"', async() => {
        const status = setScenarioStepStatus('skipped');
        expect(status).toContain('skipped');
    });

    it('should return red color for "failed"', async() => {
        const status = setScenarioStepStatus('failed');
        expect(status).toContain('failed');
    });
    it('should return blue color for other statuses', async() => {
        const status = setScenarioStepStatus('other');
        expect(status).toContain('other');
    });
});
describe('2)updateScenariosStatusCounts', () => {
    it('should increment passed count and return false if scenarioStepStatus is "passed"', () => {
        const result = updateScenariosStatusCounts('passed');
        expect(result).toBe(false);
});
});
describe('2)updateScenariosStatusCounts', () => {
    it('should increment passed count and return false if scenarioStepStatus is "passed"', () => {
        const result = updateScenariosStatusCounts('passed');
        expect(result).toBe(false);
    });

    it('should increment failed count and return true if scenarioStepStatus is "failed"', () => {
        const result = updateScenariosStatusCounts('failed');
        expect(result).toBe(true);
    });
    it('should increment failed count and return true if scenarioStepStatus is "failed"', () => {
        const result = updateScenariosStatusCounts('failed');
        expect(result).toBe(true);
    });

    it('should increment failed count and return true if scenarioStepStatus is "broken"', () => {
        const result = updateScenariosStatusCounts('broken');
        expect(result).toBe(true);
    });

    it('should increment skipped count and return false if scenarioStepStatus is "skipped"', () => {
        const result = updateScenariosStatusCounts('skipped');
        expect(result).toBe(false);
    });

    it('should increment skipped count and return false if scenarioStepStatus is "canceled"', () => {
        const result = updateScenariosStatusCounts('canceled');
        expect(result).toBe(false);
    });

    it('should return false if scenarioStepStatus is neither "passed", "failed", "broken", "skipped", nor "canceled"', () => {
        const result = updateScenariosStatusCounts('unknown');
        expect(result).toBe(false);
    })
    it('should increment failed count and return true if scenarioStepStatus is "broken"', () => {
        const result = updateScenariosStatusCounts('broken');
        expect(result).toBe(true);
    });

    it('should increment skipped count and return false if scenarioStepStatus is "skipped"', () => {
        const result = updateScenariosStatusCounts('skipped');
        expect(result).toBe(false);
    });

    it('should increment skipped count and return false if scenarioStepStatus is "canceled"', () => {
        const result = updateScenariosStatusCounts('canceled');
        expect(result).toBe(false);
    });

    it('should return false if scenarioStepStatus is neither "passed", "failed", "broken", "skipped", nor "canceled"', () => {
        const result = updateScenariosStatusCounts('unknown');
        expect(result).toBe(false);
    });
})
