const transpile = require('../../src/commands/transpile')
const provaGherkinExtensions =require('@g4/prova-gherkin-extensions');
jest.mock('@g4/prova-gherkin-extensions', () => ({
    run: jest.fn()
}));

describe('1)Transpile command', () => {
    it('should call provaGherkinExtensions.run() when builder is executed', async () => {
        await transpile.builder({});
        expect(provaGherkinExtensions.run).toHaveBeenCalled();
    });

    it('should handle errors when provaGherkinExtensions.run() throws an error', async () => {
        const mockError = new Error('Test error');
        provaGherkinExtensions.run.mockRejectedValueOnce(mockError);
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

        await transpile.builder({});
        expect(consoleErrorSpy).toHaveBeenCalledWith(mockError);
    });
});