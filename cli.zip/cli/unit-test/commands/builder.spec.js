const frameworkUsage = require('../../src/commands/FrameworkUsage')
const initAPI = require('../../src/commands/init-api')
const lint = require('../../src/commands/lint')
const reportResults = require('../../src/commands/report-results')
const report=require('../../src/commands/report')
const testApi = require('../../src/commands/test-api')
const testParallel = require('../../src/commands/test-parallel')

const testing=require('../../src/commands/test')
describe('I)Builder-framework usage', () => {
    test('1)mockName-Build-Framework-Usage', async () => {
        const mockFn = jest.fn(frameworkUsage.builder("prova FrameworkUsage"))
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
   
    test('3)mockName-Build-Lint', async () => {
        const mockFn = jest.fn(lint.builder("prova lint"))
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
    test('7)mockName-Build-reportResult', async () => {
        const mockFn = jest.fn(reportResults.builder("prova results"))
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
});