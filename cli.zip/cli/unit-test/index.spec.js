let index=require('../src/index')
describe('I)index', () => {
    test('1)mockName-print Banner', async () => {
        const mockFn = jest.fn(index.printBanner)
        mockFn.mockImplementation()
        await mockFn()
        expect(mockFn).toHaveBeenCalled();
    });
});
