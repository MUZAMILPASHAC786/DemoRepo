# Prova CLI
----
#### CLI utility for the prova framework
Prova CLI code base is the code base which gives all prova related commands [ prova init, help , test, reports , results, etc ] . So ideally prova CLI helps us to create a project and commands gives over layer to manage our tests.

### Etymology
CLI stands for `command-line interface`

### Dependencies
* Node >= v14
* Npm >= v6
* Python >= v2.7

### Install
```bash
# point npm to nexus registry
npm config set registry "https://nexus3.allegiantair.com/repository/g4npm/" -g

npm install -g @g4/prova-cli

npm install
```
<br />

### Usage
```bash
# See all available options
prova --help

# Setup a test suite using Prova
prova init

# Run tests
prova test

# Specify tags in tests
tag='@basic' prova test
```
<br />

### Commands
ALl the commands mention in below image  is part of Prova-CLI

![picture](images/Prova-CLI-Commands.png)

#### How your project will use Prova
Your test suite that will be setup by `prova init` will add `prova` as a dependency in 
package.json. 
All the [BDD Glossary](docs/bdd-glossary.md), 
[Actions](docs/actions.md), 
[Helpers](docs/helpers.md) will be available to use.
![picture](images/prova-framework.png)

### Documentation
* [Troubleshooting](docs/troubleshooting.md)
* [Contribute to Prova CLI Development](docs/contribute.md)

### Release Notes
* Please find release notes under CHANGELOG
  https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/browse/CHANGELOG.md 

### Confluence 
For More information check in below
https://confluence.allegiantair.com/display/QTA/Prova-Javascript+framework+playbook

### Contribute
Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License
Copyright (c) Allegiant Travel Company