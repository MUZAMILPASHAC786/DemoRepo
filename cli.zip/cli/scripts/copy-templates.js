const fs = require('fs-extra');
const path = require('path');

(async () => {
    const templateDir = path.join(__dirname, '../src/templates');
    const buildDir = path.join(__dirname, '../build/templates');

    await fs.copy(templateDir, buildDir);
})();
