# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.13.11](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.10...v1.13.11) (2024-11-08)


### Features

* QAA-28843_manual count and reason for manual count in Grafana is fixed ([#6](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/issues/6)) ([94f76cb](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/94f76cbe4a58b11e5d9f7b0a0a6997e210541984))

### [1.13.10](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.9...v1.13.10) (2024-11-05)


### Features

* QAA-28851 Fixed the prova test AU script issue in prova init ([#5](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/issues/5)) ([9ec748b](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/9ec748b2ec43f197f5c0d41fc1827e4956749f7e))

### [1.13.9](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.8...v1.13.9) (2024-10-29)


### Features

* QAA-28775_Fixed the issues when dataTable is used in feature file ([#3](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/issues/3)) ([982e837](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/982e83795a14cd164b679041e3403dd44f6d6b7d))


### Bug Fixes

* QAA-28826 Fixed issue in webservice count in MatrixforGrafana ([#4](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/issues/4)) ([1f7ef0c](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/1f7ef0c7194e3132e2078dad4bc9df88a53ad96e))

### [1.13.8](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.7...v1.13.8) (2024-10-28)


### Bug Fixes

* QAA-28806 Fixed issue in matrix for grafana ([#2](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/issues/2)) ([995aa34](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/995aa346a841704732db3e03a71300dcfc011be7))

### [1.13.7](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.6...v1.13.7) (2024-10-09)


### Features

* QAA-28641_Modified code in utils.js file for Examples to be pushed to qtest in all scenarios ([#1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/issues/1)) ([a99e53c](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/a99e53c492300582db47cfba0de6362a32537bd1))

### [1.13.6](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.5...v1.13.6) (2024-06-26)

### [1.13.5](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.4...v1.13.5) (2024-06-13)


### Features

* QAA-27526 Added Unit-test cases for prova-cli library ([17decdc](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/17decdc9c212ad0e44d6b1ea617c9c72f1e76519))
* QAA-27852_updated size parameter for get API in qTestUtil file ([c044abd](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/c044abdc5346f8b2c5f25c8f476096342c78f922))

### [1.13.4](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.3...v1.13.4) (2024-05-23)

### [1.13.3](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.2...v1.13.3) (2024-05-16)

### [1.13.2](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.1...v1.13.2) (2024-03-20)


### Features

* QAA-27393_Added code to select folder ID  based on folder name in qTestUtil file ([720db34](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/720db3402a7c6be1cbf47038dc7ba943e3c967fc))
* QAA-27430 Added logic for handling more than one example keyword ([1bed53a](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/1bed53aa9417cd0dd280071ef0c95185d3e78e48))
* QAA-27430 Added logic to handle tags in examples ([8528e06](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/8528e06768fce8824ce64ca4417eebb19e5dae8b))

### [1.13.1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.13.0...v1.13.1) (2024-03-05)


### Features

* QAA-27376_push2qTest_enhancements and issues ([0b40344](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/0b403448d3fb02a347c19501561b294e78cc5f75))

## [1.13.0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.12.0...v1.13.0) (2024-03-05)

## [1.12.0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.6...v1.12.0) (2024-02-28)


### Features

* QAA-27360_Modified persistenceTeam ([d5d0275](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/d5d0275c1e27afcb79827b0200eac54b09e9c249))
* QAA-27360_Removed hardcoded values for P1 Regression and Sub Type fields ([6cb5b62](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/6cb5b621646a57101344115fc134ad78e82d76d3))

### [1.11.6](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.5...v1.11.6) (2024-02-27)


### Features

* QAA-27360 updated team name error message ([ecd433e](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/ecd433e3333fe935b25ccff5080e8ba68a86da0f))
* QAA-27360_Added code to handle P1 Regression field. ([6ba5b79](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/6ba5b799a0c7cc618231838cbd1c162e5ebd1aec))
* QAA-27360_Added code to handle persistence Team drop down ([4d4c79d](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/4d4c79d2ebb732a149a1ba5135a9308501dd109a))
* QAA-27360_Added UNAUTHORIZED to all API calls ([0004549](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/0004549695c8fc4d8eac32b6630eb161e5111057))
* QAA-27360_removed commented lines ([6c37eae](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/6c37eae8145eddbd61e2691306125a084249cdfb))

### [1.11.5](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.4...v1.11.5) (2024-02-22)


### Features

* QAA-27328_Updated test case properties in  qTestAPI.js ([056ca41](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/056ca41b85dd3275580a02f255496e91a4c6b5cd))
* updated build folder ([03639bf](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/03639bf8283df8a17d1a016ad5f7bdf9777cab91))

### [1.11.4](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.3...v1.11.4) (2024-02-21)


### Features

* QAA-27328_Added Bearer token as Input ([81ec6f4](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/81ec6f4580b325460a1751f02a7f0ac327e6c60d))

### [1.11.3](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.2...v1.11.3) (2024-02-16)


### Bug Fixes

* QAA-27281_fixed import chalk ([c9f6f18](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/c9f6f182c4ba9463b345030ccba64184cc9e28c0))
* QAA-27281-Updated getCredential file ([011fab0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/011fab0a81a61af032083284ec1106f74ad9371f))

### [1.11.2](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.1...v1.11.2) (2024-02-16)


### Features

* QAA-27281_Added code based on username and password to generate token ([0ccae74](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/0ccae740cffbcb1f34835ba6ba18bce868fb9ffd))

### [1.11.1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.11.0...v1.11.1) (2024-02-13)


### Bug Fixes

* installed node-fetch@2 ([044f425](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/044f42599f72d347dab4264d995a1f71fc04228a))

## [1.11.0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.10.1...v1.11.0) (2024-02-13)


### Features

* QAA-27236_PushToQTest Prova-CLI Command ([9543071](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/9543071a764977eb6078c3afe831e5e3c176b65b))

### [1.10.1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.10.0...v1.10.1) (2023-12-21)


### Features

* QAA-27028_Fix count discrepancy for new tags ([eea8bfe](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/eea8bfe77e590d072f9a8f6401bb54db073e361c))
* QAA-27028_removed unused condition ([8717768](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/8717768a12f231dc0a8358c66802416f02d2bedb))

## [1.10.0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.9.1...v1.10.0) (2023-12-08)


### Features

* QAA-26878 Added coding to capture scenario details tagged as [@disabled](https://git.allegiantair.com:8443/disabled), [@deprecated](https://git.allegiantair.com:8443/deprecated), [@obsolete](https://git.allegiantair.com:8443/obsolete) ([392a12f](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/392a12f3fceb4a9b4034d2ac71fd63716ea9fa7c))
* QAA-26987_Updated MatrixforGrafana with checking upgraded to prova-ui ([ca60ea5](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/ca60ea5e3e7b4cfcf8f5abf9bff9c1ddd10713f1))
* Removed the files that was added for testing ([110a295](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/110a295fa618125892a95d34785fbbf231759fbb))

### [1.9.1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.9.0...v1.9.1) (2023-11-06)


### Features

* Updated README.md file ([4ac2022](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/4ac2022d948035440cd19575a8ec4c874f601e69))

## [1.9.0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/compare/v1.8.1...v1.9.0) (2023-09-14)


### Features

* QAA-26738 added prova-init-api command ([8790e3d](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/8790e3da3732cab5c36bf0ab06da18138fc8c279))
* QAA-26738 modified init-api file ([609c259](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/609c25973a1f4785256b7bb42772dbe870c42965))
* QAA-26738 updated build file ([c694582](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/c69458272628331f00962fb7d1de231d732e1476))
* QAA-26738 updated build folder ([45c91c0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/45c91c0c84339500c15fc74e2344e523bfec4b16))
* updated init-api file ([2f8a777](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/2f8a777922a57faf30e3910fe9203b01519730d8))

### 1.8.1 (2023-07-12)


### Features

* added standard version in provaCLI ([7973fa1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/7973fa1eb58d062f0490313cd45935f00bb9b69e))
* removed nvmrc & npmrc ([02c2fbb](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/commit/02c2fbbcaebbce31f6144f3cbd188ecdc17e6ae2))

## [1.8.0] - 2023-06-06
- QAA-26464 - Prova CLI support to AutoNG/Java project
 - Added the condition for info.properties "infoPropertiesName"
## [1.7.3] - 2023-05-23
- QAA-26425 - Updated the init command

## [1.7.2] - 2023-03-16
- QAA-26147 - Fixed issue with featurePath in MatrixforGrafana Command

## [1.7.1] - 2023-02-23
- QAA-25974 - Fixed issue with filepath in MatrixforGrafana Command

## [1.7.0] - 2023-02-22
- QAA-25974 - Code refactoring to easily validate commands
  - Rremoved tagSummaryNew as it was duplicate of tagSummary
  - Added features to scenarios and manifest get info for tag and not having tag
  - Added jest cases to validate commands

## [1.6.2] (11 NOV 2022)

- Fixed the issue with MatrixforGrafana command for WS scenarios- QAA-25303
  (Updated the Scenrio.js for  MatrixForGrafana to include Examples acount under same sceaniro)

## 1.6.1 (13 OCT 2022)

- Fixed the issue with framework usage command - QAA 

## 1.6.0 (12 SEP 2022)

- Added new command  to collect framework usage of Prova - QAA-25039
- Updated the Init.js command
- Updated the dependencies in package.json
- Updated the browser-config.json
## 1.5.0 (17 AUG 2022)

- Added new command  to collect framework usage of Prova - QAA-24435
- New Command: prova FrameworkUsage
- Added the Database control db=yes
## 1.4.0 (30 June 2022)

-   Added new command  to collect scenarios list and count that are tagged as manual and regression - QAA-24437
- New Command: prova NotAutomatedScenarios

## 1.3.0 (16 MAR 2022)

-   Added ability to collect information from specified path rather then package.json - QAA-24267

## 1.2.0 (16 MAR 2022)

-   Added WS tag details to MatrixforGrafana
-   Added runtime paramater to control manual entries to DB
## 0.10.0 (29 Sept 2020)

-   Add new cli option (prova test-prarallel)

## 0.9.0 (0 Sept 2020)

-   Add performance time to prova results

## 0.8.2 (0 Sept 2020)

-   Updating Prova Gherkin Extensions to @g4/prova-gherkin-extensions@0.3.2

## 0.8.1 (24 July 2020)

-   Updating Prova Gherkin Extensions to @g4/prova-gherkin-extensions@0.3.1

## 0.8 (24 July 2020)

-   Added support for Allure and cucumber html results in terminal

## 0.7.1 (09 July 2020)

-   Added support for Allure Reporter and cucumber html reporter
-   Added support for these reports from CLI itself

## 0.7.0 (09 June 2020)

-   Added support for Multiple Cucumber Html Reporter

## 0.6.0 (27 May 2020)

-   Added support for cucumber-html-reporter

## 0.5.2 (20 May 2020)

-   Bumpled version @g4/prova-gherkin-extensions to 0.2.0

## 0.5.1 (20 May 2020)

-   Updated to use the @g4/prova-gherkin-extensions from nexus

## 0.5.0 (20 May 2020)

-   Support for prova transpile feature

## 0.4.1 (13 May 2020)

-   Build

## 0.4.0 (13 May 2020)

-   New Command: prova lint
-   Eslint Support in Test Suite template
-   Eslint Support in Test Suite template

## 0.3.0 (09 May 2020)

-   New Command: prova scenarios
-   New Command: prova tag-count
-   New Command: prova tag-summary

## 0.2.7 (07 May 2020)

-   Fixed bug in wdio.conf.js in test suite template

## 0.2.6 (07 May 2020)

-   Updated template examples

## 0.2.5 (06 May 2020)

-   Updated build templates

## 0.2.4 (06 May 2020)

-   Using @g4/prova from nexus in the test suite

## 0.2.1 (30 Apr 2020)

-   Added Troubleshooting article
-   Choice for prova-autonextgen-bindings installation is defaulted to yes
-   Improved step definition template in step-defintions/search-form.js

## 0.2.0 (30 Apr 2020)

-   Support for choosing whether to install prova-autonextgen-bindings during prova init

## 0.1.0 (29 Apr 2020)

-   Initial Release of Prova Framework
