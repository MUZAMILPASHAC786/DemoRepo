# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.14.8](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.7...v1.14.8) (2024-10-28)


### Bug Fixes

* QAA-28708 fixed issues in loyalty booking ([#5](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/issues/5)) ([975e8c7](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/975e8c716fc15d0bf49112993a424b49fe1b867e))

### [1.14.7](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.6...v1.14.7) (2024-10-18)


### Features

* QAA-28702 Fixed bundles issue ([#4](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/issues/4)) ([e004e73](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/e004e73f76067a2e099cb6e28907446bad3ba8ff))

### [1.14.6](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.5...v1.14.6) (2024-10-04)


### Features

* QAA-28610 Change departDays as input for createFlightMethod ([#1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/issues/1)) ([2afe592](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/2afe592fe36146927feee683029259f04ce77f6d))

### [1.14.5](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.4...v1.14.5) (2024-07-16)


### Features

* QAA-27964 Added Hotel payment details to trip summary ([667f4c1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/667f4c12e30bc899de2a46406192b0eebb26e00f))
* QAA-27964 Added necessary Hotel and Car details in the response ([9ad3743](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/9ad374322a11b052eadb9ee1e2a6373d65777643))


### Bug Fixes

* QAA-27971 Modified the car drop off time and date calculation ([4e0421d](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/4e0421d6ab98fb5fd9b3c3fdcb52753e2fe60832))

### [1.14.4](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.3...v1.14.4) (2024-06-26)

### [1.14.3](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.2...v1.14.3) (2024-06-03)


### Features

* QAA-27526 Add unit test and test coverage for the library ([ac2f29a](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/ac2f29a4102d7a70bb17b3b42ae48a3bca6780f9))

### [1.14.2](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.1...v1.14.2) (2024-05-23)


### Features

* QAA-27729 Modified code to fix issue in Raiders Booking ([07fb639](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/07fb6394b4e113d7549b06d180eba694209019db))

### [1.14.1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.14.0...v1.14.1) (2024-05-09)


### Features

* QAA-27703_Added Travel Insurance as new feature in payment page ([6188d48](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/6188d48faca4dbb35d4146911d1f54de0c1b4aaa))

## [1.14.0](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.6...v1.14.0) (2024-05-09)

### [1.13.6](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.5...v1.13.6) (2024-05-03)


### Features

* QAA-27697 Added encryption url for stg02.aws env ([e95613c](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/e95613ca30414c415d33cc4741325c496dde9284))

### [1.13.5](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.4...v1.13.5) (2024-04-23)


### Bug Fixes

* QAA-27606 Enabled the Create flight Feature and downgraded the ibm_db to 2.8.0 ([3d7181c](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/3d7181cc44c1e65baa596a54c1112d2f3e957cc9))

### [1.13.4](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.3...v1.13.4) (2024-04-12)


### Features

* QAA-27543 Downgraded ibm version to 2.8.2 ([4cee8db](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/4cee8dbc3dde6b10c035ca5898fa47d6edc99e1a))


### Bug Fixes

* QAA-27543 removed create flight feature to fix DB2 binding issue ([fc358bb](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/fc358bbd78148c573aa6950e9ad589d6f7116cc7))

### [1.13.3](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.2...v1.13.3) (2024-03-29)


### Bug Fixes

* QAA-27480 Wrong error handling message for failures in BAT ([01c3e43](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/01c3e435e353519036e4a018ecad62ed92d03079))
* QAA-27480 Wrong error handling message for failures in BAT ([32b4d75](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/32b4d750ad2eacb1b404e144b821ed4f30c1523a))
* QAA-27480 Wrong error handling message for failures in BAT ([9722bff](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/9722bff3838a11a63ff739db4a8c40d4735764bf))
* QAA-27504 Added login token variable in payment page ([b635cdf](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/b635cdfb7d2f5252c30cb1f055afef2a5c81cacb))

### [1.13.2](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.1...v1.13.2) (2024-03-05)


### Features

* QAA-27228 BAT Automation fix to address seat selection based on availability ([ef43638](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/ef436381859715b380af8ec5b847fb916013b560))
* QAA-27278 BAT Automation fix to address seat selection based on availability ([d1bb6e4](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/d1bb6e464b02abd20b88fde0ef9d88b3625dbf5d))

### [1.13.1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.13.0...v1.13.1) (2024-02-28)


### Features

* QAA-27185 Added integration test cases for booking with YPTA ,bundles and bags input parameter ([1c2318b](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/1c2318b2ff4bbc357e70749418d0a66e34923cca))

## [1.13.0](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.12.2...v1.13.0) (2024-02-28)


### Features

* QAA-27185-added ypta booking by passing adultsCount as "totalAdultCountIncludingYPTA|YPTA-yptaCount" ([09c9a9b](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/09c9a9b08bcbc13e2cbf85cce69e26e5775cf587))

### [1.12.2](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.12.1...v1.12.2) (2024-01-31)

### [1.12.1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.12.0...v1.12.1) (2024-01-31)

## [1.12.0](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.11.4...v1.12.0) (2024-01-31)


### Features

* QAA-27067 Added nomignore file ([b188a38](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/b188a382855f895a4eb165252230d75bc17f6c20))
* QAA-27067 updated npmignore file ([003a2e3](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/003a2e31f32f1d579d6018ea7ced703408e91bf1))
* QAA-27067_ibm_db version update ([cd8e802](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/cd8e802fdc2262314a96329c3e006ae3e28cad6c))
* QAA-27186-Added Allegiant World Master Card,Allegiant World Visa Card,Master Debit Card,Visa Debit Card and Discover Debit Card and CCV Details ([ffb5db7](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/ffb5db74224e8a06923f23f2abe1695ca41708de))
* QAA-27186-removed hardcoded cardnum and ccv. Added cardType in the format other|creditCardNum|creditCardCVV ([a1efae6](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/a1efae6d4e10ec52f2fdcc8b43b71f891c37ead6))

### [1.11.4](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.11.3...v1.11.4) (2023-12-21)


### Features

* QAA-26999 Added encryption url for prd01 env ([fa4ed31](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/fa4ed311f52a888b337e32a4728c6429f8231806))


### Bug Fixes

* QAA-26999 Made total bundles mandatory for raiders booking ([5f134dd](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/5f134dd531e2b638150c56b9f62dc74e021e686c))
* QAA-26999 Made total bundles mandatory for raiders booking ([6280040](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/6280040adec8bb4a84ef31c2c4366ad721b72c7d))

### [1.11.3](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.11.2...v1.11.3) (2023-12-14)


### Features

* QAA-27006_Added Master-CC card number and CVV details ([86fb071](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/86fb0719bda5e4e8afe8a68d670894c3de215b39))
* Updated README.md file ([a9286e8](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/a9286e8a0e610c9bedac933d56c64916b7b51ae3))

### [1.11.2](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.11.1...v1.11.2) (2023-12-05)


### Features

* QAA-26982 Added encryption URL for stg01.aws environment ([33d3e53](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/33d3e534916083ab75db037c396e836e32ea571a))

### [1.11.1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.11.0...v1.11.1) (2023-12-04)


### Features

* Environment change in integration cases and lint issues fixed ([28526ba](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/28526ba5af940dbcd3a1d919db8c7aafffdae26a))
* QAA-26974 Fixed car , hotel selection issue and game date selection in raiders. ([f130a76](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/f130a76fd859edf194eae671736baa55038e4685))
* QAA-26974 fixed issue faced in stg for raiders booking ([c32373f](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/c32373f8b0f265654c702fc6c00810f1966f7caf))
* QAA-26974 Fixed Lint issues in raiders booking ([c8177d4](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/c8177d4a0c7c76dc337e35199a2f7b28d67371a6))
* QAA-26974 regression test cases date update ([a062d58](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/a062d583037a592fb69abb5bc406de8d02f4509d))
* raiders changes ([9eda5c9](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/9eda5c9b09e08a318d1450079a461553ee6c4b95))
* removed CommonMethods.isAlive() mentod ([c7636db](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/c7636db3c75031559dc0171a3a416bfbeae429e2))

## [1.11.0](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.10.1...v1.11.0) (2023-10-25)


### Features

* QAA-26857 modified GqlBookingWithEnvAlone method ([0698dee](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/0698deeca00ab01abe77479359270328baed3589))

### [1.10.1](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.10.0...v1.10.1) (2023-10-10)


### Features

* QAA-26828 modified modifyBags file ([5651cd9](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/5651cd998659cf308207d6d623b4507f6b157d58))

## [1.10.0](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/compare/v1.9.1...v1.10.0) (2023-10-10)


### Features

* added basic bundle condition ([43ed833](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/43ed8339d6cb8aefa3b671a49474cada2acd493a))
* Added method for flight creation ([86cac17](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/86cac17eabd7e60d829a9d132f66ed1164e0bb95))
* Fixed Lint issues ([2e17388](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/2e173882aef42730430434a0a7cf2170e258ce4d))
* Fixed seat issue in flight creation ([a2c0170](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/a2c01703b7ca3de0ebcee9b1fe298b3a0042159f))
* modified createFlight file ([ba51702](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/ba5170299f3304a99950f356730355f182191787))
* Modified test-booking file ([e2eb5a5](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/e2eb5a541331827ada4f6c1ed72f828dab8b4b39))
* QAA-25660 modified bundle selection module ([df7d437](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/df7d4374f49f1d5ecb01ab82069cf3e9d8ed0cd0))
* QAA-25660 updated the gql-booking file ([d6332b8](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/d6332b8798e34171c76dc8b9cc38c3977bf44172))
* QAA-26588 modified test-booking ([6948b62](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/6948b62ba0a545b35839be7733ca82bf96640fb6))
* QAA-26761 added raiders booking ([bd443ad](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/bd443ad40bb2d155099943f4b9e604dec3dbc04a))
* QAA-26828 Added bag modification and cancel Trip ([60b082e](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/60b082e60c7dd506376712c3a22e260913f52ac8))
* QAA-26828 fixed issue in OW modification ([140c3cc](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/140c3ccdfde117e6c8fabad23204dd023c5fbc67))
* QAA-26828 Modified Cancel Booking method ([fd9429e](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/fd9429e39d565ddf86fce4bdd9a92335616a6e00))
* QAA-26828 Modified gql-booking file ([529aa42](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/529aa42099316967e2663bd3b892940bdbdd7005))
* QAA-26828 modified payment page ([f6bbacd](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/f6bbacd25b9c4609c0f1fc5e5c809976f7e4cdaa))

### 1.9.1 (2023-07-12)


### Features

* added standard version in jsgqlbooking ([47ce8fa](https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/commit/47ce8fa2f708a614c1639c641e9fdc833af560d2))

## [Unreleased]
- QAA-26539 added new date selection logic

## [1.9.0] - 2023-06-17
- QAA-26504 added new loyalty points functionality
            updated login functionality with emailId/Password as inputs

## [1.8.0] - 2023-06-06
- QAA-26467 added new valid KTN functionality

## [1.7.2] - 2023-05-23 
-QAA-26435 Modified flights page variables

## [1.7.1] - 2023-04-25 
-QAA-26354 Fixed issues in flights page 

## [1.7.0] - 2023-04-03
- QAA-25994-Fixed traveler type issue when only child added.
           -Fixed Error messages
           -Added new field for error explicitly
- QAA-26062-Add payment using promotion code feature
           -Added legroom + and economy+ seat types selection
- QAA-25979-Converted Integration tests from jest to Mocha due to certificate error
- QAA-25995-Fixed Nationality issue in international booking
- QAA-25853-Fixed lap infant details issue in international booking
- QAA-26063-Added Trip Summary details
- QAA-26100-modified integration testcases inorder to reduce the execution time and rerun the failed scenarios alone
- QAA-26122-Generating the dynamic credit-card details instead of hardcoded card details for booking
- QAA-26097-Added method that does booking by taking env alone
- QAA-26164-Modified error handling and added more negative-integration-test-cases

## [1.6.1] - 2023-02-13
- QAA-25962-modified seat selection page coding for International Booking

## [1.6.0] - 2023-02-02 
- QAA-25904-added SSR options along with adult count
           -added infant details to travelers-SSR for domestic booking
           -added seat-type for seat-selection Ex:economy
           -added nationality options for International booking
           
## [1.5.1] - 2023-01-20
- QAA-25907-modified the card-details and traveler's firstname

## [1.5.0] - 2023-01-12 
- QAA-25824-added feature to get quantity of bags-page-items from user
- QAA-25825-added voucher payment

## [1.4.0] - 2023-01-03
- QAA-25678-added testlayer to the library in this version
- QAA-25677-added proper Error handling Message
- QAA-25763-added Integration testcases to test whole gql and also added negative cases.

## [1.3.0] - 2022-12-14
- QAA-25675 - Added code to book flight by passing depart and return date and also by passing Flight numbers of both depart and return.
- QAA-25645 - Added passport and Emergency Details as part of International Booking

## [1.2.0] - 2022-12-06
- QAA-25651 Fixed issues with the DOB for child travller
- Fixed bundles issue with International booking
- QAA-25593 - Added child-adult seat selection in Seats page
- QAA-25648 - returning multiple values to be consumed by the user

## [1.1.0] - 2022-11-22 
- Added login,Known Traveler,Redress features
- Added International booking in this version

## [1.0.1] - 2022-10-17
- Corrected the environment handling part and removed comments

## [1.0.0] - 2022-10-13
- Added flexibility to the library to be used by Persistent Teams which supports almost all the modules for Booking

## [0.1.0] - 2022-08-04
- Created seperate modules rather than one gql bookings file

## [0.0.2] - 2022-07-08
- This version contains the basic things that are needed to perform a booking

## [0.0.1] - 2022-07-05
- This version contains the basic things that are needed to perform a booking
