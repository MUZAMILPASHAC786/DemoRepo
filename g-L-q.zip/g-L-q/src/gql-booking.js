const GqlCall = require('./helpers/gql-helper/graph-ql-call');
const CommonMethods = require('./helpers/common-helpers/common');
const Flights = require('./booking-calls/flights');
const Bundles = require('./booking-calls/bundles');
const Travellers = require('./booking-calls/travellers');
const Seats = require('./booking-calls/seats');
const Bags = require('./booking-calls/bags');
const Hotels = require('./booking-calls/hotels');
const Cars = require('./booking-calls/cars');
const Payment = require('./booking-calls/payment');
const Login = require('./booking-calls/login');
const TripSummary = require('./booking-calls/tripSummary');
// const NewFlight = require('./booking-calls/createFlight');
const Raiders = require('./booking-calls/raiders')
const ModifyBags = require('./modify-calls/modifyBags')
const CancelITN = require('./cancel-calls/cancelBooking')
const TripSummaryModifyDetails = require('./modify-calls/tripSummary')
let GqlBooking = async function GqlBooking(environment, origin, destination, tripType, adultsCounts, childrenCount, lapInfantCount, departDays,
    returnDays, bundleType, seatspage, petInCabin, hotelspage, carspage, paymentType, cardType, isInternational, login, ktn, redress, departFlightNum, returnFlightNum, _bagsPage, raidersBooking, travelInsurance) {
    var returnAllGqlOutputs = {}
    var tripSummaryDetails = {}
    let flagForRaidersBooking = 0;
    let gameDateSelected;
    let inputArray = [];
    inputArray = arguments
    let argumentNameArray = ["environment", "origin", "destination", "tripType", "adultsCounts", "childrenCount", "lapInfantCount", "departDays",
        "returnDays", "bundleType", "seatspage", "petInCabin", "hotelspage", "carspage", "paymentType", "cardType", "isInternational", "login", "ktn", "redress", "departFlightNum", "returnFlightNum", "_bagsPage", "raidersBooking", "travelInsurance"]
    try {
        /**
* This method takes input given by user and validates it
* @param {*} input1 Ex : ".stg01.aws"
* @param {*} argumentName Ex : "environment"
*/
        async function checkInput(input1, argumentName) {
            if (input1 === undefined || input1 === "") {
                if (argumentName === "environment" || argumentName === "origin" || argumentName === "destination" || argumentName === "tripType" || 
                    argumentName === "adultsCounts" || argumentName === "paymentType" | argumentName === "isInternational") {
                    console.error(`Input for ${argumentName} entered by user is invalid`)
                    throw Error(`Input for ${argumentName} entered by user is invalid`)
                }
            }
        }
        for (let a = 0; a < inputArray.length; a++) {
            await checkInput(inputArray[a], argumentNameArray[a])
        }
        let adultWithSSR, adultsCount, yptaCount, RaidersIndex;
        if (typeof adultsCounts === typeof String()) {
            if (adultsCounts.includes(':')) {
                adultWithSSR = adultsCounts.split(':');
                adultsCount = parseInt(adultWithSSR[0]);
            } else if (adultsCounts.includes('YPTA')) {
                adultsCount = parseInt(adultsCounts.split('|')[0]);
                yptaCount = parseInt(adultsCounts.split('-')[1]);
            }
        } else {
            adultsCount = adultsCounts;
        }
        let startTime, endTime;
        startTime = new Date();
        let env = environment;
        // let url = "www{env}.allegiantair.com".replace("{env}", env)
        // let checkRequestUri
        // checkRequestUri = await CommonMethods.isAlive(url)
        // if (checkRequestUri === false) {
        //     throw new Error("data passed to env is wrong")
        // }
        if (adultsCount === 0) {
            // eslint-disable-next-line no-param-reassign
            adultsCount = 1;
            console.log("Adult count can't be 0, Hence adultsCount=", adultsCount);
        }

        // if (checkRequestUri === true) {
        let gqlCall = new GqlCall(env);
        let flights = new Flights(gqlCall);
        let raiders = new Raiders(gqlCall);

        let travelersCountForRaidersBooking = adultsCount + childrenCount;
        if (raidersBooking === 'yes') {
            if (hotelspage === 'no') {
                // eslint-disable-next-line no-param-reassign
                hotelspage = 'yes';
            }
            if (bundleType === '' || bundleType === 'bonus' || bundleType === 'basic') {
                // eslint-disable-next-line no-param-reassign
                bundleType = 'total';
            }
            let productID = await raiders.stadiumConfig();
            var { gameAvailableDate, transactionid } = await raiders.showsAvailability(productID);
            while (flagForRaidersBooking !== -1) {
                var seatarr = await raiders.raidersBooking(
                    gameAvailableDate,
                    productID,
                    destination,
                    travelersCountForRaidersBooking,
                    flagForRaidersBooking,
                );
                if (seatarr.length === 0) {
                    flagForRaidersBooking++;
                } else {
                    RaidersIndex = flagForRaidersBooking;
                    flagForRaidersBooking = -1;
                }
            }
            if (flagForRaidersBooking === -1) {
                gameDateSelected = gameAvailableDate[RaidersIndex];
            } else {
                throw new Error('Failed to Select seat in the stadium');
            }
        }
        //Get a list of depart and return dates from the query
        var { availableDepartDates, availableReturnDates } = await flights.dateSelection(
            origin,
            destination,
            departDays,
            returnDays,
            tripType,
            transactionid,
            gameDateSelected,
        );

        console.log('departDate - ', availableDepartDates);
        console.log('returnDate - ', availableReturnDates);

        let plusorMinusDays = 0;
        // if (isInternational.includes("no")) {
        //     plusorMinusDays = 14;
        // }
        if (availableDepartDates) {
            //Pass list of dates and Get the flight details of possible date from the query
            var subTripType = (departDays !== undefined && departDays === 0) ? "CHECKIN" : tripType;
            var {
                departDate,
                returnDate,
                departureFlightId,
                returningFlightId,
                arrivalTime,
                departingTime,
                retArrivalTime,
                retDepartingTime,
            } = await flights.flightBooking(subTripType, origin, destination, availableDepartDates,
                availableReturnDates, plusorMinusDays, adultsCount, childrenCount, lapInfantCount, departFlightNum, returnFlightNum, transactionid)

            if (departureFlightId) {
                console.log('departDate is->', departDate);
                console.log('departureFlightId is- >', departureFlightId);
                console.log('Depart Trip departingTime is ->', departingTime);
                console.log('Depart Trip arrivalTime is ->', arrivalTime);
                if (tripType === 'ROUNDTRIP') {
                    console.log('returnDate is->', returnDate);
                    console.log('returningFlightId is ->', returningFlightId);
                    console.log('Return Trip departingTime is ->', retDepartingTime);
                    console.log('Return Trip arrivalTime is ->', retArrivalTime);
                }
                if (raidersBooking === 'yes') {
                    var transactionId = transactionid;
                } else {
                    var transactionId = await flights.getTransactionId();
                }

                let bundles = new Bundles(gqlCall, transactionId);
                let travellers = new Travellers(gqlCall, transactionId);
                let seats = new Seats(gqlCall, transactionId);
                let bags = new Bags(gqlCall, transactionId);
                let hotels = new Hotels(gqlCall, transactionId);
                let cars = new Cars(gqlCall, transactionId);
                let loginAccount = new Login(gqlCall, transactionId);
                let payment = new Payment(gqlCall, transactionId);
                let tripDetails = new TripSummary(gqlCall, transactionId);
                let travelerid = await flights.orderCreation(
                    tripType,
                    departureFlightId,
                    returningFlightId,
                );
                if (raidersBooking === 'yes') {
                    //     if (travelerid.length <= seatarr.length) {
                    //         for (let t = 0; t < travelerid.length; t++) {
                    await raiders.selectShowAfterFlight(seatarr, gameDateSelected, travelerid);
                    //     }
                    // }
                    // else {
                    //     throw new Error("Seats unavailable in stadium!")
                    // }
                }
                if (bundleType) {
                    await bundles.bundleSelection(
                        tripType,
                        origin,
                        destination,
                        departDate,
                        returnDate,
                    );
                    await bundles.bundlemutation(bundleType);
                    console.log('bundleType is ->', bundleType);
                }
                if (travelerid) {
                    var {
                        travellerDetails,
                        firstName,
                        lastName,
                        petInCabinSSR,
                    } = await travellers.travellerDetails(adultsCount, travelerid, ktn, redress, isInternational, lapInfantCount, departureFlightId, returningFlightId, tripType, adultWithSSR, childrenCount, yptaCount)
                    let bagsPage
                    if (bundleType === "total" || bundleType === "bonus" || bundleType === "basic") {

                        if (seatspage === "no") {
                            // eslint-disable-next-line no-param-reassign
                            seatspage = 'yes';
                        }
                    }
                    if (seatspage.includes("yes")) {
                        let {
                            departFlightArray,
                            returnFlightArray,
                            departSeatRow,
                            returnSeatRow,
                        } = await seats.seatMap(origin, destination, departDate, returnDate, tripType);

                        let returnSeatSelects
                            = await seats.seatSelection(tripType, travelerid, departFlightArray, departureFlightId, returnFlightArray, returningFlightId, bundleType, adultsCount, childrenCount, seatspage, isInternational,
                                departSeatRow, returnSeatRow)
                        if (isInternational.includes("yes")) {
                            if (tripType === "ROUNDTRIP") {
                                await seats.seatSelectionInternational(returnSeatSelects)

                            }
                        }
                    }
                    if (_bagsPage) {
                        bagsPage = _bagsPage
                        let bagsPageQty = bagsPage.split(":");
                        // console.log("bagspagqty",bagsPageQty)
                        await bags.bagSelection(travelerid, departureFlightId, returningFlightId, bagsPageQty, bundleType);

                        await bags.priorityAccessSelection(travelerid, departureFlightId, returningFlightId, bagsPageQty, bundleType);

                        await bags.tripFlexSelection(bagsPageQty);


                    }
                    else {
                        if (bundleType === "total") {
                            // if (_bagsPage === undefined) {
                            bagsPage = "1Both:1Both:1Both:0"
                            // }

                        }
                        else if (bundleType === "bonus") {
                            // if (_bagsPage === undefined) {
                            bagsPage = "1Both:0Both:1Both:0"
                            // }

                        }
                        else if (bundleType === "basic") {
                            bagsPage = "0Both:1Both:0Both:0"
                        }
                        else {
                            bagsPage = "1Both:1Both:0Both:0"
                        }

                        let bagsPageQty = bagsPage.split(":");
                        // console.log("bagspagqty",bagsPageQty)
                        await bags.bagSelection(travelerid, departureFlightId, returningFlightId, bagsPageQty, bundleType);

                        await bags.priorityAccessSelection(travelerid, departureFlightId, returningFlightId, bagsPageQty, bundleType);

                        await bags.tripFlexSelection(bagsPageQty);

                    }

                    if (petInCabin === "yes") {
                        await bags.petInCabinSelection(travelerid, departureFlightId, returningFlightId, petInCabinSSR);
                    }

                    if (hotelspage === "yes") {
                        let roomTypeSelected
                        let roomsSelected
                        var {
                            hotelId,
                            roomsCount,
                            checkOutDate,
                        } = await hotels.hotelList(origin, destination, departDate, returnDate, roomTypeSelected, roomsSelected, adultsCount, tripType);
                        if (hotelId !== undefined) {
                            console.log("hotel id ->", hotelId)
                            let roomId = await hotels.hotelBooking(hotelId, destination, departDate, roomsCount, checkOutDate);
                            console.log("room id ->", roomId)
                            await hotels.roomSelection(roomId);
                        }
                    }
                    // let carType
                    if (carspage === "yes") {
                        let toTimeForVehicleSearch;
                        let fromTimeForVehicleSearch = CommonMethods.getTimeBasedOnArrivalTime(arrivalTime)
                        if (tripType === "ONEWAY") {
                            toTimeForVehicleSearch = CommonMethods.addDays(fromTimeForVehicleSearch, 3);
                        } else {
                            toTimeForVehicleSearch = CommonMethods.getTimeBasedOnReturnDepartTime(retDepartingTime);
                        }
                        var vendorId = await cars.vehicleList(origin, destination, departDate, returnDate, fromTimeForVehicleSearch, toTimeForVehicleSearch);
                        if (vendorId !== "") {
                            if (vendorId !== undefined) {
                                console.log("Vehicles available -> vendorId is ->", vendorId)
                                await cars.vehicleSelection(vendorId);
                            }
                        }
                    }
                    if (firstName) {
                        if (login === "yes") {
                            var {
                                loginEmail,
                                loginPassword,
                            } = await loginAccount.accountCreation(firstName, lastName)

                            if (loginEmail) {
                                var loginToken = await loginAccount.login(loginEmail, loginPassword)
                            } //end of loginEmail if loop
                        }
                        else if (login !== undefined) {
                            if (login.includes(":")) {
                                var loginEmail = login.split(":")[1]
                                var loginPassword = login.split(":")[2]
                                var loginToken = await loginAccount.login(loginEmail, loginPassword)
                                var { loyaltyPointDetails,
                                    firstNameLoyaltyAccount,
                                    lastNameLoyaltyAccount } = await loginAccount.getloyaltyTravelerDetails(loginToken)
                                console.log("The loyaltyPoints available:", loyaltyPointDetails)
                            }
                        }
                    } //end of firstName if loop
                } //end of travelerid if loop
                tripSummaryDetails = await tripDetails.tripSummary(tripSummaryDetails, departureFlightId, returningFlightId, tripType, bundleType);
                let balancePayment = ''
                let card, voucherCR, voucherDO;
                if (paymentType === "voucher+card") {
                    let voucherCard = cardType.split("+")

                    if (voucherCard.length <= 3) {

                        for (let i = 0; i < voucherCard.length; i++) {
                            if (voucherCard[i].includes("CR")) {
                                voucherCR = voucherCard[i];
                                await payment.voucherPayment(env, voucherCR);
                            } else if (voucherCard[i].includes("DO")) {
                                voucherDO = voucherCard[i];
                                await payment.voucherPayment(env, voucherDO);
                            } else {
                                card = voucherCard[i];
                            }
                        }
                    }
                    var { confNumber, encryptCC, encryptCvv } = await payment.paymentPage(env, card, balancePayment, loginToken, travelInsurance);
                } else if (paymentType === "voucher+card+promocode") {

                    let voucherCard = cardType.split("+")

                    if (voucherCard.length <= 4) {

                        for (let i = 0; i < voucherCard.length; i++) {
                            if (voucherCard[i].includes("CR")) {
                                voucherCR = voucherCard[i];
                                await payment.voucherPayment(env, voucherCR);
                            } else if (voucherCard[i].includes("DO")) {
                                voucherDO = voucherCard[i];
                                await payment.voucherPayment(env, voucherDO);
                            } else if (voucherCard[i].includes("PROMO")) {
                                promo = voucherCard[i];
                                await payment.promoPayment(promo);
                            } else {
                                card = voucherCard[i];
                            }
                        }
                    }
                    var { confNumber, encryptCC, encryptCvv } = await payment.paymentPage(
                        env,
                        card,
                        balancePayment,
                        loginToken,
                        travelInsurance,
                    );
                } else if (paymentType.includes('loyalty')) {
                    //to get the total loyalty points of user
                    let getPoints = await payment.getPoints(loginToken);
                    console.log('total loyalty points: ', getPoints);
                    let totalLoyaltypoints = getPoints * 100;
                    //to get balanced amount to be paid
                    let getPrice = await payment.getBalancedDue(loginToken);
                    console.log('balanced amount to be paid ', getPrice);
                    let loyaltypoints = getPrice * 100;
                    if (totalLoyaltypoints >= loyaltypoints) {
                        console.log('perform complete from loyaltyPayment: ');
                        balancePayment = await payment.loyaltyPayment(loyaltypoints, loginToken);
                        console.log('balance after loyaltyPayment: ', balancePayment);
                        var { confNumber, encryptCC, encryptCvv } = await payment.paymentPage(
                            env,
                            cardType,
                            balancePayment,
                            loginToken,
                            travelInsurance, loginEmail, firstNameLoyaltyAccount, lastNameLoyaltyAccount
                        );
                    } else if (totalLoyaltypoints < loyaltypoints) {
                        console.log('perform partial payment from loyaltyPayment: ');
                        balancePayment = await payment.loyaltyPayment(loyaltypoints, loginToken);
                        console.log('balance after loyaltyPayment: ', balancePayment);
                        var { confNumber, encryptCC, encryptCvv } = await payment.paymentPage(
                            env,
                            cardType,
                            balancePayment,
                            loginToken,
                            travelInsurance, loginEmail, firstNameLoyaltyAccount, lastNameLoyaltyAccount
                        );
                    } else {
                        throw new Error('Loyalty points are 0, Hence Booking was unsuccessful');
                    }
                } else if (paymentType === 'card') {
                    var { confNumber, encryptCC, encryptCvv } = await payment.paymentPage(
                        env,
                        cardType,
                        balancePayment,
                        loginToken,
                        travelInsurance,
                    );
                } else {
                    throw new Error(
                        'paymentType is empty or wrong, Hence Booking was unsuccessful',
                    );
                }
                endTime = new Date();
                console.log(
                    `Total Booking took ${Math.floor((endTime - startTime) / 1000)} seconds`,
                );
            } // end of departureFlightId if loop
        } // end of departDate if loop
        // } //end of checkRequesturi if loop
    } catch (err) {
        returnAllGqlOutputs.error = err.message + ' ,Hence Booking was unsuccessful';
    }
    if (returnAllGqlOutputs.error === undefined) {
        returnAllGqlOutputs.departDate = departDate;
        returnAllGqlOutputs.departureFlightId = departureFlightId;
        if (returnDate !== undefined) {
            returnAllGqlOutputs.returnDate = returnDate;
            if (returningFlightId !== undefined) {
                returnAllGqlOutputs.returningFlightId = returningFlightId;
                returnAllGqlOutputs.retArrivalTime = retArrivalTime;
                returnAllGqlOutputs.retDepartingTime = retDepartingTime;
            }
        }

        returnAllGqlOutputs.arrivalTime = arrivalTime;
        returnAllGqlOutputs.departingTime = departingTime;
        returnAllGqlOutputs.TransactionID = transactionId;
        returnAllGqlOutputs.travellerDetails = travellerDetails;
        if (hotelId !== undefined) {
            returnAllGqlOutputs.hotelId = hotelId;
        }
        if (vendorId !== undefined) {
            returnAllGqlOutputs.vendorId = vendorId;
        }
        if (tripSummaryDetails !== undefined) {
            returnAllGqlOutputs.TripSummaryDetails = tripSummaryDetails;
        }
        returnAllGqlOutputs.encryptCC = encryptCC;
        returnAllGqlOutputs.encryptCvv = encryptCvv;
        returnAllGqlOutputs.firstName = firstName;
        returnAllGqlOutputs.lastName = lastName;
        if (loginEmail !== undefined) {
            returnAllGqlOutputs.loginEmail = loginEmail;
        }
        if (loginPassword !== undefined) {
            returnAllGqlOutputs.loginPassword = loginPassword;
        }
        if (confNumber !== undefined) {
            returnAllGqlOutputs.confNumber = confNumber;
        } else {
            returnAllGqlOutputs.confNumber = '';
        }
    }
    return returnAllGqlOutputs
}
module.exports.GqlBooking = GqlBooking
module.exports.ModifyBooking = async function ModifyBooking(env, firstName, lastName, confNumber, bagsPage, card) {
    var returnAllGqlOutputs = {}
    // let checkRequestUri
    // let url = "www{env}.allegiantair.com".replace("{env}", env)
    try {
        // checkRequestUri = await CommonMethods.isAlive(url)
        // if (checkRequestUri === false) {
        //     throw new Error("data passed to env is wrong")
        // }
        try {
            let gqlCall = new GqlCall(env)
            let modifyBags = new ModifyBags(gqlCall)
            var { transactionModificationId, travelerid, departFlightId, returnFlightId, paymentFirstName, paymentLastName } = await modifyBags.getItineraryDetails(firstName, lastName, confNumber)
            await modifyBags.modifyOrder(confNumber, paymentFirstName, paymentLastName, transactionModificationId)
            if (bagsPage) {
                let bagsPageQty = bagsPage.split(":");
                // console.log("bagspagqty",bagsPageQty)
                await modifyBags.addOrChangeBags(bagsPageQty, travelerid, departFlightId, returnFlightId)
            }
            let tripSummaryModifyDetails = new TripSummaryModifyDetails(gqlCall, transactionModificationId)
            let { balanceDueAmount } = await tripSummaryModifyDetails.tripSummary()
            let { ITN, encryptCC, encryptCvv } = await modifyBags.paymentForModification(env, firstName, lastName, card)
            if (returnAllGqlOutputs.error === undefined) {
                returnAllGqlOutputs.confNumber = ITN
                returnAllGqlOutputs.encryptCC = encryptCC
                returnAllGqlOutputs.encryptCvv = encryptCvv
                returnAllGqlOutputs.balanceDueAmount = balanceDueAmount
            }
            console.log("Modification Completed")
            return returnAllGqlOutputs
        }
        catch (err) {
            throw new Error("Modification of ITN failed due to invalid input")
        }
        // eslint-disable-next-line new-cap
    }
    catch (err) {
        returnAllGqlOutputs.error = err.message + " ,Hence Modification was unsuccessful"
    }
    return returnAllGqlOutputs
}
module.exports.CancelBooking = async function CancelBooking(env, firstName, lastName, confNumber) {
    var returnAllGqlOutputs = {};
    // let checkRequestUri
    // let url = "www{env}.allegiantair.com".replace("{env}", env)

    try {
        // checkRequestUri = await CommonMethods.isAlive(url)

        // if (checkRequestUri === false) {
        //     throw new Error("data passed to env is wrong")
        // }
        try {
            let gqlCall = new GqlCall(env)
            let cancelITN = new CancelITN(gqlCall)
            var { transactionModificationId, paymentFirstName, paymentLastName } = await cancelITN.getItineraryDetails(firstName, lastName, confNumber)
            let { refundAmount, penaltyAmount } = await cancelITN.cancelItinerary(paymentFirstName, paymentLastName, confNumber, transactionModificationId);
            if (returnAllGqlOutputs.error === undefined) {
                returnAllGqlOutputs.refundAmount = refundAmount
                returnAllGqlOutputs.penaltyAmount = penaltyAmount
            }
            console.log("Cancellation completed")
            return returnAllGqlOutputs
        }
        catch (err) {
            throw new Error("Cancellation of ITN failed due to invalid input")
        }
        // eslint-disable-next-line new-cap
    } catch (err) {
        returnAllGqlOutputs.error = err.message + ' ,Hence Cancellation was unsuccessful';
    }
    return returnAllGqlOutputs;
};
module.exports.GqlBookingWithEnvAlone = async function GqlBookingWithEnvAlone(env) {
    var returnAllGqlOutputs = {};
    // let checkRequestUri
    // let url = "www{env}.allegiantair.com".replace("{env}", env)

    try {
        // checkRequestUri = await CommonMethods.isAlive(url)

        // if (checkRequestUri === false) {
        //     throw new Error("data passed to env is wrong")
        // }
        let isInternationalDefault;
        let origin = 'BLI';
        let destination = 'LAS';
        if (env === '-intnexusg4.okd' || env === '-qatnexusg4.okd' || env === '.stg') {
            isInternationalDefault = 'yes';
        } else {
            isInternationalDefault = 'no';
        }
        let gqlCall = new GqlCall(env)
        let flights = new Flights(gqlCall)
        let {
            departDate,
            returnDate,
        } = await flights.dateSelection(origin, destination, "4", "5", "ONEWAY");
        // eslint-disable-next-line new-cap
        returnAllGqlOutputs = await GqlBooking(env, origin, destination, "ONEWAY", 1, 0, 0, departDate, returnDate, "", "no", "no", "no", "no", "card", "Master", isInternationalDefault, "no", "no", "no", "", "")
    }
    catch (err) {
        returnAllGqlOutputs.error = err.message + " ,Hence Booking was unsuccessful"
    }
    return returnAllGqlOutputs;
};
// /**
//  * This method performs GQL call for date selection
//  * @param {string} env Ex : ".qa1"
//  * @param {string} origin Ex: "LAS"
//  * @param {string} destination Ex : "MEX"
//  * @param {string} tailNumber Ex : "215NV"
//  * @param {string} aircraftType Ex : "32A"
//  * @param {string} seatSize Ex : "177"
//  * @param {string} departDays Ex : "2023-08-02"
//  * @param {string} hours Ex : "5"
//  * @returns {json} flight Number
//  */
// module.exports.createFlight = async function createFlight(env,origin,destination,tailNumber,aircraftType,seatSize,departDays,hours) {
//     const regex = /^\d{4}-\d{2}-\d{2}$/;
//     let newflights = new NewFlight();
//     var flightDetails = {};
//     let flightNumber;
//     let startTime, endTime;
//     /**
//  * This method calculates date
//  * */
//     async function date() {
//         var todaysDate = new Date();
//         if (departDays.match(regex) === null) {
//             let selectableDepDate = new Date(
//                 todaysDate.setDate(todaysDate.getDate() + Number(departDays)),
//             );
//             departDate = selectableDepDate.toISOString().split('T')[0];
//         } else {
//             departDate = departDays;
//         }
//         return departDate;
//     }
//     try {
//         if (!departDays.match(regex) === true && departDays.length >= 9) {
//             throw new Error('departDate format passed is not correct');
//         }
//         var departDate = await date();
//         console.log('Started Flight Creation!!!!');
//         startTime = new Date();
//         flightNumber = await newflights.createFlightRecord(env,origin,destination,tailNumber,aircraftType,seatSize,departDate,hours);
//         await newflights.createFareClass(env, flightNumber, aircraftType, seatSize, departDate);
//         flightDetails.env = env;
//         flightDetails.departDate = departDate;
//         flightDetails.origin = origin;
//         flightDetails.destination = destination;
//         flightDetails.flightNumber = flightNumber;
//         endTime = new Date();
//         console.log(`Total Booking took ${Math.floor((endTime - startTime) / 1000)} seconds`);
//     } catch (err) {
//         flightDetails.error = err.message;
//         return flightDetails;
//     }
//     return { flightDetails, flightNumber };
// };
