const CardDetails = require('../helpers/card-helpers/cardDetails');
const CardNumbers = require('../helpers/card-helpers/cardNumbers');
module.exports = class ModifyBags {
    /**
* This is constructer for Modify Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall) {
        this.GqlCall = GqlCall;
        this._transactionId = '';
    }

    /**
* This method performs GQL call to get ITN details
* @param {*} firstName Ex:Marianne
* @param {*} lastName Ex:"Hill"
* @param {*} confNumber Ex:"G5JRHM"
*/
    async getItineraryDetails(firstName, lastName, confNumber) {
        let query = `query FindFlightOrder($orderSearchCriteria: OrderSearchCriteria!) {
            transactionId
            findOrder(orderSearchCriteria: $orderSearchCriteria) {
              ...OrderFragment
              errors
              failures {
                title
                message
                __typename
              }
              __typename
            }
            allegiantApplication(name: DESKTOPMANAGETRAVEL) {
              ... on DesktopManageTravel {
                configurations {
                  googleMapsApiKey
                  disableInternationalModify
                  customerServiceContactNumber
                  __typename
                }
                bagFeesDates {
                  travelDate
                  __typename
                }
                __typename
              }
              __typename
            }
          }
          
          fragment OrderFragment on FindOrderResponse {
            __typename
            order {
              orderNumber
              bookingChannel
              created
              createdBy
              createdByName
              orderType
              orderPolicy {
                canBeCanceled
                canBeModified
                flightDisposition {
                  type
                  __typename
                }
                __typename
              }
              __typename
              status
              customer {
                __typename
                firstName
                lastName
                email
                alternateEmail
                billingAddress {
                  __typename
                  ...AddressFragment
                }
                phone {
                  countryPrefix
                  number
                  type
                  __typename
                }
              }
              loyaltyCustomer {
                firstName
                lastName
                email
                phone {
                  countryPrefix
                  number
                  __typename
                }
                __typename
              }
              travelers {
                __typename
                ...TravelerFragment
              }
              bookingDate
              confirmationNumber
              vendorConfirmationNumber
              isInternational
              payments {
                __typename
                ...OrderPaymentFragment
                ... on CreditCardPayment {
                  accertifyStatus
                  code
                  cardName: name
                  holderName
                  cardNumber: number
                  cardDescription: description
                  __typename
                }
                ... on LoyaltyPayment {
                  id
                  points
                  __typename
                }
                ... on PromoPayment {
                  id
                  description
                  __typename
                }
                ... on VoucherPayment {
                  id
                  type
                  __typename
                }
              }
              items {
                __typename
                ...HotelOrderItemFragment
                ...ShowOrderItemFragment
                ... on BundleOrderItem {
                  id
                  type
                  bundle {
                    __typename
                    ...FlightBundleFragment
                  }
                  price {
                    __typename
                    ...MoneyFragment
                  }
                  __typename
                }
                ... on FlightOrderItem {
                  orderItemStatus
                  canBeCanceled
                  changeFee {
                    name
                    code
                    value {
                      amount
                      currency
                      __typename
                    }
                    __typename
                  }
                  id
                  journeyId
                  journeyTravelerIds
                  flight {
                    __typename
                    ...FlightFragment
                  }
                  type
                  price {
                    __typename
                    ...FlightOrderItemPriceFragment
                  }
                  ancillariesShop {
                    __typename
                    ...AncillaryShopItemFragment
                  }
                  __typename
                }
                ... on SeatOrderItem {
                  id
                  type
                  flightId
                  column
                  row
                  travelerId
                  price {
                    __typename
                    ...MoneyFragment
                  }
                  isBundledAncillaryIncluded
                  status
                  __typename
                }
                ... on TravelerAncillaryOrderItem {
                  id
                  flightId
                  travelerId
                  ancillaryType
                  quantity
                  price {
                    __typename
                    ...MoneyFragment
                  }
                  isBundledAncillaryIncluded
                  __typename
                }
                ... on ItineraryAncillaryOrderItem {
                  id
                  ancillaryType
                  quantity
                  orderItemStatus
                  price {
                    __typename
                    ...MoneyFragment
                  }
                  isBundledAncillaryIncluded
                  __typename
                }
                ... on VehicleOrderItem {
                  id
                  vehicle {
                    __typename
                    ...VehicleFragment
                  }
                  vendor {
                    __typename
                    ...VehicleVendorFragment
                  }
                  confirmationNumber
                  pickUpDate
                  dropOffDate
                  location
                  prices: price {
                    __typename
                    subtotal {
                      __typename
                      ...MoneyFragment
                    }
                    taxesAndFees {
                      __typename
                      ...MoneyFragment
                    }
                    total {
                      __typename
                      ...MoneyFragment
                    }
                  }
                  promotions {
                    __typename
                    code
                    description
                  }
                  orderItemStatus
                  __typename
                }
              }
              price {
                __typename
                ...OrderPriceFragment
              }
              loyalty {
                __typename
                ...OrderLoyaltyFragment
              }
            }
          }
          
          fragment AddressFragment on Address {
            __typename
            line1
            line2
            city
            state {
              __typename
              ...StateFragment
            }
            postalCode
            country {
              __typename
              name
              code
            }
          }
          
          fragment StateFragment on State {
            __typename
            name
            code
          }
          
          fragment TravelerFragment on Traveler {
            __typename
            id
            firstName
            middleName
            lastName
            suffix
            gender
            dateOfBirth
            knownTravelerNumber
            redressNumber
            email
            type
            phone {
              __typename
              ...PhoneFragment
            }
            isPrimary
            ssrs {
              __typename
              ...SSRFragment
            }
            isEligibleForSubmittingResidencyDetails
            residencyDetails {
              travelerId
              __typename
            }
          }
          
          fragment PhoneFragment on Phone {
            __typename
            type
            countryPrefix
            country {
              __typename
              code
              name
              phonePrefixCode
              states {
                __typename
                name
                code
              }
            }
            number
          }
          
          fragment SSRFragment on Ssr {
            __typename
            code
            flightId
            title
            description
            price {
              __typename
              ...MoneyFragment
            }
            additionalInfo
            display
          }
          
          fragment MoneyFragment on MoneyTotal {
            __typename
            currency
            amount
          }
          
          fragment OrderPaymentFragment on OrderPayment {
            __typename
            paymentType
            paymentMethod
            paymentStatus
            total {
              __typename
              ...MoneyFragment
            }
          }
          
          fragment FlightBundleFragment on FlightBundleAncillary {
            __typename
            id
            tier
            name
            icon
            banner
            ancillaries {
              __typename
              ...FlightAncillaryFragment
            }
            discount {
              __typename
              ... on FlatDiscount {
                ...FlatDiscountFragment
                __typename
              }
              ... on PercentDiscount {
                ...PercentDiscountFragment
                __typename
              }
            }
            discountType
            originalPricePerParty {
              __typename
              ...MoneyFragment
            }
            bundlePricePerParty {
              __typename
              ...MoneyFragment
            }
            savingsPerParty {
              __typename
              ...MoneyFragment
            }
            originalPricePerPerson {
              __typename
              ...MoneyFragment
            }
            bundlePricePerPerson {
              __typename
              ...MoneyFragment
            }
            savingsPerPerson {
              __typename
              ...MoneyFragment
            }
          }
          
          fragment FlightAncillaryFragment on FlightAncillary {
            __typename
            type
            name
            icon
            strikethruPrice {
              __typename
              ...MoneyFragment
            }
            price {
              __typename
              ...MoneyFragment
            }
            discount {
              __typename
              ...FlatDiscountFragment
            }
            numberOfIncludedItems
          }
          
          fragment FlatDiscountFragment on FlatDiscount {
            __typename
            currency
            amount
          }
          
          fragment PercentDiscountFragment on PercentDiscount {
            __typename
            value
          }
          
          fragment FlightFragment on Flight {
            __typename
            id
            number
            departingTime
            arrivalTime
            isOvernight
            isFlown
            providerId
            checkinCompleted
            checkInOpenIn
            operatedBy {
              __typename
              carrier
              flightNo
            }
            origin {
              __typename
              ...AirportFragment
            }
            destination {
              __typename
              ...AirportFragment
            }
            status {
              irop
              dispositionReason
              iropHistory {
                iropDateTime
                flightNumber
                departureDate
                departureTime
                arrivalDate
                arrivalTime
                origin {
                  code
                  title
                  displayName
                  __typename
                }
                destination {
                  code
                  title
                  displayName
                  __typename
                }
                __typename
              }
              arrival {
                terminal
                gate
                status
                __typename
              }
              departure {
                terminal
                gate
                status
                __typename
              }
              __typename
            }
            travelers {
              id
              status
              __typename
            }
          }
          
          fragment AirportFragment on Airport {
            __typename
            locationId
            code
            title
            displayName
            city
            country
            state
            geoPoint {
              __typename
              ...GeoPointFragment
            }
          }
          
          fragment GeoPointFragment on GeoPoint {
            __typename
            latitude
            longitude
          }
          
          fragment FlightOrderItemPriceFragment on FlightOrderItemPrice {
            __typename
            subtotal
            taxes {
              __typename
              breakdown {
                __typename
                ...TaxFragment
              }
              total {
                __typename
                ...MoneyFragment
              }
            }
            fees {
              __typename
              breakdown {
                __typename
                ...FeeFragment
              }
              total {
                __typename
                ...MoneyFragment
              }
            }
            discountValue {
              __typename
              ...MoneyFragment
            }
            discountType
            total
          }
          
          fragment TaxFragment on Tax {
            __typename
            name
            code
            value {
              __typename
              ...MoneyFragment
            }
          }
          
          fragment FeeFragment on Fee {
            __typename
            name
            code
            value {
              __typename
              ...MoneyFragment
            }
          }
          
          fragment OrderPriceFragment on OrderPrice {
            __typename
            taxes {
              __typename
              ...MoneyFragment
            }
            fees {
              __typename
              ...MoneyFragment
            }
            total
            balanceDue
            totalPaid
          }
          
          fragment OrderLoyaltyFragment on OrderLoyalty {
            __typename
            rewardPoints
            bonusPoints
            bonusAndRewardPoints
            applicableAmount {
              __typename
              ...MoneyFragment
            }
          }
          
          fragment AncillaryShopItemFragment on AncillaryShopItemInterface {
            __typename
            type
            pricesBreakdown {
              __typename
              quantity
              price {
                __typename
                ...MoneyFragment
              }
              strikethruPrice {
                __typename
                ...MoneyFragment
              }
              isIncludedInBundle
            }
          }
          
          fragment VehicleFragment on Vehicle {
            __typename
            category
            type
            description
            image
            code
            seats
            bags
            promos {
              __typename
              ...VehiclePromotionFragment
            }
          }
          
          fragment VehiclePromotionFragment on VehiclePromotion {
            __typename
            id
            code
            description
            headlineDescription
            shortDescription
            details
            termsAndConditions
            displayFrom
            displayTo
            reservationFrom
            reservationTo
            occupancyFrom
            occupancyTo
            blackoutDates {
              __typename
              from
              to
            }
          }
          
          fragment VehicleVendorFragment on VehicleVendor {
            __typename
            itemId: id
            name
            logo
          }
          
          fragment HotelOrderItemFragment on HotelOrderItem {
            __typename
            id
            roomId
            roomsCount
            adultCount
            childrenCount
            stayLength
            confirmationNumber
            orderItemStatus
            roomType
            checkin {
              time
              policy
              __typename
            }
            checkout {
              time
              policy
              __typename
            }
            hotel {
              __typename
              name
              address
              image
              phone {
                __typename
                number
                countryPrefix
              }
              geoPoint {
                __typename
                longitude
                latitude
              }
            }
          }
          
          fragment ShowOrderItemFragment on OrderItem {
            ... on ShowOrderItem {
              id
              type
              show {
                date
                location
                categoryCode
                categoryName
                meta
                productName
                productDescription
                __typename
              }
              quantity
              __typename
            }
            __typename
          }`
        let variables = `{
                "orderSearchCriteria": {
                  "firstName": "${firstName}",
                  "lastName": "${lastName}",
                  "orderNumber": "${confNumber}"
                }
              }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            let transactionModificationId, travellers, departFlightId, returnFlightId, paymentFirstName, paymentLastName
            let travelerid = []
            try {
                transactionModificationId = responseJson.data.transactionId
                travellers = responseJson.data.findOrder.order.travelers
                departFlightId = responseJson.data.findOrder.order.items[0].flight.id
                if ((responseJson.data.findOrder.order.items[1].__typename) === "FlightOrderItem") {
                    returnFlightId = responseJson.data.findOrder.order.items[1].flight.id
                }
                paymentFirstName = responseJson.data.findOrder.order.customer.firstName
                paymentLastName = responseJson.data.findOrder.order.customer.lastName
                for (let i = 0; i < travellers.length; i++) {
                    travelerid.push(responseJson.data.findOrder.order.travelers[i].id)
                }
            } catch (err) {
                throw new Error("ITN details are not available")
            }
            return { transactionModificationId, travelerid, departFlightId, returnFlightId, paymentFirstName, paymentLastName }
        })
    }
    /**
* This method performs GQL call for modify Order
* @param {*} confNumber Ex:Marianne
* @param {*} paymentFirstName Ex:"Adult"
* @param {*} paymentLastName Ex:"Hill"
* @param {*} transactionModificationId Ex:"timeline14uidf"
*/
    async modifyOrder(confNumber, paymentFirstName, paymentLastName, transactionModificationId) {
        if (transactionModificationId !== undefined) {
            this._transactionId = transactionModificationId
        }
        let query = `mutation GetModifyOrder($orderSearchCriteria: OrderSearchCriteria!) {
            getModifyOrder(orderSearchCriteria: $orderSearchCriteria) {
              order {
                items {
                  ... on FlightOrderItem {
                    id
                    __typename
                  }
                  __typename
                }
                confirmationNumber
                bookingDate
                __typename
              }
              errors
              __typename
            }
          }`
        let variables = `{
    "orderSearchCriteria": {
      "firstName": "${paymentFirstName}",
      "lastName": "${paymentLastName}",
      "orderNumber": "${confNumber}"
    }
  }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables)
    }
    /**
* This method performs GQL call for modify Bags
* @param {*} bagsPageQty Ex:0
* @param {*} travelerid Ex:['1']
* @param {*} departureFlightId Ex:"2023-10-16-G4-272"
* @param {*} returningFlightId Ex:"2023-10-16-G4-272"
*/
    async addOrChangeBags(bagsPageQty, travelerid, departureFlightId, returningFlightId) {
        let query = `mutation selectTravelerAncillaries($travelersAncillaries: [TravelerAncillaryInput!]!) {
            selectTravelerAncillaries(travelersAncillaries: $travelersAncillaries) {
              order {
                items {
                  id
                  ... on TravelerAncillaryOrderItem {
                    flightId
                    travelerId
                    ancillaryType
                    quantity
                    price {
                      amount
                      currency
                      __typename
                    }
                    bundledAncillaryPrice {
                      amount
                      __typename
                    }
                    isBundledAncillaryIncluded
                    __typename
                  }
                  __typename
                }
                price {
                  total
                  __typename
                }
                __typename
              }
              errors
              __typename
            }
          }`
        let CIQuantity, CIQuantity2, COQuantity, COQuantity2
        let CIQty, CIQty2
        let bagsObject = {}
        let bagsArray = []
        CIQty = bagsPageQty[0].charAt(0)
        CIQuantity = 0
        if (bagsPageQty[0].includes("Dep") || bagsPageQty[0].includes("Both")) {

            CIQuantity = CIQty
            let CIBdepartDetails = `{
        "flightId": "${departureFlightId}",
        "travelerId": "${travelerid}",
        "type": "CHECK_IN_BAG",
        "quantity": "${CIQuantity}"
      }`
            travelerid.forEach((id) => {
                let newCIBdepartDetails = JSON.parse(CIBdepartDetails)
                newCIBdepartDetails.travelerId = id;
                bagsArray.push(newCIBdepartDetails);
            })
        }

        CIQty2 = bagsPageQty[0].charAt(0)
        CIQuantity2 = 0


        if (bagsPageQty[0].includes("Return") || bagsPageQty[0].includes("Both")) {
            if (returningFlightId !== undefined) {
                CIQuantity2 = CIQty2

            }
            let CIBreturnDetails = `{
                "flightId": "${returningFlightId}",
                "travelerId": "${travelerid}",
                "type": "CHECK_IN_BAG",
                "quantity": "${CIQuantity2}"    
              }`
            travelerid.forEach((id) => {
                let newCIBreturnDetails = JSON.parse(CIBreturnDetails);
                newCIBreturnDetails.travelerId = id;
                bagsArray.push(newCIBreturnDetails);
            })
        }
        let COQty, COQty2
        COQty = bagsPageQty[1].charAt(0)
        COQuantity = 0
        if (bagsPageQty[1].includes("Dep") || bagsPageQty[1].includes("Both")) {

            COQuantity = COQty
            let COBdepartDetails = `{
                "flightId": "${departureFlightId}",
                "travelerId": "${travelerid}",
                "type": "CARRY_ON_BAG",
                "quantity": "${COQuantity}"
              }`
            travelerid.forEach((id) => {
                let newCOBdepartDetails = JSON.parse(COBdepartDetails);
                newCOBdepartDetails.travelerId = id;
                bagsArray.push(newCOBdepartDetails);
            })
        }
        COQty2 = bagsPageQty[1].charAt(0)
        COQuantity2 = 0
        if (bagsPageQty[1].includes("Return") || bagsPageQty[1].includes("Both")) {
            if (returningFlightId !== undefined) {
                COQuantity2 = COQty2
            }
            let COBreturnDetails = `{
                    "flightId": "${returningFlightId}",
                    "travelerId": "${travelerid}",
                    "type": "CARRY_ON_BAG",
                    "quantity": "${COQuantity2}"
                  }`
            travelerid.forEach((id) => {
                let newCOBreturnDetails = JSON.parse(COBreturnDetails);
                newCOBreturnDetails.travelerId = id;
                bagsArray.push(newCOBreturnDetails);
            })
        }
        bagsObject.travelersAncillaries = bagsArray
        let variables = JSON.stringify(bagsObject)
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            if (responseJson.data?.selectTravelerAncillaries.errors.length !== 0) {
                throw new Error("Failed in Bag modification!")
            }
        })
    }
    /**
* This method performs GQL call for payment
* @param {*} env Ex:"stg"
* @param {*} firstName Ex:Marianne
* @param {*} lastName Ex:"Hill"
* @param {*} card Ex:"Master"
*/
    async paymentForModification(env,firstName, lastName,card) {
        let query = `mutation bookOrder($customer: OrderCustomerInput!, $payment: OrderPaymentInput!, $registerUser: Boolean!) {
            bookOrder(customer: $customer, payment: $payment, registerUser: $registerUser) {
              order {
                confirmationNumber
                __typename
              }
              errors
              __typename
            }
          }`
        let cardTypes
        if(card===undefined){
            cardTypes="Master"
        }
        else{
            cardTypes=card
        }
        let {
            creditCardNum,
            creditCardCvv,
        } = await CardNumbers.getCreditCardNumbers(cardTypes)
        // console.log("creditCardNum: ", creditCardNum)
        // console.log("creditCardCvv: ", creditCardCvv)
        let cardDetails = await CardDetails.getEncryptedValues(creditCardNum, creditCardCvv, env);
        let encryptCC = cardDetails[0]
        let encryptCvv = cardDetails[1]

        let variables = `{
          "customer": {
            "firstName": "${firstName}",
            "lastName": "${lastName}",
            "email": "accept@fraudtest.com",
            "alternateEmail": "",
            "password": "",
            "passwordRepeat": "",
            "subscribeToNewsletter": false
          },
          "payment": {
            "creditCardPayment": {
              "type": "CREDIT_CARD",
              "number": "${encryptCC}",
              "cvv": "${encryptCvv}",
              "encryptionType": "PIE",
              "cardHolderName": "Adult A",
                "expireMonth": 12,
                "expireYear": 2030,
                "shouldStoreCard": false
              },
              "instantCreditCardPayment": null,
              "billingAddress": {
                "line1": "New Colony",
                "line2": "",
                "countryCode": "US",
                "stateCode": "NY",
                "city": "New York",
                "postalCode": "02170"
              },
              "billingPhone": {
                "number": "7025551111",
                "type": "NOT_SELECTED",
                "countryCode": "US",
                "prefixCode": "1"
              }
            },
            "registerUser": true
          }`

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            let ITN
            try {
                ITN = responseJson.data.bookOrder.order.confirmationNumber
            } catch (err) {
                throw new Error("Failed in Payment page")
            }
            return {ITN,encryptCC,encryptCvv}
        })
    }
 
}