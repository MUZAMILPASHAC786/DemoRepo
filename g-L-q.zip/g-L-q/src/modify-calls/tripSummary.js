module.exports = class TripSummary {

    /**
* This is constructer for Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }
    /**
* This method performs GQL call for hotelList
*/
    async tripSummary() {
        let query = `query payment {
            order {
              customer {
                email
                __typename
              }
              items {
                ... on FlightOrderItem {
                  flight {
                    destination {
                      code
                      __typename
                    }
                    __typename
                  }
                  __typename
                }
                __typename
              }
              price {
                total
                balanceDue
                totalPaid
                __typename
              }
              loyalty {
                totalPoints
                totalAmount {
                  amount
                  currency
                  __typename
                }
                applicableAmount {
                  amount
                  currency
                  __typename
                }
                futureStatementCredit {
                  amount
                  currency
                  __typename
                }
                totalDueAmount {
                  amount
                  currency
                  __typename
                }
                dueAmount {
                  amount
                  currency
                  __typename
                }
                earningPoints {
                  masterCardPoints
                  allwaysPoints
                  totalEarning
                  __typename
                }
                applicablePoints
                bonusPoints
                enrolled
                eligible
                bonusAndRewardPoints
                errors
                __typename
              }
              payments {
                ...OrderPaymentFragment
                ...PromoPaymentFragment
                ...VoucherPaymentFragment
                ...LoyaltyPaymentFragment
                __typename
              }
              instantCreditSelected
              isUpliftSelected
              __typename
            }
            settings {
              card {
                pieKey
                pieLib
                maxStoredLimit
                types {
                  code
                  name
                  description
                  fields {
                    name
                    regex
                    regexMin
                    __typename
                  }
                  rank
                  logo {
                    default
                    highlight
                    disable
                    __typename
                  }
                  __typename
                }
                riskDeviceLibInfo {
                  libPath
                  libTimeout
                  __typename
                }
                __typename
              }
              loyalty {
                enabled
                cardIcon
                displayPointsBookingPath
                __typename
              }
              instantCredit {
                enabled
                __typename
              }
              __typename
            }
            countries {
              name
              code
              phonePrefixCode
              states {
                name
                code
                __typename
              }
              __typename
            }
          }
          
          fragment OrderPaymentFragment on OrderPayment {
            paymentType
            paymentStatus
            paymentMethod
            total {
              amount
              currency
              __typename
            }
            __typename
          }
          
          fragment PromoPaymentFragment on PromoPayment {
            id
            description
            total {
              amount
              currency
              __typename
            }
            isAutoApplied
            __typename
          }
          
          fragment VoucherPaymentFragment on VoucherPayment {
            id
            type
            __typename
          }
          
          fragment LoyaltyPaymentFragment on LoyaltyPayment {
            id
            points
            __typename
          }`

        let variables = ``
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            let balanceDueAmount
            try {
                balanceDueAmount= responseJson.data.order.price.balanceDue
            }
            catch (err) {
                console.error("TripSummary is unavailable")
            }
            return {balanceDueAmount}
        })

    }
}