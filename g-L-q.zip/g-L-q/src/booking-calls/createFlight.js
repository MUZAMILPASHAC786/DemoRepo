// const fetch = require('node-fetch')
// const DB2Util = require('../helpers/gql-helper/DB2')

// module.exports = class NewFlight {
//     /**
//   * This method performs flight creation
//   * @param {string} env Ex : ".qa1"
//   * @param {string} origin Ex: "LAS"
//   * @param {string} destination Ex : "MEX"
//   * @param {string} tailNumber Ex : "215NV"
//   * @param {string} aircraftType Ex : "32A"
//   * @param {string} seatSize Ex : "177"
//   * @param {string} departDate Ex : "2023-08-02"
//   * @param {string} hours Ex : "5"
//   * @returns {json} flight Number
//   */
//     async createFlightRecord(env, origin, destination, tailNumber, aircraftType, seatSize, departDate, hours) {
//         let flightBody = "{\r\n    \"actualEquipment\": {\r\n        \"configuration\": \"32B\",\r\n"
//             + "        \"make\": \"Airbus\",\r\n        \"typeIata\": \"320\"\r\n    },\r\n"
//             + "    \"arrivalAirportActual\": {\r\n        \"code\": \"\",\r\n"
//             + "        \"codeType\": \"IATA\",\r\n        \"city\": \"Syracuse\",\r\n"
//             + "        \"state\": \"NY\",\r\n        \"timeZone\": \"America/New_York\",\r\n"
//             + "        \"airportCodeByType\": {\r\n            \"iata\": \"\",\r\n"
//             + "            \"icao\": \"\",\r\n            \"local\": \"\"\r\n        }\r\n    },\r\n"
//             + "    \"arrivalAirportScheduled\": {\r\n        \"code\": \"\",\r\n"
//             + "        \"codeType\": \"IATA\",\r\n        \"city\": \"Syracuse\",\r\n"
//             + "        \"state\": \"NY\",\r\n        \"timeZone\": \"America/New_York\",\r\n"
//             + "        \"airportCodeByType\": {\r\n            \"iata\": \"\",\r\n"
//             + "            \"icao\": \"\",\r\n            \"local\": \"\"\r\n        }\r\n    },\r\n"
//             + "    \"authorizedSeats\": 186,\r\n    \"carrier\": \"G4\",\r\n"
//             + "    \"departureAirportScheduled\": {\r\n        \"code\": \"\",\r\n"
//             + "        \"codeType\": \"IATA\",\r\n        \"city\": \"Tuscaloosa\",\r\n"
//             + "        \"state\": \"AL\",\r\n        \"timeZone\": \"America/Chicago\",\r\n"
//             + "        \"airportCodeByType\": {\r\n            \"iata\": \"\",\r\n"
//             + "            \"icao\": \"\",\r\n            \"local\": \"\"\r\n        }\r\n    },\r\n"
//             + "    \"departureAirportActual\": {\r\n        \"code\": \"\",\r\n"
//             + "        \"codeType\": \"IATA\",\r\n        \"city\": \"Tuscaloosa\",\r\n"
//             + "        \"state\": \"AL\",\r\n        \"timeZone\": \"America/Chicago\",\r\n"
//             + "        \"airportCodeByType\": {\r\n            \"iata\": \"\",\r\n"
//             + "            \"icao\": \"\",\r\n            \"local\": \"\"\r\n        }\r\n    },\r\n"
//             + "    \"flightStatus\": {\r\n        \"displayStatus\": \"ONTIME\",\r\n"
//             + "        \"flightStatusIata\": \"AA\",\r\n        \"flightStatus\": \"ON\"\r\n    },\r\n"
//             + "    \"scheduledEquipment\": {\r\n        \"configuration\": \"32B\",\r\n"
//             + "        \"make\": \"Airbus\",\r\n        \"typeIata\": \"320\"\r\n    },\r\n"
//             + "    \"sta\": \"\",\r\n    \"std\": \"\",\r\n    \"etd\": null,\r\n"
//             + "    \"eta\": null,\r\n    \"scheduledSeats\": 186,\r\n    \"assignedTail\": \"321NV\",\r\n"
//             + "    \"scheduledTail\": \"321NV\",\r\n    \"routeIdentifier\": \"2000\",\r\n"
//             + "    \"routeMiles\": 452,\r\n    \"market\": \"CUNSFB\",\r\n    \"base\": \"SFB\",\r\n"
//             + "    \"departureDateLocal\": \"\",\r\n    \"flightLeg\": \"1\",\r\n"
//             + "    \"isInternational\": true,\r\n    \"flightNumber\": \"\",\r\n"
//             + "    \"assignSeats\": true,\r\n    \"flightRules\": \"D\",\r\n    \"lockState\": \"N\",\r\n"
//             + "    \"closeState\": \"O\",\r\n    \"category\": \"SF\",\r\n    \"flightType\": \"RF\",\r\n"
//             + "    \"divert\": null\r\n}"

//         let query = JSON.parse(flightBody)

//         let flightNumber = Math.floor((Math.random() * ((8000 - 7000) + 1)) + 7000);

//         query.arrivalAirportActual.code = destination
//         query.arrivalAirportActual.airportCodeByType.iata = destination
//         query.arrivalAirportActual.airportCodeByType.icao = destination
//         query.arrivalAirportActual.airportCodeByType.local = destination
//         query.arrivalAirportScheduled.code = destination
//         query.arrivalAirportScheduled.airportCodeByType.iata = destination
//         query.arrivalAirportScheduled.airportCodeByType.icao = destination
//         query.arrivalAirportScheduled.airportCodeByType.local = destination

//         query.departureAirportScheduled.code = origin
//         query.departureAirportScheduled.airportCodeByType.iata = origin
//         query.departureAirportScheduled.airportCodeByType.icao = origin
//         query.departureAirportScheduled.airportCodeByType.local = origin
//         query.departureAirportActual.code = origin
//         query.departureAirportActual.airportCodeByType.iata = origin
//         query.departureAirportActual.airportCodeByType.icao = origin
//         query.departureAirportActual.airportCodeByType.local = origin
//         /**
// * This method performs  date selection
// * @param {string} env Ex : ".qa1"
// * @param {string} flightNumber Ex: "7761"
// * @param {string} aircraftType Ex : "32A"
// * @param {string} departDate Ex : "2023-08-02"
// */

//         if (hours !== undefined) {
//             /**
//     * This method performs  date selection
//     * @param {num} num Ex : ".qa1"
//     * @returns {string} flight Number
//     */
//             function padTo2Digits(num) {
//                 return num.toString().padStart(2, '0');
//             }
//             /**
//     * This method performs hour calculation
//     * @param {num} date Ex : "2023-08-01"
//     * @param {nextHour} nextHour Ex : "2"
//     * @param {hours} hours Ex : "4"
//     * @returns {string} flight Number
//     */
//             function formatDate(date, nextHour, hours) {
//                 return (
//                     [
//                         date.getFullYear(),
//                         padTo2Digits(date.getMonth() + 1),
//                         padTo2Digits(date.getDate()),
//                     ].join('-') +
//                     'T' +
//                     [
//                         padTo2Digits(date.getHours() + nextHour + hours),
//                         padTo2Digits(date.getMinutes()),
//                     ].join(':')
//                 );
//             }
//             var hourFormat = formatDate(new Date(), 0, hours)
//             var hourFormat2 = formatDate(new Date(), 2, hours)
//             query.sta = hourFormat + ":00Z"
//             query.std = hourFormat2 + ":00Z"
//         }
//         query.sta = departDate + "T21:02:00Z"
//         query.std = departDate + "T18:33:00Z"
//         query.departureDateLocal = departDate
//         query.flightNumber = flightNumber
//         query.actualEquipment.configuration = aircraftType
//         query.scheduledEquipment.configuration = aircraftType
//         query.authorizedSeats = seatSize
//         query.scheduledSeats = seatSize
//         query.scheduledTail = tailNumber
//         query.assignedTail = tailNumber
//         let headerObj = {
//             'Content-Type': 'application/json',
//             'Accept': 'application/json',
//             'x-gen2-caller-key': 'WS',
//             'x-gen2-user-id': 'WS',
//             'x-gen2-user-name': 'flightJar',
//         }

//         let requestOpts = {
//             method: 'POST',
//             headers: headerObj,
//             body: JSON.stringify(query),
//         };

//         let endpoint = "https://dlb" + env + ".allegiantair.com/flight-record/flights";

//         let response = {}
//         process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
//         response = await fetch(endpoint, requestOpts)
//         response = await response.json()
//         try {
//             if (response.apierror.status === 'CONFLICT') {
//                 this.createFlightRecord(env, origin, destination, tailNumber, aircraftType, seatSize, departDate, hours)
//             }
//         }
//         catch (err) {
//         }
//         finally {
//             process.env.NODE_TLS_REJECT_UNAUTHORIZED = "1";
//         }

//         return flightNumber
//     }
//     /**
//    * This method performs GQL call for date selection
//    * @param {string} env Ex : ".qa1"
//    * @param {string} flightNumber Ex: "7761"
//    * @param {string} aircraftType Ex : "32B"
//    * @param {string} seatSize Ex : "177"
//    * @param {string} departDate Ex : "2023-08-02"
//    * @returns {json} flight Number
//    */
//     async createFareClass(env, flightNumber, aircraftType, seatSize, departDate) {
//         let fareBody = "{\r\n   \"flightNumber\": \"7385\",\r\n  \"leg\": \"1\",\r\n"
//             + "  \"departDate\": \"2019-10-03\",\r\n  \"flightFareClassInventoryBuckets\": [\r\n    {\r\n"
//             + "      \"fareClassCode\": \"Y\",\r\n      \"rank\": 0,\r\n"
//             + "      \"totalBucketSeats\": 186,\r\n      \"totalFlightSeats\": 186\r\n    }\r\n"
//             + "  ]\r\n}"

//         let query = JSON.parse(fareBody)
//         query.departDate = departDate
//         query.flightNumber = flightNumber
//         query.totalBucketSeats = seatSize
//         query.totalFlightSeats = seatSize
//         let endpoint = "http://jbshc1" + env + ".allegiantair.com:9980/g4-flight-management/v1/api/fares/buckets/flights";

//         let headerObj = {
//             'Content-Type': 'application/json',
//             'Accept': 'application/json',
//             'x-gen2-caller-key': 'WS',
//             'x-gen2-user-id': 'WS',
//             'x-gen2-user-name': 'flightJar',
//         }

//         let requestOpts = {
//             method: 'POST',
//             headers: headerObj,
//             body: JSON.stringify(query),
//         };
//         let response = {}
//         process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
//         response = await fetch(endpoint, requestOpts)
//         response = await response.json()
//         console.log(response)
//         await createSeatMap(env, flightNumber, aircraftType, departDate);
//         /**
//    * This method performs seat configuration
//    * @param {string} env Ex : ".qa1"
//    * @param {string} flightNumber Ex: "7761"
//    * @param {string} aircraftType Ex : "32B"
//    * @param {string} departDate Ex : "2023-08-02"
//    */
//         async function createSeatMap(env, flightNumber, aircraftType, departDate) {
//             let database = "CMSDB";
//             let hostConnection = "db2" + env + ".allegiantair.com";
//             if (env.includes("aws")) {
//                 hostConnection = "db2" + env + ".allegiant.com"
//             }
//             let userName = "g4dev"
//             let userPass = "L0ck1tUp"
//             let portNum = "50001"

//             let dbutil = new DB2Util(database, hostConnection, userName, userPass, portNum)
//             await dbutil.createConnection()
//             let query = "INSERT INTO CMSDB.RSFSEATS (SACOMP, SADDATE, SAFLT, SALEG, SAROW, SALETTER, SAPOSN, SASIDE, SACABIN, SAEXIT, SAEXTSALE, SAOPEN, CHGCDE, PAGE, CRT)select '20', '"
//                 + departDate + "', '" + flightNumber
//                 + "', '1', SEATROW, LETTER, POSN, SIDE, CABIN, EXITROW, EXTSALE, 'Y', 'A', 0, 'testUser'from CMSDB.SEATMAPS where ACTYPE = '"
//                 + aircraftType + "' and TAIL = 'ALL'"
//             await dbutil.executeQuery(query)
//             await dbutil.closeConnection();
//             // console.log("QueryResults",dbutil.getQueryResults())
//             // console.log("RowCount",dbutil.getRowCount())
//         }
//     }


// }