module.exports = class Seats {

    /**
* This is constructer for Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }
    /**
* This method performs GQL call for seatSelection
* @param {string } origin Ex:"BLI"
* @param {string } destination Ex:"LAS"
* @param {string} departDate Ex:"2022-06-12"
* @param {string} returnDate Ex:"2022-06-17"
* @param {string} tripType Ex:"ONEWAY"
* @returns {Array}  departFlightArray 
* @returns {Array}  returnFlightArray 
*/
    async seatMap(origin, destination, departDate, returnDate, tripType) {
        let seatMapQuery = `query seatsPageQuery($origin: IataCode, $destination: IataCode, $departureDate: DateTime, $returnDate: DateTime) {
application(name: DESKTOPBOOKINGPATH) {
... on DesktopBookingPath {
  destinationAdverts(filters: {section: BOOKING_SEATS, position: LEFT, origin: $origin, destination: $destination, departureDate: $departureDate, returningDate: $returnDate}) {
    content
    position
    __typename
  }
  configurations {
    displaySkipLinkSeatsPage
    __typename
  }
  __typename
}
__typename
}
flightSearchCriteria {
tripType
adultsCount
childrenCount
lapInfantCount
origin
destination
__typename
}
order {
travelers {
  id
  firstName
  lastName
  type
  ssrs {
    code
    __typename
  }
  __typename
}
items {
  id
  ... on BundleOrderItem {
    __typename
    id
    bundle {
      id
      name
      tier
      icon
      ancillaries {
        type
        __typename
      }
      __typename
    }
  }
  ... on SeatOrderItem {
    id
    travelerId
    flightId
    row
    column
    autoSelect
    price {
      amount
      __typename
    }
    ...seatPriceFragment
    __typename
  }
  ... on FlightOrderItem {
    id
    __typename
    flight {
      id
      origin {
        code
        __typename
      }
      destination {
        code
        __typename
      }
      departingTime
      aircraft {
        make
        model
        __typename
      }
      __typename
    }
    seatmap {
      ...seatPlanFragment
      __typename
    }
  }
  __typename
}
__typename
}
}

fragment seatPlanFragment on FlightSeatmap {
colsMap
seatSizesMap {
id
name
legroomStars
__typename
}
rows {
id
hasLeftExit
hasRightExit
items {
  ... on FlightSeat {
    type
    id
    price {
      amount
      currency
      __typename
    }
    seatPrice {
      subtotal
      taxes {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      taxesIncludedInBundle {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      total
      isUpgradePrice
      __typename
    }
    position
    sizeId
    isAvailable
    isExitRow
    isIncludedInBundle
    __typename
  }
  ... on FlightRowBlank {
    type
    __typename
  }
  ... on FlightRowAisle {
    type
    __typename
  }
  __typename
}
__typename
}
__typename
}

fragment seatPriceFragment on SeatOrderItem {
seatPrice {
subtotal
taxes {
  breakdown {
    name
    code
    value {
      amount
      __typename
    }
    __typename
  }
  total {
    amount
    currency
    __typename
  }
  __typename
}
taxesIncludedInBundle {
  breakdown {
    name
    code
    value {
      amount
      __typename
    }
    __typename
  }
  total {
    amount
    currency
    __typename
  }
  __typename
}
total
isUpgradePrice
__typename
}
__typename
}`
        let seatMapVariables = `{
"origin":"${origin}",
"destination": "${destination}",
"departureDate": "${departDate}",
"returningDate": "${returnDate}"
}`


        return await this.GqlCall.graphQlCall(this._transactionId, seatMapQuery, seatMapVariables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                let departFlightArray = responseJson.data.order.items[0];
                let returnFlightArray = responseJson.data.order.items[1];
                let departSeatRow, returnSeatRow
                departSeatRow = responseJson.data.order.items[0].seatmap.rows.length;
                if (tripType === "ROUNDTRIP") {
                    returnSeatRow = responseJson.data.order.items[1].seatmap.rows.length;
                }
                return {
                    departFlightArray,
                    returnFlightArray,
                    departSeatRow,
                    returnSeatRow,
                }
            } catch (err) {
                throw new Error("depart or return seats are not available")
            }

        })
    }
    /**
* This method performs GQL call for seatSelection
*@param  {string } tripType Ex:"RoundTrip"
*@param  {string } travelerid Ex:1
* @param {string} departFlightArray Ex:"3A"
* @param {string} departureFlightId Ex:"2022-06-12-AW-1"
* @param {string} returnFlightArray, Ex:"3A"
* @param {string} returningFlightId Ex:"2022-06-12-AW-1"
* @param {string} bundleType Ex:"bonus"
* @param {string} adultsCount Ex:1
* @param {string} childrenCount Ex:1
* @param {string} seatspage Ex:"yes"
* @param {string} isInternational Ex:"yes"
* @param {string} departSeatRow Ex:"26"
* @param {string} returnSeatRow Ex:"26"
* @returns {Array} returnSeatSelects 
*/
    async seatSelection(tripType, travelerid, departFlightArray, departureFlightId, returnFlightArray, returningFlightId, bundleType, adultsCount, childrenCount, seatspage, isInternational, departSeatRow, returnSeatRow) {
        let seatSelectionQuery = `mutation seatSelect($seatsSelection: [SeatSelectionInput!]!) {
selectSeats(seatsSelection: $seatsSelection) {
  order {
    price {
      total
      __typename
    }
    items {
      id
      ... on SeatOrderItem {
        id
        travelerId
        flightId
        row
        column
        autoSelect
        price {
          amount
          __typename
        }
        ...seatPriceFragment
        bundledAncillaryPrice {
          amount
          __typename
        }
        __typename
      }
      ... on FlightOrderItem {
        seatmap {
          ...seatPlanFragment
          __typename
        }
        __typename
      }
      __typename
    }
    __typename
  }
  errors
  __typename
}
}

fragment seatPlanFragment on FlightSeatmap {
colsMap
seatSizesMap {
  id
  name
  legroomStars
  __typename
}
rows {
  id
  hasLeftExit
  hasRightExit
  items {
    ... on FlightSeat {
      type
      id
      price {
        amount
        currency
        __typename
      }
      seatPrice {
        subtotal
        taxes {
          breakdown {
            name
            code
            value {
              amount
              __typename
            }
            __typename
          }
          total {
            amount
            currency
            __typename
          }
          __typename
        }
        taxesIncludedInBundle {
          breakdown {
            name
            code
            value {
              amount
              __typename
            }
            __typename
          }
          total {
            amount
            currency
            __typename
          }
          __typename
        }
        total
        isUpgradePrice
        __typename
      }
      position
      sizeId
      isAvailable
      isExitRow
      isIncludedInBundle
      __typename
    }
    ... on FlightRowBlank {
      type
      __typename
    }
    ... on FlightRowAisle {
      type
      __typename
    }
    __typename
  }
  __typename
}
__typename
}

fragment seatPriceFragment on SeatOrderItem {
seatPrice {
  subtotal
  taxes {
    breakdown {
      name
      code
      value {
        amount
        __typename
      }
      __typename
    }
    total {
      amount
      currency
      __typename
    }
    __typename
  }
  taxesIncludedInBundle {
    breakdown {
      name
      code
      value {
        amount
        __typename
      }
      __typename
    }
    total {
      amount
      currency
      __typename
    }
    __typename
  }
  total
  isUpgradePrice
  __typename
}
__typename
}`
        let seatTypes
        let AdultChildSeats = []
        let seatSelectionArray = []
        // let seatsArray = []
        let seatCompleteArray = []
        let seatDetails = {}
        if (childrenCount > 0 && seatspage.includes(":")) {
            console.log("seat-type cannot be consider, if child is there, default seats selecting")
        }

        if (seatspage.includes(":")) {
            seatTypes = seatspage.split(":");
        } else {
            seatTypes = 0;
        }

        let departSeatSelects, returnSeatSelects;
        departSeatSelects = fillSeatDetails(travelerid, departFlightArray, departureFlightId, seatTypes, departSeatRow)

        if (tripType === "ROUNDTRIP") {
            returnSeatSelects = fillSeatDetails(travelerid, returnFlightArray, returningFlightId, seatTypes, returnSeatRow)
        }
        if (isInternational.includes("yes")) {
            seatSelectionArray = departSeatSelects
            seatDetails.seatsSelection = seatSelectionArray
            seatDetails.activeLeg = 1

            let variables = JSON.stringify(seatDetails);
            return await this.GqlCall.graphQlCall(this._transactionId, seatSelectionQuery, variables).then((response) => {
                let responseJson = JSON.parse(JSON.stringify(response));
                try {
                    responseJson.data.selectSeats.order.length
                } catch (err) {
                    throw new Error("seats are not available")
                }
                return {
                    departSeatSelects,
                    returnSeatSelects,
                }
            })

        } else {
            seatSelectionArray = departSeatSelects
            if (tripType === "ROUNDTRIP") {
                seatSelectionArray = departSeatSelects.concat(returnSeatSelects)
            }
            seatDetails.seatsSelection = seatSelectionArray

            let variables = JSON.stringify(seatDetails);
            return await this.GqlCall.graphQlCall(this._transactionId, seatSelectionQuery, variables).then((response) => {
                let responseJSON = JSON.parse(JSON.stringify(response));
                try {
                    responseJSON.data.selectSeats.order.length
                } catch (err) {
                    throw new Error("seats are not available")
                }
                return {
                    departSeatSelects,
                    returnSeatSelects,
                }
            })
        }


        /**
* This method performs setting variable array
* @param {string }travelerid Ex:1
* @param {string }seatsArray Ex:"3A"
* @param {string} flightId Ex:"2022-09-20-G4-272"
* @param {string} seatTypes Ex:"legroom"
* @param {string} seatRowCount Ex:"26"
* @returns {Array} seatsSelectionArray
*/
        function fillSeatDetails(travelerid, seatsArray, flightId, seatTypes, seatRowCount) {
            let count=0
            let nonmatchTraveler=0
            let adultGreater
            if (seatsArray === returnFlightArray) {
                seatCompleteArray = []
            }
            for (let seatLimit = 0; seatLimit < seatRowCount; seatLimit++) {
                let seat = 0;
                while (seat < 7) {
                    if ((seatsArray.seatmap?.rows) !== null) {
                        if ((seatsArray.seatmap?.rows[seatLimit].items[seat].id) !== undefined) {
                            if ((seatsArray.seatmap?.rows[seatLimit].items[seat].isAvailable) !== false) {
                                if (bundleType === "bonus" || bundleType === "Bonus" || bundleType === "BONUS" || bundleType === "total" || bundleType === "Total" || bundleType === "TOTAL") {
                                    if (childrenCount === 0) {
                                        if (seatTypes.length > 1) {
                                            if (seatTypes[1] === "economy") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 2 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === false) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else if (seatTypes[1] === "economy+exit") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 2 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === true) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else if (seatTypes[1] === "legroom+") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 3 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === false) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else if (seatTypes[1] === "legroom+exit") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 3 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === true) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else {
                                                seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                seat++
                                            }
                                        } else {
                                            seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                            seat++
                                        }
                                    } else {
                                        seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                        seat++
                                    }
                                } else {
                                    if (childrenCount === 0) {
                                        if (seatTypes.length > 1) {
                                            if (seatTypes[1] === "economy") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 2 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === false) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else if (seatTypes[1] === "economy+exit") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 2 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === true) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else if (seatTypes[1] === "legroom+") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 3 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === false) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else if (seatTypes[1] === "legroom+exit") {
                                                if ((seatsArray.seatmap.rows[seatLimit].items[seat].sizeId) === 3 && (seatsArray.seatmap.rows[seatLimit].items[seat].isExitRow) === true) {
                                                    seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                    seat++
                                                } else {
                                                    seat++
                                                }
                                            } else {
                                                seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                                seat++
                                            }
                                        } else {
                                            seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                            seat++
                                        }
                                    } else {
                                        seatCompleteArray.push(seatsArray.seatmap.rows[seatLimit].items[seat].id)
                                        seat++
                                    }
                                }
                            } else {
                                seat++
                            }
                        } else {
                            seat++
                        }
                    } else {
                        seat++
                    }
                }
            }
            if (childrenCount !== 0) {
                if (childrenCount <= adultsCount) {
                    let adultSeatArray = []
                    let childSeatArray = []
                    AdultChildSeats = []
                    let j = 0;
                    for (let i = 0; i < childrenCount; i++) {
                        while (j < seatCompleteArray.length) {
                            if (seatCompleteArray[j].includes("A")) {
                                if (seatCompleteArray[j + 1].includes("B")) {
                                    adultSeatArray.push(seatCompleteArray[j]);
                                    childSeatArray.push(seatCompleteArray[j + 1]);
                                  
                                    seatCompleteArray.splice(j, 1);
                                    seatCompleteArray.splice(j, 1);
                                    break;
                                } else {
                                    j++;
                                }

                            } else if (seatCompleteArray[j].includes("D")) {
                                if (seatCompleteArray[j + 1].includes("E")) {
                                    adultSeatArray.push(seatCompleteArray[j]);
                                    childSeatArray.push(seatCompleteArray[j + 1]);
                                    seatCompleteArray.splice(j, 1);
                                    seatCompleteArray.splice(j, 1);
                                    break;
                                } else {
                                    j++;
                                }
                            } else if (seatCompleteArray[j].includes("B")) {
                                if (seatCompleteArray[j + 1].includes("C")) {
                                    adultSeatArray.push(seatCompleteArray[j + 1]);
                                    childSeatArray.push(seatCompleteArray[j]);
                                    seatCompleteArray.splice(j, 1);
                                    seatCompleteArray.splice(j, 1);
                                    break;
                                } else {
                                    j++;
                                }
                            } else if (seatCompleteArray[j].includes("E")) {
                                if (seatCompleteArray[j + 1].includes("F")) {
                                    adultSeatArray.push(seatCompleteArray[j + 1]);
                                    childSeatArray.push(seatCompleteArray[j]);
                                    seatCompleteArray.splice(j, 1);
                                    seatCompleteArray.splice(j, 1);
                                    break;
                                } else {
                                    j++;
                                }
                            } else {
                                j++;
                            }

                        }
                    }

                    AdultChildSeats = adultSeatArray.concat(childSeatArray)
                }
                else if(childrenCount>adultsCount){
                    let adultSeatArray = []
                    let childSeatArray = []
                    if(childrenCount===3 && adultsCount===1)
                    {
                        throw new Error("seat selection not possible,Child should be placed near Adult")
                    }
                    let j = 0;
                    if(adultsCount===2)
                    {
                        adultGreater=1                
                        // AdultChildSeats = []
                        let j = 0;
                        for (let i = 0; i < adultGreater; i++) {
                            while (j < seatCompleteArray.length) {
                                if (seatCompleteArray[j].includes("A")) {
                                    if (seatCompleteArray[j + 1].includes("B")) {
                                        adultSeatArray.push(seatCompleteArray[j]);
                                        childSeatArray.push(seatCompleteArray[j + 1]);
                                    
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        break;
                                    } else {
                                        j++;
                                    }

                                } else if (seatCompleteArray[j].includes("D")) {
                                    if (seatCompleteArray[j + 1].includes("E")) {
                                        adultSeatArray.push(seatCompleteArray[j]);
                                        childSeatArray.push(seatCompleteArray[j + 1]);
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        break;
                                    } else {
                                        j++;
                                    }
                                } else if (seatCompleteArray[j].includes("B")) {
                                    if (seatCompleteArray[j + 1].includes("C")) {
                                        adultSeatArray.push(seatCompleteArray[j + 1]);
                                        childSeatArray.push(seatCompleteArray[j]);
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        break;
                                    } else {
                                        j++;
                                    }
                                } else if (seatCompleteArray[j].includes("E")) {
                                    if (seatCompleteArray[j + 1].includes("F")) {
                                        adultSeatArray.push(seatCompleteArray[j + 1]);
                                        childSeatArray.push(seatCompleteArray[j]);
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        break;
                                    } else {
                                        j++;
                                    }
                                } else {
                                    j++;
                                }

                            }
                        }

                        // AdultChildSeats = adultSeatArray.concat(childSeatArray)
                
                    }
                    else{
                        adultGreater=adultsCount
                    }
                    for (let i = 0; i < adultGreater; i++) {
                        while (j < seatCompleteArray.length) {
                            if (seatCompleteArray[j].includes("A")) {
                                if (seatCompleteArray[j + 1].includes("B")) {
                                    if(seatCompleteArray[j + 2].includes("C"))
                                    {
                                        adultSeatArray.push(seatCompleteArray[j+1]);
                                        childSeatArray.push(seatCompleteArray[j]);
                                        childSeatArray.push(seatCompleteArray[j+2]);
                                
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        break;
                                    }
                                    else {
                                        j++;
                                    }
                                } else {
                                    j++;
                                }

                            } else if (seatCompleteArray[j].includes("D")) {
                                if (seatCompleteArray[j + 1].includes("E")) {
                                    if(seatCompleteArray[j + 2].includes("F"))
                                    {
                                        adultSeatArray.push(seatCompleteArray[j+1]);
                                        childSeatArray.push(seatCompleteArray[j]);
                                        childSeatArray.push(seatCompleteArray[j+2]);
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        seatCompleteArray.splice(j, 1);
                                        break;
                                    }else{
                                        j++;
                                    }
                                } else {
                                    j++;
                                }
                            }  else {
                                j++;
                            }

                        }
                    }

                    AdultChildSeats = adultSeatArray.concat(childSeatArray)
                }
            }
            let nonmatch = 0
            let match = 0
            if (childrenCount !== 0) {
                if (childrenCount <= adultsCount) {
                    count = childrenCount * 2
                    nonmatchTraveler = travelerid.length - count
                }else if(childrenCount > adultsCount)
                {
                    if(childrenCount===2)
                    {
                        count=childrenCount+1
                    }else if(childrenCount===3)
                    {
                        count=childrenCount+2
                    }
                    nonmatchTraveler = travelerid.length - count
                }
            }
         
            let seatsSelectionArray = []
            for (let index = 0; index < travelerid.length; index++) {
                let seatDetails = {}
                seatDetails.travelerId = travelerid[index]
                if (childrenCount !== 0) {
                    if (nonmatch < nonmatchTraveler) {
                        seatDetails.seatId = seatCompleteArray[nonmatch]
                    } else if (match < count) {
                        seatDetails.seatId = AdultChildSeats[match]
                    } else {
                        seatDetails.seatId = seatCompleteArray[index]
                    }
                } else {
                    seatDetails.seatId = seatCompleteArray[index]
                }
                seatDetails.flightId = flightId
                seatsSelectionArray.push(seatDetails)
                nonmatch++;
                if (nonmatch > nonmatchTraveler) {
                    match++;
                }
            }
            return seatsSelectionArray
        }
    }
    /**
* This method performs setting variable array
* @param {string} returnSeatSelects Ex: 1
*/
    async seatSelectionInternational(returnSeatSelects) {
        let seatSelectionQuery = `mutation seatSelect($seatsSelection: [SeatSelectionInput!]!, $activeLeg: Int) {
    selectSeats(seatsSelection: $seatsSelection, activeLeg: $activeLeg) {
      order {
        price {
          total
          __typename
        }
        items {
          id
          ... on SeatOrderItem {
            id
            travelerId
            flightId
            row
            column
            autoSelect
            price {
              amount
              __typename
            }
            ...seatPriceFragment
            bundledAncillaryPrice {
              amount
              __typename
            }
            __typename
          }
          ... on FlightOrderItem {
            seatmap {
              ...seatPlanFragment
              __typename
            }
            __typename
          }
          __typename
        }
        __typename
      }
      errors
      __typename
    }
  }
  
  fragment seatPlanFragment on FlightSeatmap {
    colsMap
    seatSizesMap {
      id
      name
      legroomStars
      __typename
    }
    rows {
      id
      hasLeftExit
      hasRightExit
      items {
        ... on FlightSeat {
          type
          id
          price {
            amount
            currency
            __typename
          }
          seatPrice {
            subtotal
            taxes {
              breakdown {
                name
                code
                value {
                  amount
                  __typename
                }
                __typename
              }
              total {
                amount
                currency
                __typename
              }
              __typename
            }
            taxesIncludedInBundle {
              breakdown {
                name
                code
                value {
                  amount
                  __typename
                }
                __typename
              }
              total {
                amount
                currency
                __typename
              }
              __typename
            }
            total
            isUpgradePrice
            __typename
          }
          position
          sizeId
          isAvailable
          isExitRow
          isIncludedInBundle
          __typename
        }
        ... on FlightRowBlank {
          type
          __typename
        }
        ... on FlightRowAisle {
          type
          __typename
        }
        __typename
      }
      __typename
    }
    __typename
  }
  
  fragment seatPriceFragment on SeatOrderItem {
    seatPrice {
      subtotal
      taxes {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      taxesIncludedInBundle {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      total
      isUpgradePrice
      __typename
    }
    __typename
  }`
        let seatDetailsInter = {}
        try {
            seatDetailsInter.seatsSelection = (Object.values(returnSeatSelects)).flat()
        }
        catch (err) {
            throw new Error("seats are not available")
        }
        seatDetailsInter.activeLeg = 2

        let variables = JSON.stringify(seatDetailsInter);
        return await this.GqlCall.graphQlCall(this._transactionId, seatSelectionQuery, variables).then((response) => {
            let responseJSON = JSON.parse(JSON.stringify(response));

            try {
                responseJSON.data.selectSeats.order.length
            } catch (err) {
                throw new Error("seats are not available")
            }
            return {
                returnSeatSelects,
            }
        })

    }
}