module.exports = class Login {

    /**
* This is constructer for Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;

    }
    /**
* This method performs GQL call for accountCreation
* @param {*} firstName Ex:Mary
* @param {*} lastName Ex:Quiry
* @return {*} loginEmail
* @returns {*} loginPassword
* @returns {*} loginID
* @returns {*} accountToken
**/
    async accountCreation(firstName, lastName) {
        let accountCreationQuery = `mutation registerCustomer($customerAccount: RegisterCustomerInput!, $attemptClaimOrder: Boolean) {
           registerCustomer(customerAccount: $customerAccount, attemptClaimOrder: $attemptClaimOrder) {
             errors
             account {
               id
               userName
               firstName
               lastName
               __typename
             }
             token
             __typename
           }
         }`
        let randomNo = Math.floor(Math.random() * 999) + 100
        /**
* This method performs GQL call for generating random dates
* @param {*} start  gives random date
* @param {*} end gives random date
* @return {*} random date

**/
        function randomDate(start, end) {
            return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
        }
        let loginEmail = ""
        let loginID,accountToken
        let dateRandom = randomDate(new Date(2012, 0, 1), new Date());
        var res = dateRandom.toISOString().slice(0, 10).replace(/-/g, "");

        loginEmail = "tsqa.automation+" + randomNo + res + "@allegiantsqa.com";
        let loginPassword = loginEmail.replace("com", "coM")
        let accountCreationVariables = `{
           "customerAccount": {
             "emailAddress": "${loginEmail}",
             "password": "${loginPassword}",
             "firstName": "${firstName}",
             "lastName": "${lastName}",
             "dateOfBirth": "1998-02-24",
             "shouldReceiveNewsletter": true,
             "customerPrograms": [
               {
                 "programId": "1"
               }
             ]
           },
           "attemptClaimOrder": false
         }`

        return await this.GqlCall.graphQlCall(this._transactionId, accountCreationQuery, accountCreationVariables).then((response) => {

            let responseJson = JSON.parse(JSON.stringify(response));

           
            try {
                loginID = responseJson.data.registerCustomer.account.id;
                accountToken = responseJson.data.registerCustomer.token;
                return {
                    loginEmail,
                    loginPassword,
                    loginID,
                    accountToken,
                }
            }
            catch (err) {
                console.error("account creation was unsuccessful");
            }
        })

    }

    /**
* This method performs GQL call for login
* @param {*} loginEmail Ex:tsqa.automation+43920181021@tridentsqa.com
* @param {*} loginPassword Ex:tsqa.automation+43920181021@tridentsqa.coM
* @returns {*} loginToken
**/
    async login(loginEmail, loginPassword) {
        let loginQuery = `mutation login($userName: String!, $password: String!, $rememberMe: Boolean!, $attemptClaimOrder: Boolean, $application: LoginApplication = MYALLEGIANT) {
  login(userName: $userName, password: $password, rememberMe: $rememberMe, application: $application, attemptClaimOrder: $attemptClaimOrder) {
    viewer {
      userName
      firstName
      forceResetPassword
      id
      __typename
    }
    token
    errors
    __typename
  }
}`
        let loginVariables = `{
        "application": "MYALLEGIANT",
        "userName": "${loginEmail}",
        "password": "${loginPassword}",
        "rememberMe": false,
        "attemptClaimOrder": false
      }`

        return await this.GqlCall.graphQlCall(this._transactionId, loginQuery, loginVariables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                let loginToken = responseJson.data.login.token
                return loginToken
            }
            catch (e) {
                throw new Error("login was unsuccessful")
            }
        })
    }
    /**
* This method gets details of login account
* @param {*} loginToken Token will get generated
* @returns {*} loyaltyPointDetails,
* @returns {*} firstNameLoyaltyAccount,
* @returns {*} lastNameLoyaltyAccount,
**/
    async getloyaltyTravelerDetails(loginToken){
        let query = `query mySummaryQuery($refetch: Boolean) {
    viewer {
      id
      loyaltyId
      firstName
      lastName
      loyalty(refetch: $refetch) {
        status
        total
        pointsValue
        __typename
      }
      isLoyaltyCardLinked
      __typename
    }
  }`
        let variables=`{
      "refetch": false
    }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables, loginToken).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                var loyaltyPointDetails = responseJson.data.viewer.loyalty.pointsValue;
            } catch (err) {
                throw new Error("Traveler Details are Not available for loyalty booking")
            }
            let firstNameLoyaltyAccount = responseJson.data.viewer.firstName
            let lastNameLoyaltyAccount =responseJson.data.viewer.lastName
            // let departid = responseJson.data.updateOrderTravelers.order.items[0];
            // let returnid = []
            // if (tripType === "ROUNDTRIP") {
            //     returnid = responseJson.data.updateOrderTravelers.order.items[1];
            // }

            return {
                loyaltyPointDetails,
                firstNameLoyaltyAccount,
                lastNameLoyaltyAccount,
            }

        })
    }
}