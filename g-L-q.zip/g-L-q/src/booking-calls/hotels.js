module.exports = class Hotels {

    /**
* This is constructer for Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }
    /**
* This method performs GQL call for hotelList
* @param {string} origin Ex : "LAS"
* @param {string} destination Ex : "MEX"
* @param {string} departDate Ex: "2022-06-12" 
* @param {string} returnDate Ex: "2022-06-12"
* @param {string} roomTypeSelected Ex: "Deluxe"
* @param {string} roomsSelected Ex: "2"
* @param {string} adultsCount Ex: "2"
* @param {string} tripType Ex: "ROUNDTRIP"
* @returns {string} hotelId
* @returns {string} roomsCount
*/
    async hotelList(origin, destination, departDate, returnDate, roomTypeSelected, roomsSelected, adultsCount, tripType) {
    // eslint-disable-next-line max-len
        let query = `query hotels($packageHotelSearchCriteria: PackageHotelSearchInput, $sort: HotelSort, $filters: HotelFiltersInput, $offset: Int, $limit: Int, $origin: IataCode, $destination: IataCode, $departureDate: DateTime, $returnDate: DateTime) {
        application(name: DESKTOPBOOKINGPATH) {
          ... on DesktopBookingPath {
            destinationAdverts(filters: {section: BOOKING_HOTELS, position: TOP, origin: $origin, destination: $destination, departureDate: $departureDate, returningDate: $returnDate}) {
              content
              position
              __typename
            }
            __typename
          }
          __typename
        }
        order {
          items {
            id
            ... on FlightOrderItem {
              id
              __typename
              flight {
                id
                operatedBy {
                  carrier
                  flightNo
                  __typename
                }
                __typename
              }
            }
            __typename
          }
          __typename
        }
        hotelsForPackage(packageHotelSearchCriteria: $packageHotelSearchCriteria, filters: $filters) {
          result {
            list(sort: $sort, offset: $offset, limit: $limit) {
              ...HotelFragment
              __typename
            }
            totalCount
            filters {
              ratings {
                name
                count
                __typename
              }
              priceRanges {
                from
                to
                count
                __typename
              }
              amenities {
                name
                count
                __typename
              }
              landmarks {
                name
                count
                __typename
              }
              neighborhoods {
                name
                count
                __typename
              }
              __typename
            }
            lowestHotelPrice
            minRooms
            maxRooms
            __typename
          }
          errors
          __typename
        }
        packageHotelSearchCriteria {
          locationCode
          checkIn
          checkOut
          roomsCount
          __typename
        }
      }
      
      fragment HotelFragment on Hotel {
        id
        name
        address
        description
        geoPoint {
          latitude
          longitude
          __typename
        }
        image
        hotelGallery {
          path
          alternativeText
          __typename
        }
        inOrder
        featured
        sunseekerPromotion
        rating
        promos {
          id
          code
          headlineDescription
          shortDescription
          details
          termsAndConditions
          reservationFrom
          reservationTo
          occupancyFrom
          occupancyTo
          blackoutDates {
            from
            to
            __typename
          }
          __typename
        }
        prices {
          lowestRoom
          dailyAverageRate
          strikeThroughRate
          packageTotal {
            amount
            currency
            __typename
          }
          __typename
        }
        __typename
      }`
      
        let roomsCount, checkOutDate;
        if (roomsSelected) {
            roomsCount = roomsSelected
        } else {
            roomsCount = Math.round(adultsCount / 2);
        }
        let variables
        if (tripType === "ONEWAY") {
            let splitYear = parseInt(departDate.split('-')[0])
            let splitMonth = departDate.split('-')[1]
            let splitDate = parseInt(departDate.split('-')[2])
            splitDate = splitDate + 3
            if(splitDate < 10){
                splitDate = '0'+splitDate
            }
            checkOutDate = (splitYear + '-' + splitMonth + '-' + splitDate)

            variables = `{
              "sort": "FEATURED_DESC",
              "offset": 0,
              "limit": 10,
              "filters": {},
              "packageHotelSearchCriteria": {
                "locationCode": "${destination}",
                "checkIn": "${departDate}",
                "checkOut": "${checkOutDate}",
                "roomsCount": "${roomsCount}"
              },
              "origin": "${origin}",
              "destination": "${destination}",
              "departureDate": "${departDate}"
            }`
        }
        else {
            checkOutDate = returnDate;

            variables = `{
              "sort": "FEATURED_DESC",
              "offset": 0,
              "limit": 10,
              "filters": {},
              "packageHotelSearchCriteria": {
                "locationCode": "${destination}",
                "checkIn": "${departDate}",
                "checkOut": "${checkOutDate}",
                "roomsCount": "${roomsCount}"
              },
              "origin": "${origin}",
              "destination": "${destination}",
              "departureDate": "${departDate}",
              "returningDate": "${returnDate}"
            }`
        }

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            let hotelId;
            let suitableHotel;

            try {
                if (responseJson.data.hotelsForPackage.result === null) {
                    console.log("Hotels are unavailable")
                    return "";
                } else {
                    if (responseJson.data.hotelsForPackage.result.list.length === 0) {
                        console.log("Hotels are unavailable")
                        return "";
                    } else if (roomTypeSelected) {
                        let hotelsAvailable = (responseJson.data.hotelsForPackage.result.list).length
                        for (let m = 0; m < hotelsAvailable; m++) {
                            let hotelRooms = responseJson.data.hotelsForPackage.result.list[m].hotelGallery
                            let hotelRoomsLength = hotelRooms.length
                            let n = 0;
                            while (n < hotelRoomsLength) {
                                let h = hotelRooms[n].alternativeText
                                if (h.includes(roomTypeSelected)) {
                                    suitableHotel = responseJson.data.hotelsForPackage.result.list[m].id
                                    break;

                                } else {
                                    n++;
                                }

                            }
                        }
                        if (suitableHotel) {
                            hotelId = suitableHotel;
                        } else {
                            console.log("The type of room you selected is unavailable...")
                            hotelId = responseJson.data.hotelsForPackage.result.list[0].id;
                        }

                    } else {
                        hotelId = responseJson.data.hotelsForPackage.result.list[0].id;
                    }
                }
                return {
                    hotelId,
                    roomsCount,
                    checkOutDate,
                }
            } catch (err) {
                console.error("Hotels are unavailable");
                return "";
            }

        })
    }

    /**
* This method performs GQL call for hotelBooking
* @param {string} hotelId Ex : "1"
* @param {string} destination Ex : "MEX"
* @param {string} departDate Ex: "2022-06-12"
* @param {string} roomsCount Ex: "2"
* @param {string} checkOutDate Ex: "2023-09-19"
* @returns {string} roomId
*/
    async hotelBooking(hotelId, destination, departDate, roomsCount, checkOutDate) {
        let query = `query hotelDetails($packageHotelSearchCriteria: PackageHotelSearchInput, $hotelId: String!) {
        hotelsForPackage(packageHotelSearchCriteria: $packageHotelSearchCriteria) {
          result {
            hotel(hotelId: $hotelId) {
              id
              name
              rating
              address
              inOrder
              amenities {
                name
                image
                __typename
              }
              geoPoint {
                latitude
                longitude
                __typename
              }
              hotelGallery {
                path
                alternativeText
                __typename
              }
              description
              showsDescription
              amenitiesDescription
              diningDescription
              accommodations
              policy {
                description
                checkIn
                checkOut
                checkInMinimumAge
                resortFeeApplicable
                resortFeeInclusions
                parkFeeApplicable
                parkFeeInclusions
                __typename
              }
              rooms {
                id
                name
                image
                inOrder
                amenities {
                  name
                  icon
                  __typename
                }
                gallery {
                  alternativeText
                  path
                  __typename
                }
                options {
                  name
                  __typename
                }
                description
                promos {
                  id
                  code
                  headlineDescription
                  shortDescription
                  details
                  termsAndConditions
                  reservationFrom
                  reservationTo
                  occupancyFrom
                  occupancyTo
                  blackoutDates {
                    from
                    to
                    __typename
                  }
                  __typename
                }
                prices {
                  lowestRoom
                  dailyAverageRate
                  strikeThroughRate
                  __typename
                }
                priceBreakdown {
                  packageTotal {
                    amount
                    __typename
                  }
                  packageTotalWithTaxes {
                    amount
                    __typename
                  }
                  total
                  __typename
                }
                __typename
              }
              __typename
            }
            __typename
          }
          errors
          __typename
        }
        packageHotelSearchCriteria {
          checkIn
          checkOut
          roomsCount
          __typename
        }
        order {
          items {
            __typename
            ... on FlightOrderItem {
              id
              flight {
                id
                departingTime
                arrivalTime
                origin {
                  code
                  __typename
                }
                destination {
                  code
                  __typename
                }
                __typename
              }
              flightPrice: price {
                total
                subtotal
                taxesAndFees
                taxes {
                  total {
                    amount
                    currency
                    __typename
                  }
                  breakdown {
                    name
                    code
                    value {
                      amount
                      currency
                      __typename
                    }
                    __typename
                  }
                  __typename
                }
                fees {
                  total {
                    amount
                    currency
                    __typename
                  }
                  breakdown {
                    name
                    code
                    value {
                      amount
                      currency
                      __typename
                    }
                    __typename
                  }
                  __typename
                }
                discountValue {
                  amount
                  currency
                  __typename
                }
                discountType
                total
                __typename
              }
              __typename
            }
            ... on HotelOrderItem {
              id
              __typename
            }
            ... on VehicleOrderItem {
              id
              price {
                total {
                  amount
                  __typename
                }
                __typename
              }
              __typename
            }
          }
          travelers {
            id
            firstName
            lastName
            __typename
          }
          __typename
        }
        application(name: DESKTOPBOOKINGPATH) {
          ... on DesktopBookingPath {
            configurations {
              googleMapsApiKey
              displaySkipLinkHotelDetailsPage
              __typename
            }
            __typename
          }
          __typename
        }
        settings {
          uplift {
            pages {
              pageName
              pageValue
              __typename
            }
            __typename
          }
          __typename
        }
      }`

        let variables = `{
        "hotelId": "${hotelId}",
        "packageHotelSearchCriteria": {
          "checkIn": "${departDate}",
          "checkOut": "${checkOutDate}",
          "locationCode": "${destination}",
          "roomsCount": "${roomsCount}"
      }
    }`

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                responseJson.data.hotelsForPackage.result.hotel.rooms[0].id;
            }
            catch (err) {
                console.error("room id was not available");
            }
            return responseJson.data.hotelsForPackage?.result.hotel.rooms[0].id;
        })
    }

    /**
* This method performs GQL call for roomSelection
* @param {*} roomId Ex:"4712"
*/
    async roomSelection(roomId) {
        let query = `mutation selectRoomPackage($roomId: ID!) {
        selectRoomPackage(roomId: $roomId) {
          order {
            items {
              id
              __typename
            }
            price {
              total
              balanceDue
              taxes {
                amount
                __typename
              }
              fees {
                amount
                __typename
              }
              __typename
            }
            __typename
          }
          errors
          __typename
        }
      }`

        let variables = `{
        "roomId": "${roomId}"
      }`
        await this.GqlCall.graphQlCall(this._transactionId, query, variables).catch(function () {
            console.error("room is not selected");
        })
    }
}