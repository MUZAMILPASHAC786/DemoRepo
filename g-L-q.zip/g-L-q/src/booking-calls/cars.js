module.exports = class Cars {

    /**
* This is constructer for Cars Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }
    /**
* This method performs GQL call for vehicleList
* @param {string} origin Ex : "MEX"
* @param {string} destination Ex : "LAS"
* @param {string} departDate Ex : "2022-04-12"
* @param {string} returnDate Ex: "2022-04-12"
* @param {string} fromTimeForVehicleSearch Ex: ""
* @param {string} toTimeForVehicleSearch Ex: ""
* @returns {string} vendorId
*/
    async vehicleList(origin, destination, departDate, returnDate, fromTimeForVehicleSearch, toTimeForVehicleSearch) {
    // eslint-disable-next-line max-len
        let query = `query vehicles($vehicleSearchCriteria: VehicleSearchInput!, $sort: VehicleShopSort, $offset: Int, $limit: Int, $filters: VehicleFiltersInput, $origin: IataCode, $destination: IataCode, $departureDate: DateTime, $returnDate: DateTime) {
          application(name: DESKTOPBOOKINGPATH) {
            ... on DesktopBookingPath {
              destinationAdverts(filters: {section: BOOKING_VEHICLES, position: TOP, origin: $origin, destination: $destination, departureDate: $departureDate, returningDate: $returnDate}) {
                content
                position
                __typename
              }
              __typename
            }
            __typename
          }
          vehicles(vehicleSearchCriteria: $vehicleSearchCriteria, filters: $filters) {
            result {
              list(sort: $sort, offset: $offset, limit: $limit) {
                ...VehicleFragment
                __typename
              }
              totalCount
              vendorsMap {
                id
                name
                logo
                __typename
              }
              filtersMap {
                category {
                  name
                  count
                  __typename
                }
                seats {
                  name
                  count
                  __typename
                }
                bags {
                  name
                  count
                  __typename
                }
                __typename
              }
              __typename
            }
            errors
            __typename
          }
        }
        
        fragment VehicleFragment on VehicleShopItem {
          id
          vehicle {
            category
            type
            description
            transmission
            hasAirConditioned
            image
            code
            seats
            bags
            promos {
              id
              code
              headlineDescription
              shortDescription
              details
              termsAndConditions
              reservationFrom
              reservationTo
              occupancyFrom
              occupancyTo
              blackoutDates {
                from
                to
                __typename
              }
              __typename
            }
            __typename
          }
          vendorOffer {
            id
            vendor {
              id
              name
              logo
              __typename
            }
            priceBreakdown {
              price {
                amount
                currency
                __typename
              }
              taxesAndFees {
                amount
                currency
                __typename
              }
              __typename
            }
            __typename
          }
          __typename
        }`

        let variables = `{
          "offset": 0,
          "limit": 10,
          "vehicleSearchCriteria": {
            "locationCode": "${destination}",
            "from": "${fromTimeForVehicleSearch}",
            "to": "${toTimeForVehicleSearch}"
          },
          "origin": "${origin}",
          "destination": "${destination}",
          "departureDate": "${departDate}",
          "returnDate": "${returnDate}",
          "filters": {
            "category": [],
            "seatsCount": [],
            "bagsCount": []
          }
        }`

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                if (responseJson.data.vehicles !== undefined) {
                    if (responseJson.data.vehicles.result === null) {
                        console.log("Vehicles are not available")
                        return "";
                    } else {
                        if (responseJson.data.vehicles.result.list.length === 0) {
                            console.log("Vehicles are not available")
                            return "";
                        } else {
                            let randomVehiclesListIndex = Math.floor(Math.random() * responseJson.data.vehicles.result.list.length)
                            let randomVendorOfferIndex = Math.floor(Math.random() * responseJson.data.vehicles.result.list[randomVehiclesListIndex].vendorOffer.length)
                            return responseJson.data.vehicles.result.list[randomVehiclesListIndex].vendorOffer[randomVendorOfferIndex].id;
                        }
                    }
                }
            }
            catch (err) {
                console.error("vehicles are unavailable")
            }

        })
    }

    /**
* This method performs GQL call for vehicleList
* @param {string} vendorId Ex : "CCAR_1"
*/
    async vehicleSelection(vendorId) {
        let query = `mutation selectVehicle($vendorId: ID!) {
          selectVehicle(vehicleVendorOfferId: $vendorId) {
            order {
              status
              price {
                total
                __typename
              }
              items {
                id
                ... on VehicleOrderItem {
                  vehiclePrice: price {
                    total {
                      amount
                      currency
                      __typename
                    }
                    __typename
                  }
                  vehicle {
                    category
                    type
                    description
                    __typename
                  }
                  vendor {
                    logo
                    name
                    __typename
                  }
                  pickUpDate
                  dropOffDate
                  promotions {
                    id
                    code
                    headlineDescription
                    __typename
                  }
                  __typename
                }
                __typename
              }
              __typename
            }
            errors
            __typename
          }
        }`

        let variables = `{
          "vendorId": "${vendorId}"
        }`

        await this.GqlCall.graphQlCall(this._transactionId, query, variables).catch(function () {
            console.error("vehicle is not selected");
        })
    }
}