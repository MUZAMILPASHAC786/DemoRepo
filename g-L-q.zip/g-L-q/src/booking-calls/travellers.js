const {
    faker,
} = require('@faker-js/faker');

module.exports = class Travellers {

    /**
   * This is constructer for Bags Call
   * @param {*} GqlCall is object of GQL booking class
   * @param {*} transactionId is the transactionIf of the flow
   */
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }
    /**
   * This method performs GQL call for travellerDetails
   * @param {*} adultsCount Ex:3
   * @param {*} travellerId Ex:1
   * @param {string} ktn known Traveller
   * @param {string} redress Redress#
   * @param {string} isInternational isInternational
   * @param {*} lapInfantCount Ex:1
   * @param {string} departureFlightId contains departureFlightId
   * @param {string} returningFlightId contains returningFlightId
   * @param {string} tripType Roundtrip 
   * @param {string} adultWithSSR SSR selection
   * @param {*} childrenCount Ex:1
   * @param {*} yptaCount Ex:1
   * @returns {*} travellerDetails,departid,returnid,petInCabinSSR
   */
    async travellerDetails(adultsCount, travellerId, ktn, redress, isInternational, lapInfantCount, departureFlightId, returningFlightId, tripType, adultWithSSR, childrenCount, yptaCount) {
        let query = `mutation continueButtonMutation($travelers: [TravelerInput!]!) {
  updateOrderTravelers(travelers: $travelers) {
    order {
      travelers {
        ...travelerFragment
        __typename
      }
      items {
        ... on FlightOrderItem {
          id
          __typename
        }
        __typename
      }
      __typename
    }
    errors
    __typename
  }
}

fragment travelerFragment on Traveler {
  id
  type
  firstName
  middleName
  lastName
  suffix
  gender
  dateOfBirth
  knownTravelerNumber
  documents {
    documentType
    documentNumber
    countryCode
    expirationDate
    __typename
  }
  emergencyContact {
    firstName
    lastName
    phone {
      number
      type
      countryPrefix
      __typename
    }
    __typename
  }
  nationality
  countryOfResidence
  redressNumber
  email
  isPrimary
  phone {
    number
    type
    countryPrefix
    country {
      name
      code
      phonePrefixCode
      states {
        name
        code
        __typename
      }
      __typename
    }
    __typename
  }
  ssrs {
    code
    flightId
    title
    description
    additionalInfo
    infantOnLap {
      firstName
      middleName
      lastName
      dateOfBirth
      suffix
      gender
      nationality
      countryOfResidence
      documents {
        documentNumber
        documentType
        countryCode
        expirationDate
        __typename
      }
      __typename
    }
    display
    __typename
  }
  __typename
}`
        let infantDetails, SSRCount, SSRD, infantDetailsInternational, SSRSpecific, SSRSpecificCount
        let petInCabinSSR = []
        let PassportNo = ""
        let lastNameTraveler, phoneNo
        let travellersObj = {}
        let travellers = []
        let travellerDetails
        let ktnNo;
        if (ktn === "yes") {
            ktnNo = Math.random().toString(36).slice(2);
        } else {
            ktnNo = ""
        }
        let redressNo;
        if (redress === "yes") {
            redressNo = Math.random().toString(36).slice(2);
        } else {
            redressNo = ""
        }
        if (isInternational.includes("yes")) {
            travellerDetails = `{
        "id": "1",
        "firstName": "Marianne",
        "middleName": "",
        "lastName": "lastname",
        "suffix": "JR",
        "gender": "FEMALE",
        "dateOfBirth": "1993-04-02T00:00:00Z",
        "knownTravelerNumber": "${ktnNo}",
        "redressNumber": "${redressNo}",
        "nationality": "US",
        "countryOfResidence": "US",
        "phone": {
          "number": "NOT_PROVIDED",
          "type": "NOT_SELECTED",
          "prefixCode": "1",
          "countryCode": "US"
        },
        "documents": [
        ],
        "emergencyContact": {
          "firstName": "Marianne",
          "lastName": "lastname",
          "phone": {
            "number": "99469138729000",
            "type": "NOT_SELECTED",
            "prefixCode": "1"
          }
        },
        "isPrimary": true,
        "ssrs": [],
        "email": null
  }`
            if (lapInfantCount > 0) {
                infantDetailsInternational = ` {
              "code": "INFT",
              "flightId": "2023-01-21-G4-7112",
              "travelerId": "1",
              "additionalInfo": "0_INFANT-IN-LAP-DOB_1-1-2023",
              "infantOnLap": {
                "id": "1",
                "assignToTraveler": "1",
                "firstName": "Cillu",
                "middleName": "",
                "lastName": "Kretess",
                "suffix": "NOT_SELECTED",
                "gender": "FEMALE",
                "dateOfBirth": "1993-04-02T00:00:00Z",
                "nationality": "MX",
                "countryOfResidence": "MX",
                "documents": null
              }
            }`

            }
        } else {
            travellerDetails = `{
    "id": "1",
    "firstName": "James",
    "middleName": "",
    "lastName": "lastname",
    "suffix": "JR",
    "gender": "FEMALE",
    "dateOfBirth": "1998-04-02T00:00:00Z",
    "knownTravelerNumber": "${ktnNo}",
    "redressNumber": "${redressNo}",
    "phone": {
      "number": "9946912567",
      "type": "NOT_SELECTED",
      "prefixCode": "1",
      "countryCode": "US" 
    },
    "documents": null,
    "emergencyContact": null,
    "isPrimary": true,
    "ssrs": [],
    "email": ""
  }`



        }
        infantDetails = `{
  "code": "INFT",
  "flightId": "flightID",
  "travelerId": "1",
  "additionalInfo": "null"
}`
        let countAdults, countYPTA, countChildren
        countAdults = adultsCount
        countYPTA = yptaCount
        countChildren = childrenCount
        if ((countYPTA !== undefined) || (countYPTA > 0)) {
            if (countAdults > countYPTA) {
                countAdults = countAdults - countYPTA
            } else {
                countAdults = countYPTA - countAdults
            }
        }

        travellerId.forEach((id) => {
            let newTravellersDetails = JSON.parse(travellerDetails);
            newTravellersDetails.id = id;

            if (typeof ktn === "object" && countAdults >= ktn.length && id <= ktn.length) {
                newTravellersDetails.firstName = ktn[id - 1].firstName;
                newTravellersDetails.lastName = ktn[id - 1].lastName;
                newTravellersDetails.gender = ktn[id - 1].gender;
                newTravellersDetails.dateOfBirth = ktn[id - 1].dob + "T00:00:00.000Z";
                newTravellersDetails.knownTravelerNumber = ktn[id - 1].validKtnNum;
            } else {
                lastNameTraveler = faker.name.lastName();
                newTravellersDetails.lastName = lastNameTraveler

                if (id <= countAdults) {
                    newTravellersDetails.dateOfBirth = faker.date.birthdate({
                        max: 90,
                        min: 18,
                        mode: "age",
                    });
                } else {
                    if (countYPTA >= 1) {
                        newTravellersDetails.dateOfBirth = faker.date.birthdate({
                            max: 17,
                            min: 15,
                            mode: "age",
                        });
                        countYPTA--
                    } else if (countChildren >= 1) {
                        newTravellersDetails.dateOfBirth = faker.date.birthdate({
                            max: 14,
                            min: 1,
                            mode: "age",
                        });
                        countChildren--
                    }
                }

                if (id % 2 === 1) {
                    newTravellersDetails.gender = "MALE"
                }
            }


            if (id < 2) {
                newTravellersDetails.isPrimary = true;
                newTravellersDetails.email = faker.internet.email();
            } else {
                newTravellersDetails.isPrimary = false;
            }
            if (isInternational.includes("yes")) {
                if (id <= lapInfantCount) {
                    let newInfantDetails = JSON.parse(infantDetailsInternational);
                    newInfantDetails.travelerId = id;
                    newInfantDetails.flightId = departureFlightId;
                    newInfantDetails.infantOnLap.id = id;
                    newInfantDetails.infantOnLap.assignToTraveler = id;
                    if (id % 2 === 1) {
                        newInfantDetails.infantOnLap.gender = "MALE"
                    }
                    newTravellersDetails.ssrs.push(newInfantDetails)
                    petInCabinSSR.push(newInfantDetails)
                    if (tripType === "ROUNDTRIP") {
                        let newInfantDetailsReturn = JSON.parse(infantDetailsInternational);
                        newInfantDetailsReturn.travelerId = id;
                        newInfantDetailsReturn.flightId = returningFlightId;
                        newInfantDetailsReturn.infantOnLap.id = id;
                        newInfantDetailsReturn.infantOnLap.assignToTraveler = id;
                        if (id % 2 === 1) {
                            newInfantDetails.infantOnLap.gender = "MALE"
                        }
                        newTravellersDetails.ssrs.push(newInfantDetailsReturn)
                        petInCabinSSR.push(newInfantDetailsReturn)
                    }
                }
            }
            if (isInternational.includes("yes")) {
                let Residence
                phoneNo = Math.floor(Math.random() * 1000000000000);
                newTravellersDetails.emergencyContact.phone.number = phoneNo
                lastNameTraveler = faker.name.lastName();
                newTravellersDetails.emergencyContact.lastName = lastNameTraveler
                if (isInternational.includes(":")) {
                    Residence = isInternational.split(":")
                    if (Residence.length > 1) {
                        newTravellersDetails.nationality = Residence[1]
                    }
                    if (Residence.length > 2) {
                        newTravellersDetails.countryOfResidence = Residence[2]
                    }
                }
                PassportNo = 'KP' + Math.floor(Math.random() * 1000000);

                let passportDetails = `{
"documentType": "P",
"documentNumber": "${PassportNo}",
"countryCode": "US",
"expirationDate": "2030-12-31T00:00:00Z"
}`

                let newpassportDetails = JSON.parse(passportDetails);
                newTravellersDetails.documents.push(newpassportDetails)

            } else {
                if (lapInfantCount > 0) {
                    if (id <= lapInfantCount) {
                        let newInfantDetails = JSON.parse(infantDetails);
                        newInfantDetails.travelerId = id;
                        newInfantDetails.flightId = departureFlightId;
                        newInfantDetails.additionalInfo = "0_INFANT-IN-LAP-DOB_" + faker.date.birthdate({
                            max: 1.5,
                            min: 1,
                            mode: "age",
                        });
                        newTravellersDetails.ssrs.push(newInfantDetails)
                        petInCabinSSR.push(newInfantDetails)
                        if (tripType === "ROUNDTRIP") {
                            let newInfantDetailsReturn = JSON.parse(infantDetails);
                            newInfantDetailsReturn.travelerId = id;
                            newInfantDetailsReturn.flightId = returningFlightId;
                            newInfantDetailsReturn.additionalInfo = "0_INFANT-IN-LAP-DOB_" + faker.date.birthdate({
                                max: 1.5,
                                min: 1,
                                mode: "age",
                            });
                            newTravellersDetails.ssrs.push(newInfantDetailsReturn)
                            petInCabinSSR.push(newInfantDetailsReturn)
                        }
                    }
                }
            }
            travellers.push(newTravellersDetails)
        })
        /**
   * This method Selects SSR type based on User input
   * @param {*} SSRDetails Ex:DEAF
   * @returns {*} SSR,SSRR
   */
        async function selectSSR(SSRDetails) {
            let SSR = {}
            let SSRR = {}
            if (SSRDetails === "WCHRA") {
                SSR.code = "WCHR"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCHR"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "WCHRB") {
                SSR.code = "WCHS"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCHS"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "WCHRC") {
                SSR.code = "WCHC"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCHC"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "WCHRSA") {
                SSR.code = "WCMP"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCMP"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "WCHRSB") {
                SSR.code = "WCLB"
                SSR.flightId = departureFlightId
                // newTravellersDetails.ssrs.push(SSR)
                petInCabinSSR.push(SSR)
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCLB"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "WCHRSC") {
                SSR.code = "WCBD"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCBD"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "WCHRSD") {
                SSR.code = "WCBW"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "WCBW"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "PPOC") {
                SSR.code = "PPOC"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "PPOC"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "SVAN") {
                SSR.code = "SVAN"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "SVAN"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "DEAF") {
                SSR.code = "DEAF"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "DEAF"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "BLND") {
                SSR.code = "BLND"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "BLND"
                    SSRR.flightId = returningFlightId
                }
            }
            if (SSRDetails === "DPNA") {
                SSR.code = "DPNA"
                SSR.flightId = departureFlightId
                if (tripType === "ROUNDTRIP") {
                    SSRR.code = "DPNA"
                    SSRR.flightId = returningFlightId
                }
            }
            return { SSR, SSRR }
        }
        if (adultWithSSR !== undefined) {
            if (adultWithSSR.length > 1) {
                for (let count = 1; count <= adultWithSSR.length - 1; count++) {
                    if ((adultWithSSR[count]).includes("-")) {
                        SSRD = adultWithSSR[count].split("-")
                        SSRCount = parseInt(SSRD[1])
                        for (let countEach = 1; countEach <= SSRCount; countEach++) {
                            let { SSR, SSRR } = await selectSSR(SSRD[0])
                            if (countEach <= travellerId.length) {
                                if (countEach = travellers[countEach - 1].id) {
                                    SSR.travelerId = countEach.toString(36);
                                    travellers[countEach - 1].ssrs.push(SSR)
                                    petInCabinSSR.push(SSR)
                                    if (tripType === "ROUNDTRIP") {
                                        SSRR.travelerId = countEach.toString(36);
                                        travellers[countEach - 1].ssrs.push(SSRR)
                                        petInCabinSSR.push(SSRR)
                                    }

                                }
                            }
                        }
                    }
                    if ((adultWithSSR[count]).includes("|")) {
                        //2:WCHRA|1:WCHRSA|2
                        //"9:WCHRA|2&4"
                        //"6:WCHRA|1&4:DEAF|2&5"
                        SSRSpecific = adultWithSSR[count].split("|")
                        if (SSRSpecific[1].includes("&")) {
                            SSRSpecificCount = SSRSpecific[1].split("&")
                        } else {
                            SSRSpecificCount = []
                            SSRSpecificCount.push(SSRSpecific[1])
                        }
                        for (let i of SSRSpecificCount) {
                            let { SSR, SSRR } = await selectSSR(SSRSpecific[0])
                            SSR.travelerId = i.toString(36);
                            travellers[i - 1].ssrs.push(SSR)
                            petInCabinSSR.push(SSR)
                            if (tripType === "ROUNDTRIP") {
                                SSRR.travelerId = i.toString(36);
                                travellers[i - 1].ssrs.push(SSRR)
                                petInCabinSSR.push(SSRR)
                            }
                        }

                    }
                }
            }
        }
        travellersObj.travelers = travellers
        let variables = JSON.stringify(travellersObj);
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                var travellerDetails = responseJson.data.updateOrderTravelers.order.travelers;
            } catch (err) {
                throw new Error("Traveler Details are Not available")
            }
            let firstName = responseJson.data.updateOrderTravelers.order.travelers[0].firstName
            let lastName = responseJson.data.updateOrderTravelers.order.travelers[0].lastName
            // let departid = responseJson.data.updateOrderTravelers.order.items[0];
            // let returnid = []
            // if (tripType === "ROUNDTRIP") {
            //     returnid = responseJson.data.updateOrderTravelers.order.items[1];
            // }

            return {
                travellerDetails,
                firstName,
                lastName,
                petInCabinSSR,
            }

        })
    }
}