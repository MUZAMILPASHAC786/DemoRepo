module.exports = class TripSummary {

    /**
* This is constructer for Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }
    /**
* This method performs GQL call for hotelList
* @param {*} tripSummaryDetails -contains tripsummary
* @param {string} departureFlightId Ex : "7113"
* @param {string} returningFlightId Ex: "7112" 
* @param {string} tripType Ex: "ROUNDTRIP"
* @param {string} bundleType Ex: "total"
*/
    async tripSummary(tripSummaryDetails, departureFlightId, returningFlightId, tripType) {
        let query = `query cart {
  order {
    hasPendingCSAdjustments
    orderNumber
    items {
      id
      __typename
      ...BundleOrderItemFragment
      ...FlightOrderItemFragment
      ...HotelOrderItemFragment
      ...SeatOrderItemFragment
      ...TravelerAncillaryOrderItemFragment
      ...VehicleOrderItemFragment
      ...ItineraryAncillaryOrderItemFragment
      ...ShowOrderItemFragment
    }
    ...TravelersFragment
    price {
      total
      balanceDue
      totalDueToday
      totalDueAtHotelCheckout
      taxes {
        amount
        __typename
      }
      fees {
        amount
        __typename
      }
      __typename
    }
    payments {
      ... on PromoPayment {
        id
        description
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      __typename
    }
    isInternational
    __typename
  }
}

fragment BundleOrderItemFragment on OrderItem {
  ... on BundleOrderItem {
    id
    bundle {
      id
      tier
      name
      banner
      ancillaries {
        name
        type
        price {
          amount
          __typename
        }
        __typename
      }
      __typename
    }
    price {
      amount
      currency
      __typename
    }
    __typename
  }
  __typename
}

fragment FlightOrderItemFragment on OrderItem {
  ... on FlightOrderItem {
    id
    flight {
      id
      number
      providerId
      origin {
        code
        displayName
        city
        state
        country
        title
        street
        postalCode
        __typename
      }
      destination {
        code
        displayName
        city
        state
        country
        title
        street
        postalCode
        __typename
      }
      departingTime
      arrivalTime
      isOvernight
      operatedBy {
        carrier
        __typename
      }
      __typename
    }
    flightPrice: price {
      total
      subtotal
      taxesAndFees
      taxes {
        total {
          amount
          currency
          __typename
        }
        breakdown {
          name
          code
          value {
            amount
            currency
            __typename
          }
          __typename
        }
        __typename
      }
      fees {
        total {
          amount
          currency
          __typename
        }
        breakdown {
          name
          code
          value {
            amount
            currency
            __typename
          }
          __typename
        }
        __typename
      }
      discountValue {
        amount
        currency
        __typename
      }
      discountType
      total
      __typename
    }
    __typename
  }
  __typename
}

fragment HotelOrderItemFragment on OrderItem {
  ... on HotelOrderItem {
    id
    hotelPrice: price {
      total
      __typename
    }
    actualPrice {
      total
      __typename
    }
    paymentDueAt
    roomType
    roomsCount
    roomId
    hotelId
    hotel {
      name
      promos {
        id
        code
        headlineDescription
        __typename
      }
      __typename
    }
    checkin {
      time
      __typename
    }
    checkout {
      time
      __typename
    }
    roomsCount
    adultCount
    childrenCount
    __typename
  }
  __typename
}

fragment SeatOrderItemFragment on OrderItem {
  ... on SeatOrderItem {
    id
    flightId
    travelerId
    column
    row
    price {
      amount
      currency
      __typename
    }
    seatPrice {
      subtotal
      taxes {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      taxesIncludedInBundle {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      total
      isUpgradePrice
      __typename
    }
    bundledAncillaryPrice {
      amount
      __typename
    }
    isBundledAncillaryIncluded
    seatSizeId
    __typename
  }
  __typename
}

fragment TravelerAncillaryOrderItemFragment on OrderItem {
  ... on TravelerAncillaryOrderItem {
    id
    flightId
    travelerId
    ancillaryType
    quantity
    price {
      amount
      currency
      __typename
    }
    bundledAncillaryPrice {
      amount
      __typename
    }
    isBundledAncillaryIncluded
    __typename
  }
  __typename
}

fragment VehicleOrderItemFragment on OrderItem {
  ... on VehicleOrderItem {
    id
    vehiclePrice: price {
      total {
        amount
        currency
        __typename
      }
      __typename
    }
    vehicle {
      category
      code
      type
      description
      __typename
    }
    vendor {
      name
      __typename
    }
    promotions {
      id
      code
      headlineDescription
      __typename
    }
    pickUpDate
    dropOffDate
    __typename
  }
  __typename
}

fragment ItineraryAncillaryOrderItemFragment on OrderItem {
  ... on ItineraryAncillaryOrderItem {
    id
    ancillaryType
    quantity
    price {
      amount
      currency
      __typename
    }
    bundledAncillaryPrice {
      amount
      __typename
    }
    isBundledAncillaryIncluded
    __typename
  }
  __typename
}

fragment ShowOrderItemFragment on OrderItem {
  ... on ShowOrderItem {
    id
    type
    show {
      date
      location
      categoryCode
      categoryName
      meta
      productName
      productDescription
      __typename
    }
    quantity
    price {
      total {
        amount
        currency
        __typename
      }
      subtotal {
        amount
        currency
        __typename
      }
      taxesAndFees {
        amount
        currency
        __typename
      }
      __typename
    }
    __typename
  }
  __typename
}

fragment TravelersFragment on Order {
  travelers {
    id
    firstName
    lastName
    middleName
    suffix
    isPrimary
    type
    ssrs {
      code
      flightId
      title
      price {
        amount
        currency
        __typename
      }
      additionalInfo
      __typename
    }
    __typename
  }
  __typename
}`

        let variables = ``
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                responseJson.data.order.price.total
                let itemsLength = responseJson.data.order.items.length
                let departureFlightPriceDetails = {}
                let returnFlightPriceDetails = {}
                let bundledAncillaryPriceDetails = {}
                let DepartCheckInBagPrice = []
                let ReturnCheckInBagPrice = []
                let DepartCarryonBagPrice = []
                let ReturnCarryonBagPrice = []
                let DepartPriorityAccessPrice = []
                let ReturnPriorityAccessPrice = []
                let DepartTripFlexPrice = []
                let ReturnTripFlexPrice = []
                let DepartSeatPriceDetails = []
                let ReturnSeatPriceDetails = []
                let hotelOrderItem = {}
                let vehicleOrderItem = {}
                let ReturnPetInCabinPrice = []
                let DepartPetInCabinPrice = []
                let tripFlex = 0
                tripSummaryDetails.Total = responseJson.data.order.price.total
                tripSummaryDetails.totalDueToday=responseJson.data.order.price.totalDueToday
                tripSummaryDetails.totalDueAtHotelCheckout=responseJson.data.order.price.totalDueAtHotelCheckout
                tripSummaryDetails.taxes = responseJson.data.order.price.taxes.amount
                tripSummaryDetails.fees = responseJson.data.order.price.fees.amount
                let i = 0;
                while (i < itemsLength) {
                    if (responseJson.data.order.items[i].__typename === "FlightOrderItem") {
                        if (i === 0) {
                            departureFlightPriceDetails.departureFlightPrice = responseJson.data.order.items[i].flightPrice.total
                            departureFlightPriceDetails.departureFlightTaxesAndFees = responseJson.data.order.items[i].flightPrice.taxesAndFees
                            if (responseJson.data.order.items[i].flightPrice.taxes.breakdown !== null || responseJson.data.order.items[i].flightPrice.taxes.breakdown !== undefined) {
                                departureFlightPriceDetails.USAfederalExciseTax = responseJson.data.order.items[i].flightPrice.taxes.breakdown[0].value.amount
                                departureFlightPriceDetails.USAsecurityFee = responseJson.data.order.items[i].flightPrice.fees.breakdown[0].value.amount
                                departureFlightPriceDetails.USAsegmentTax = responseJson.data.order.items[i].flightPrice.fees.breakdown[1].value.amount
                                departureFlightPriceDetails.carrierUsageAmount = responseJson.data.order.items[i].flightPrice.fees.breakdown[2].value.amount
                                departureFlightPriceDetails.USApassengerFacilityCharge = responseJson.data.order.items[i].flightPrice.fees.breakdown[3].value.amount
                                departureFlightPriceDetails.discount = responseJson.data.order.items[i].flightPrice.discountValue.amount
                            }
                        }
                        if (tripType === "ROUNDTRIP") {
                            if (i === 1 || responseJson.data.order.items[0].flight.number === returningFlightId) {
                                returnFlightPriceDetails.returnFlightPrice = responseJson.data.order.items[i].flightPrice.total
                                returnFlightPriceDetails.returnFlightTaxesAndFees = responseJson.data.order.items[i].flightPrice.taxesAndFees
                                if (responseJson.data.order.items[i].flightPrice.taxes.breakdown !== null || responseJson.data.order.items[i].flightPrice.taxes.breakdown !== undefined) {
                                    returnFlightPriceDetails.USAfederalExciseTax = responseJson.data.order.items[i].flightPrice.taxes.breakdown[0].value.amount
                                    returnFlightPriceDetails.Fees = responseJson.data.order.items[i].flightPrice.fees.total.amount
                                    returnFlightPriceDetails.USAsecurityFee = responseJson.data.order.items[i].flightPrice.fees.breakdown[0].value.amount
                                    returnFlightPriceDetails.USAsegmentTax = responseJson.data.order.items[i].flightPrice.fees.breakdown[1].value.amount
                                    returnFlightPriceDetails.carrierUsageAmount = responseJson.data.order.items[i].flightPrice.fees.breakdown[2].value.amount
                                    returnFlightPriceDetails.USApassengerFacilityCharge = responseJson.data.order.items[i].flightPrice.fees.breakdown[3].value.amount
                                    returnFlightPriceDetails.discount = responseJson.data.order.items[i].flightPrice.discountValue.amount
                                }
                            }
                        }
                    }
                    if (responseJson.data.order.items[i].__typename === "BundleOrderItem") {
                        let bundleItemLength = responseJson.data.order.items[i].bundle.ancillaries.length
                        bundledAncillaryPriceDetails.bundlePrice = responseJson.data.order.items[i].price.amount
                        for (let j = 0; j < bundleItemLength; j++) {
                            if (responseJson.data.order.items[i].bundle.ancillaries[j].type === "SEAT") {
                                bundledAncillaryPriceDetails.seatPrice = responseJson.data.order.items[i].bundle.ancillaries[j].price.amount
                            }
                            if (responseJson.data.order.items[i].bundle.ancillaries[j].type === "CARRY_ON_BAG") {
                                bundledAncillaryPriceDetails.carryonBagPrice = responseJson.data.order.items[i].bundle.ancillaries[j].price.amount
                            }
                            if (responseJson.data.order.items[i].bundle.ancillaries[j].type === "PRIORITY_BOARDING") {
                                bundledAncillaryPriceDetails.priorityAccess = responseJson.data.order.items[i].bundle.ancillaries[j].price.amount
                            }
                            if (responseJson.data.order.items[i].bundle.ancillaries[j].type === "CHECK_IN_BAG") {
                                bundledAncillaryPriceDetails.CheckInBagPrice = responseJson.data.order.items[i].bundle.ancillaries[j].price.amount
                            }
                            if (responseJson.data.order.items[i].bundle.ancillaries[j].type === "TRIP_FLEX") {
                                bundledAncillaryPriceDetails.tripFlexPrice = responseJson.data.order.items[i].bundle.ancillaries[j].price.amount
                            }

                        }

                    }
                    if (responseJson.data.order.items[i].__typename === "TravelerAncillaryOrderItem") {
                        if (responseJson.data.order.items[i].ancillaryType === "CHECK_IN_BAG") {
                            if (responseJson.data.order.items[i].price.amount !== 0) {
                                if (responseJson.data.order.items[i].flightId === departureFlightId) {
                                    DepartCheckInBagPrice.push(responseJson.data.order.items[i].price.amount)

                                }
                                else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                                    ReturnCheckInBagPrice.push(responseJson.data.order.items[i].price.amount)

                                }
                            }
                            // if (bundleType === "bonus" || bundleType === "basic" || bundleType === "total") {
                            //   if (responseJson.data.order.items[i].bundledAncillaryPrice.amount !== null) {
                            //     if (responseJson.data.order.items[i].flightId === departureFlightId) {
                            //       DepartCheckInBagPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)

                            //     }
                            //     else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                            //       ReturnCheckInBagPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)

                            //     }

                            //   }


                            // }

                        }

                        if (responseJson.data.order.items[i].ancillaryType === "CARRY_ON_BAG") {
                            if (responseJson.data.order.items[i].price.amount !== 0) {
                                if (responseJson.data.order.items[i].flightId === departureFlightId) {
                                    DepartCarryonBagPrice.push(responseJson.data.order.items[i].price.amount)

                                }
                                else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                                    ReturnCarryonBagPrice.push(responseJson.data.order.items[i].price.amount)
                                }
                            }
                            // if (bundleType === "bonus" || bundleType === "basic" || bundleType === "total") {
                            //   if (responseJson.data.order.items[i].bundledAncillaryPrice.amount !== null) {
                            //     if (responseJson.data.order.items[i].flightId === departureFlightId) {
                            //       DepartCarryonBagPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)

                            //     }
                            //     else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                            //       ReturnCarryonBagPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)

                            //     }
                            //   }

                            // }

                        }
                        if (responseJson.data.order.items[i].ancillaryType === "PRIORITY_BOARDING") {
                            if (responseJson.data.order.items[i].price.amount !== 0) {
                                if (responseJson.data.order.items[i].flightId === departureFlightId) {
                                    DepartPriorityAccessPrice.push(responseJson.data.order.items[i].price.amount)
                                }
                                else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                                    ReturnPriorityAccessPrice.push(responseJson.data.order.items[i].price.amount)
                                }

                            }
                            // if (bundleType === "bonus" || bundleType === "basic" || bundleType === "total") {
                            //   if (responseJson.data.order.items[i].bundledAncillaryPrice.amount !== null) {
                            //     if (responseJson.data.order.items[i].flightId === departureFlightId) {
                            //       DepartPriorityAccessPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)
                            //     }
                            //     else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                            //       ReturnPriorityAccessPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)
                            //     }

                            //   }
                            // }

                        }
                        if (responseJson.data.order.items[i].ancillaryType === "TRIP_FLEX") {
                            if (responseJson.data.order.items[i].price.amount !== 0) {
                                if (responseJson.data.order.items[i].flightId === departureFlightId) {
                                    DepartTripFlexPrice.push(responseJson.data.order.items[i].price.amount)
                                }
                                else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                                    ReturnTripFlexPrice.push(responseJson.data.order.items[i].price.amount)
                                }
                            }
                            // if (bundleType === "bonus" || bundleType === "basic" || bundleType === "total") {
                            //   if (responseJson.data.order.items[i].bundledAncillaryPrice.amount !== null) {
                            //     if (responseJson.data.order.items[i].flightId === departureFlightId) {
                            //       DepartTripFlexPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)
                            //     }
                            //     else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                            //       ReturnTripFlexPrice.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)

                            //     }
                            //   }
                            // }

                        }
                    }
                    if (responseJson.data.order.items[i].__typename === "SeatOrderItem") {
                        if (responseJson.data.order.items[i].price.amount !== 0) {
                            if (responseJson.data.order.items[i].flightId === departureFlightId) {
                                DepartSeatPriceDetails.push(responseJson.data.order.items[i].price.amount)

                            }
                            else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                                ReturnSeatPriceDetails.push(responseJson.data.order.items[i].price.amount)

                            }
                        }
                        // if (bundleType === "bonus" || bundleType === "basic" || bundleType === "total") {
                        //   if (responseJson.data.order.items[i].bundledAncillaryPrice.amount !== null) {
                        //     if (responseJson.data.order.items[i].flightId === departureFlightId) {
                        //       DepartSeatPriceDetails.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)
                        //     }
                        //     else if (responseJson.data.order.items[i].flightId === returningFlightId) {
                        //       ReturnSeatPriceDetails.push(responseJson.data.order.items[i].bundledAncillaryPrice.amount)
                        //     }
                        //   }
                        // }

                    }
                    if (responseJson.data.order.items[i].__typename === "ItineraryAncillaryOrderItem") {

                        if (responseJson.data.order.items[i].price.amount !== 0) {

                            tripFlex = responseJson.data.order.items[i].price.amount

                        }
                    }

                    if (responseJson.data.order.items[i].__typename === "HotelOrderItem") {
                        hotelOrderItem.hotelPrice = Math.round(responseJson.data.order.items[i].hotelPrice.total)
                        hotelOrderItem.hotelCheckinDate = responseJson.data.order.items[i].checkin.time
                        hotelOrderItem.hotelCheckoutDate = responseJson.data.order.items[i].checkout.time
                        hotelOrderItem.hotelName = responseJson.data.order.items[i].hotel.name
                        hotelOrderItem.hotelRoomType = responseJson.data.order.items[i].roomType
                    }
                    if (responseJson.data.order.items[i].__typename === "VehicleOrderItem") {
                        vehicleOrderItem.vehiclePrice = Math.round(responseJson.data.order.items[i].vehiclePrice.total.amount)
                        vehicleOrderItem.vehiclePickUpDateTime = responseJson.data.order.items[i].pickUpDate
                        vehicleOrderItem.vehicleDropOffDateTime = responseJson.data.order.items[i].dropOffDate
                        vehicleOrderItem.vehicleVendorName = responseJson.data.order.items[i].vendor.name
                        vehicleOrderItem.vehicleCategory = responseJson.data.order.items[i].vehicle.category
                        vehicleOrderItem.vehicleType = responseJson.data.order.items[i].vehicle.type
                        vehicleOrderItem.vehicleDescription = responseJson.data.order.items[i].vehicle.description
                        i++;
                    }
                    else {
                        i++;
                    }

                }
                for (let t = 0; t < responseJson.data.order.travelers.length; t++) {
                    if (responseJson.data.order.travelers[t].ssrs.length !== 0) {
                        for (let s = 0; s < responseJson.data.order.travelers[t].ssrs.length; s++) {
                            if (responseJson.data.order.travelers[t].ssrs[s].code === "PETC") {
                                if (responseJson.data.order.travelers[t].ssrs[s].price.amount !== 0) {
                                    if (responseJson.data.order.travelers[t].ssrs[s].flightId === departureFlightId) {
                                        DepartPetInCabinPrice.push(responseJson.data.order.travelers[t].ssrs[s].price.amount)
                                    }
                                    else if (responseJson.data.order.travelers[t].ssrs[s].flightId === returningFlightId) {
                                        ReturnPetInCabinPrice.push(responseJson.data.order.travelers[t].ssrs[s].price.amount)
                                    }
                                }
                            }
                        }

                    }
                }

                if (DepartCarryonBagPrice.length !== 0) {
                    departureFlightPriceDetails.DepartCarryonBagPrice = DepartCarryonBagPrice
                }
                if (DepartCheckInBagPrice.length !== 0) {
                    departureFlightPriceDetails.DepartCheckInBagPrice = DepartCheckInBagPrice
                }
                if (DepartPriorityAccessPrice.length !== 0) {
                    departureFlightPriceDetails.DepartPriorityAccessPrice = DepartPriorityAccessPrice
                }
                if (DepartTripFlexPrice.length !== 0) {
                    departureFlightPriceDetails.DepartTripFlexPrice = DepartTripFlexPrice
                }
                if (DepartSeatPriceDetails.length !== 0) {
                    departureFlightPriceDetails.DepartSeatPriceDetails = DepartSeatPriceDetails
                }
                if (DepartPetInCabinPrice.length !== 0) {
                    departureFlightPriceDetails.DepartPetInCabinPrice = DepartPetInCabinPrice
                }
                tripSummaryDetails.DepartureFlightPriceDetails = departureFlightPriceDetails

                if (tripType === "ROUNDTRIP") {
                    if (ReturnCheckInBagPrice.length !== 0) {
                        returnFlightPriceDetails.ReturnCheckInBagPrice = ReturnCheckInBagPrice
                    }
                    if (ReturnCarryonBagPrice.length !== 0) {
                        returnFlightPriceDetails.ReturnCarryonBagPrice = ReturnCarryonBagPrice
                    }
                    if (ReturnPriorityAccessPrice.length !== 0) {
                        returnFlightPriceDetails.ReturnPriorityAccessPrice = ReturnPriorityAccessPrice
                    }
                    if (ReturnTripFlexPrice.length !== 0) {
                        returnFlightPriceDetails.ReturnTripFlexPrice = ReturnTripFlexPrice
                    }
                    if (ReturnSeatPriceDetails.length !== 0) {
                        returnFlightPriceDetails.ReturnSeatPriceDetails = ReturnSeatPriceDetails
                    }
                    if (ReturnPetInCabinPrice.length !== 0) {
                        returnFlightPriceDetails.ReturnPetInCabinPrice = ReturnPetInCabinPrice
                    }

                    tripSummaryDetails.ReturnFlightPriceDetails = returnFlightPriceDetails

                }
                if (tripFlex !== 0) {
                    tripSummaryDetails.ItineraryAncillaryTripFlex = tripFlex
                }

                if(hotelOrderItem !==undefined){
                    if(JSON.stringify(hotelOrderItem) !== "{}"){                                    
                        tripSummaryDetails.hotelDetails=hotelOrderItem
                    }
                }
                if(vehicleOrderItem !==undefined){
                    if(JSON.stringify(vehicleOrderItem) !== "{}"){   
                        tripSummaryDetails.vehicleDetails=vehicleOrderItem
                    }
                }
                return tripSummaryDetails
            }
            catch (err) {
                console.error("TripSummary is unavailable")
            }
        })

    }
}