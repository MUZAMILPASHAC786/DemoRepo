module.exports = class Flights {

    /**
    * This is constructer for Bags Call
    * @param {*} GqlCall is object of GQL booking class
    */
    constructor(GqlCall) {
        this.GqlCall = GqlCall;
        this._transactionId = '';
    }

    /**
    * this method is used to find dateDiffInDays
    * @param {*} dateOne - actual dep/ret date
    * @param {*} dateTwo - dep/ret date from array of dates
    * @returns {string} difference in days
    */
    dateDiffInDays(dateOne, dateTwo) {
        let validDateOne = new Date(dateOne)
        let validDateTwo = new Date(dateTwo)
        var lowerDate = Date.UTC(validDateOne.getFullYear(), validDateOne.getMonth(), validDateOne.getDate());
        var higherDate = Date.UTC(validDateTwo.getFullYear(), validDateTwo.getMonth(), validDateTwo.getDate());

        return Math.floor((higherDate - lowerDate) / (86400000));
    }
    /**
    * This method performs GQL call for date selection
    * @param {string} origin Ex: "LAS"
    * @param {string} destination Ex : "MEX"
    * @param {string} departDays Ex : "10" or "2022-12-15"
    * @param {string} returnDays Ex : "5" or "2022-12-22"
    * @param {string} tripType Ex : "ONEWAY"
    * @param {string} transactionid Ex:timeline650bf041a9749
    * @param {string} gameAvailableDate Ex:"2023-10-20"
    * @returns {json} availableDepartDates,availableReturnDates
    */
    async dateSelection(origin, destination, departDays = 0, returnDays = 1, tripType, transactionid, gameAvailableDate) {
        if (transactionid !== undefined) {
            this._transactionId = transactionid
        }
        let query = `query flightMarket($origin: IataCode!, $destination: IataCode!) {
        flightMarket(origin: $origin, destination: $destination) {
            type
            calendar {
            availableFrom
            availableUntil
            departingDates {
                date
                __typename
            }
            returningDates {
                date
                __typename
            }
            __typename
            }
            __typename
        }
        }`
        let variables = `{
        "origin": "${origin}",
        "destination": "${destination}"
        }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let departDatesThreshold = 3;
            let returnDatesThreshold = 3;
            let availableDepartDates = []
            let availableReturnDates = []
            let responseJson = JSON.parse(JSON.stringify(response));
            let departDateArray
            try {
                departDateArray = responseJson.data.flightMarket.calendar.departingDates
            }
            catch (error) {
                throw new Error("depart dates are not available, as calendar is null because data in origin or destination was wrong")
            }
            var todaysDate = new Date()
            const regex = /^\d{4}-\d{2}-\d{2}$/;
            let departDate, returnDate
            if (departDays.match(regex) === null && departDays.length <= 3) {
                let selectableDepDate = new Date(todaysDate.setDate(todaysDate.getDate() + Number(departDays)))
                let actualDepartDate = selectableDepDate.toISOString().split("T")[0]
                if (transactionid !== undefined) {
                    if ((actualDepartDate.split("-")[1]) < (gameAvailableDate.split("-")[1])) {
                        console.log("Raiders booking is initiated,match date is : ", gameAvailableDate)
                    } else if ((actualDepartDate.split("-")[1]) === (gameAvailableDate.split("-")[1])) {
                        if ((actualDepartDate.split("-")[2]) < (gameAvailableDate.split("-")[2])) {
                            console.log("Raiders booking is initiated,match date is : ", gameAvailableDate)
                        } else {
                            throw new Error("Raiders Booking failed,due to the chosen Depart date is greater than available Game date")
                        }
                    }
                }
                for (let i = 0; i < departDateArray.length; i++) {
                    let departAllDates = departDateArray[i].date
                    let difference = dateDiffInDays(actualDepartDate, departAllDates);
                    if (difference >= 0) {
                        //In same day booking scenario i.e, departDays = 0, consider flights within next 24 hours
                        if (departDays !== "0" || (departDays === "0" && difference <= 1)) {
                            availableDepartDates.push(departAllDates);
                            console.log("Depart Flights are Available on ", departAllDates, ", Hence stored date as availabe.")
                            //Storing 3(*departDatesThreshold) possible depart dates to process
                            if (availableDepartDates.length >= departDatesThreshold) {
                                break;
                            }
                        }
                    }
                }
            } else if (!departDays.match(regex) === true && departDays.length >= 4) {
                throw new Error("Departure Date format passed is not correct")
            } else {
                if (transactionid !== undefined) {
                    if ((departDays.split('-')[1]) < (gameAvailableDate.split('-')[1])) {
                        console.log("Raiders booking is initiated,match date is : ", gameAvailableDate)
                    } else if ((departDays.split('-')[1]) === (gameAvailableDate.split('-')[1])) {
                        if ((departDays.split('-')[2]) < (gameAvailableDate.split('-')[2])) {
                            console.log("Raiders booking is initiated,match date is : ", gameAvailableDate)
                        } else {
                            throw new Error("Raiders Booking failed,due to the chosen Depart date")
                        }
                    } else {
                        throw new Error("Raiders Booking failed,due to the chosen Depart date")
                    }
                }
                availableDepartDates.push(departDays);
            }
            if (availableDepartDates.length === 0) {
                throw new Error("Flights are not available on depart dates passed")
            }
            else {
                departDate = availableDepartDates[0]
            }
            if (tripType === "ROUNDTRIP") {
                let returnDatesArray = responseJson.data.flightMarket.calendar.returningDates
                if (returnDays.match(regex) === null && returnDays.length <= 3) {
                    if (departDays !== 0 || returnDays !== 0) {
                        returnDatesArray = returnDatesArray.filter(greaterThanDepartDate);
                    }
                    if (transactionid !== undefined) {
                        returnDatesArray = returnDatesArray.filter(greaterThanGameDate);
                    }
                    let ReturnDepDate = new Date(departDate)
                    let selectableRetDate = new Date(ReturnDepDate.setDate(ReturnDepDate.getDate() + Number(returnDays)))
                    let actualReturnDate = selectableRetDate.toISOString().split("T")[0]
                    for (let i = 0; i < returnDatesArray.length; i++) {
                        let returnAllDates = returnDatesArray[i].date
                        let difference = dateDiffInDays(actualReturnDate, returnAllDates);
                        let sameDayBooking = false;
                        if (departDays === "0" && returnDays === "1") {
                            sameDayBooking = true
                        }
                        if (difference >= 0) {
                            if (!sameDayBooking || (sameDayBooking && difference <= 1)) {
                                availableReturnDates.push(returnAllDates);
                                console.log("Return Flights are Available on ", returnAllDates, ", Hence stored date as availabe")
                                //Storing 3(*returnDatesThreshold) possible return dates to process
                                if (availableReturnDates.length >= returnDatesThreshold) {
                                    break;
                                }
                            }
                        }
                    }
                } else if (!returnDays.match(regex) === true && returnDays.length >= 4) {
                    throw new Error("Return Date format passed is not correct")
                } else {
                    returnDate = returnDays
                    availableReturnDates.push(returnDate);
                }
                if (availableReturnDates.length === 0) {
                    throw new Error("Flights are not available on return dates passed")
                }
            }

            //             /**
            // * this function is used to fetch valid dates
            // * @param {*} DateArray - departure /return dates array
            // * @param {*} validDate - current /depart dates 
            // * @param {*} Days - departure /return days
            // * @returns {string} valid dates
            // */
            //             function validDates(DateArray, validDate, Days) {
            //                 let ArrayOfDates = [];

            //                 if (Days < 7) {
            //                     ArrayOfDates = checkAvailableDates(7)
            //                 } else if (Days >= 7 && Days < 15) {
            //                     ArrayOfDates = checkAvailableDates(15)
            //                 } else if (Days >= 15 && Days < 30) {
            //                     ArrayOfDates = checkAvailableDates(30)
            //                 } else if (Days >= 30 && Days < 45) {
            //                     ArrayOfDates = checkAvailableDates(45)
            //                 } else if (Days >= 45 && Days < 60) {
            //                     ArrayOfDates = checkAvailableDates(60)
            //                 } else {
            //                     ArrayOfDates = checkAvailableDates(120)
            //                 }

            //                 if (ArrayOfDates.length === 0) {
            //                     throw new Error("No Flights are available in selected date range")
            //                 }

            //                 /**
            //                * this function is used to list available flights dates in days range
            //                * @param {integer} days days for depart and return Ex: 7 or 10
            //                * @returns {string} list of valid dates
            //                */
            //                 function checkAvailableDates(days) {
            //                     var dateDiffLoop
            //                     let valid_Date = new Date(validDate)
            //                     if (DateArray.length < days) {
            //                         dateDiffLoop = DateArray.length
            //                     }
            //                     else {
            //                         dateDiffLoop = days
            //                     }
            //                     for (var i = 0; i < dateDiffLoop; i++) {
            //                         if (i < days) {
            //                             var Array = DateArray[i].date
            //                             var validArray = new Date(Array)

            //                             const difference = dateDiffInDays(valid_Date, validArray);
            //                             if (difference <= days) {
            //                                 var format = validArray => validArray.toISOString().slice(0, 10);
            //                                 var validTDate = format(validArray)
            //                                 ArrayOfDates.push(validTDate)
            //                             }
            //                         }
            //                     }
            //                     return ArrayOfDates
            //                 }

            //                 return ArrayOfDates
            //             }

            /**
    * this method is used to find dateDiffInDays
    * @param {*} dateOne - actual dep/ret date
    * @param {*} dateTwo - dep/ret date from array of dates
    * @returns {string} difference in days
    */
            function dateDiffInDays(dateOne, dateTwo) {
                let validDateOne = new Date(dateOne)
                let validDateTwo = new Date(dateTwo)
                var lowerDate = Date.UTC(validDateOne.getFullYear(), validDateOne.getMonth(), validDateOne.getDate());
                var higherDate = Date.UTC(validDateTwo.getFullYear(), validDateTwo.getMonth(), validDateTwo.getDate());

                return Math.floor((higherDate - lowerDate) / (86400000));
            }
            /**
    * This function returns arrival date greater than depart date
    * @param {*} returnDate Ex: "2022-06-15" 
    * @returns {string} date
    */
            function greaterThanDepartDate(returnDate) {
                return returnDate.date > departDate;
            }

            /**
    * This function returns arrival date greater than game date
    * @param {*} returnDate Ex: "2022-06-15" 
    * @returns {string} date
    */
            function greaterThanGameDate(returnDate) {
                return returnDate.date > gameAvailableDate;
            }
            //Returning date arrays from the method
            return {
                availableDepartDates,
                availableReturnDates,
            };
        })
    }

    /**
    * This method performs GQL call for flight booking
    * @param {string} tripType Ex: ROUNDTRIP/ONEWAY
    * @param {string} origin Ex: "LAS"
    * @param {string} destination Ex : "MEX"
    * @param {Array} availableDepartDates Ex: ["2022-06-12", "2022-06-17", "2022-06-19"]
    * @param {Array} availableReturnDates Ex: ["2022-06-12", "2022-06-17", "2022-06-19"]
    * @param {string} plusorMinusDays Ex: 14/0
    * @param {integer} adultsCount Ex: 1
    * @param {integer} childrenCount Ex: 0
    * @param {integer} lapInfantCount Ex: 1
    * @param {integer} departFlightNum Ex: "7332"
    * @param {integer} returnFlightNum Ex: "513"
    * @param {*} transactionid Ex:timeline650bf041a9749
    * @returns {json} departDate, returnDate, departureFlightId, returningFlightId,arrivalTime,departingTime
    */
    async flightBooking(tripType, origin, destination, availableDepartDates, availableReturnDates, plusorMinusDays, adultsCount = 1, childrenCount = 0, lapInfantCount = 0, departFlightNum = "", returnFlightNum = "", transactionid) {
        let variables
        var totalSeats = adultsCount + childrenCount;
        if (adultsCount > 9 || (childrenCount > 3)) {
            throw new Error("Adults count cannot be more than 9 (OR) childrenCount cannot be more than 3")
        }
        let isCheckInProcess = (tripType !== undefined && tripType === "CHECKIN")? true : false ;

        if(tripType === "CHECKIN")
        {
            // eslint-disable-next-line no-param-reassign
            tripType = "ONEWAY" //converting to one way
        }

        let query = `query flights($flightSearchCriteria: FlightSearchCriteriaInput!) {
        transactionId
        flights(flightSearchCriteria: $flightSearchCriteria) {
            departing {
            ...FlightOptionFragment
            __typename
            }
            returning {
            ...FlightOptionFragment
            __typename
            }
            loyaltyFare {
            discount
            __typename
            }
            __typename
        }
        order {
            items {
            id
            __typename
            ... on FlightOrderItem {
                flight {
                id
                __typename
                }
                __typename
            }
            ... on ShowOrderItem {
                id
                type
                show {
                categoryCode
                __typename
                }
                __typename
            }
            }
            __typename
        }
        }
        
        fragment FlightOptionFragment on FlightOption {
        id
        flight {
            id
            number
            origin {
            displayName
            code
            __typename
            }
            destination {
            code
            displayName
            __typename
            }
            departingTime
            arrivalTime
            isOvernight
            __typename
        }
        strikethruPrice
        price
        baseFare
        availableSeatsCount
        discountType
        totalDiscountValue
        incentiveType
        incentiveSavedAmount
        incentiveReturnDate
        onTimePerformance {
            onTimeArrival
            thirtyMinuteLate
            cancellations
            disclaimer
            __typename
        }
        __typename
        }`


        /*Pass a pair of depart and return dates to the query to get flight information. Check with the remaining dates if a possible flight is not available
        */
        let departIndex = 0;
        let returnIndex = 0;
        if (tripType === "ONEWAY") {
            //Added such that the while loop does not break in case of ONEWAY where return dates are empty
            returnIndex = -1
        }
        let retry = 0;
        console.log("flight booking started");
        while (departIndex < availableDepartDates.length && returnIndex < availableReturnDates.length && retry < 6) {
            retry++;
            var departDate = availableDepartDates[departIndex];
            var returnDate = availableReturnDates[returnIndex];
            if (returnDate !== undefined && departDate !== undefined && this.dateDiffInDays(returnDate, departDate) > 0) {
                continue;
            }
            if (tripType === "ROUNDTRIP") {
                console.log("RT booking verified for departDate:" + departDate + " and returnDate:" + returnDate)
                variables = `{
                "flightSearchCriteria": {
                "tripType": "${tripType}",
                "origin": "${origin}",
                "destination": "${destination}",
                "departDate": {
                    "date": "${departDate}",
                    "minusDays": ${plusorMinusDays},
                    "plusDays": ${plusorMinusDays}
                },
                "returnDate": {
                    "date": "${returnDate}",
                    "minusDays": ${plusorMinusDays},
                    "plusDays": ${plusorMinusDays} 
                },
                "adultsCount": ${adultsCount},
                "childrenCount": ${childrenCount},
                "lapInfantCount": ${lapInfantCount},
                "lapInfantDobs": []
                }
            }`
            } else if (tripType === 'ONEWAY') {
                console.log("OW booking verified for departDate:" + departDate)
                variables = `{
                    "flightSearchCriteria": {
                    "tripType": "${tripType}",
                    "origin": "${origin}",
                    "destination": "${destination}",
                    "departDate": {
                        "date": "${departDate}",
                        "minusDays": ${plusorMinusDays},
                        "plusDays": ${plusorMinusDays}
                    },
                    "adultsCount": ${adultsCount},
                    "childrenCount": ${childrenCount},
                    "lapInfantCount": ${lapInfantCount},
                    "lapInfantDobs": []
                    }
                }`
            }
            var {
                departDate,
                returnDate,
                departureFlightId,
                returningFlightId,
                arrivalTime,
                departingTime,
                retArrivalTime,
                retDepartingTime,
            } = await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
                let responseJson = JSON.parse(JSON.stringify(response));
                let departureFlightId, returningFlightId, arrivalTime, departingTime
                let returningFlightArray
                try {
                    var departingArray = responseJson.data.flights.departing;
                    if (tripType === "ROUNDTRIP") {
                        var returningArray = responseJson.data.flights.returning;
                    }
                }
                catch (err) {
                    throw new Error("Flights are Not Available, check inputs(origin/destination) passed are correct")
                }
                let departingFlightArray = departingArray.filter(function (d) {
                    //Consider the flights which has enough seats on the particular date
                    if (d.id.includes(departDate) && d.availableSeatsCount >= totalSeats) {
                        return d;
                    }
                })
                if (departingFlightArray.length === 0) {
                    if (departIndex === availableDepartDates.length) {
                        throw new Error("No possible flights for selected dates")
                    }
                    console.log("Depart flight has no availability, so checking next depart date")
                    return {
                        departDate,
                        returnDate,
                        departureFlightId,
                        returningFlightId,
                        arrivalTime,
                        departingTime,
                    }; //returning empty dates to check for next possible date
                }
                departureFlightId = getFlightIdDetails(departingFlightArray, departFlightNum)
                if (tripType === "ROUNDTRIP") {
                    //Consider the flights which has enough seats on the particular date
                    returningFlightArray = returningArray.filter(function (d) {
                        if (d.id.includes(returnDate) && d.availableSeatsCount >= totalSeats) {
                            return d;
                        }
                    })
                    if (returningFlightArray.length === 0) {
                        if (returnIndex === availableReturnDates.length) {
                            throw new Error("No possible flights for selected dates")
                        }
                        console.log("Return flight has no availability, so checking next return date")
                        return {
                            departDate,
                            returnDate,
                            departureFlightId,
                            returningFlightId,
                            arrivalTime,
                            departingTime,
                        };
                        //returning empty dates to check for next possible date
                    }
                }
                if (transactionid === undefined) {
                    this._transactionId = responseJson.data.transactionId
                }



                if (tripType === "ROUNDTRIP") {
                    returningFlightId = getFlightIdDetails(returningFlightArray, returnFlightNum)
                }
                /**
    * this function returns flight details
    * @param {*} flightArray -
    * @param {string} flightNum - departure/return flight numbers Ex: "7474"
    * @returns {string}- flightId 
    */
                function getFlightIdDetails(flightArray, flightNum) {
                    let flightId
                    if (flightNum.length === 0) {
                        flightId = flightArray[0].id;
                    } else {
                        flightId = flightDetails(flightArray, flightNum)
                        if (flightId === undefined) {
                            throw new Error("The Flight with Specified flight_Number is Not Available")
                        }
                    }
                    return flightId
                }

                /**
    * this function returns flight details
    * @param {*} flightArray -
    * @param {string} flightNum - departure/return flight numbers Ex: "7474"
    * @returns {*} -
    */
                function flightDetails(flightArray, flightNum) {
                    let flightNUMs, flightIDs
                    let flightNumArray = []
                    for (var i = 0; i < flightArray.length; i++) {
                        flightNUMs = flightArray[i].flight.number
                        flightNumArray.push(flightNUMs)
                        if (flightNum === flightNUMs) {
                            flightIDs = flightArray[i].flight.id
                            return flightIDs
                        }
                    }
                    console.log("available flight numbers", flightNumArray)
                }

                [arrivalTime, departingTime] = getArrivalDepartingTimes(departingFlightArray, departFlightNum);
                
                if(isCheckInProcess) //checking if the flight is avaiable in next 24 hours
                {                   
                   
                    let valueCheck = withInNext24Hours(departingTime)
                    if (valueCheck === false) {
                        return {
                            departDate,
                            returnDate,
                            departureFlightId,
                            returningFlightId,
                            arrivalTime,
                            departingTime,
                        };
                        
                    }
                    
                }
                /**
            * this function is used to check if time stamp is within next 24 hours
            * @param {string} checkTime  -
            * @returns {*} -
            */
                function withInNext24Hours(checkTime) {
                    // console.log("The arrival time is given by :>>"+checkTime)
                    let now = new Date()
                    // console.log("Now "+now)
                    let next24HRs = new Date(now.getTime() + 24 * 60 * 60 * 1000)
                    // console.log("next 24 hours  "+next24HRs)
                    let timeCheck = new Date(checkTime);
                    // console.log("The check time is  " +timeCheck)
                    return timeCheck >= now && timeCheck <= next24HRs;

                }
                
                if (tripType === "ROUNDTRIP") {
                    [retArrivalTime, retDepartingTime] = getArrivalDepartingTimes(returningFlightArray, returnFlightNum);
                }
                /**
            * this function is used for getArrivalDepartingTimes
            * @param {*} departingFlightArray -
            * @param {string} departFlightNum  -
            * @returns {*} -
            */
                function getArrivalDepartingTimes(departingFlightArray, departFlightNum) {
                    let arrivalTime, departingTime;
                    if (departFlightNum.length !== 0) {
                        for (let i = 0; i < departingFlightArray.length; i++) {
                            let departFlightNUMs = departingFlightArray[i].flight.number

                            if (departFlightNUMs === departFlightNum) {
                                arrivalTime = departingFlightArray[i].flight.arrivalTime
                                departingTime = departingFlightArray[i].flight.departingTime
                            }
                        }
                    } else {
                        arrivalTime = departingFlightArray[0].flight.arrivalTime
                        departingTime = departingFlightArray[0].flight.departingTime
                    }
                    return [arrivalTime, departingTime];
                }

                return {
                    departDate,
                    returnDate,
                    departureFlightId,
                    returningFlightId,
                    arrivalTime,
                    departingTime,
                    retArrivalTime,
                    retDepartingTime,
                };
            })

            //Continue with next dates if either of the flights are not available
            if (departureFlightId === undefined) {
                departIndex++;
                if (departIndex >= availableDepartDates.length) {
                    throw new Error("Failed to get departure flights even after searching for possibilities")
                }
                continue;
            }
            if (tripType === "ROUNDTRIP") {
                if (returningFlightId === undefined) {
                    returnIndex++;
                    if (returnIndex >= availableReturnDates.length) {
                        throw new Error("Failed to get return flights even after searching for possibilities")
                    }
                    continue;
                }
            }
            return {
                departDate,
                returnDate,
                departureFlightId,
                returningFlightId,
                arrivalTime,
                departingTime,
                retArrivalTime,
                retDepartingTime,
            };
        }
    }
    // }
    /**
    * This method performs GQL call for orderCreation
    * @param {string} tripType Ex: "ROUNDTRIP"/ "ONEWAY"
    * @param {string} departureFlightId Ex: "2022-06-12-AW-1"
    * @param {string} returningFlightId Ex: "2022-06-12-AW-1"
    * @returns {string} travelerId 
    */
    async orderCreation(tripType, departureFlightId, returningFlightId) {
        let query = `mutation continueButtonMutation($departureFlightId: ID!, $returningFlightId: ID) {
  selectFlights(departureFlightId: $departureFlightId, returningFlightId: $returningFlightId) {
    transactionId
    order {
      status
      travelers {
        id
        __typename
      }
      __typename
    }
    errors
    __typename
  }
}`

        let variables;
        if (tripType === "ONEWAY") {
            variables = `{
            "departureFlightId": "${departureFlightId}"
            }`
        } else {
            variables = `{
            "departureFlightId": "${departureFlightId}",
            "returningFlightId": "${returningFlightId}"
            }`
        }

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                let travelerArray = responseJson.data.selectFlights.order.travelers;

                let travelerid = []
                travelerArray.forEach((traveller) => {
                    travelerid.push(traveller.id);
                })
                return travelerid;
            } catch (err) {
                throw new Error("traveler details are not available")
            }

        })
    }
    /**
    * This method return trasactionId
    * @returns {string} travelerId
    */
    async getTransactionId() {
        return this._transactionId;
    }
}