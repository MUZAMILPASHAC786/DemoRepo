const CardDetails = require('../helpers/card-helpers/cardDetails');
const CardNumbers = require('../helpers/card-helpers/cardNumbers');
const {
    faker,
} = require('@faker-js/faker');
const fetch = require('node-fetch')
const chalk = require('chalk');
module.exports = class Payment {

    /**
 * This is constructer for Bags Call
 * @param {*} GqlCall is object of GQL booking class
 * @param {*} transactionId is the transactionIf of the flow
 */
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }

    /**
 * This method performs GQL call for paymentPage
 * @param {string} promo Ex: "PROMO50"
 */
    async promoPayment(promo) {
        let query = `mutation addPromoPayment($payment: PromoPaymentInput!) {
    addPromoPayment(payment: $payment) {
      order {
        items {
          id
          __typename
          ...BundleOrderItemFragment
          ...FlightOrderItemFragment
          ...HotelOrderItemFragment
          ...SeatOrderItemFragment
          ...TravelerAncillaryOrderItemFragment
          ...VehicleOrderItemFragment
          ...ItineraryAncillaryOrderItemFragment
        }
        ...TravelersFragment
        payments {
          ...OrderPaymentFragment
          ...PromoPaymentFragment
          ...VoucherPaymentFragment
          ...LoyaltyPaymentFragment
          __typename
        }
        price {
          total
          balanceDue
          taxes {
            amount
            __typename
          }
          fees {
            amount
            __typename
          }
          __typename
        }
        loyalty {
          applicableAmount {
            amount
            currency
            __typename
          }
          applicablePoints
          earningPoints {
            masterCardPoints
            allwaysPoints
            totalEarning
            __typename
          }
          __typename
        }
        __typename
      }
      errors
      __typename
    }
  }
  
  fragment OrderPaymentFragment on OrderPayment {
    paymentType
    paymentStatus
    paymentMethod
    total {
      amount
      currency
      __typename
    }
    __typename
  }
  
  fragment PromoPaymentFragment on PromoPayment {
    id
    description
    total {
      amount
      currency
      __typename
    }
    isAutoApplied
    __typename
  }
  
  fragment VoucherPaymentFragment on VoucherPayment {
    id
    type
    __typename
  }
  
  fragment LoyaltyPaymentFragment on LoyaltyPayment {
    id
    points
    __typename
  }
  
  fragment BundleOrderItemFragment on OrderItem {
    ... on BundleOrderItem {
      id
      bundle {
        id
        tier
        name
        banner
        ancillaries {
          name
          type
          price {
            amount
            __typename
          }
          __typename
        }
        __typename
      }
      price {
        amount
        currency
        __typename
      }
      __typename
    }
    __typename
  }
  
  fragment FlightOrderItemFragment on OrderItem {
    ... on FlightOrderItem {
      id
      flight {
        id
        number
        origin {
          code
          displayName
          city
          state
          title
          street
          postalCode
          __typename
        }
        destination {
          code
          displayName
          city
          state
          title
          street
          postalCode
          __typename
        }
        departingTime
        arrivalTime
        isOvernight
        __typename
      }
      flightPrice: price {
        total
        subtotal
        taxesAndFees
        taxes {
          total {
            amount
            currency
            __typename
          }
          breakdown {
            name
            code
            value {
              amount
              currency
              __typename
            }
            __typename
          }
          __typename
        }
        fees {
          total {
            amount
            currency
            __typename
          }
          breakdown {
            name
            code
            value {
              amount
              currency
              __typename
            }
            __typename
          }
          __typename
        }
        discountValue {
          amount
          currency
          __typename
        }
        discountType
        total
        __typename
      }
      __typename
    }
    __typename
  }
  
  fragment HotelOrderItemFragment on OrderItem {
    ... on HotelOrderItem {
      id
      hotelPrice: price {
        total
        __typename
      }
      roomType
      roomsCount
      roomId
      hotelId
      hotel {
        name
        promos {
          id
          code
          headlineDescription
          __typename
        }
        __typename
      }
      checkin {
        time
        __typename
      }
      checkout {
        time
        __typename
      }
      roomsCount
      adultCount
      childrenCount
      __typename
    }
    __typename
  }
  
  fragment SeatOrderItemFragment on OrderItem {
    ... on SeatOrderItem {
      id
      flightId
      travelerId
      column
      row
      price {
        amount
        currency
        __typename
      }
      seatPrice {
        subtotal
        taxes {
          breakdown {
            name
            code
            value {
              amount
              __typename
            }
            __typename
          }
          total {
            amount
            currency
            __typename
          }
          __typename
        }
        taxesIncludedInBundle {
          breakdown {
            name
            code
            value {
              amount
              __typename
            }
            __typename
          }
          total {
            amount
            currency
            __typename
          }
          __typename
        }
        total
        isUpgradePrice
        __typename
      }
      bundledAncillaryPrice {
        amount
        __typename
      }
      isBundledAncillaryIncluded
      seatSizeId
      __typename
    }
    __typename
  }
  
  fragment TravelerAncillaryOrderItemFragment on OrderItem {
    ... on TravelerAncillaryOrderItem {
      id
      flightId
      travelerId
      ancillaryType
      quantity
      price {
        amount
        currency
        __typename
      }
      bundledAncillaryPrice {
        amount
        __typename
      }
      isBundledAncillaryIncluded
      __typename
    }
    __typename
  }
  
  fragment VehicleOrderItemFragment on OrderItem {
    ... on VehicleOrderItem {
      id
      vehiclePrice: price {
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      vehicle {
        category
        code
        type
        description
        __typename
      }
      vendor {
        name
        __typename
      }
      promotions {
        id
        code
        headlineDescription
        __typename
      }
      pickUpDate
      dropOffDate
      __typename
    }
    __typename
  }
  
  fragment ItineraryAncillaryOrderItemFragment on OrderItem {
    ... on ItineraryAncillaryOrderItem {
      id
      ancillaryType
      quantity
      price {
        amount
        currency
        __typename
      }
      bundledAncillaryPrice {
        amount
        __typename
      }
      isBundledAncillaryIncluded
      __typename
    }
    __typename
  }
  
  fragment TravelersFragment on Order {
    travelers {
      id
      firstName
      lastName
      middleName
      suffix
      isPrimary
      type
      ssrs {
        code
        flightId
        title
        price {
          amount
          currency
          __typename
        }
        additionalInfo
        __typename
      }
      __typename
    }
    __typename
  }`

        let variables = `{
    "payment": {
      "code": "${promo}"
    }
  }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                console.log(`promocode status ${chalk.green(responseJson.data.addPromoPayment.order.payments[0].paymentStatus)}`,)
                console.log(`promocode used ${chalk.green(responseJson.data.addPromoPayment.order.payments[0].description)}`,)
            } catch (err) {
                console.error("promocode payment is unsuccessful, provide valid promo code");
            }
        })

    }

    /**
 * This method performs GQL call for paymentPage
 * @param {string} env Ex: ".stg" / ".qa1" 
 * @param {string} voucher Ex: "CR" / "DO"
 */
    async voucherPayment(env, voucher) {
        let query = `mutation addVoucherPayment($payment: VoucherPaymentInput!) {
  addVoucherPayment(payment: $payment) {
    order {
      items {
        id
        __typename
        ...BundleOrderItemFragment
        ...FlightOrderItemFragment
        ...HotelOrderItemFragment
        ...SeatOrderItemFragment
        ...TravelerAncillaryOrderItemFragment
        ...VehicleOrderItemFragment
        ...ItineraryAncillaryOrderItemFragment
      }
      ...TravelersFragment
      payments {
        ...OrderPaymentFragment
        ...PromoPaymentFragment
        ...VoucherPaymentFragment
        ...LoyaltyPaymentFragment
        __typename
      }
      price {
        total
        balanceDue
        taxes {
          amount
          __typename
        }
        fees {
          amount
          __typename
        }
        __typename
      }
      loyalty {
        applicableAmount {
          amount
          currency
          __typename
        }
        applicablePoints
        earningPoints {
          masterCardPoints
          allwaysPoints
          totalEarning
          __typename
        }
        __typename
      }
      promoError {
        name
        errors
        __typename
      }
      __typename
    }
    errors
    __typename
  }
}

fragment OrderPaymentFragment on OrderPayment {
  paymentType
  paymentStatus
  paymentMethod
  total {
    amount
    currency
    __typename
  }
  __typename
}

fragment PromoPaymentFragment on PromoPayment {
  id
  description
  total {
    amount
    currency
    __typename
  }
  isAutoApplied
  __typename
}

fragment VoucherPaymentFragment on VoucherPayment {
  id
  type
  __typename
}

fragment LoyaltyPaymentFragment on LoyaltyPayment {
  id
  points
  __typename
}

fragment BundleOrderItemFragment on OrderItem {
  ... on BundleOrderItem {
    id
    bundle {
      id
      tier
      name
      banner
      ancillaries {
        name
        type
        price {
          amount
          __typename
        }
        __typename
      }
      __typename
    }
    price {
      amount
      currency
      __typename
    }
    __typename
  }
  __typename
}

fragment FlightOrderItemFragment on OrderItem {
  ... on FlightOrderItem {
    id
    flight {
      id
      number
      origin {
        code
        displayName
        city
        state
        title
        street
        postalCode
        __typename
      }
      destination {
        code
        displayName
        city
        state
        title
        street
        postalCode
        __typename
      }
      departingTime
      arrivalTime
      isOvernight
      __typename
    }
    flightPrice: price {
      total
      subtotal
      taxesAndFees
      taxes {
        total {
          amount
          currency
          __typename
        }
        breakdown {
          name
          code
          value {
            amount
            currency
            __typename
          }
          __typename
        }
        __typename
      }
      fees {
        total {
          amount
          currency
          __typename
        }
        breakdown {
          name
          code
          value {
            amount
            currency
            __typename
          }
          __typename
        }
        __typename
      }
      discountValue {
        amount
        currency
        __typename
      }
      discountType
      total
      __typename
    }
    __typename
  }
  __typename
}

fragment HotelOrderItemFragment on OrderItem {
  ... on HotelOrderItem {
    id
    hotelPrice: price {
      total
      __typename
    }
    roomType
    roomsCount
    roomId
    hotelId
    hotel {
      name
      promos {
        id
        code
        headlineDescription
        __typename
      }
      __typename
    }
    checkin {
      time
      __typename
    }
    checkout {
      time
      __typename
    }
    roomsCount
    adultCount
    childrenCount
    __typename
  }
  __typename
}

fragment SeatOrderItemFragment on OrderItem {
  ... on SeatOrderItem {
    id
    flightId
    travelerId
    column
    row
    price {
      amount
      currency
      __typename
    }
    seatPrice {
      subtotal
      taxes {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      taxesIncludedInBundle {
        breakdown {
          name
          code
          value {
            amount
            __typename
          }
          __typename
        }
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      total
      isUpgradePrice
      __typename
    }
    bundledAncillaryPrice {
      amount
      __typename
    }
    isBundledAncillaryIncluded
    seatSizeId
    __typename
  }
  __typename
}

fragment TravelerAncillaryOrderItemFragment on OrderItem {
  ... on TravelerAncillaryOrderItem {
    id
    flightId
    travelerId
    ancillaryType
    quantity
    price {
      amount
      currency
      __typename
    }
    bundledAncillaryPrice {
      amount
      __typename
    }
    isBundledAncillaryIncluded
    __typename
  }
  __typename
}

fragment VehicleOrderItemFragment on OrderItem {
  ... on VehicleOrderItem {
    id
    vehiclePrice: price {
      total {
        amount
        currency
        __typename
      }
      __typename
    }
    vehicle {
      category
      code
      type
      description
      __typename
    }
    vendor {
      name
      __typename
    }
    promotions {
      id
      code
      headlineDescription
      __typename
    }
    pickUpDate
    dropOffDate
    __typename
  }
  __typename
}

fragment ItineraryAncillaryOrderItemFragment on OrderItem {
  ... on ItineraryAncillaryOrderItem {
    id
    ancillaryType
    quantity
    price {
      amount
      currency
      __typename
    }
    bundledAncillaryPrice {
      amount
      __typename
    }
    isBundledAncillaryIncluded
    __typename
  }
  __typename
}

fragment TravelersFragment on Order {
  travelers {
    id
    firstName
    lastName
    middleName
    suffix
    isPrimary
    type
    ssrs {
      code
      flightId
      title
      price {
        amount
        currency
        __typename
      }
      additionalInfo
      __typename
    }
    __typename
  }
  __typename
}`
        let voucherDetails
        let voucherType
        let voucherAmount
        if (voucher.includes(":")) {
            voucherDetails = voucher.split(":")
            voucherType = voucherDetails[0]
            voucherAmount = voucherDetails[1]

        } else {
            voucherType = voucher
            if (voucherType === "CR") {
                voucherAmount = 30
            } else {
                voucherAmount = 15
            }
        }

        if (voucherType === "CR") {

            var voucherEmail = "test.data@email.com"
            var voucherNumber = await getVocherNumber(env, voucherEmail, voucherAmount, voucherType);
            console.log("CR voucherNumber is:-> ", voucherNumber)
        } else {


            var voucherEmail = ""
            var voucherNumber = await getVocherNumber(env, voucherEmail, voucherAmount, voucherType);
            console.log("DO voucherNumber is:-> ", voucherNumber)
        }

        let variables = `{
"payment": {
"number": "${voucherNumber}",
"type": "${voucherType}",
"customerName": "",
"email": "${voucherEmail}"
}
}`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                console.log(`voucher status ${chalk.green(responseJson.data.addVoucherPayment.order.payments[0].paymentStatus)}`,)
            } catch (err) {
                console.error("voucher payment is unsuccessful");
            }
        })

        /**
 * This method performs GQL call for paymentPage
 * @param {string} env Ex: ".stg"
 * @param {string} voucherEmail Ex: "test@gmail.com"
 * @param {string} voucherAmount Ex: "15"
 * @param {string} voucherType Ex: "CR" / "DO" 
 */
        async function getVocherNumber(env, voucherEmail, voucherAmount, voucherType) {
            const data = {
                "code": voucherType,
                "firstName": faker.name.firstName(),
                "lastName": faker.name.lastName(),
                "email": voucherEmail,
                "orderId": "AA1234",
                "params": [{
                    "name": "amount",
                    "value": voucherAmount,
                },
                {
                    "name": "basisDate",
                    "value": new Date().toISOString().slice(0, 10),
                },
                ],
            };

            if (env.includes(".okd")) {
                var url = "https://vouchers-webapp-api{env}.allegiantair.com/vouchers/v2/api/vouchers".replace("{env}", env)
            } else {
                var url = "http://jbshc1{env}.allegiantair.com:9380/vouchers/v2/api/vouchers".replace("{env}", env)
            }
            const generatedVoucher = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            })
                .then((response) => response.json())
            return generatedVoucher.nbr
        }
    }

    /**
 * This method performs GQL call to get BanlancedDue amount
 * @param {string} loginToken Ex: auth-Token generated after login
 * @returns {integer} returns the trip summary values.
 */
    async getPoints(loginToken) {
        let query = `query getPoints {
      viewer {
        id
        loyalty {
          status
          lastMonthEarned
          lastStatementEarned
          lastYearEarned
          totalEarned
          bonus
          expired
          normal
          purchased
          redeemed
          total
          pointsValue
          errors
          __typename
        }
        __typename
      }
    }`
        let variables
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables, loginToken).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            return responseJson.data.viewer.loyalty.pointsValue
        }).catch(function () {
            console.error("the trip balance amount is undefined");
        })

    }

    /**
 * This method performs GQL call to get BanlancedDue amount
 * @param {string} loginToken Ex: auth-Token generated after login
 * @returns {integer} returns the trip summary values.
 */
    async getBalancedDue(loginToken) {
        let query = `query upliftConfig {
  settings {
    uplift {
      apiKey
      apiCode
      pages {
        pageName
        pageValue
        __typename
      }
      __typename
    }
    __typename
  }
  order {
    items {
      id
      ... on FlightOrderItem {
        flight {
          id
          origin {
            code
            displayName
            city
            __typename
          }
          destination {
            code
            displayName
            city
            __typename
          }
          departingTime
          __typename
        }
        price {
          discountType
          total
          __typename
        }
        __typename
      }
      ... on BundleOrderItem {
        bundle {
          id
          ancillaries {
            name
            type
            price {
              amount
              __typename
            }
            __typename
          }
          __typename
        }
        __typename
      }
      ... on ItineraryAncillaryOrderItem {
        ancillaryType
        isBundledAncillaryIncluded
        price {
          amount
          currency
          __typename
        }
        quantity
        __typename
      }
      ... on TravelerAncillaryOrderItem {
        ancillaryType
        isBundledAncillaryIncluded
        price {
          amount
          currency
          __typename
        }
        quantity
        __typename
      }
      ... on VehicleOrderItem {
        vehiclePrice: price {
          total {
            amount
            currency
            __typename
          }
          __typename
        }
        vehicle {
          code
          description
          __typename
        }
        __typename
      }
      ... on HotelOrderItem {
        hotelPrice: price {
          total
          __typename
        }
        hotel {
          name
          address
          phone {
            number
            type
            countryPrefix
            country {
              name
              code
              phonePrefixCode
              __typename
            }
            __typename
          }
          __typename
        }
        checkin {
          time
          __typename
        }
        checkout {
          time
          __typename
        }
        roomType
        roomsCount
        adultCount
        childrenCount
        stayLength
        __typename
      }
      ... on SeatOrderItem {
        isBundledAncillaryIncluded
        column
        row
        price {
          amount
          __typename
        }
        __typename
      }
      __typename
    }
    travelers {
      id
      firstName
      lastName
      dateOfBirth
      ssrs {
        code
        title
        price {
          amount
          currency
          __typename
        }
        __typename
      }
      __typename
    }
    price {
      balanceDue
      __typename
    }
    __typename
  }
}`
        let variables
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables, loginToken).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            // console.log("responseJson points: ", responseJson.data.order.price.balanceDue)
            let getPrice = responseJson.data.order.price.balanceDue
            return getPrice
        }).catch(function () {
            console.error("the trip balance amount is undefined");
        })

    }

    /**
 * This method performs GQL call for loyalty payment
 * @param {integer} loyaltypoints return value from getpoints method Ex: "59200"
 * @param {String} loginToken return value from login method.
 */
    async loyaltyPayment(loyaltypoints, loginToken) {
        let query = `mutation addLoyaltyPayment($points: Int!) {
        addLoyaltyPayment(points: $points) {
          order {
            items {
              id
              __typename
              ...BundleOrderItemFragment
              ...FlightOrderItemFragment
              ...HotelOrderItemFragment
              ...SeatOrderItemFragment
              ...TravelerAncillaryOrderItemFragment
              ...VehicleOrderItemFragment
              ...ItineraryAncillaryOrderItemFragment
            }
            ...TravelersFragment
            payments {
              ...OrderPaymentFragment
              ...PromoPaymentFragment
              ...VoucherPaymentFragment
              ...LoyaltyPaymentFragment
              __typename
            }
            price {
              total
              balanceDue
              taxes {
                amount
                __typename
              }
              fees {
                amount
                __typename
              }
              __typename
            }
            promoError {
              name
              errors
              __typename
            }
            loyalty {
              applicableAmount {
                amount
                currency
                __typename
              }
              applicablePoints
              earningPoints {
                masterCardPoints
                allwaysPoints
                totalEarning
                __typename
              }
              __typename
            }
            __typename
          }
          errors
          __typename
        }
      }
      
      fragment OrderPaymentFragment on OrderPayment {
        paymentType
        paymentStatus
        paymentMethod
        total {
          amount
          currency
          __typename
        }
        __typename
      }
      
      fragment PromoPaymentFragment on PromoPayment {
        id
        description
        total {
          amount
          currency
          __typename
        }
        isAutoApplied
        __typename
      }
      
      fragment VoucherPaymentFragment on VoucherPayment {
        id
        type
        __typename
      }
      
      fragment LoyaltyPaymentFragment on LoyaltyPayment {
        id
        points
        __typename
      }
      
      fragment BundleOrderItemFragment on OrderItem {
        ... on BundleOrderItem {
          id
          bundle {
            id
            tier
            name
            banner
            ancillaries {
              name
              type
              price {
                amount
                __typename
              }
              __typename
            }
            __typename
          }
          price {
            amount
            currency
            __typename
          }
          __typename
        }
        __typename
      }
      
      fragment FlightOrderItemFragment on OrderItem {
        ... on FlightOrderItem {
          id
          flight {
            id
            number
            origin {
              code
              displayName
              city
              state
              title
              street
              postalCode
              __typename
            }
            destination {
              code
              displayName
              city
              state
              title
              street
              postalCode
              __typename
            }
            departingTime
            arrivalTime
            isOvernight
            __typename
          }
          flightPrice: price {
            total
            subtotal
            taxesAndFees
            taxes {
              total {
                amount
                currency
                __typename
              }
              breakdown {
                name
                code
                value {
                  amount
                  currency
                  __typename
                }
                __typename
              }
              __typename
            }
            fees {
              total {
                amount
                currency
                __typename
              }
              breakdown {
                name
                code
                value {
                  amount
                  currency
                  __typename
                }
                __typename
              }
              __typename
            }
            discountValue {
              amount
              currency
              __typename
            }
            discountType
            total
            __typename
          }
          __typename
        }
        __typename
      }
      
      fragment HotelOrderItemFragment on OrderItem {
        ... on HotelOrderItem {
          id
          hotelPrice: price {
            total
            __typename
          }
          roomType
          roomsCount
          roomId
          hotelId
          hotel {
            name
            promos {
              id
              code
              headlineDescription
              __typename
            }
            __typename
          }
          checkin {
            time
            __typename
          }
          checkout {
            time
            __typename
          }
          roomsCount
          adultCount
          childrenCount
          __typename
        }
        __typename
      }
      
      fragment SeatOrderItemFragment on OrderItem {
        ... on SeatOrderItem {
          id
          flightId
          travelerId
          column
          row
          price {
            amount
            currency
            __typename
          }
          seatPrice {
            subtotal
            taxes {
              breakdown {
                name
                code
                value {
                  amount
                  __typename
                }
                __typename
              }
              total {
                amount
                currency
                __typename
              }
              __typename
            }
            taxesIncludedInBundle {
              breakdown {
                name
                code
                value {
                  amount
                  __typename
                }
                __typename
              }
              total {
                amount
                currency
                __typename
              }
              __typename
            }
            total
            isUpgradePrice
            __typename
          }
          bundledAncillaryPrice {
            amount
            __typename
          }
          isBundledAncillaryIncluded
          seatSizeId
          __typename
        }
        __typename
      }
      
      fragment TravelerAncillaryOrderItemFragment on OrderItem {
        ... on TravelerAncillaryOrderItem {
          id
          flightId
          travelerId
          ancillaryType
          quantity
          price {
            amount
            currency
            __typename
          }
          bundledAncillaryPrice {
            amount
            __typename
          }
          isBundledAncillaryIncluded
          __typename
        }
        __typename
      }
      
      fragment VehicleOrderItemFragment on OrderItem {
        ... on VehicleOrderItem {
          id
          vehiclePrice: price {
            total {
              amount
              currency
              __typename
            }
            __typename
          }
          vehicle {
            category
            code
            type
            description
            __typename
          }
          vendor {
            name
            __typename
          }
          promotions {
            id
            code
            headlineDescription
            __typename
          }
          pickUpDate
          dropOffDate
          __typename
        }
        __typename
      }
      
      fragment ItineraryAncillaryOrderItemFragment on OrderItem {
        ... on ItineraryAncillaryOrderItem {
          id
          ancillaryType
          quantity
          price {
            amount
            currency
            __typename
          }
          bundledAncillaryPrice {
            amount
            __typename
          }
          isBundledAncillaryIncluded
          __typename
        }
        __typename
      }
      
      fragment TravelersFragment on Order {
        travelers {
          id
          firstName
          lastName
          middleName
          suffix
          isPrimary
          type
          ssrs {
            code
            flightId
            title
            price {
              amount
              currency
              __typename
            }
            additionalInfo
            __typename
          }
          __typename
        }
        __typename
      }`

        let variables = `{
        "points": ${loyaltypoints}
      }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables, loginToken).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            // console.log("loyalty payment status: ", responseJson.data.addLoyaltyPayment.order.payments[0].paymentStatus)
            console.log("loyalty_points Used: ", responseJson.data.addLoyaltyPayment.order.payments[0].points)
            let balancePayment = responseJson.data.addLoyaltyPayment.order.price.balanceDue
            return balancePayment
        }).catch(function () {
            console.error("loyaltypoints payment is unsuccessful, provide req loyaltypoints");
        })
    }
    /**
 * This method performs GQL call for paymentPage
 * @param {string} env Ex: "stg" 
 * @param {string} card Ex: "MasterCard" 
 * @param {string} balancePayment Ex: balance amount after loyalty payment
 * @param {string} loginToken Ex: auth-Token generated after login
 * @param {string} travelInsurance Ex: "yes"/"no"
 *  @param {string}loginEmail Ex: test123@allegiantair.com
 *  @param {string}firstNameLoyaltyAccount Ex: Test
 *  @param {string}lastNameLoyaltyAccount Ex: A
 * @returns {string} confirmationNumber Ex: "BNG6R5" 
 */
    async paymentPage(env, card, balancePayment, loginToken, travelInsurance, loginEmail, firstNameLoyaltyAccount, lastNameLoyaltyAccount) {
        let query = `mutation bookOrder($customer: OrderCustomerInput!, $payment: OrderPaymentInput!, $registerUser: Boolean!, $upsell: [OrderUpsellInput!]) {
  bookOrder(customer: $customer, payment: $payment, registerUser: $registerUser, upsell: $upsell) {
    order {
      confirmationNumber
      __typename
    }
    errors
    __typename
  }
}`
        let {
            creditCardNum,
            creditCardCvv,
        } = await CardNumbers.getCreditCardNumbers(card)
        let cardDetails = await CardDetails.getEncryptedValues(creditCardNum, creditCardCvv, env);
        let encryptCC = cardDetails[0]
        let encryptCvv = cardDetails[1]
        let upsellVariable

        if (travelInsurance === 'yes') {
            upsellVariable = `[{
        "type": "TRAVEL_INSURANCE"
      }]`
            await this.travelInsuranceOption(loginToken, env)
        } else {
            upsellVariable = `[]`
        }

        let variables
        if (balancePayment !== '') {
            if (balancePayment === 0) {
                if(firstNameLoyaltyAccount!==undefined){
                    variables = `{
            "customer": {
              "firstName": "${firstNameLoyaltyAccount}",
              "lastName": "${lastNameLoyaltyAccount}",
              "email": "${loginEmail}",
              "alternateEmail": "",
              "password": "",
              "passwordRepeat": "",
              "subscribeToNewsletter": false
            },
            "payment": {
              "creditCardPayment": null,
              "instantCreditCardPayment": null,
              "billingAddress": {
                "line1": "Test",
                "line2": "Test",
                "countryCode": "US",
                "stateCode": "CO",
                "city": "test",
                "postalCode": "20170"
              },
              "billingPhone": {
                "number": "45445656767778",
                "type": "NOT_SELECTED",
                "countryCode": "US",
                "prefixCode": "1"
              }
            },
            "registerUser": true,
            "upsell": ${upsellVariable}
          }`
                }
            } else {
                if(firstNameLoyaltyAccount!==undefined){
                    variables = `{
    "customer": {
      "firstName": "${firstNameLoyaltyAccount}",
      "lastName": "${lastNameLoyaltyAccount}",
      "email": "${loginEmail}",
      "alternateEmail": "",
      "password": "",
      "passwordRepeat": "",
      "subscribeToNewsletter": false
    },
 "payment": {
                  "creditCardPayment": {
                    "type": "CREDIT_CARD",
                   "number": "${encryptCC}",
                    "cvv": "${encryptCvv}",
                    "encryptionType": "PIE",
                    "cardHolderName": "Adult A",
                    "expireMonth": 12,
                    "expireYear": 2030,
                    "shouldStoreCard": false
                  },
                  "instantCreditCardPayment": null,
                  "billingAddress": {
                    "line1": "New Colony",
                    "line2": "",
                    "countryCode": "US",
                    "stateCode": "NY",
                    "city": "New York",
                    "postalCode": "89113"
                  },
                  "billingPhone": {
                    "number": "7025551111",
                    "type": "NOT_SELECTED",
                    "countryCode": "US",
                    "prefixCode": "1"
                  }
                },
                "registerUser": true,
                "upsell": ${upsellVariable}
              }`
                }else{
                    variables = `{
                "customer": {
                  "firstName": "Adult",
                  "lastName": "A",
                  "email": "accept@fraudtest.com",
                  "alternateEmail": "accept@fraudtest.com",
                  "password": "",
                  "passwordRepeat": "",
                  "subscribeToNewsletter": false
                },
                "payment": {
                  "creditCardPayment": {
                    "type": "CREDIT_CARD",
                   "number": "${encryptCC}",
                    "cvv": "${encryptCvv}",
                    "encryptionType": "PIE",
                    "cardHolderName": "Adult A",
                    "expireMonth": 12,
                    "expireYear": 2030,
                    "shouldStoreCard": false
                  },
                  "instantCreditCardPayment": null,
                  "billingAddress": {
                    "line1": "New Colony",
                    "line2": "",
                    "countryCode": "US",
                    "stateCode": "NY",
                    "city": "New York",
                    "postalCode": "89113"
                  },
                  "billingPhone": {
                    "number": "7025551111",
                    "type": "NOT_SELECTED",
                    "countryCode": "US",
                    "prefixCode": "1"
                  }
                },
                "registerUser": true,
                "upsell": ${upsellVariable}
              }`

                }
            }
        }else{
            variables = `{
           "customer": {
             "firstName": "Adult",
             "lastName": "A",
             "email": "accept@fraudtest.com",
             "alternateEmail": "accept@fraudtest.com",
             "password": "",
             "passwordRepeat": "",
             "subscribeToNewsletter": false
           },
           "payment": {
             "creditCardPayment": {
               "type": "CREDIT_CARD",
              "number": "${encryptCC}",
               "cvv": "${encryptCvv}",
               "encryptionType": "PIE",
               "cardHolderName": "Adult A",
               "expireMonth": 12,
               "expireYear": 2030,
               "shouldStoreCard": false
             },
             "instantCreditCardPayment": null,
             "billingAddress": {
               "line1": "New Colony",
               "line2": "",
               "countryCode": "US",
               "stateCode": "NY",
               "city": "New York",
               "postalCode": "89113"
             },
             "billingPhone": {
               "number": "7025551111",
               "type": "NOT_SELECTED",
               "countryCode": "US",
               "prefixCode": "1"
             }
           },
           "registerUser": true,
           "upsell": ${upsellVariable}
         }`

        }
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables, loginToken).then((response) => {
            let confNumber
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                confNumber = responseJson.data.bookOrder.order.confirmationNumber;
            } catch (err) {
                throw new Error("Payment was Failed")
            }
            return {
                confNumber,
                encryptCC,
                encryptCvv,
            }
        })
    }

    /**
 * This method select Travel Insurance in payment page
 * @param {string} loginToken Ex: auth-Token generated after login
 * @param {string} env Ex: "stg01.aws" 
 */
    async travelInsuranceOption(loginToken, env) {
        let query = `query travelInsurance($criteria: UpsellQuoteInput!) {
        upsellQuote(criteria: $criteria) {
          quote {
            __typename
            ... on TravelInsuranceQuote {
              content
              quoteId
              totalPrice
              __typename
            }
          }
          errors
          __typename
        }
      }`

        let variables = `{
  "criteria": {
    "type": "TRAVEL_INSURANCE",
    "travelInsuranceCriteria": {
      "customerAddress": {
        "countryCode": "US",
        "postalCode": "89113",
        "stateCode": "NY",
        "phone": null
      }
    }
  }
}`

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables, loginToken).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                let insurancePrice = responseJson.data.upsellQuote.quote.totalPrice
                console.log("Travel Insurance Price is:-", insurancePrice)
            } catch (err) {
                console.error("Travel Insurance is Not available in env = " + env)
            }
        })
    }

}