module.exports = class Bags {

    /**
* This is constructer for Bags Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }

    /**
* This method performs GQL call for bagSelection
* @param {*} travelerid Ex:1
* @param {*} departureFlightId Ex:"2022-06-12-AW-1"
* @param {*} returningFlightId Ex:"2022-06-12-AW-1"
* @param {*} bagsPageQty Ex:"1Dep:1Return:2Both:1"(checked bag and carryon bag quantity will be taken from this)
* @param {*} bundleType Ex:"total"
*/
    async bagSelection(travelerid, departureFlightId, returningFlightId, bagsPageQty, bundleType) {
        let query = `mutation selectTravelerAncillaries($travelersAncillaries: [TravelerAncillaryInput!]!) {
            selectTravelerAncillaries(travelersAncillaries: $travelersAncillaries) {
              order {
                items {
                  id
                  ... on TravelerAncillaryOrderItem {
                    flightId
                    travelerId
                    ancillaryType
                    quantity
                    price {
                      amount
                      currency
                      __typename
                    }
                    bundledAncillaryPrice {
                      amount
                      __typename
                    }
                    isBundledAncillaryIncluded
                    __typename
                  }
                  __typename
                }
                price {
                  total
                  __typename
                }
                __typename
              }
              errors
              __typename
            }
          }`

        /**
* Note: CIB-> CHECK-IN-BAG and COB -> CARRY_ON_BAG
* @param {*} bagsArray - array variable used to push bags details
* @param {*} bagsObject - object variable to store bags details
*@param {*} bagsPageQty-quantity of items
*/
        let CIQuantity, CIQuantity2, COQuantity, COQuantity2
        let CIQty, CIQty2
        let bagsObject = {}
        let bagsArray = []
        CIQty = bagsPageQty[0].charAt(0)
        CIQuantity = 0
        if (bagsPageQty[0].includes("Dep") || bagsPageQty[0].includes("Both") || bundleType === "total" || bundleType === "bonus" || bundleType === "basic") {

            if (bagsPageQty[0].includes("Dep") || bagsPageQty[0].includes("Both")) {

                CIQuantity = CIQty
                if (bundleType === "total" || bundleType === "bonus") {
                    if (CIQuantity <= 0) {
                        CIQuantity = 1;
                    }
                }
            }
            else {
                CIQuantity = CIQty
                if (bundleType === "total" || bundleType === "bonus") {
                    if (CIQuantity <= 0) {
                        CIQuantity = 1;
                    }
                    // else if (CIQty <= 0) {
                    //     CIQuantity = 1;
                    // }
                    // else {
                    //   CIQuantity = CIQty
                    // }
                }

            }
            let CIBdepartDetails = `{
              "flightId": "${departureFlightId}",
              "travelerId": "${travelerid}",
              "type": "CHECK_IN_BAG",
              "quantity": "${CIQuantity}"
            }`
            travelerid.forEach((id) => {
                let newCIBdepartDetails = JSON.parse(CIBdepartDetails)
                newCIBdepartDetails.travelerId = id;
                bagsArray.push(newCIBdepartDetails);
            })
        }



        CIQty2 = bagsPageQty[0].charAt(0)
        CIQuantity2 = 0
        if (bagsPageQty[0].includes("Return") || bagsPageQty[0].includes("Both") || bundleType === "total" || bundleType === "bonus" || bundleType === "basic") {
            if (returningFlightId !== undefined) {

                if (bagsPageQty[0].includes("Return") || bagsPageQty[0].includes("Both")) {

                    CIQuantity2 = CIQty2
                    if (bundleType === "total" || bundleType === "bonus") {
                        if (CIQuantity2 <= 0) {
                            CIQuantity2 = 1;
                        }
                    }
                }
                else {
                    CIQuantity2 = CIQty2
                    if (bundleType === "total" || bundleType === "bonus") {
                        if (CIQuantity2 <= 0) {
                            CIQuantity2 = 1;
                        }
                        // else if (CIQty2 <= 0) {
                        //     CIQuantity2 = 1;
                        // }
                        // else {
                        //     CIQuantity2 = CIQty2
                        // }
                    }
                }
            }
            let CIBreturnDetails = `{
        "flightId": "${returningFlightId}",
        "travelerId": "${travelerid}",
        "type": "CHECK_IN_BAG",
        "quantity": "${CIQuantity2}"    
      }`
            travelerid.forEach((id) => {
                let newCIBreturnDetails = JSON.parse(CIBreturnDetails);
                newCIBreturnDetails.travelerId = id;
                bagsArray.push(newCIBreturnDetails);
            })
        }





        let COQty, COQty2
        COQty = bagsPageQty[1].charAt(0)
        COQuantity = 0
        if (bagsPageQty[1].includes("Dep") || bagsPageQty[1].includes("Both") || bundleType === "total" || bundleType === "bonus" || bundleType === "basic") {


            if (bagsPageQty[1].includes("Dep") || bagsPageQty[1].includes("Both")) {

                COQuantity = COQty
                if (bundleType === "total" || bundleType === "basic") {
                    //if bags are 0,the bag quantity will be by default added 
                    if (COQuantity <= 0) {
                        COQuantity = 1;
                    }

                }
            }
            else {
                COQuantity = COQty
                if (bundleType === "total" || bundleType === "basic") {
                    if (COQuantity <= 0) {
                        COQuantity = 1;
                    }
                    // else if (COQty <= 0) {
                    //     COQuantity = 1;
                    // }
                    // else {
                    //     COQuantity = COQty
                    // }
                }

            }
            let COBdepartDetails = `{
            "flightId": "${departureFlightId}",
            "travelerId": "${travelerid}",
            "type": "CARRY_ON_BAG",
            "quantity": "${COQuantity}"
          }`
            travelerid.forEach((id) => {
                let newCOBdepartDetails = JSON.parse(COBdepartDetails);
                newCOBdepartDetails.travelerId = id;
                bagsArray.push(newCOBdepartDetails);
            })
        }


        COQty2 = bagsPageQty[1].charAt(0)
        COQuantity2 = 0
        if (bagsPageQty[1].includes("Return") || bagsPageQty[1].includes("Both") || bundleType === "total" || bundleType === "bonus" || bundleType === "basic") {
            if (returningFlightId !== undefined) {

                if (bagsPageQty[1].includes("Return") || bagsPageQty[1].includes("Both")) {

                    COQuantity2 = COQty2
                    if (bundleType === "total" || bundleType === "basic") {
                        if (COQuantity2 <= 0) {
                            COQuantity2 = 1;
                        }

                    }
                }
                else {
                    COQuantity2 = COQty2
                    if (bundleType === "total" || bundleType === "basic") {
                        if (COQuantity2 <= 0) {
                            COQuantity2 = 1;
                        }
                        // else if (COQty2 <= 0) {
                        //     COQuantity2 = 1;
                        // }
                        // else {
                        //     COQuantity2 = COQty2
                        // }
                    }
                }
            }
            let COBreturnDetails = `{
          "flightId": "${returningFlightId}",
          "travelerId": "${travelerid}",
          "type": "CARRY_ON_BAG",
          "quantity": "${COQuantity2}"
        }`
            travelerid.forEach((id) => {
                let newCOBreturnDetails = JSON.parse(COBreturnDetails);
                newCOBreturnDetails.travelerId = id;
                bagsArray.push(newCOBreturnDetails);
            })
        }



        bagsObject.travelersAncillaries = bagsArray
        let variables = JSON.stringify(bagsObject)

        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                responseJson.data.selectTravelerAncillaries.order
            } catch (err) {
                throw new Error("traveler bags details are not available")
            }
            return responseJson.data.selectTravelerAncillaries.order
        })
    }

    /**
* This method performs GQL call for tripFlexSelection
* @param {integer} bagsPageQty Ex: 0/1 (Trip Flex Quantity)
*/
    async tripFlexSelection(bagsPageQty) {
        let query = `mutation selectItineraryAncillaries($itineraryAncillaries: [ItineraryAncillaryInput!]!) {
            selectItineraryAncillaries(itineraryAncillaries: $itineraryAncillaries) {
              order {
                price {
                  total
                  balanceDue
                  __typename
                }
                items {
                  id
                  ... on ItineraryAncillaryOrderItem {
                    ancillaryType
                    quantity
                    price {
                      amount
                      currency
                      __typename
                    }
                    isBundledAncillaryIncluded
                    __typename
                  }
                  __typename
                }
                payments {
                  ... on PromoPayment {
                    id
                    description
                    total {
                      amount
                      currency
                      __typename
                    }
                    __typename
                  }
                  __typename
                }
                __typename
              }
              errors
              __typename
            }
          }`
        let tripflexQty
        if (bagsPageQty[3]) {
            tripflexQty = bagsPageQty[3];
        }
        else {
            tripflexQty = 0;
        }
        let variables = `{
              "itineraryAncillaries": [
                {
                  "type": "TRIP_FLEX",
                  "quantity": "${tripflexQty}"
                }
              ]
            }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                responseJson.data.selectItineraryAncillaries.order
            } catch (err) {
                throw new Error("tripflex details not ,Hence Booking was unsuccessful")
            }
            return responseJson.data.selectItineraryAncillaries.order
        })
    }

    /**
*  This function is used for priorityAccessSelection
* @param {*} travelerid - contains travelerid
* @param {*} departureFlightId - contains travelerid
* @param {*} returningFlightId - contains travelerid
* @param {*} bagsPageQty - contains quantity for priorityAccess
* @param {*} bundleType Ex:"total"
* @returns {string} ancillaries order value
*/
    async priorityAccessSelection(travelerid, departureFlightId, returningFlightId, bagsPageQty, bundleType) {
        let query = `mutation selectTravelerAncillaries($travelersAncillaries: [TravelerAncillaryInput!]!) {
        selectTravelerAncillaries(travelersAncillaries: $travelersAncillaries) {
          order {
            items {
              id
              __typename
            }
            price {
              total
              balanceDue
              __typename
            }
            __typename
          }
          errors
          __typename
        }
      }`
        let PAQuantity, PAQuantity2

        let PAQty, PAQty2
        PAQty = bagsPageQty[2].charAt(0)
        let priorityObj = {}
        let PriorityArray = []
        PAQuantity = 0
        if (bagsPageQty[2].includes("Dep") || bagsPageQty[2].includes("Both") || bundleType === "total" || bundleType === "bonus" || bundleType === "basic") {

            if (bagsPageQty[2].includes("Dep") || bagsPageQty[2].includes("Both")) {

                PAQuantity = PAQty
                if (bundleType === "total" || bundleType === "bonus") {
                    if (PAQuantity <= 0) {
                        PAQuantity = 1
                    }
                }
            }
            else {
                PAQuantity = PAQty
                if (bundleType === "total" || bundleType === "bonus") {
                    if (PAQuantity <= 0) {
                        PAQuantity = 1;
                    }
                    // else if (PAQty <= 0) {
                    //     PAQuantity = 1;
                    // }
                    // else {
                    //     PAQuantity = PAQty
                    // }
                }
            }
            let priorityDepartDetails = `{
              "type": "PRIORITY_BOARDING",
              "travelerId": "${travelerid}",
              "flightId": "${departureFlightId}",
              "quantity": "${PAQuantity}"
              }`
            travelerid.forEach((id) => {
                let newpriorityDepartDetails = JSON.parse(priorityDepartDetails);
                newpriorityDepartDetails.travelerId = id;
                PriorityArray.push(newpriorityDepartDetails)
            })
        }
        PAQty2 = bagsPageQty[2].charAt(0)
        PAQuantity2 = 0
        if (bagsPageQty[2].includes("Return") || bagsPageQty[2].includes("Both") || bundleType === "total" || bundleType === "basic") {
            if (returningFlightId !== undefined) {

                if (bagsPageQty[2].includes("Return") || bagsPageQty[2].includes("Both")) {

                    PAQuantity2 = PAQty2
                    if (bundleType === "total") {
                        if (PAQuantity2 <= 0) {
                            PAQuantity2 = 1
                        }
                    }
                }
                else {
                    PAQuantity2 = PAQty2
                    if (bundleType === "total") {
                        if (PAQuantity2 <= 0) {
                            PAQuantity2 = 1;
                        }
                        // else if (PAQty2 <= 0) {
                        //     PAQuantity2 = 1;
                        // }
                        // else {
                        //     PAQuantity2 = PAQty2
                        // }
                    }
                }
                let priorityReturnDetails = `{
    "type": "PRIORITY_BOARDING",
    "travelerId": "${travelerid}",
    "flightId": "${returningFlightId}",
    "quantity": "${PAQuantity2}"
  }`
                travelerid.forEach((id) => {
                    let newpriorityReturnDetails = JSON.parse(priorityReturnDetails);
                    newpriorityReturnDetails.travelerId = id;
                    PriorityArray.push(newpriorityReturnDetails)
                })
            }

        }


        priorityObj.travelersAncillaries = PriorityArray;
        let variables = JSON.stringify(priorityObj);
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                responseJson.data.selectTravelerAncillaries.order
            } catch (err) {
                throw new Error("priority Boarding details are not available")
            }
            return responseJson.data.selectTravelerAncillaries.order
        })
    }


    /**
* This function is used for petInCabinSelection
* @param {*} travelerid - contains travelerid
* @param {*} departureFlightId - contains departureFlightId
* @param {*} returningFlightId - contains returningFlightId
* @param {string} petInCabinSSR - contains petincabin and SSR
* @returns {string} traveller information
*/
    async petInCabinSelection(travelerid, departureFlightId, returningFlightId, petInCabinSSR) {
        let query = `mutation updateOrderTravelerSsrs($ssrs: [SsrInput!]!) {
        updateOrderTravelerSsrs(ssrs: $ssrs) {
          order {
            price {
              total
              balanceDue
              __typename
            }
            items {
              id
              ... on FlightOrderItem {
                seatmap {
                  rows {
                    id
                    items {
                      ... on FlightSeat {
                        id
                        seatRestrictions
                        isRestrictedBySSR
                        isAvailable
                        isExitRow
                        __typename
                      }
                      __typename
                    }
                    __typename
                  }
                  __typename
                }
                __typename
              }
              __typename
            }
            travelers {
              id
              ssrs {
                code
                flightId
                title
                price {
                  amount
                  currency
                  __typename
                }
                additionalInfo
                __typename
              }
              __typename
            }
            payments {
              ... on PromoPayment {
                id
                description
                total {
                  amount
                  currency
                  __typename
                }
                __typename
              }
              __typename
            }
            __typename
          }
          errors
          __typename
        }
      }`

        let petInCabinObject = {}
        let petDepartDetails = `{
      "code": "PETC",
      "travelerId": "${travelerid}",
      "flightId": "${departureFlightId}",
      "additionalInfo": null
    }`
        travelerid.forEach((id) => {
            let newPetDepartDetails = JSON.parse(petDepartDetails);
            newPetDepartDetails.travelerId = id;
            petInCabinSSR.push(newPetDepartDetails)
        })
        if (returningFlightId !== undefined) {
            let petReturnDetails = `{
      "code": "PETC",
      "travelerId": "${travelerid}",
      "flightId": "${returningFlightId}",
      "additionalInfo": null
    }`
            travelerid.forEach((id) => {
                let newPetReturnDetails = JSON.parse(petReturnDetails);
                newPetReturnDetails.travelerId = id;
                petInCabinSSR.push(newPetReturnDetails)
            })
        }
        petInCabinObject.ssrs = petInCabinSSR;
        let variables = JSON.stringify(petInCabinObject)
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                return responseJson.data.updateOrderTravelerSsrs.order.travelers
            }
            catch (err) {
                console.error("pet in cabin is Not available")
            }
        })
    }

}