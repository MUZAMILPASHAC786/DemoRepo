module.exports = class Bundles {

    /**
* This is constructer for Bundles Call
* @param {*} GqlCall is object of GQL booking class
* @param {*} transactionId is the transactionIf of the flow
*/
    constructor(GqlCall, transactionId) {
        this.GqlCall = GqlCall;
        this._transactionId = transactionId;
    }

    /**
* This method selects bundles based on the input
* @param {string} tripType Ex: "ROUNDTRIP" / "ONEWAY"
* @param {string} origin Ex: "LAS"
* @param {string} destination Ex : "MEX"
* @param {string} departDate Ex: "2022-06-12"
* @param {string} returnDate Ex: "2022-06-12"
*/
    async bundleSelection(tripType, origin, destination, departDate, returnDate) {
        let bundleDetailsQuery = `query bundles($origin: IataCode, $destination: IataCode, $departureDate: DateTime, $returnDate: DateTime) {
application(name: DESKTOPBOOKINGPATH) {
... on DesktopBookingPath {
destinationAdverts(filters: {section: BOOKING_BUNDLES, position: BOTTOM, origin: $origin, destination: $destination, departureDate: $departureDate, returningDate: $returnDate}) {
  content
  position
  __typename
}
__typename
}
__typename
}
order {
items {
id
... on BundleOrderItem {
  bundle {
    id
    tier
    name
    icon
    banner
    discount {
      ... on PercentDiscount {
        value
        __typename
      }
      ... on FlatDiscount {
        amount
        currency
        __typename
      }
      __typename
    }
    discountType
    ancillaries {
      type
      name
      numberOfIncludedItems
      price {
        amount
        currency
        __typename
      }
      strikethruPrice {
        amount
        currency
        __typename
      }
      discount {
        amount
        currency
        __typename
      }
      __typename
    }
    originalPricePerParty {
      amount
      currency
      __typename
    }
    bundlePricePerParty {
      amount
      currency
      __typename
    }
    originalPricePerPerson {
      amount
      currency
      __typename
    }
    bundlePricePerPerson {
      amount
      currency
      __typename
    }
    savingsPerParty {
      amount
      currency
      __typename
    }
    savingsPerPerson {
      amount
      currency
      __typename
    }
    __typename
  }
  __typename
}
... on FlightOrderItem {
  flight {
    id
    origin {
      code
      __typename
    }
    destination {
      code
      __typename
    }
    __typename
  }
  __typename
}
__typename
}
qualifyingBundledAncillaries {
maxSavedPrice {
  amount
  currency
  __typename
}
maxSavedPriceFor
list {
  id
  tier
  name
  icon
  banner
  discount {
    ... on PercentDiscount {
      value
      __typename
    }
    ... on FlatDiscount {
      amount
      currency
      __typename
    }
    __typename
  }
  discountType
  ancillaries {
    type
    name
    numberOfIncludedItems
    price {
      amount
      currency
      __typename
    }
    strikethruPrice {
      amount
      currency
      __typename
    }
    discount {
      amount
      currency
      __typename
    }
    __typename
  }
  originalPricePerParty {
    amount
    currency
    __typename
  }
  bundlePricePerParty {
    amount
    currency
    __typename
  }
  originalPricePerPerson {
    amount
    currency
    __typename
  }
  bundlePricePerPerson {
    amount
    currency
    __typename
  }
  savingsPerParty {
    amount
    currency
    __typename
  }
  savingsPerPerson {
    amount
    currency
    __typename
  }
  __typename
}
allAncillariesList {
  type
  name
  icon
  __typename
}
__typename
}
__typename
}
}`;

        let bundleDetailsVariables
        if (tripType === "ROUNDTRIP") {
            bundleDetailsVariables = `{
  "origin": "${origin}",
  "destination": "${destination}",
  "departureDate": "${departDate}",
  "returningDate": "${returnDate}"
  }`;
        } else {
            bundleDetailsVariables = `{
  "origin": "${origin}",
  "destination": "${destination}",
  "departureDate": "${departDate}"
  }`;
        }
        return await this.GqlCall.graphQlCall(this._transactionId, bundleDetailsQuery, bundleDetailsVariables)

    }
    /**
* This method performs bundle mutatoin gql calll
* @param {*} bundleType Ex : "bonus" / "total"
* @returns {string} bundle information
*/
    async bundlemutation(bundleType) {
        let bundleTypeSelectionQuery = ` mutation continueButtonMutation($tier: Int!) {
selectBundledAncillary(tier: $tier) {
order {
...BundlePageMutationResponse
__typename
}
errors
__typename
}
}

fragment BundlePageMutationResponse on Order {
price {
total
__typename
}
items {
id
... on BundleOrderItem {
bundle {
  id
  name
  tier
  __typename
}
__typename
}
... on FlightOrderItem {
flight {
  id
  origin {
    code
    __typename
  }
  destination {
    code
    __typename
  }
  __typename
}
seatmap {
  ...seatPlanFragment
  __typename
}
__typename
}
__typename
}
__typename
}

fragment seatPlanFragment on FlightSeatmap {
colsMap
seatSizesMap {
id
name
legroomStars
__typename
}
rows {
id
hasLeftExit
hasRightExit
items {
... on FlightSeat {
  type
  id
  price {
    amount
    currency
    __typename
  }
  seatPrice {
    subtotal
    taxes {
      breakdown {
        name
        code
        value {
          amount
          __typename
        }
        __typename
      }
      total {
        amount
        currency
        __typename
      }
      __typename
    }
    taxesIncludedInBundle {
      breakdown {
        name
        code
        value {
          amount
          __typename
        }
        __typename
      }
      total {
        amount
        currency
        __typename
      }
      __typename
    }
    total
    isUpgradePrice
    __typename
  }
  position
  sizeId
  isAvailable
  isExitRow
  isIncludedInBundle
  __typename
}
... on FlightRowBlank {
  type
  __typename
}
... on FlightRowAisle {
  type
  __typename
}
__typename
}
__typename
}
__typename
}`;

        let tierNo;
        if (bundleType.toLowerCase() === "total") {
            tierNo = 3;
        }
        else if (bundleType.toLowerCase() === "bonus") {
            tierNo = 2;
        }
        else if (bundleType.toLowerCase() === "basic") {
            tierNo = 1;
        }

        let bundleTypeSelectionVariables = `{
"tier": ${tierNo}
}`;

        return await this.GqlCall.graphQlCall(this._transactionId, bundleTypeSelectionQuery, bundleTypeSelectionVariables).then((response) => {
            let responseJson = JSON.parse(JSON.stringify(response));
            try {
                responseJson.data.selectBundledAncillary.order.items[2].bundle
            }
            catch (err) {
                throw new Error("Bundles are not available, as bundleType data was incorrect")
            }
            return responseJson.data.selectBundledAncillary.order.items[2].bundle
        })
    }
}

