module.exports = class Raiders {

    /**
* This is constructer for Raiders Call
* @param {*} GqlCall is object of GQL booking class
*/
    constructor(GqlCall) {
        this.GqlCall = GqlCall;
        this._transactionId = '';
    }
    /**
* This method gets the product ID Ex:33,32
*/
    async stadiumConfig() {
        let query = `query getStadiumConfig {
        application(name: DESKTOPBOOKINGPATH) {
          ... on DesktopBookingPath {
            configurations {
              allegiantStadiumProductIds
              allegiantStadiumBookingCacheCounter
              __typename
            }
            __typename
          }
          __typename
        }
      }`

        return await this.GqlCall.graphQlCall(this._transactionId, query).then((response) => {
            let productID
            try {
                let responseJson = JSON.parse(JSON.stringify(response));
                productID = responseJson.data.application.configurations.allegiantStadiumProductIds
            } catch (err) {
                throw new Error("Raiders details are not available")
            }
            return productID;
        })
    }
    /**
* This method gets game date
* @param {string} productID Ex : 32
* @returns {*} game date
**/
    async showsAvailability(productID) {
        let splitYear, splitMonth, splitDate
        let query = `query showsAvailability($showAvailabilitySearchCriteria: ShowAvailabilitySearchInput!) {
      transactionId
      showsAvailability(showAvailabilitySearchCriteria: $showAvailabilitySearchCriteria) {
        result {
          useDate
          quantity
          showConditions
          __typename
        }
        errors
        __typename
      }
    }`
        var dates = new Date().toISOString().split("T")[0]
        /**
* This method splits the date 
* @param {*} date Ex:"2023-09-19"
*/
        function dateSplit(date) {
            splitYear = parseInt(date.split('-')[0])
            splitMonth = parseInt(date.split('-')[1])
            splitDate = parseInt(date.split('-')[2])
        }
        dateSplit(dates)
        var nextD
        if (splitDate === 31) {
            if (splitMonth === '1' || splitMonth === '3' || splitMonth === '5' || splitMonth === '7' || splitMonth === '8' || splitMonth === '10' || splitMonth === '12') {
                nextD = (splitYear + '-' + (('0' + (splitMonth)).slice(-2)) + '-01')
            }
        } else if (splitMonth === 2) {
            if (splitDate === '29' || splitDate === "28") {
                nextD = (splitYear + '-' + (('0' + (splitMonth)).slice(-2)) + '-01')
            }
        } else if (splitDate === 30) {
            if (splitMonth === '4' || splitMonth === '6' || splitMonth === '9' || splitMonth === '11') {
                nextD = (splitYear + '-' + (('0' + (splitMonth)).slice(-2)) + '-01')
            }
        } else {
            nextD = (splitYear + '-' + ('0' + (splitMonth)).slice(-2) + '-' + ('0' + (splitDate + 1)).slice(-2))
        }

        var currentD = ((splitYear + 1) + '-' + ('0' + (splitMonth)).slice(-2) + '-' + ('0' + splitDate).slice(-2))
        let variable
        //     if (config3 !== '') {
        variable = `{
      "showAvailabilitySearchCriteria": {
        "startDate": "${nextD.replace("'", "")}",
        "endDate": "${currentD.replace("'", "")}",
        "productIds": [
          ${productID}
        ],
        "showConditions": [
          "PACKAGE_ID",
          "OPPONENT_NAME",
          "OPPONENT_CITY",
          "SECTION_NUMBER"
        ]
      }
    }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variable).then((response) => {
            let responseJson
            let gameAvailableDate = []
            try {
                responseJson = JSON.parse(JSON.stringify(response));

                for (let j = 0; j < responseJson.data.showsAvailability.result.length; j++) {
                    if (responseJson.data.showsAvailability.result[j].quantity !== 0) {
                        gameAvailableDate.push(responseJson.data.showsAvailability.result[j].useDate)

                    }

                }
                if (gameAvailableDate.length === 0) {
                    throw new Error("Raiders Tickets are not available")
                }
            } catch (err) {
                throw new Error("Raiders details are not available")
            }
            let transactionid = responseJson.data.transactionId
            this._transactionId = transactionid
            return {
                gameAvailableDate,
                transactionid,
            };
        })
    }
    /**
* This method gets available seat array for game
* @param {string} gameAvailableDate Ex: "2023-09-08"
* @param {string} productID Ex : 32
* @param {string} destination Ex : "LAS"
* @param {string} travelersCountForRaidersBooking Ex : 1
* @param {string} flagForRaidersBooking Ex : 1
* @returns {Array} seatArray
*/
    async raidersBooking(gameAvailableDate, productID, destination, travelersCountForRaidersBooking, flagForRaidersBooking) {
        let seatarr = []
        let query = `query stadiumShows($showSearchCriteria: ShowSearchInput!) {
        shows(showSearchCriteria: $showSearchCriteria) {
          result {
            name
            description
            categories {
              id
              meta
              description
              rates {
                date
                availableQuantity
                price {
                  total
                  __typename
                }
                __typename
              }
              __typename
            }
            __typename
          }
          errors
          __typename
        }
      }`
        let gameDate = gameAvailableDate[flagForRaidersBooking]
        if (flagForRaidersBooking >= (gameAvailableDate.length)) {
            throw new Error("No sufficient seats in stadium for the traveler count provided ")
        }
        let variables = `{
        "showSearchCriteria": {
          "locationCode":"${destination}" ,
          "startDate": "${gameDate.replace("'", "")}",
          "endDate": "${gameDate.replace("'", "")}",
          "productIds": [
            ${productID}
          ]
        }
      }`
        return await this.GqlCall.graphQlCall(this._transactionId, query, variables).then((response) => {
            let responseJson
            try {
                responseJson = JSON.parse(JSON.stringify(response));
       
                // let seatLength = responseJson.data.shows.result[0].categories.length
                // if (travelersCountForRaidersBooking <= seatLength) {
                for (let i = 0; i < (responseJson.data.shows.result[0].categories.length); i++) {
                    if((responseJson.data.shows.result[0].categories[i].rates.length)!==0){
                        if((responseJson.data.shows.result[0].categories[i].rates[0].availableQuantity)!==0)
                        {
                            seatarr.push(responseJson.data.shows.result[0].categories[i].id)
                        }
                    }
                }
                if (travelersCountForRaidersBooking <= seatarr.length) {
                    console.log("seats are available in stadium for the travelers count provided")
                }
                else {
                    seatarr = []
                }
            } catch (err) {
                throw new Error("seats are not available in stadium for the traveler count provided")
            }
            return seatarr
        })
    }
    /**
* This method performs ticket booking for raiders
* @param {String} seatarr Ex: MJK778
* @param {String} gameDateSelected Ex: 2023-09-19
* @param {String} travelerid Ex: 1
*/
    async selectShowAfterFlight(seatarr, gameDateSelected, travelerid) {
        let query = `mutation selectShow($showDate: Date!, $selectShowDetails: [SelectShowInput!]!) {
          selectShow(showDate: $showDate, selectShowDetails: $selectShowDetails) {
            order {
              status
              __typename
            }
            errors
            __typename
          }
        }`
        let selectShowDetailsArray = []
        for (let i = 0; i < travelerid.length; i++) {
            let showDetails = `{
        "categoryId": "${seatarr[i]}",
        "quantity": 1,
        "usedByTravelers": [
          ${i + 1}
        ]
      }`
            selectShowDetailsArray.push(showDetails)

        }
        let variables = `{
      "showDate": "${gameDateSelected.replace("'", "")}",
      "selectShowDetails": [
        ${selectShowDetailsArray}
      ]
    }`
        await this.GqlCall.graphQlCall(this._transactionId, query, variables).catch(function () {
            throw new Error("Raiders Booking failed");
        })
    }

}