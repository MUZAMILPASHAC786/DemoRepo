const ping = require('ping')
/**
 * This Class is used to encrypt and get card details
 */
class CommonMethods {
    /**
     * Thi function returns time based on arrival time
     * @param {*} date This is arrival time
     * @returns {*} time calculated time
     */
    getTimeBasedOnArrivalTime(date) {
        let dateObj = new Date(date)
        let month = dateObj.getMonth() + 1;
        let hours = dateObj.getHours();
        let minutes = dateObj.getMinutes();
        let seconds = dateObj.getSeconds();
        let currDate = dateObj.getDate()

        if (minutes > 0 && minutes < 30) {
            hours = hours + 1;
            minutes = '00';
        } else {
            hours = hours + 1;
            minutes = 30;
        }

        return dateObj.getFullYear() + '-' + (month < 10 ? '0' + (month) : month) + '-' +  (currDate < 10 ? '0' + (currDate) : currDate) + 'T' + hours + ':' + minutes + ':' + (seconds === 0 ? '00' : seconds)
    }
    /**
     * Thi function returns time based on return flight depart time
     * @param {*} date This is return flight depart time
     * @returns {*} time calculated time
     */
    getTimeBasedOnReturnDepartTime(date) {
        let dateObj = new Date(date)
        let month = dateObj.getMonth() + 1;
        let hours = dateObj.getHours();
        let minutes = dateObj.getMinutes();
        let seconds = dateObj.getSeconds();
        let currDate = dateObj.getDate()
 
        if (minutes > 0 && minutes < 30) {
            hours = hours - 1;
            minutes = '30';
        } else {
            hours = hours - 1;
            minutes = '00';
        }
 
        return dateObj.getFullYear() + '-' + (month < 10 ? '0' + (month) : month) + '-' +  (currDate < 10 ? '0' + (currDate) : currDate) + 'T' + hours + ':' + minutes + ':' + (seconds === 0 ? '00' : seconds)
    }
    /**
     * This function returns date added by specified days
     * @param {*} date This is arrival time date
     * @param {*} days days to be added
     * @returns {*} time calculated time
     */
    addDays(date, days) {

        let dateObj = new Date(date)       
        let hours = dateObj.getHours(); 
        let minutes = dateObj.getMinutes();
        let seconds = dateObj.getSeconds();
        dateObj.setDate(dateObj.getDate() + days);
        let month = dateObj.getMonth() + 1;
        let dateVal = dateObj.getDate();

        if (hours === 0){
            hours = '00'
        }else if(hours < 10){
            hours = '0' + hours
        }

        if (minutes === 0){
            minutes = '00'
        }else if(minutes < 10){
            minutes = '0' + minutes
        }

        if (seconds === 0){
            seconds = '00'
        }else if(seconds < 10){
            seconds = '0' + seconds
        }
        
        // eslint-disable-next-line max-len
        return dateObj.getFullYear() + '-' + (month < 10 ? '0' + (month) : month) + '-' + (dateVal <10 ? '0' + dateVal : dateVal) + 'T' + hours + ':' +  minutes + ':' + seconds
    }

    //function to check url is alive or not
    /**
     * This function to check url is alive or not
     * @param {*} host This is url passed
     * @returns {*} return response as true or false
     */
    async isAlive(host) {
        return await ping.promise.probe(host).then((response) => {
            return response.alive;
        });
    }
}

module.exports = new CommonMethods();