const fetch = require('node-fetch');
const Encrypt = require('./encryption');
/**
 * This Class is used to encrypt and get card details
 */
class GetCardDetails {
    _PIE = {};

    /**
     * This method gets Keys reequired for generating the encrypted card details
     * @returns {string} pieKey has pieKey value 
     * @returns {string} pieKeyId has pieKey value 
     */
    async getKeys(env) {
        process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0
        let getKeyUrl = "https://fes.devshare.allegiantair.com/pie/v1/1/getkey.js"
        if ((env.includes('aws')) || (env === '.stg') || (env === '-prd01')) {
            getKeyUrl = "https://fes" + env + ".allegiantair.com/pie/v1/1/getkey.js"
        }
        let getKeyResponse
        let pieKeyText
        try {
            getKeyResponse = await fetch(getKeyUrl);
            pieKeyText = await getKeyResponse.text();
            if (pieKeyText === undefined || pieKeyText.length === 0) {
                console.log("Pie key text information is empty");
                throw new Error("invalid response")
            }
        }
        catch (error) {
            throw new Error("FES Key generation failed due to error")
        }
        let pieKey = pieKeyText.split('PIE.K = "')[1].split('"')[0];
        let pieKeyId = pieKeyText.split('PIE.key_id = "')[1].split('"')[0];
        let pieKeyPhase = pieKeyText.split('PIE.phase = ')[1].split(';')[0];

        return {
            pieKey,
            pieKeyId,
            pieKeyPhase
        }
    }

    /**
     * This method gets encrypted cc and cvv values
     * @param {string} CreditCardNumber contains the cc number which needs to get encrypted
     * @param {string} CreditCardCVV contains the cvv info which needs to get encrypted
     * @returns {string} CreditCardNumber encrypted has pieKey value 
     * @returns {string} CreditCardCVV pieKeyId has pieKey value 
     */
    async getEncryptedValues(CreditCardNumber, CreditCardCVV, env) {
        await this.getKeys(env).then(({
            pieKey,
            pieKeyId,
            pieKeyPhase
        }) => {
            this._kval = pieKey;
            this._kId = pieKeyId
            this._kPhase = pieKeyPhase
        })
        // PIE namespace
        // eslint-disable-next-line no-unused-vars

        this._PIE.L = 6;
        this._PIE.E = 4;
        this._PIE.K = this._kval;
        this._PIE.key_id = this._kId;
        this._PIE.phase = this._kPhase;
        // eslint-disable-next-line new-cap
        return Encrypt.ProtectPANandCVV(this._PIE, CreditCardNumber, CreditCardCVV);
    }
}

module.exports = new GetCardDetails()