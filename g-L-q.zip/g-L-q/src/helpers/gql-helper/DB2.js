// const ibmdb = require('ibm_db');

// module.exports = class DB2Util {
//     #connectionString;
//     #conn;
//     #resultSet;
//     /**
//      * This is constructor of DB2Util
//      * @param {*} database contains database
//      * @param {*} hostConnection contains hostConnection
//      * @param {*} userName contains userName
//      * @param {*} userPass contains userPass
//      * @param {*} portNum contains portNum
//      */
//     constructor(database,hostConnection, userName, userPass, portNum) {
//         let parameter = "DRIVER={DB2};DATABASE=" + database + ";HOSTNAME=" + hostConnection + ";UID=" + userName + ";PWD=" + userPass + ";PORT=" + portNum + ";PROTOCOL=TCPIP";
//         this.#connectionString = parameter;
//     }
//     /**
//      * This method is used to createConnection
//      */
//     async createConnection() {
//         this.#conn = await ibmdb.open(this.#connectionString)
//     }
//     /**
//      * This method is used to execute query
//      * @param {*} query contains query
//      */
//     async executeQuery(query) {
//         // console.log("Executing Query..>" + query);

//         await this.#conn.query(query).then(data => {                    
//             this.#resultSet =JSON.parse(JSON.stringify(data))
//         }, err => {
            
//         });
//     }
  
//     /**
//      * This method is used to execute query
//      * @returns {*} resultSet Json object
//      */
//     getQueryResults() {
//         return this.#resultSet;
//     }
//     /**
//      * This method is used to getrowcount
//      * @returns {*} length of row count
//      */
//     getRowCount() {
//         return this.#resultSet.length;
//     }
//     /**
//      * This method is used to closeConnection
//      * @returns {*} true if connection is closed
//      */
//     closeConnection() {
//         return this.#conn.closeSync();
//     }
   
// };