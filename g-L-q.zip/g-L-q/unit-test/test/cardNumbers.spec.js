const cardNumbers = require("../../src/helpers/card-helpers/cardNumbers")


/**
*Testing cardNumbers using jest
*/
describe('cardNumbers', () => {

    it('getCardNumbers', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'AWMC'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers Master', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'Master'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers Visa', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'Visa'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers Discover', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'Discover'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers Amex', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'Amex'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers Diners', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'Diners'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers JCB', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', 'JCB'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCardNumbers Union Pay', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('qa1', 'Union Pay'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);
    it('getCardNumbers :qa1', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('qa1', ''))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);
    it('getCardNumbers:stg', async () => {
        const mockFn = jest.fn(await cardNumbers.getCardNumbers('stg', ''))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('reverseString', async () => {
        const mockFn = jest.fn(await cardNumbers.reverseString('reverseString'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCreditCardNumbers', async () => {
        const mockFn = jest.fn(await cardNumbers.getCreditCardNumbers('Diners'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCreditCardNumbers Master-CC', async () => {
        const mockFn = jest.fn(await cardNumbers.getCreditCardNumbers('Master-CC'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCreditCardNumbers Others', async () => {
        const mockFn = jest.fn(await cardNumbers.getCreditCardNumbers('others|5253545657575757|773'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCreditCardNumbers null', async () => {
        const mockFn = jest.fn(await cardNumbers.getCreditCardNumbers(''))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCreditCardNumbers Amex', async () => {
        const mockFn = jest.fn(await cardNumbers.getCreditCardNumbers('Amex'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('getCreditCardNumbers Diners', async () => {
        const mockFn = jest.fn(await cardNumbers.getCreditCardNumbers('Diners'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);
    
})