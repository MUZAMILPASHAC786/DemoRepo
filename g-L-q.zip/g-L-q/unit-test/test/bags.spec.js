const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Bags = require("../../src/booking-calls/bags")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'
let departureFlightId1 = "2024-05-23-G4-401", returningFlightId1 = "2024-07-08-G4-283"

/**
*Testing Bags page using jest
*/

describe('bag tests', () => {
    it('1.should return response in bags page', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '1Return', '2Both', '1'], ""))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);
    it('1.should return response in bags page - total bundle', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['0Both', '0Both', '0Both', '0'], "total"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);
    it('1.should return response in no dep bags page - total bundle', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['', '1Ret', '1Both', '1'], "total"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);
    it('1.should return response for tripFlexSelection', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('tripflex details not ,Hence Booking was unsuccessful');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.tripFlexSelection(['1Dep', '1Return', '1Both', '1']))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('tripflex details not ,Hence Booking was unsuccessful')
        }
    }, 6000);
    it('tripflex selection not provided', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('tripflex details not ,Hence Booking was unsuccessful');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.tripFlexSelection(['1Dep', '1Return', '1Both']))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('tripflex details not ,Hence Booking was unsuccessful')
        }
    });

    it('1.should return response for priorityAccessSelection', async () => {
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.priorityAccessSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '1Return', '0Both', '1'], "total"))
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: priority Boarding details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('1.should return response for priorityAccessSelection for return', async () => {
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.priorityAccessSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '1Return', '0'], "total"))
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: priority Boarding details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('1.should return response for  petInCabinSelection', async () => {
        let petInCabinSSR = [
            {
                code: "PETC",
                travelerId: "1",
                flightId: "2024-05-23-G4-401",
                additionalInfo: null,
            },
        ]
        let bags = new Bags(gqlCall, transactionId)
        const mockFn = jest.fn(await bags.petInCabinSelection(['1'], departureFlightId1, returningFlightId1, petInCabinSSR))
    });

    it('no bags selected', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['0Return', '0Both', '0'], "total"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);

    it('1 carryon bag selected for return', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Return', '1Both', '1'], "total"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);


    it('bags selected for dep', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '0Ret', '1Both', '1'], "total"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);

    it('bags selected for both dep and ret', async () => {
        const errorMock = jest.fn(() => {
            throw new Error('traveler bags details are not available');
        })
        try {
            let bags = new Bags(gqlCall, transactionId)
            const mockFn = jest.fn(await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '0Return', '1'], "bonus"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
        } catch (error) {
            expect(errorMock).toThrow('traveler bags details are not available')
        }
    }, 6000);

}, 6000);