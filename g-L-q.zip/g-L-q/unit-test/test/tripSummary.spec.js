const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const TripSummary = require("../../src/modify-calls/tripSummary")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'

let tripSummary = new TripSummary(gqlCall, transactionId)

/**
*Testing trip summary page using jest
*/
describe('trip summary', () => {

    it('tripSummary', async () => {
        const mockFn = jest.fn(await tripSummary.tripSummary())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });
})