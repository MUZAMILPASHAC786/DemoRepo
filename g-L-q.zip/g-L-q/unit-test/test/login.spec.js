const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Login = require("../../src/booking-calls/login")

let env = "-intnexusg4.okd"
let login = "yes"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'
let loginEmail, loginPassword
/**
*Testing login page using jest
*/

if (login === "yes") {
    describe('login tests', () => {

        it('should return email and password ', async () => {
            const errorMock = jest.fn(() => {
                throw new Error('priority Boarding details are not available');
            })
            try {
                let loginAccount = new Login(gqlCall, transactionId)
                const mockFn = jest.fn(await loginAccount.accountCreation("Louis", "Bernard"))
                mockFn()
                expect(mockFn).toHaveBeenCalled()
            } catch (error) {
                expect(errorMock).toThrow('priority Boarding details are not available')
            }
        }, 6000);
        it('should return response for login', async () => {
            const errorMock = jest.fn(() => {
                throw new Error('login was unsuccessful');
            })
            try {
                let loginAccount = new Login(gqlCall, transactionId)
                jest.fn(await loginAccount.login(loginEmail, loginPassword))
            } catch (error) {
                expect(errorMock).toThrow('login was unsuccessful')
                expect(global.error).toHaveBeenCalled()

            }
        }, 6000);
    });

}