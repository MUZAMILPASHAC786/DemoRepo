const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Flights = require("../../src/booking-calls/flights")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let flights = new Flights(gqlCall)
let departureFlightId1 = "2024-06-02-G4-284", returningFlightId1 = "2024-06-08-G4-283"


/**
*Testing flights page using jest
*/
describe('I-flight tests-date selection', () => {

    it('1.should return response from flights page - oneway', async () => {
        const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "2024-10-10", "2024-10-14", "ONEWAY", "timeline6706cf560523d", "2024-10-27"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response from flights page - raiders  - oneway', async () => {
        const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "", "2024-07-25", "ONEWAY", "timeline6641b4a8070aa", "2024-07-20"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
        // expect(fetchSpy).toHaveBeenCalled()
    }, 6000);

    it('1.should return response from flights page - roundtrip', async () => {
        const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "2024-06-05", "2024-06-08", "ROUNDTRIP", "timeline6641b4a8070aa", "2024-07-20"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response from flights page - raiders - roundtrip', async () => {
        const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "", "2024-07-25", "ROUNDTRIP", "timeline6641b4a8070aa", "2024-07-20"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response for flight booking', async () => {
        const mockFn = jest.fn(await flights.flightBooking("ROUNDTRIP", "BLI", "LAS", ["2022-06-12", "2022-06-17", "2022-06-19"], ["2022-06-12", "2022-06-17", "2022-06-19"], 14, 1, 1, 0, "", "", ''))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response for flight booking : oneway', async () => {
        const mockFn = jest.fn(await flights.flightBooking("ONEWAY", "BLI", "LAS", 4, 6, 14, 1, 1, 0, "", "", ''))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response for flight booking - adults count >9 and children count >3', async () => {
        try {
            const mockFn = jest.fn(await flights.flightBooking("ONEWAY", "BLI", "LAS", 4, 6, 14, 10, 4, 0, "", "", ''))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Adults count cannot be more than 9 (OR) childrenCount cannot be more than 3'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('order creation - roundtrip', async () => {
        const errorSpy = jest.spyOn(global, 'Error');
        errorSpy.mockImplementation(() => {
            throw new Error('Mocked error');
        });
        try {
            await flights.orderCreation("ROUNDTRIP", departureFlightId1, returningFlightId1)
        } catch (error) {
            expect(errorSpy).toBeCalled()
            expect(errorSpy).toHaveBeenCalledWith('Mocked error');
        }
        errorSpy.mockRestore()
    }, 6000);

    it('order creation - oneway', async () => {
        const errorSpy = jest.spyOn(global, 'Error');
        errorSpy.mockImplementation(() => {
            throw new Error('Mocked error');
        });
        try {
            await flights.orderCreation("ONEWAY", departureFlightId1, returningFlightId1)
        } catch (error) {
            expect(errorSpy).toHaveBeenCalled()
            expect(errorSpy).toHaveBeenCalledWith('Mocked error');
        }
        errorSpy.mockRestore()
    }, 6000);

    it('should return transactionID', async () => {
        const mockFn = jest.fn(await flights.getTransactionId())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });
    it('should return dateDiffInDays', async () => {
        const mockFn = jest.fn(await flights.dateDiffInDays("2024-06-05", "2024-06-08"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });

    it('calendar null', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("", "", "2024-05-05", "2024-05-08", "ROUNDTRIP", "", "2024-05-08"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: depart dates are not available, as calendar is null because data in origin or destination was wrong'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);


    it('depart date equal to game date - error', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("LAS", "BLI", "2024-05-05", "2024-05-08", "ROUNDTRIP", "", "2024-05-05"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Raiders Booking failed,due to the chosen Depart date'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('depart date less than game date', async () => {
        const mockFn = jest.fn(await flights.dateSelection("LAS", "BLI", "2024-06-05", "2024-06-08", "ROUNDTRIP", "timeline6641b4a8070aa", "2024-06-12"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    }, 6000);

    it('depart date greater than game date - error', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "20", "2024-11-05", "ROUNDTRIP", "timeline6641b4a8070aa", "2024-10-27"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Raiders Booking failed,due to the chosen Depart date is greater than available Game date'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('depart date format - error', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("LAS", "BLI", "2024-10-13", "2024-10-14", "ROUNDTRIP", "timeline6706cf560523d", "2024-10-27"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Departure Date format passed is not correct'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('return date format - error', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("LAS", "BLI", "2024-10-13", "2024-10-14", "ROUNDTRIP", "timeline6706cf560523d", "2024-10-27"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Return Date format passed is not correct'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('flights not available - error', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("LAS", "BLI", "", "", "ROUNDTRIP", "timeline6641b4a8070aa", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Flights are not available on depart dates passed'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('rountrip: depart date=2', async () => {
        const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "2", "2", "ROUNDTRIP", "timeline6641b4a8070aa", "2024-07-20"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('rountrip: sameday', async () => {
        try {
            const mockFn = jest.fn(await flights.dateSelection("BLI", "LAS", "0", "1", "ROUNDTRIP", "timeline6641b4a8070aa", "2024-07-20"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Flights are not available on return dates passed'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);
});