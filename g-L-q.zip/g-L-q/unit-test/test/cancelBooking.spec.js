const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const CancelBooking = require("../../src/cancel-calls/cancelBooking")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'

let cancelBooking = new CancelBooking(gqlCall, transactionId)

/**
*Testing cancelBooking using jest
*/
describe('cancelBooking', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });

    it('getItineraryDetails', async () => {
        const mockFn = jest.fn(await cancelBooking.getItineraryDetails('JAMES', 'OLSON', 'S46DQF'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 10000);

    it('getItineraryDetails - error', async () => {
        try {
            const mockFn = jest.fn(await cancelBooking.getItineraryDetails())
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: ITN details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('cancelItinerary', async () => {
        try {
            const mockFn = jest.fn(await cancelBooking.cancelItinerary('JAMES', 'OLSON', 'S46DQF', 'timeline1398fde'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Error occurred in Cancellation'
            expect(error.toString()).toEqual(expectError)
        }

    });
})