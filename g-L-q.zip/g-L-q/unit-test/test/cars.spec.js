const CommonMethods = require('../../src/helpers/common-helpers/common')
const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Cars = require("../../src/booking-calls/cars")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'
let arrivalTime
let departDate1 = "2024-06-02", returnDate1 = "2024-06-04", fromTimeForVehicleSearch, toTimeForVehicleSearch

/**
*Testing  cars page using jest
*/
describe('car tests', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('should return from time for vehicle', async () => {
        arrivalTime = 'Thu May 09 2024 15:40:25 GMT+0530 (India Standard Time)'
        let value = await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime)
        console.log(`await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime) ==> ${value}`)
        const mockFn = jest.fn(await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime))
        let mockData = '2024-05-09T15:40:25'
        mockFn.mockReturnValueOnce(() => mockData)
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });
    it('should return from time for vehicle  - less than 30 min', async () => {
        arrivalTime = 'Thu May 09 2024 15:20:25 GMT+0530 (India Standard Time)'
        let value = await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime)
        console.log(`await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime) ==> ${value}`)
        const mockFn = jest.fn(await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime))
        let mockData = '2024-05-09T15:20:25'
        mockFn.mockImplementation(() => mockData)
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });
    it('should return response in cars page', async () => {
        const mockFn = jest.fn(await CommonMethods.addDays(fromTimeForVehicleSearch, 3))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)

    });
    it('should return response in cars page - hours 00 and sec 00', async () => {
        fromTimeForVehicleSearch = 'Thu May 09 2024 00:0:00 GMT+0530 (India Standard Time)'
        const todo = await CommonMethods.addDays(fromTimeForVehicleSearch, 3)
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        toTimeForVehicleSearch = todo
        console.log("toTimeForVehicleSea", todo)
    });
    it('should return response in cars page - hours <10, minutes <10 and sec <10', async () => {
        fromTimeForVehicleSearch = 'Thu May 09 2024 04:05:05 GMT+0530 (India Standard Time)'
        const todo = await CommonMethods.addDays(fromTimeForVehicleSearch, 3)
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        toTimeForVehicleSearch = todo
        console.log("toTimeForVehicleSea", todo)
    });
    it('should check url is alive or not', async () => {
        const todo = await CommonMethods.isAlive('https://www.google.com/')
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
    });

    it('should return response for car Selection', async () => {
        let cars = new Cars(gqlCall, transactionId)
        const mockFn = jest.fn(await cars.vehicleList("BLI", "LAS", departDate1, returnDate1, '2024-06-02T09:30', '2024-06-04T12:30'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });

    it('should return response for car Selection', async () => {
        let cars = new Cars(gqlCall, transactionId)
        const mockFn = jest.fn(await cars.vehicleList("BLI", "LAS", "", "", '2024-05-23T17:00:00', '2024-05-26T17:00:00'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });

    it('no car list', async () => {
        let cars = new Cars(gqlCall, transactionId)
        const mockFn = jest.fn(await cars.vehicleList("ALB", "SFB", departDate1, returnDate1, '2024-05-23T17:00:00', '2024-05-26T17:00:00'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });

    it('vehicleSelection', async () => {
        let cars = new Cars(gqlCall, transactionId)
        const mockFn = jest.fn(await cars.vehicleSelection("CCAR_1"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });
});