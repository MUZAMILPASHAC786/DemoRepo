const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Payment = require("../../src/booking-calls/payment")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'

/**
*Testing payment page using jest
*/

describe('payment tests', () => {
    it('should return response from payment page', async () => {
        try {
            let payment = new Payment(gqlCall, transactionId)
            const mockFn = jest.fn(await payment.paymentPage(env, "Master", "100", "", "yes"))
            mockFn.mockImplementation(() => "BNG6R5")
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: FES Key generation failed due to error'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('promoPayment', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.promoPayment("PROMO50"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('voucherPayment : CR', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.voucherPayment(".qa1", "CR"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('voucherPayment : DO', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.voucherPayment(".qa1", "DO"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('voucherPayment : CR', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.voucherPayment(".qa1", "CR:100"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('voucherPayment : DO', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.voucherPayment("-intnexusg4.okd", "DO"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('getPoints', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.getPoints())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 8000);

    it('getBalancedDue', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.getBalancedDue())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('loyaltyPayment', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.loyaltyPayment())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('travelInsuranceOption', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const mockFn = jest.fn(await payment.travelInsuranceOption())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

});
