const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Travellers = require("../../src/booking-calls/travellers");

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'
let departureFlightId1 = "2024-06-02-G4-284", returningFlightId1 = "2024-06-08-G4-283"

/**
*Testing travellers page using jest
*/
describe('traveller tests', () => {
    beforeEach(() => {
        jest.setTimeout(20000);
    });

    it('1.should return response from travellers page', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", "2:WCHRA-2:WCHRSA-2", 1, ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('ktn=yes and redress=yes', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "yes", "yes", "yes:MX", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", "2:WCHRA-2:WCHRSA-2"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    },6000);

    it('ktn=yes and redress=yes', async () => {
        let ktnobject = [
            {
                firstName: "BKnown",
                lastName: "Traveler",
                gender: "FEMALE",
                dob: "1980-08-15",
                validKtnNum: 135701701
            },
            {
                firstName: "CKnown",
                lastName: "Traveler",
                gender: "MALE",
                dob: "1994-05-03",
                validKtnNum: 135707280
            },
            {
                firstName: "EKnown",
                lastName: "Traveler",
                gender: "FEMALE",
                dob: "1941-02-17",
                validKtnNum: 135704211
            }
        ]
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(4, ['1', '2'], ktnobject, "yes", "yes:US:MX", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", "2:WCHRA-2:WCHRSA-2", "", 1))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('ypta', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "yes", "yes", "yes", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", "2:WCHRA-2:WCHRSA-2", 1, 2))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('adult with SSR: WCHRA', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRA-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('adult with SSR: WCHRB', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRB-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: WCHRC', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRB-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    },6000);
    it('adult with SSR: WCHRSA', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRB-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    },6000);
    it('adult with SSR: WCHRSB', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRB-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    },6000);
    it('adult with SSR: WCHRSC', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRSC-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: WCHRSD', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "WCHRSD-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: PPOC', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "PPOC-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: SVAN', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "SVAN-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: DEAF', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "DEAF-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: BLND', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "BLND-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
    it('adult with SSR: DPNA', async () => {
        try {
            let travellers = new Travellers(gqlCall, transactionId)
            const mockFn = jest.fn(await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 1, departureFlightId1, returningFlightId1, "ROUNDTRIP", ["1", "DPNA-1", "WCHRSA-1"], "", ""))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Traveler Details are Not available'
            expect(error.toString()).toEqual(expectError)
        }
    });
});