const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Raiders = require("../../src/booking-calls/raiders")

/**
*Testing raiders page using jest
*/
describe('raiders booking', () => {

    it('stadiumConfig', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall)
        const mockFn = jest.fn(await raiders.stadiumConfig())
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('stadiumConfig : error', async () => {
        let gqlCall = new GqlCall()
        let raiders = new Raiders(gqlCall)
        try {
            const mockFn = jest.fn(await raiders.stadiumConfig())
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Raiders details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('showsAvailability', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall)
        const mockFn = jest.fn(await raiders.showsAvailability('31', '33', '28'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('showsAvailability - config3 null', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall)
        try {
            const mockFn = jest.fn(await raiders.showsAvailability('31', '33', ''))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Raiders details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('showsAvailability - config2 and config3 null', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall)
        try {
            const mockFn = jest.fn(await raiders.showsAvailability('31', '', ''))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Raiders details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('game available date undefined', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall, 'timeline663cb7f541405')
        try {
            const mockFn = jest.fn(await raiders.showsAvailability())
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Raiders details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);


    it('raidersBooking', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall)
        const mockFn = jest.fn(await raiders.raidersBooking('2024-10-27', '111','LAS','1','1'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('selectShowAfterFlight', async () => {
        let env = "-intnexusg4.okd"
        let gqlCall = new GqlCall(env)
        let raiders = new Raiders(gqlCall)
        const mockFn = jest.fn(await raiders.selectShowAfterFlight('G252JI', '2024-10-27','1'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

})