const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const ModifyBags = require("../../src/modify-calls/modifyBags")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'

let modifyBags = new ModifyBags(gqlCall, transactionId)

/**
*Testing modify bags using jest
*/
describe('modify bags', () => {

    beforeEach(() => {
        jest.setTimeout(20000);
    });
    it('getItineraryDetails', async () => {
        const mockFn = jest.fn(await modifyBags.getItineraryDetails('JAMES', 'OLSON', 'S46DQF'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 10000);

    it('getItineraryDetails - error', async () => {
        try {
            const mockFn = jest.fn(await modifyBags.getItineraryDetails())
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: ITN details are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('modifyOrder', async () => {
        const mockFn = jest.fn(await modifyBags.modifyOrder('S46DQF', 'JAMES', 'OLSON', 'timeline1398fde'))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });

    it('addOrChangeBags', async () => {
        try {
            const mockFn = jest.fn(await modifyBags.addOrChangeBags(['3Return', '0Dep'], ['1'], '2024-06-02-G4-284', '2024-06-08-G4-283'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Failed in Bag modification!'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('addOrChangeBags : Both', async () => {
        try {
            const mockFn = jest.fn(await modifyBags.addOrChangeBags(['3Dep', '0Return'], ['1'], '2024-06-02-G4-284', '2024-06-08-G4-283'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: Failed in Bag modification!'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('paymentForModification', async () => {
        try {
            const mockFn = jest.fn(await modifyBags.paymentForModification('-intnexusg4.okd', 'JAMES', 'OLSON', 'Master'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: FES Key generation failed due to error'
            expect(error.toString()).toEqual(expectError)
        }

    });

    it('paymentForModification - car undefined', async () => {
        try {
            const mockFn = jest.fn(await modifyBags.paymentForModification('-intnexusg4.okd', 'JAMES', 'OLSON'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: FES Key generation failed due to error'
            expect(error.toString()).toEqual(expectError)
        }

    });
})