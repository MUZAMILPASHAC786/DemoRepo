const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');

let transactionId = 'timeline663cb7f541405'

/**
*Testing  graphqlcalls using jest
*/
describe('graphQlCall', () => {

    it('graphQlCall', async () => {
        let gqlCall = new GqlCall()
        const mockFn = jest.fn(await gqlCall.graphQlCall(transactionId))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);
})