const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Hotels = require("../../src/booking-calls/hotels")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'

/**
*Testing  hotels page using jest
*/
describe('hotel tests', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });

    it('1.should return response from hotels page', async () => {
        // const mockData = { hotel: 'true' };
        // const mockResponse = { json: jest.fn().mockResolvedValue(mockData) };
        // jest.spyOn(global, 'fetch').mockResolvedValue(mockResponse);

        let hotels = new Hotels(gqlCall, transactionId)
        const mockFn = jest.fn(await hotels.hotelList("BLI", "LAS", "2024-06-05", "2024-06-07", "Deluxe", "2", "2", "ROUNDTRIP"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response from hotels page : throw error', async () => {
        let hotels = new Hotels(gqlCall, transactionId)
        const mockFn = jest.fn(await hotels.hotelList("BLI", "LAS", "", "", "Deluxe", "2", "2", "ROUNDTRIP"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('1.should return response from hotels page : room not selected', async () => {
        let hotels = new Hotels(gqlCall, transactionId)
        const mockFn = jest.fn(await hotels.hotelList("BLI", "LAS", "2024-06-05", "2024-06-07", "Deluxe", "", "2", "ONEWAY"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    }, 6000);

    it('2.should return response for hotel Booking', async () => {
        let hotels = new Hotels(gqlCall, transactionId)
        const mockFn = jest.fn(await hotels.hotelBooking("25", "LAS", "2024-06-05", "1", "2024-06-07"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
        expect(global.error).toHaveBeenCalled()

    });
    it('3.should return response for room booking', async () => {
        let hotels = new Hotels(gqlCall, transactionId)
        const mockFn = jest.fn(await hotels.roomSelection("4712"))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1)
    });

});