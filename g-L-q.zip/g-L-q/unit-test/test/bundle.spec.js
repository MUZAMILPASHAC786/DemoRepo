const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Bundles = require("../../src/booking-calls/bundles")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'
let departDate1, returnDate1
let bundleType = ""

/**
* Testing bundles page using jest
*/

describe('bundles tests', () => {

    it('1.should return response from bundles page- roundtrip', async () => {
        let bundles = new Bundles(gqlCall, transactionId)
        const mockFn = jest.fn(await bundles.bundleSelection("ROUNDTRIP", "BLI", "LAS", departDate1, returnDate1))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledWith()
    }, 6000);

    it('1.should return response from bundles page - oneway', async () => {
        let bundles = new Bundles(gqlCall, transactionId)
        const mockFn = jest.fn(await bundles.bundleSelection("ONEWAY", "BLI", "LAS", departDate1, returnDate1))
        mockFn.mockImplementation(() => { })
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledWith()
    }, 6000);

    it('2.should return response for bundle selection', async () => {
        try {
            let bundles = new Bundles(gqlCall, transactionId)
            const mockFn = jest.fn(await bundles.bundlemutation("basic"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledWith()
        } catch (error) {
            let expectError = 'Error: Bundles are not available, as bundleType data was incorrect'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('bundlemutation : total', async () => {
        try {
            let bundles = new Bundles(gqlCall, transactionId)
            const mockFn = jest.fn(await bundles.bundlemutation("total"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledWith()
        } catch (error) {
            let expectError = 'Error: Bundles are not available, as bundleType data was incorrect'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('bundlemutation : bonus', async () => {
        try {
            let bundles = new Bundles(gqlCall, transactionId)
            const mockFn = jest.fn(await bundles.bundlemutation("bonus"))
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledWith()
        } catch (error) {
            let expectError = 'Error: Bundles are not available, as bundleType data was incorrect'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);
});