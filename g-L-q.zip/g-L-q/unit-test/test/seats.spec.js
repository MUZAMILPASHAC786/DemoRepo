const GqlCall = require('../../src/helpers/gql-helper/graph-ql-call');
const Seats = require("../../src/booking-calls/seats")

let env = "-intnexusg4.okd"
let gqlCall = new GqlCall(env)
let transactionId = 'timeline663cb7f541405'
let departureFlightId1 = "2024-05-23-G4-401", returningFlightId1 = "2024-05-30-G4-386"
let departDate1 = "2024-06-05", returnDate1 = "2024-06-08"
let departFlightArray = require('../test-data/departFlightArray.json')
let returnFlightArray = require('../test-data/returnFlightArray.json')

/**
*Testing Seats page using jest
*/
describe('seat tests', () => {

    it('seatMap : oneway', async () => {
        let seats = new Seats(gqlCall, transactionId)
        try {
            const mockFn = jest.fn(await seats.seatMap("BLI", "LAS", departDate1, returnDate1, "ONEWAY"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: depart or return seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('seatMap : roundtrip', async () => {
        let seats = new Seats(gqlCall, transactionId)
        try {
            const mockFn = jest.fn(await seats.seatMap("BLI", "LAS", departDate1, returnDate1, "ROUNDTRIP"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: depart or return seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('should return response for Seat Selection', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ROUNDTRIP", '1', departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "", 1, 1, "yes", "yes", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('should return response for Seat Selection:economy', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ROUNDTRIP", '1', departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "", 1, 1, "yes:economy", "no", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('should return response for Seat Selection', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ONEWAY", ['1', '2', '3'], departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "", 1, 2, "yes", "yes", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('should return response for Seat Selection', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ONEWAY", ['1', '2', '3', '4'], departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "bonus", 1, 3, "yes:legroom+exit", "yes", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seat selection not possible,Child should be placed near Adult'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('should return response for Seat Selection', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ONEWAY", ['1', '2', '3', '4', '5'], departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "total", 2, 3,"yes:legroom+", "yes", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('should return response for Seat Selection:total bundle', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ROUNDTRIP", '1', departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "total", 1, 1, "yes:economy+exit", "no", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

    it('seatSelectionInternational', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelectionInternational("1"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('seatSelectionInternational', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelectionInternational())
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }

    }, 6000);

    it('should return response for Seat Selection', async () => {
        try {
            let seats = new Seats(gqlCall, transactionId)
            const mockFn = jest.fn(await seats.seatSelection("ROUNDTRIP", '1', departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "bonus", 1, 0, "yes:economy", "yes", "6", "6"))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: seats are not available'
            expect(error.toString()).toEqual(expectError)
        }
    });

});