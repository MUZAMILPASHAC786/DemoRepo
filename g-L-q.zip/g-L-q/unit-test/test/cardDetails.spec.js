const cardDetails = require("../../src/helpers/card-helpers/cardDetails")

/**
*Testing card details using jest
*/
describe('card details', () => {

    it('getKeys', async () => {
        try {
            let env = '.stg'
            const mockFn = jest.fn(await cardDetails.getKeys(env))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: FES Key generation failed due to error'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('getEncryptedValues', async () => {
        try {
            const mockFn = jest.fn(await cardDetails.getEncryptedValues('5454545454545454', '737', '.stg'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: FES Key generation failed due to error'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);

    it('getEncryptedValues : qa1', async () => {
        try {
            const mockFn = jest.fn(await cardDetails.getEncryptedValues('5432000000003332', '998', '.qa1'))
            mockFn.mockImplementation(() => { })
            mockFn()
            expect(mockFn).toHaveBeenCalled()
            expect(mockFn).toHaveBeenCalledTimes(1)
        } catch (error) {
            let expectError = 'Error: FES Key generation failed due to error'
            expect(error.toString()).toEqual(expectError)
        }
    }, 6000);
})