//SpyOn console error, info, log and assert

global.error = jest.spyOn(console, 'error').mockImplementation(() => { })
global.log = jest.spyOn(console, 'log').mockImplementation(() => { })

afterAll(() => {
    global.error.mockRestore();
    global.log.mockRestore();
});
afterEach(() => {
    global.error.mockClear();
    global.log.mockClear()
});