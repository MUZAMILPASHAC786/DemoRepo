const GqlBooking = require('../src/gql-booking')
const assert = require('assert');
describe('TC13-Domestic GQL_Flight booking with different card,date,bag parameter', () => {
    it('TC13.1.should return booking details for ROUNDTRIP with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes:economy", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC13.2.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:economy", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC13.3.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "", "yes:economy", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC13.4.should return booking details for ONEWAY with bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "", "yes:economy", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC13.5.should return booking details for ROUNDTRIP with flight-Number,basic bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "basic", "yes:economy", "yes", "yes", "yes", "card", "Master", "no", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC13.6.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "", "yes:economy", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC13.7.should return booking details for ONEWAY with flight-Number,bonus bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "bonus", "yes:economy", "no", "yes", "no", "card", "Discover", "no", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC13.8.should return booking details for ROUNDTRIP with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes:legroom+", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC13.9.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:legroom+", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC13.10.should return booking details for ROUNDTRIP with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes:legroom+exit", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC13.11.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:legroom+exit", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
});

describe('TC14-Domestic GQL_Flight booking with different adult-count,SSR', () => {

    it('TC14.1.should return booking details for ONEWAY with flight-Number,without bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "", "yes:legroom", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC14.2.should return booking details for ROUNDTRIP with flight-Number,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "basic", "yes:legroom", "yes", "yes", "yes", "card", "Master", "no", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC14.3.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "", "yes:economy", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC14.4.should return booking details for ONEWAY with flight-Number,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "bonus", "yes:economy+exit", "no", "yes", "no", "card", "Discover", "no", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});
describe('TC15-Domestic GQL_Flight booking with voucher', () => {

    it('TC15.1.should return booking details for ROUNDTRIP with flight-Number,basic bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "basic", "yes:legroom+", "yes", "yes", "yes", "voucher+card", "CR+Master", "no", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC15.2.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "total", "yes:legroom+exit", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "no", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.3.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "", "yes:legroom+", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.4.should return booking details for ONEWAY with basic bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-03-11", "2023-03-11", "bonus", "yes:economy", "no", "no", "yes", "voucher+card", "CR+DO", "no", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.5.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "basic", "yes:legroom+", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.6.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "", "yes:legroom+", "yes", "no", "yes", "voucher+card", "DO:500", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.7.should return booking details for ONEWAY with bonus bundles-card and date specified for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-03-14", "2023-03-15", "bonus", "yes:economy", "no", "no", "yes", "voucher+card", "CR+DO", "no", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.8.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "total", "yes:economy", "no", "no", "yes", "voucher+card", "DO+CR", "no", "yes", "no", "no", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.9.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "basic", "yes:economy", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "no", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC15.10.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "", "yes:economy", "yes", "no", "yes", "voucher+card", "DO:500+CR", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
});
describe('TC16-Domestic GQL_Flight booking with voucher and promocodes', () => {
    it('TC16.1.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:economy", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "no", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC16.2.should return booking details for ROUNDTRIP with flight-Number,basic bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "basic", "yes:economy", "yes", "yes", "yes", "voucher+card+promocode", "CR+Master+PROMO50", "no", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC16.3.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "total", "yes:economy", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "no", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC16.4.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "basic", "yes:economy", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC16.5.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "", "yes:economy", "yes", "no", "yes", "voucher+card", "DO:500+PROMO100", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC16.6.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "total", "yes:legroom+", "no", "no", "yes", "voucher+card", "DO+CR", "no", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC16.7.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "basic", "yes:legroom+", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "no", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC16.8.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "", "yes:legroom+", "yes", "no", "yes", "voucher+card", "DO:500+CR", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
});
