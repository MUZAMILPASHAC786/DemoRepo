const GqlBooking = require('../src/gql-booking')
const assert = require('assert');
describe('TC01-Domestic GQL_Flight booking with different card,date,bag parameter', () => {
    it('TC01.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "", "yes", "no", "yes", "no", "card", "Visa", "no", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC01.2.should return booking details for ROUNDTRIP without bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "1", "", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC01.3.should return booking details for ROUNDTRIP without bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC01.4.should return booking details for ROUNDTRIP without bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "4", "5", "", "yes", "yes", "yes", "no", "card", "Diners", "no", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC01.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "", "yes", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});

describe('TC02-Domestic GQL_Flight booking without bundle,,SSR', () => {
    it('TC02.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC02.2.should return booking details for ROUNDTRIP without bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "", "yes", "yes", "yes", "yes", "card", "Master", "no", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC02.3.should return booking details for ONEWAY without bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC03.4.should return booking details for ROUNDTRIP without bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.5.should return booking details for ONEWAY without bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "", "yes", "no", "yes", "no", "card", "Discover", "no", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});

describe('TC03-Domestic GQL_Flight booking with voucher', () => {
    it('TC03.1.should return booking details for ONEWAY without bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "no", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC03.2.should return booking details for ONEWAY without bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-03-10", "2023-03-11", "", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "no", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.3.should return booking details for ONEWAY without bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "no", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.4.should return booking details for ONEWAY without bundle, date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.5.should return booking details for ROUNDTRIP without bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.6.should return booking details for ONEWAY without bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "no", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.7.should return booking details for ROUNDTRIP without bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "no", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.8.should return booking details for ONEWAY without bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "no", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC03.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC03.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "", "no", "yes", "no", "yes", "voucher+card", "DO:500", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });

});
