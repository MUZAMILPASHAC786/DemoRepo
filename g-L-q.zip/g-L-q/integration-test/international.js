const GqlBooking = require('../src/gql-booking')
const assert = require('assert');

describe('TC17-International GQL_Flight booking for ONEWAY-with different card-without child', () => {

    it('TC17.1..should return booking details for ONEWAY with no bundles,with seat-type-legroom+', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ONEWAY", 3, 1, 2, "1", "5", "", "yes:legroom+", "yes", "no", "no", "voucher+card", "CR:50+DO:50+Visa", "yes:US:MX", "no", "yes", "no", "", "", "1Retrurn:1Dep:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC17.2.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes:economy", "yes", "yes", "yes", "voucher+card", "DO", "yes:US:US", "yes", "yes", "yes", "", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });

    it('TC17.3.should return booking details for ONEWAY with no bundles-card type Diners', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ONEWAY", 9, 0, 3, "10", "12", "", "yes", "yes", "yes", "yes", "voucher+card", "DO:1000", "yes:MX", "yes", "no", "yes", "", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC17.4.should return booking details for ONEWAY with no bundles,with seat-type-legroom+', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ONEWAY", 3, 1, 2, "1", "5", "", "no", "no", "no", "no", "voucher+card", "DO+CR+Visa", "yes:US:MX", "no", "yes", "no", "", "", "1Return:1Dep:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC17.5.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes", "yes", "yes", "no", "voucher+card", "DO", "yes:US:US", "yes", "yes", "yes", "", "", "1Both:1Return:1Dep:1",).then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC17.6.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes", "yes", "yes", "no", "card", "Diner", "yes:US:US", "yes", "yes", "yes", "", "", "0Both:1Return:0Dep:0",).then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });

    it('TC17.7.should return booking details for ONEWAY with no bundles-card type Diners', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "BLI", "ONEWAY", 9, 0, 3, "10", "12", "", "yes:legroom+exit", "no", "yes", "yes", "voucher+card", "CR+Master", "yes:MX", "yes", "no", "yes", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
});

