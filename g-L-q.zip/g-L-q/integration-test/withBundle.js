const GqlBooking = require('../src/gql-booking')
const assert = require('assert');

describe('TC04-Domestic GQL_Flight booking with different card,date,bag parameter,with bonus bundle', () => {
    it('TC04.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "bonus", "yes", "no", "yes", "no", "card", "Visa", "no", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC04.2.should return booking details for ROUNDTRIP with bonus bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "1", "bonus", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC04.3.should return booking details for ROUNDTRIP with bonus bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "bonus", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC04.4.should return booking details for ROUNDTRIP with bonus bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "4", "5", "bonus", "yes", "yes", "yes", "no", "card", "Diners", "no", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC04.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "bonus", "yes", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});
describe('TC05-Domestic GQL_Flight booking with bonus bundle,,SSR', () => {
    it('TC05.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "bonus", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC05.2.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "bonus", "yes", "yes", "yes", "yes", "card", "Master", "no", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC05.3.should return booking details for ONEWAY with bonus bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "bonus", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC05.4.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "bonus", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC05.5.should return booking details for ONEWAY with bonus bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "bonus", "yes", "no", "yes", "no", "card", "Discover", "no", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});


describe('TC06-Domestic GQL_Flight booking with voucher,with bonus bundle', () => {
    it('TC06.1.should return booking details for ONEWAY with bonus bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "bonus", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "no", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC06.2.should return booking details for ONEWAY with bonus bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-03-10", "2023-03-12", "bonus", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "no", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.3.should return booking details for ONEWAY with bonus bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "no", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.4.should return booking details for ONEWAY with bonus bundle, date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.5.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "bonus", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.6.should return booking details for ONEWAY with bonus bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "no", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.7.should return booking details for ROUNDTRIP with bonus bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "no", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.8.should return booking details for ONEWAY with bonus bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "bonus", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "bonus", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "no", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC06.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC06.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "bonus", "no", "yes", "no", "yes", "voucher+card", "DO:500", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });

});
describe('TC07-Domestic GQL_Flight booking with different card,date,bag parameter,with total bundle', () => {
    it('TC07.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "total", "yes", "no", "yes", "no", "card", "Visa", "no", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC07.2.should return booking details for ROUNDTRIP with total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "1", "total", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC07.3.should return booking details for ROUNDTRIP with total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC07.4.should return booking details for ROUNDTRIP with total bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "4", "5", "total", "yes", "yes", "yes", "no", "card", "Diners", "no", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC07.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});
describe('TC08-Domestic GQL_Flight booking with total bundle,,SSR', () => {
    it('TC08.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "total", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC08.2.should return booking details for ROUNDTRIP with total bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "total", "yes", "yes", "yes", "yes", "card", "Master", "no", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC08.3.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "total", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC09.4.should return booking details for ROUNDTRIP with total bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "total", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.5.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "total", "yes", "no", "yes", "no", "card", "Discover", "no", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});


describe('TC09-Domestic GQL_Flight booking with voucher,with total bundle', () => {
    it('TC09.1.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "no", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC09.2.should return booking details for ONEWAY with total bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-03-08", "2023-03-10", "total", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "no", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.3.should return booking details for ONEWAY with total bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "no", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.4.should return booking details for ONEWAY with total bundle, date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.5.should return booking details for ROUNDTRIP with total bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "total", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.6.should return booking details for ONEWAY with total bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "no", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.7.should return booking details for ROUNDTRIP with total bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "no", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.8.should return booking details for ONEWAY with total bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "total", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "total", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "no", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC09.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC09.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "total", "no", "yes", "no", "yes", "voucher+card", "DO:500", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });

});

describe('TC10-Domestic GQL_Flight booking with different card,date,bag parameter,with basic bundle', () => {
    it('TC10.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "basic", "yes", "no", "yes", "no", "card", "Visa", "no", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC10.2.should return booking details for ROUNDTRIP with basic bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "1", "basic", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC10.3.should return booking details for ROUNDTRIP with basic bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "basic", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC10.4.should return booking details for ROUNDTRIP with basic bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "4", "5", "basic", "yes", "yes", "yes", "no", "card", "Diners", "no", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC10.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "basic", "yes", "yes", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "7221", "1838", "1Dep:1Return:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});
describe('TC11-Domestic GQL_Flight booking with basic bundle,,SSR', () => {
    it('TC11.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "basic", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC11.2.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "basic", "yes", "yes", "yes", "yes", "card", "Master", "no", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC11.3.should return booking details for ONEWAY with basic bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "basic", "yes", "no", "yes", "no", "card", "Diners", "no", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC12.4.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "basic", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.5.should return booking details for ONEWAY with basic bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "basic", "yes", "no", "yes", "no", "card", "Discover", "no", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

});


describe('TC12-Domestic GQL_Flight booking with voucher,with basic bundle', () => {
    it('TC12.1.should return booking details for ONEWAY with basic bundle,with SSR,bag quantity', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "basic", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "no", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });
    it('TC12.2.should return booking details for ONEWAY with basic bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-03-12", "2023-03-12", "basic", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "no", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.3.should return booking details for ONEWAY with basic bundle and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "no", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.4.should return booking details for ONEWAY with basic bundle, date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.5.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "basic", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.6.should return booking details for ONEWAY with basic bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "no", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.7.should return booking details for ROUNDTRIP with basic bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "no", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.8.should return booking details for ONEWAY with basic bundle,with bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "basic", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "basic", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "no", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {

                assert.fail(response.returnGqlError.error)

            }

        })
    });

    it('TC12.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO", "no", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });
    it('TC12.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "basic", "no", "yes", "no", "yes", "voucher+card", "DO:500", "no", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                assert.fail(response.returnGqlError.error)

            }
        })
    });

});
