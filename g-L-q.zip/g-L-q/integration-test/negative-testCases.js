const GqlBooking = require('../src/gql-booking')
const assert = require('assert');
describe('TC18-Domestic GQL_Flight booking for ROUNDTRIP-with different card-without child', () => {
    it('TC18.1.should return booking details for ROUNDTRIP with total bundles-card type visa', async () => {
        await GqlBooking(".stg", "ABE", "SFB", "ONEWAY", 13, 0, 0, "1", "1", "total", "yes", "no", "no", "yes", "card", "Visa", "no", "no", "no", "yes", "", "", "1Retrurn:1Dep:1Return:1").then((response) => {

            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });


    it('TC18.2.should return booking details for ROUNDTRIP with no bundles-card type visa', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 7, 0, 5, "1", "1", "", "yes:economy", "yes", "no", "yes", "card", "Visa", "no", "no", "no", "no", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });

    it('TC18.3.should return booking details for ROUNDTRIP with bonus bundles-card type Diners', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", 5, 0, 4, "2023-03.01", "2", "bonus", "no", "no", "no", "no", "voucher+card", "CR:50+DO:50+Visa", "yes:US:MX", "yes", "no", "no", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });
    it('TC18.4.should return booking details for ROUNDTRIP with basic bundles-card type Diners', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", 1, 3, 0, "1", "1", "basic", "yes:legroom+", "no", "yes", "yes", "voucher+card", "DO:1000", "yes:US:US", "yes", "no", "yes", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });
    it('TC18.5.should return booking details for ROUNDTRIP with no bundles-card type Diners', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", 9, 0, 1, "1", "2023/03-10", "", "no", "yes", "no", "yes", "voucher+card", "CR+DO+Master", "yes", "yes", "no", "no", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });
    it('TC18.6.should return booking details for ROUNDTRIP with total bundles', async () => {
        await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", 5, 3, 1, "4", "4", "total", "yes", "no", "yes", "no", "card", "", "yes:MX", "yes", "no", "no", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });
    it('TC18.7.should return booking details for ROUNDTRIP with bonus bundles', async () => {
        await GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 5, 3, 1, "4", "4", "totl", "yes", "no", "yes", "no", "voucher+card", "CR+DO", "no", "no", "no", "no", "", "").then((response) => {
            if (response.returnAllGqlOutputs.confNumber === undefined || response.returnAllGqlOutputs.confNumber === "") {
                if (response.returnGqlError.error) {
                    assert.ok(response.returnGqlError.error)

                }
            }
        })
    });

});
