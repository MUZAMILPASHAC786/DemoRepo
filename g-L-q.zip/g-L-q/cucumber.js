let common = [
    'test/features/*.feature',
    '-r test/step-definitions',
    '--format html:./reports/cucumber-report.html',
    '--publish-quiet',
    '--format rerun:@rerun.txt'
].join(' ');

let reruns = [
    '@rerun.txt',
    '-r test/step-definitions',
    '--format html:./reports/cucumber-rerun-report.html',
    '--publish-quiet',
    '--format rerun:@rerun.txt'
].join(' ');


// Below code handles the run time tags
if (!(process.env.tag === undefined)) {
    common = common + " --tags " + process.env.tag
};

// Below code handles disabling SSL flag for testing purpose
if (process.env.disableSSL === "true") {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
};

module.exports = {
    default: common,
    rerun: reruns,
};