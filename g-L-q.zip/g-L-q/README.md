# GQL Prova
`GQL2.0V` library can used for Booking/generate `ITNs` using GQL

### Etymology
`GQL` stands for `Graph Query Language`(GraphQL)

GraphQL is a query language that describes how a client should request information through an `application programming interface` (API)

### Dependencies
* Node >= v14
* Npm >= v6
* Java >= v8

### Installation
```bash
perform `npm install @g4/gql-booking-util`.
```
<br />

### Test
Refer Testing Section in Below link
https://allegiantair0.sharepoint.com/sites/AutomationEngineering/SitePages/How-to-use-JS-GQL-Booking-library-User-Documentation.aspx

### Sample input code
![picture](images/gql-booking-sample.png)

### Output Screenshot
![picture](images/gql-booking-output-screenshot.png)

### Release Notes
* Please find release notes under CHANGELOG
  https://git.allegiantair.com:8443/projects/GQA/repos/js-gql-booking/browse/CHANGELOG.md 

### Contribute
Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License
Copyright (c) Allegiant Travel Company