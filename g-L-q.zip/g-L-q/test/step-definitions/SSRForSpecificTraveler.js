const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')

let env = ".stg01.aws"

Then('TC23.1.should return booking details for ROUNDTRIP with DEAF SSR for third traveler', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", "3:DEAF|3", 0, 0, "15", "45", "", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.2.should return booking details for ROUNDTRIP with Different SSR types', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP","3:BLND|1:DEAF|2:WCHRA|3", 1, 1, "60", "4", "", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.3.should return booking details for ROUNDTRIP with PPOC SSR', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP","5:PPOC|2&3:WCHRSA|1&5", 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.4.should return booking details for ROUNDTRIP with PPOC SSR Different types of SSR WCHRSD and DEAF', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP","9:WCHRSD|2&1&3:DEAF|3&4&9:DPNA|7&1", 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.5.should return booking details for ROUNDTRIP with SSR Different types of SSR WCHRA and DEAF', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", "9:DEAF-3:WCHRA-4", 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.6.should return booking details for ROUNDTRIP with PPOC SSR Different types of SSR SVAN and DEAF', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", "2:SVAN|1&2:DEAF|2&1", 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.7.should return booking details for ONEWAY with PPOC WHRSA SSR type', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY","5:PPOC|2&3:WCHRSA|1&5", 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC23.8.should return booking details for ONEWAY with WHRSC SVAN SSR type', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY","7:WCHRSC|5&1:SVAN|2&3&4&6", 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
