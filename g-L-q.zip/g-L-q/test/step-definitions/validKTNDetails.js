const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);
let env = ".stg01.aws"
let object = [
    {
         firstName: "BKnown",
         lastName: "Traveler",
         gender: "FEMALE",
         dob: "1980-08-15",
         validKtnNum: 135701701
     },
     {
         firstName: "CKnown",
         lastName: "Traveler",
         gender: "MALE",
         dob: "1994-05-03",
         validKtnNum: 135707280
     },
     {
         firstName: "EKnown",
         lastName: "Traveler",
         gender: "FEMALE",
         dob: "1941-02-17",
         validKtnNum: 135704211
     }
]

Then('TC19.1.should return booking details for ONEWAY with valid KTN Details and object as input for ktn', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 4, 0, 0, "8", "1", "bonus", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", object, "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC19.2.should return booking details for ROUNDTRIP with valid KTN Details and object as input for ktn', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 4, 0, 0, "1", "1", "bonus", "yes", "no", "yes", "no", "card", "Master", "yes", "yes", object, "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC19.3.should return booking details for ROUNDTRIP with valid KTN Details and object as input for ktn without login', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 3, 0, 0, "0", "2", "", "no", "no", "no", "no", "card", "", "yes", "no", object, "no").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC19.4.should return booking details for ROUNDTRIP with valid KTN Details and object as input for ktn with login', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 3, 0, 0, "0", "2", "", "no", "no", "no", "no", "card", "", "yes", "yes", object, "no").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});