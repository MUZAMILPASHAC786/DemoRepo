const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);

let env = "-qatnexusg4.okd"

Then('TC22.1.should return booking details for ONEWAY booking with 1 YPTA', async () => {
    await GqlBooking(env, "LAS", "BLI", "ONEWAY", "1|YPTA-1", 0, 0, "5", "0", "", "no", "no", "no", "no", "card", "Master-CC", "no", "no", "no", "no", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC22.2.should return booking details for ROUNDTRIP booking with 1 Adult 1 YPTA', async () => {
    await GqlBooking(env, "LAS", "CVG", "ROUNDTRIP", "2|YPTA-1", 0, 0, "5", "2", "", "yes", "yes", "yes", "yes", "card", "Master-CC", "no", "yes", "yes", "yes", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC22.3.should return booking details for ONEWAY booking with 3 Adult 2 YPTA 1 Child', async () => {
    await GqlBooking(env, "LAS", "BLI", "ONEWAY", "5|YPTA-2", 1, 0, "5", "0", "", "yes", "no", "yes", "yes", "card", "Master-CC", "no", "yes", "yes", "yes", "", "","4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC22.4.should return booking details for ROUNDTRIP booking with 2 Adult 4 YPTA 2 Child', async () => {
    await GqlBooking(env, "LAS", "BLI", "ROUNDTRIP", "6|YPTA-4", 2, 0, "5", "2", "", "no", "no", "no", "no", "card", "Master-CC", "no", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
    
});
Then('TC22.5.should return booking details for ONEWAY booking with 3 Adult 2 YPTA 1 Child and Bonus Bundle', async () => {
    await GqlBooking(env, "LAS", "BLI", "ONEWAY", "5|YPTA-2", 1, 0, "5", "0", "bonus", "yes", "no", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC22.6.should return booking details for ROUNDTRIP booking with 2 Adult 4 YPTA 2 Child and Total Bundle', async () => {
    await GqlBooking(env, "LAS", "BLI", "ROUNDTRIP", "6|YPTA-4", 2, 0, "5", "2", "total", "yes", "no", "yes", "yes", "card", "Visa", "no", "yes", "yes", "yes", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
    
});