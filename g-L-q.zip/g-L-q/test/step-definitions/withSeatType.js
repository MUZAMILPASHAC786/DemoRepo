const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);
let env = ".stg01.aws"

Then('TC13.1.should return booking details for ROUNDTRIP with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes:economy", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC13.2.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:economy", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC13.3.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "", "yes:economy", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC13.4.should return booking details for ONEWAY with bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "", "yes:economy", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "0Dep:0Dep:0Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC13.5.should return booking details for ROUNDTRIP with flight-Number,basic bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "total", "yes:economy", "yes", "yes", "yes", "card", "Master", "yes", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC13.6.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "", "yes:economy", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC13.7.should return booking details for ONEWAY with flight-Number,bonus bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "bonus", "yes:economy", "no", "yes", "no", "card", "Discover", "yes", "yes", "no", "yes", "", "", "0Dep:1Dep:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC13.8.should return booking details for ROUNDTRIP with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes:legroom+", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC13.9.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:legroom+", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC13.10.should return booking details for ROUNDTRIP with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes:legroom+exit", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC13.11.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:legroom+exit", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});


Then('TC14.1.should return booking details for ONEWAY with flight-Number,without bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "", "yes:legroom", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "0Dep:0Dep:0Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC14.2.should return booking details for ROUNDTRIP with flight-Number,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "total", "yes:legroom", "yes", "yes", "yes", "card", "Master", "yes", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC14.3.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "", "yes:economy", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC14.4.should return booking details for ONEWAY with flight-Number,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "bonus", "yes:economy+exit", "no", "yes", "no", "card", "Discover", "yes", "yes", "no", "yes", "", "", "0Dep:0Dep:1Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});


Then('TC15.1.should return booking details for ROUNDTRIP with flight-Number,basic bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "total", "yes:legroom+", "yes", "yes", "yes", "voucher+card", "CR+Master", "yes", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC15.2.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "total", "yes:legroom+exit", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "yes", "yes", "no", "no", "", "", "2Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.3.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "", "yes:legroom+", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.4.should return booking details for ONEWAY with basic bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "2023-12-17", "2023-12-18", "bonus", "yes:economy", "no", "no", "yes", "voucher+card", "CR+DO", "yes", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.5.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "total", "yes:legroom+", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.6.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 0, 1, 1, "7", "8", "", "yes:legroom+", "yes", "no", "yes", "voucher+card", "DO:500", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.7.should return booking details for ONEWAY with bonus bundles-card and date specified for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-12-17", "2023-12-18", "bonus", "yes:economy", "no", "no", "yes", "voucher+card", "CR+DO", "yes", "yes", "no", "no", "", "", "0Dep:0Dep:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.8.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "total", "yes:economy", "no", "no", "yes", "voucher+card", "DO+CR", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.9.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "total", "yes:economy", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC15.10.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "", "yes:economy", "yes", "no", "yes", "voucher+card", "DO:500+CR", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});

Then('TC16.1.should return booking details for ONEWAY with flight-Number,total bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "total", "yes:economy", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Dep:1Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC16.2.should return booking details for ROUNDTRIP with flight-Number,basic bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "total", "yes:economy", "yes", "yes", "yes", "voucher+card+promocode", "CR+Master+PROMO50", "yes", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC16.3.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "total", "yes:economy", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "yes", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC16.4.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "total", "yes:economy", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC16.5.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 0, 1, 1, "7", "4", "", "yes:economy", "yes", "no", "yes", "voucher+card+promocode", "DO:500+PROMO100", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC16.6.should return booking details for ONEWAY with total bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "total", "yes:legroom+", "no", "no", "yes", "voucher+card", "DO+CR", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC16.7.should return booking details for ROUNDTRIP with basic bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "total", "yes:legroom+", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC16.8.should return booking details for ONEWAY without bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "", "yes:legroom+", "yes", "no", "yes", "voucher+card", "DO:500+CR", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});