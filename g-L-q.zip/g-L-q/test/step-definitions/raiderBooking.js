const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);
let env = "-intnexusg4.okd"

Then('TC01.1.should return booking details for ONEWAY with raiders booking,without seats', async () => {
    await GqlBooking(env,"BLI", "LAS", "ONEWAY", 5, 1, 1, "2", "4", "", "no", "no", "yes", "no", "card", "Master", "yes", "yes", "yes", "yes", "", "","","yes").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC01.2.should return booking details for ROUNDTRIP with raiders booking,without seats', async () => {
    await GqlBooking(env,"BLI", "LAS", "ROUNDTRIP", 5, 1, 1, "4", "2", "", "no", "no", "yes", "no", "card", "Master", "yes", "yes", "yes", "yes", "", "","3Return:0Return:0Both:1","yes").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC01.3.should return booking details for ONEWAY with raiders booking,with seats', async () => {
    await GqlBooking(env,"BLI", "LAS", "ONEWAY", 5, 1, 1, "2", "4", "", "no", "no", "yes", "no", "card", "Master", "yes", "yes", "yes", "yes", "", "","","yes").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC01.4.should return booking details for ROUNDTRIP with raiders booking,with seats', async () => {
    await GqlBooking(env,"BLI", "LAS", "ONEWAY", 5, 1, 1, "2", "4", "", "no", "no", "yes", "no", "card", "Master", "yes", "yes", "yes", "yes", "", "","","yes").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
