const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);

let env = ".stg01.aws"

Then('TC21.1.should return booking details for ONEWAY with payment from Allegiant World Master Card', async () => {
    await GqlBooking(env, "CVG", "LAS", "ONEWAY", 1, 1, 1, "1", "0", "", "no", "yes", "no", "no", "card", "others|5280725769242738|998", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC21.2.should return booking details for ROUNDTRIP with payment from Allegiant World Visa Card', async () => {
    await GqlBooking(env, "CVG", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "2", "", "no", "yes", "no", "no", "card", "others|4078875839615592|999", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC21.3.should return booking details for ONEWAY with payment from Master Debit Card', async () => {
    await GqlBooking(env, "CVG", "LAS", "ONEWAY", 1, 1, 1, "1", "0", "", "no", "yes", "no", "no", "card", "others|5111005111051128|998", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC21.4.should return booking details for ROUNDTRIP with payment from Visa Debit Card', async () => {
    await GqlBooking(env, "CVG", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "2", "", "no", "yes", "no", "no", "card", "others|4000229999218008|999", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});

Then('TC21.5.should return booking details for ONEWAY with payment from Discover Debit Card', async () => {
    await GqlBooking(env, "CVG", "LAS", "ONEWAY", 1, 1, 1, "1", "0", "", "no", "yes", "no", "no", "card", "others|6011055039379233|996", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        } else {
            console.log(response)
        }
    })
});