const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBooking } = require('../../src/gql-booking')

let env = ".stg01.aws"

Then('TC22.1.should select Travel Insurance option for ONEWAY if it was available in env and complete booking', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 0, 0, "4", "5", "", "no", "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "1Dep:1Return:1Both:1", "", "yes").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC22.2.should select Travel Insurance option for ROUNDTRIP if it was available in env and complete booking', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 0, 0, "4", "5", "", "no", "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "1Dep:1Return:1Both:1", "", "yes").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC22.3.should complete booking for ONEWAY without select Travel Insurance option', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 0, 0, "4", "5", "", "no", "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "1Dep:1Return:1Both:1", "", "no").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC22.4.should complete booking for ROUNDTRIP without select Travel Insurance option', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 0, 0, "4", "5", "", "no", "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "1Dep:1Return:1Both:1", "", "no").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});