const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBooking } = require('../../src/gql-booking')

let env="-intnexusg4.okd"

Then('TC20.1.should return booking details for ONEWAY with payments from loyalty points', async () => {
    await GqlBooking(env, "LAS", "BLI", "ONEWAY", 1, 0, 0, "1", "1", "bonus", "yes", "no", "yes", "no", "card+loyalty", "Visa", "yes", "yes:amigosqa@allegiantair.com:Test@123", "yes", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC20.2.should return booking details for ROUNDTRIP with payments from loyalty points', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", 2, 0, 0, "1", "1", "bonus", "yes", "no", "yes", "no", "card+loyalty", "Master", "yes", "yes:amigosqa@allegiantair.com:Test@123", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});