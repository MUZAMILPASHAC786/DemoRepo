const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, createFlight, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
let env = ".stg01.aws"
setDefaultTimeout(90 * 1000);
Then('TC01.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 3, 1, 1, "15", "45", "", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC01.2.should return booking details for ROUNDTRIP without bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 1, 1, "4", "5", "", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC01.3.should return booking details for ROUNDTRIP without bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC01.4.should return booking details for ROUNDTRIP without bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "14", "5", "", "yes", "yes", "yes", "no", "card", "Diners", "yes", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC01.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 0, 0, 0, "11", "5", "", "yes", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});


Then('TC02.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC02.2.should return booking details for ROUNDTRIP without bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "", "yes", "yes", "yes", "yes", "card", "Master", "yes", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC02.3.should return booking details for ONEWAY without bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC02.4.should return booking details for ROUNDTRIP without bundle,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC02.5.should return booking details for ONEWAY without bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "", "yes", "no", "yes", "no", "card", "Discover", "yes", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});


Then('TC03.1.should return booking details for ONEWAY without bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 0, 0, 0, "1", "5", "", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC03.2.should return booking details for ONEWAY without bundle and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 1, 1, "1", "5", "", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "yes", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.3.should return booking details for ONEWAY without bundle and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "1", "5", "", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "yes", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.4.should return booking details for ONEWAY without bundle, date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.5.should return booking details for ROUNDTRIP without bundle,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.6.should return booking details for ONEWAY without bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "1", "5", "", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "yes", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.7.should return booking details for ROUNDTRIP without bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "17", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.8.should return booking details for ONEWAY without bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "5:PPOC-1:WCHRC-2", 1, 1, "1", "5", "", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "14", "5", "", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "yes", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC03.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "17", "8", "", "yes", "no", "no", "yes", "voucher+card", "DO", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 0, 1, 1, "1", "5", "", "no", "yes", "no", "yes", "voucher+card", "DO:500", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC03.12.should return booking details for ONEWAY with 1 adult 2 child', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 2, 0, "1", "5", "", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC03.13.should return booking details for ONEWAY with 2 adult 3 child', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 2, 3, 0, "1", "5", "", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC03.14.should return booking details for ROUNDTRIP with 1 adult 2 child', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 2, 0, "1", "5", "", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC03.15.should return booking details for ROUNDTRIP with 2 adult 3 child', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 3, 0, "1", "5", "", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC03.16.should create flight', async () => {
    await createFlight("-qatnexusg4.okd", "LAS", "BLI","215NV","32A","177","2023-12-16").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});