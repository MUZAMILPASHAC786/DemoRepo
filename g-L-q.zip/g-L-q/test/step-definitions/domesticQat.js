const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')

let env = ".stg01.aws"


Then('TC19.1.should return booking details for ONEWAY with no bundles,with seat-type-legroom+', async () => {
    await GqlBooking(env, "LAX", "BOI", "ONEWAY", 1, 0, 0, "1", "2", "", "yes:legroom+", "no", "no", "yes", "card", "Visa", "yes", "no", "no", "yes", "", "", "1Retrurn:1Dep:1Return:1").then((response) => {
        console.log("ENV checking: ", env)
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)

            }
        }
    })
});


Then('TC19.2.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
    await GqlBooking(env, "HOU", "LEX", "ROUNDTRIP", 1, 1, 1, "0", "0", "", "no", "yes", "no", "no", "card", "Visa", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)
            }
        }
    })
});

Then('TC19.3.should return booking details for ONEWAY with no bundles,with seat-type-economy', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 5, 0, 3, "1", "5", "", "no", "no", "no", "no", "voucher+card", "CR:50+DO:50+Visa", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)

            }
        }
    })
});
Then('TC19.4.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 5, 0, 3, "1", "5", "bonus", "yes", "yes", "yes", "yes", "voucher+card", "CR:50+DO:50+Visa", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)

            }
        }
    })
});
Then('TC19.5.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 5, 0, 3, "1", "5", "total", "no", "no", "no", "no", "card", "Visa", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)

            }
        }
    })
});
Then('TC19.6.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", 5, 0, 3, "1", "5", "bonus", "yes", "no", "yes", "no", "voucher+card", "CR:50+DO:50+Visa", "yes", "yes", "yes", "yes", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.fail(response.error)

            }
        }
    })
});
