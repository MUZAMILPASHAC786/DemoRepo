const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')

let env = "-intnexusg4.okd"


Then('TC18.1.should throw error for adult count greater than 9', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 13, 0, 0, "1", "1", "total", "yes", "no", "no", "yes", "card", "Visa", "yes", "no", "no", "yes", "", "", "1Retrurn:1Dep:1Return:1").then((response) => {
        console.log("ENV checking: ", env)
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});


Then('TC18.2.should throw error for child count greater than 3', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 7, 0, 5, "1", "1", "", "yes:economy", "yes", "no", "yes", "card", "Visa", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});

Then('TC18.3.should throw error for wrong pattern for return date mentioned', async () => {
    await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", 5, 0, 3, "2023-03.01", "2", "bonus", "no", "no", "no", "no", "voucher+card", "CR:50+DO:50+Visa", "yes:US:MX", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.4.should throw error as child count is greater than adult count', async () => {
    await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", 1, 3, 0, "1", "1", "basic", "yes:legroom+", "no", "yes", "yes", "voucher+card", "DO:1000", "yes:US:US", "yes", "no", "yes", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.5.should throw error for wrong pattern for return date mentioned', async () => {
    await GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", 9, 0, 1, "1", "2023/03-10", "", "no", "yes", "no", "yes", "voucher+card", "CR+DO+Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.6.should throw error for wrong bundle type entered', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 5, 3, 1, "4", "4", "totl", "yes", "no", "yes", "no", "voucher+card", "CR+DO", "yes", "no", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.7.should return booking details for ROUNDTRIP with wrong departure date format', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 9, 0, 1, "2023/03-19", "1", "", "no", "yes", "no", "yes", "voucher+card", "CR+DO+Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.8.should throw error for wrong flight details', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 9, 0, 1, "1", "5", "", "no", "yes", "no", "yes", "voucher+card", "CR+DO+Master", "yes", "yes", "no", "no", "7113", "21").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.9.should throw error for wrong origin', async () => {
    await GqlBooking(env, "BLZ", "LAS", "ROUNDTRIP", 9, 0, 1, "1", "5", "", "no", "yes", "no", "yes", "card", "Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.10.should throw error for wrong destination', async () => {
    await GqlBooking(env, "BLI", "LAz", "ROUNDTRIP", 9, 0, 1, "1", "5", "", "no", "yes", "no", "yes", "card", "Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.11.should return booking details for ROUNDTRIP with wrong departure date format', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 9, 0, 1, "1", "5", "", "no", "yes", "no", "yes", "", "Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.12.should return booking details for ROUNDTRIP with wrong departure date format', async () => {
    await GqlBooking("env", "BLI", "LAS", "ROUNDTRIP", 9, 0, 1, "2023/07-21", "5", "", "yes", "yes", "no", "yes", "card", "Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});
Then('TC18.13.should return booking details for ROUNDTRIP with 1 adult 3 child', async () => {
    await GqlBooking("env", "BLI", "LAS", "ROUNDTRIP", 1, 3, 0, "1", "5", "", "yes", "yes", "no", "yes", "card", "Master", "yes", "yes", "no", "no", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            if (response.error) {
                assert.ok(response.error)

            }
        }
    })
});