const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);

Then('TC17.1.should return booking details for ONEWAY with no bundles,with seat-type-legroom+', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ONEWAY", 3, 1, 2, "2", "5", "", "yes:legroom+", "yes", "no", "no", "voucher+card", "CR:50+DO:50+Visa", "yes:US:MX", "no", "yes", "no", "", "", "1Return:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC17.2.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes:economy", "yes", "yes", "yes", "voucher+card", "DO", "yes:US:US", "yes", "yes", "yes", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});

Then('TC17.3.should return booking details for ONEWAY with no bundles-card type Diners', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ONEWAY", 9, 0, 3, "10", "12", "", "yes", "yes", "yes", "yes", "voucher+card", "DO:1000", "yes:MX", "yes", "no", "yes", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC17.4.should return booking details for ONEWAY with no bundles,with seat-type-legroom+', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ONEWAY", 3, 1, 2, "7", "5", "", "no", "no", "no", "no", "voucher+card", "DO+CR+Visa", "yes:US:MX", "no", "yes", "no", "", "", "1Return:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC17.5.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes", "yes", "yes", "no", "voucher+card", "DO", "yes:US:US", "yes", "yes", "yes", "", "", "1Both:1Return:1Dep:1",).then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC17.6.should return booking details for ROUNDTRIP without bundles-card type visa', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "5", "", "yes", "yes", "yes", "no", "card", "Diners", "yes:US:US", "yes", "yes", "yes", "", "", "0Both:1Return:0Dep:0",).then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});

Then('TC17.7.should return booking details for ONEWAY with no bundles-card type Diners', async () => {
    await GqlBooking("-intnexusg4.okd", "MEX", "LAS", "ONEWAY", 9, 0, 3, "10", "12", "", "yes:legroom+exit", "no", "yes", "yes", "voucher+card", "CR+Master", "yes:MX", "yes", "no", "yes", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)
        }
    })
});