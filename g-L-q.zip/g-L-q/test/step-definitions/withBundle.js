const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking } = require('../../src/gql-booking')
const { setDefaultTimeout } = require('@cucumber/cucumber');
setDefaultTimeout(90 * 1000);
let env = ".stg01.aws"

Then('TC04.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "bonus", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC04.2.should return booking details for ROUNDTRIP with bonus bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "4", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC04.3.should return booking details for ROUNDTRIP with bonus bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "13", "5", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC04.4.should return booking details for ROUNDTRIP with bonus bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "4", "5", "bonus", "yes", "yes", "yes", "no", "card", "Diners", "yes", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC04.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "4", "5", "bonus", "yes", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});


Then('TC05.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "4", "5", "bonus", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC05.2.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "bonus", "yes", "yes", "yes", "yes", "card", "Master", "yes", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC05.3.should return booking details for ONEWAY with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "4", "5", "bonus", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC05.4.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "4", "5", "bonus", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC05.5.should return booking details for ONEWAY with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "4", "5", "bonus", "yes", "no", "yes", "no", "card", "Discover", "yes", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});




Then('TC06.1.should return booking details for ONEWAY with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "4", "5", "bonus", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC06.2.should return booking details for ONEWAY with bonus bundle and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-12-17", "2023-12-18", "bonus", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "yes", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.3.should return booking details for ONEWAY with bonus bundle and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "yes", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.4.should return booking details for ONEWAY with bonus bundle, date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.5.should return booking details for ROUNDTRIP with bonus bundle,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "bonus", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.6.should return booking details for ONEWAY with bonus bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "yes", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.7.should return booking details for ROUNDTRIP with bonus bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.8.should return booking details for ONEWAY with bonus bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "4", "8", "bonus", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "bonus", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "yes", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC06.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "4", "8", "bonus", "yes", "no", "no", "yes", "voucher+card", "DO", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC06.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 0, 1, 1, "4", "8", "bonus", "no", "yes", "no", "yes", "voucher+card", "DO:500", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});


Then('TC07.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "total", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC07.2.should return booking details for ROUNDTRIP with total bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "4", "total", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC07.3.should return booking details for ROUNDTRIP with total bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "4", "5", "total", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC07.4.should return booking details for ROUNDTRIP with total bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "4", "5", "total", "yes", "yes", "yes", "no", "card", "Diners", "yes", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC07.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "4", "5", "total", "yes", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "166", "201", "1Dep:1Return:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});


Then('TC08.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "4", "5", "total", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC08.2.should return booking details for ROUNDTRIP with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "4", "5", "total", "yes", "yes", "yes", "yes", "card", "Master", "yes", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC08.3.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "4", "5", "total", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC08.4.should return booking details for ROUNDTRIP with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "4", "5", "total", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC08.5.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "4", "5", "total", "yes", "no", "yes", "no", "card", "Discover", "yes", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});




Then('TC09.1.should return booking details for ONEWAY with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "4", "5", "total", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});
Then('TC09.2.should return booking details for ONEWAY with total bundle and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-12-17", "2023-12-18", "total", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "yes", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.3.should return booking details for ONEWAY with total bundle and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "yes", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.4.should return booking details for ONEWAY with total bundle, date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.5.should return booking details for ROUNDTRIP with total bundle,with SSR,bag quantity', async () => {
    await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "total", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.6.should return booking details for ONEWAY with total bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "yes", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.7.should return booking details for ROUNDTRIP with total bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.8.should return booking details for ONEWAY with total bundle,with bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "total", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "4", "5", "total", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "yes", "no", "no", "yes", "", "", "0Return:0Return:0Dep:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {

            assert.fail(response.error)

        }

    })
});

Then('TC09.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "total", "yes", "no", "no", "yes", "voucher+card", "DO", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});
Then('TC09.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
    await GqlBooking(env, "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "total", "no", "yes", "no", "yes", "voucher+card", "DO:500", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
        if (response.confNumber === undefined || response.confNumber === "") {
            assert.fail(response.error)

        }
    })
});



// Then('TC10.1.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
//     await GqlBooking(env, "ABE", "SFB", "ONEWAY", 3, 1, 1, "15", "45", "basic", "yes", "no", "yes", "no", "card", "Visa", "yes", "yes", "no", "yes", "", "", "4Dep:1Return:1Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });
// Then('TC10.2.should return booking details for ROUNDTRIP with basic bundle,bag quantity', async () => {
//     await GqlBooking(env, "ABE", "SFB", "ROUNDTRIP", 2, 1, 1, "60", "1", "basic", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Dep:0Return:0Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });
// Then('TC10.3.should return booking details for ROUNDTRIP with basic bundle,bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 2, 0, 1, "1", "5", "basic", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "3Return:0Return:0Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });
// Then('TC10.4.should return booking details for ROUNDTRIP with basic bundle,bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 5, 0, 3, "1", "5", "basic", "yes", "yes", "yes", "no", "card", "Diners", "yes", "yes", "yes", "yes", "", "", "0Both:0Both:1Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });

// Then('TC10.5.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
//     await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "basic", "yes", "yes", "yes", "yes", "card", "Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });


// Then('TC11.1.should return booking details for ROUNDTRIP with no bundles,with SSR,bag quantity', async () => {
//     await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:SVAN-1:DEAF-1:BLND-2", 0, 1, "1", "5", "basic", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC11.2.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 0, 1, "1", "5", "basic", "yes", "yes", "yes", "yes", "card", "Master", "yes", "no", "no", "yes", "", "", "0Dep:0Return:0Dep:0").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });

// Then('TC11.3.should return booking details for ONEWAY with basic bundle,with SSR,bag quantity', async () => {
//     await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 0, 1, "1", "5", "basic", "yes", "no", "yes", "no", "card", "Diners", "yes", "yes", "no", "yes", "", "", "0Dep:0Return:0Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });
// Then('TC11.4.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
//     await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ROUNDTRIP", "1:DPNA-1:DEAF-1:BLND-2", 1, 1, "1", "5", "basic", "no", "no", "no", "no", "card", "", "yes", "no", "no", "no", "", "", "1Both:1Both:1Both:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC11.5.should return booking details for ONEWAY with basic bundle,with SSR,bag quantity', async () => {
//     await GqlBooking(env, "ABE", "SFB", "ONEWAY", "2:DEAF-1", 2, 1, "1", "5", "basic", "yes", "no", "yes", "no", "card", "Discover", "yes", "yes", "no", "yes", "", "", "0Dep:1Return:0Both:0").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });




// Then('TC12.1.should return booking details for ONEWAY with basic bundle,with SSR,bag quantity', async () => {
//     await GqlBooking(env, "ABE", "SFB", "ONEWAY", 0, 0, 0, "1", "5", "basic", "yes", "yes", "yes", "yes", "voucher+card", "DO:3000+CR:2500+Master", "yes", "yes", "yes", "yes", "", "", "1Dep:1Return:1Dep:0").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });
// Then('TC12.2.should return booking details for ONEWAY with basic bundle and date for flight selection', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ONEWAY", 1, 1, 1, "2023-12-17", "2023-12-18", "basic", "yes", "no", "no", "yes", "voucher+card", "CR+DO", "yes", "yes", "no", "no", "", "", "0Both:0Both:0Both:0").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.3.should return booking details for ONEWAY with basic bundle and date for flight selection', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 0, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO+CR+Visa", "yes", "yes", "no", "no", "", "", "2Return:0Dep:1Dep:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.4.should return booking details for ONEWAY with basic bundle, date for flight selection', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR+Master", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.5.should return booking details for ROUNDTRIP with basic bundle,with SSR,bag quantity', async () => {
//     await GqlBooking("-intnexusg4.okd", "BLI", "LAS", "ONEWAY", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "basic", "yes", "no", "yes", "no", "voucher+card", "DO:500+CR+Master", "yes", "no", "no", "no", "", "", "").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.6.should return booking details for ONEWAY with basic bundle,with bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ONEWAY", "2:WCHRA-2:WCHRSA-2", 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO+CR", "yes", "yes", "no", "no", "", "", "1Return:0Dep:1Dep:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.7.should return booking details for ROUNDTRIP with basic bundle,with bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "4:BLND-1:WCHRC-2", 1, 1, "7", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO:500+CR:1000", "yes", "yes", "no", "no", "", "", "1Dep:0Dep:1Dep:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.8.should return booking details for ONEWAY with basic bundle,with bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ONEWAY", "5:PPOC-1:WCHRC-2", 1, 1, "7", "8", "basic", "no", "yes", "no", "yes", "voucher+card", "DO:500+CR", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.9.should return booking details for ONEWAY with flight-Number, bundle,bag quantity', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", "2:SVAN-2:DEAF-1", 1, 1, "1", "5", "basic", "yes", "yes", "yes", "yes", "voucher+card", "CR+Master", "yes", "no", "no", "yes", "", "", "1Dep:1Dep:1Return:0").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {

//             assert.fail(response.error)

//         }

//     })
// });

// Then('TC12.10.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "1", "8", "basic", "yes", "no", "no", "yes", "voucher+card", "DO", "yes", "yes", "no", "no", "", "", "1Dep:1Dep:1Dep:1").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });
// Then('TC12.11.should return booking details for ONEWAY with  bundles-card and date for flight selection', async () => {
//     await GqlBooking(env, "BLI", "LAS", "ONEWAY", 0, 1, 1, "7", "8", "basic", "no", "yes", "no", "yes", "voucher+card", "DO:500", "yes", "yes", "yes", "no", "", "", "1Return:1Return:1Return:0").then((response) => {
//         if (response.confNumber === undefined || response.confNumber === "") {
//             assert.fail(response.error)

//         }
//     })
// });