const { Then } = require('@cucumber/cucumber')
const assert = require('assert');
const { GqlBookingWithEnvAlone, GqlBooking, CancelBooking,ModifyBooking } = require('../../src/gql-booking')
let env = "-intnexusg4.okd"

/*method to modify ITN-add or remove bags-checkedBag:carryonBags*/
// ModifyTrip("-qatnexusg4.okd","MARIANNE","ROLFSON","D1GPMY","3Return:0Dep")
// .then((returnAllGqlOutputs) => {
//     console.log(returnAllGqlOutputs)
// })

/*method to cancel ITN*/
// CancelTrip("-qatnexusg4.okd","MARIANNE","BORER","EE7QNB")
// .then((returnAllGqlOutputs) => {
//     console.log(returnAllGqlOutputs)
// })
Then('TC01.1.should modify ITN with bags', async () => {
    await ModifyBooking("-intnexusg4.okd", "MARIANNE", "LEGROS", "ZBHBJN", "3Return:0Dep")
        .then((response) => {
            if (response.confNumber === undefined || response.confNumber === "") {
                assert.fail(response.error)
            }
        })
});
Then('TC01.2.should cancel ITN', async () => {
    await CancelBooking(env, "MARIANNE", "HERMANN", "VCKBVK").then((response) => {
        if (response.error !== undefined) {
            assert.fail(response.error)
        }
    })
});
