const {
    GqlBookingWithEnvAlone,
    GqlBooking,
    createFlight,
    CancelBooking,
    ModifyBooking
} = require('../src/gql-booking')

//*************Flight testCases Booking***************//
// GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 0, 0, 0, "2023-01-10", "0", "bonus", "yes", "yes", "no", "no", "card", "Discover", "no", "yes", "no", "no", "", "")
// GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 1, 0, 0, "1", "1", "total", "no", "no", "no", "yes", "card", "Visa", "no", "yes", "no", "no", "", "")
// GqlBooking(".stg", "ABE", "SFB", "ROUNDTRIP", 1, 0, 0, "1", "1", "total", "no", "no", "no", "yes", "card", "Visa", "no", "yes", "no", "no", "7374", "1785")
// GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 0, 1, 0, "1", "0", "total", "yes", "yes", "yes", "no", "card", "Master", "no", "no", "yes", "no", "", "")
// GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 1, 1, 1, "2022-12-26", "2", "bonus", "yes", "no", "yes", "yes", "card", "Dinners", "no", "no", "yes", "no", "", "")
// GqlBooking(".stg", "LAS", "FAT", "ONEWAY", 2, 1, 0, "2", "1", "bonus", "no", "yes", "no", "no", "card", "", "no", "no", "no", "yes", "", "")
// GqlBooking(".stg", "LAS", "FAT", "ROUNDTRIP", 3, 1, 0, "2", "2022-12-30", "total", "no", "no", "no", "yes", "card", "Discover", "no", "no", "no", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ONEWAY", 4, 1, 1, "3", "3", "total", "yes", "yes", "yes", "no", "card", "Visa", "no", "yes", "yes", "no", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 5, 2, 0, "4", "4", "bonus", "no", "no", "yes", "yes", "card", "Master", "no", "yes", "yes", "no", "", "")
// GqlBooking(".qa1", "ABE", "SFB", "ONEWAY", 6, 2, 1, "7", "15", "bonus", "yes", "yes", "no", "no", "card", "", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "IND", "AUS", "ROUNDTRIP", 1, 1, 1, "2023-01-11", "2023-01-20", "total", "yes", "no", "no", "yes", "card", "", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".qa1", "LAS", "BLI", "ONEWAY", 2, 1, 0, "15", "10", "total", "no", "yes", "yes", "no", "card", "Discover", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".qa1", "IND", "AUS", "ROUNDTRIP", 3, 1, 0, "16", "8", "bonus", "no", "no", "yes", "yes", "card", "Visa", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".qa2", "BLI", "LAS", "ROUNDTRIP", 3, 1, 0, "2023-01-15", "45", "total", "yes", "yes", "yes", "no", "card", "", "no", "yes", "no", "no", "", "")
// GqlBooking(".qa2", "ABE", "SFB", "ROUNDTRIP", 1, 1, 1, "60", "1", "bonus", "yes", "no", "yes", "yes", "card", "", "no", "yes", "yes", "no", "", "")
// GqlBooking(".qa2", "LAS", "FAT", "ROUNDTRIP", 2, 1, 0, "4", "2023-02-02", "bonus", "no", "yes", "yes", "yes", "card", "", "no", "yes", "yes", "yes", "", "")
// GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", "2:WCHR-A:2", 1, 0, "7", "8", "", "no", "no", "no", "no", "card", "Discover", "yes:MX", "yes", "yes", "yes", "7113", "7112")
// GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ONEWAY", 2, 1, 0, "3", "2", "", "yes", "yes", "no", "yes", "card", "visa", "yes", "yes", "yes", "yes", "", "")
// GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", 3, 1, 0, "2023-01-14", "2023-02-01", "", "yes", "no", "yes", "no", "card", "master", "yes", "yes", "no", "yes", "", "")
// GqlBooking("-intnexusg4.okd", "LAS", "MEX", "ROUNDTRIP", 4, 2, 1, "32", "15", "", "yes", "no", "yes", "yes", "card", "Dinners", "yes", "no", "yes", "no", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card", "DO+Master", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card", "CR:1000+Master", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card", "DO:3000+CR:2500+Master", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","card", "Master", "no", "yes", "yes", "yes", "", "","1Dep:1Return:1Both:1")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","card", "Master", "no", "yes", "yes", "yes", "", "","1Dep:1Return:0Both:1")
// GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","card", "Master", "no", "yes", "yes", "yes", "", "","1Both:1Both:1Both:1")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card","CR+DO+Master", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card","CR", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card","CR+DO", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 1, 1, "3", "2", "", "yes", "yes", "yes", "yes","voucher+card","CR:2000", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "BLI", "LAS", "ROUNDTRIP", "2:WCHR-A:2", 1, 1, "3", "4", "", "no", "no", "yes", "yes", "card", "Dinners", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 1, 0, 0, "3", "2", "bonus", "yes:economy+exit", "yes", "yes", "yes", "card", "visa", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 1, 0, 0, "3", "2", "bonus", "yes:economy", "yes", "yes", "yes", "card", "visa", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 1, 0, 0, "3", "2", "bonus", "yes", "yes", "yes", "yes", "voucher+card+promocode", "CR:100+visa+PROMO100", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 1, 0, 0, "3", "2", "bonus", "yes:economy", "yes", "yes", "yes", "voucher+card+promocode", "DO:100+visa+PROMO150", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".stg", "LAS", "BLI", "ROUNDTRIP", 2, 0, 0, "3", "2", "bonus", "yes:economy", "yes", "yes", "yes", "", "visa", "no", "yes", "yes", "yes", "", "")
// GqlBooking(".qa1", "BLI", "LAS", "ONEWAY", 1, 0, 0, "1", "1", "", "no", "no", "no", "no", "card+loyalty", "Master", "no", "yes:amigosqa@allegiantair.com:Test@123", "yes", "yes", "", "")
// GqlBooking(".qa2","SFB","BMI", "ROUNDTRIP", 9, 3, 1, "2023-08-08", "2023-08-10", "", "yes", "no", "no", "no", "card", "Master", "no", "yes", "yes", "yes", "7887", "7826")
// GqlBooking(".qa1", "BLI", "LAS", "ONEWAY", 1, 0, 0, "1", "1", "", "no", "no", "no", "no", "card+loyalty", "Master", "no", "yes:amigosqa@allegiantair.com:Test@123", "yes", "yes", "", "")
// GqlBooking("-qatnexusg4.okd","BLI", "LAS", "ROUNDTRIP", 5, 1, 1, "6", "7", "", "no", "no", "no", "no", "card", "Master", "yes", "no", "no", "no", "", "","")
// GqlBooking(".stg", "BLI", "LAS", "ONEWAY", 1, 0, 0, "2", "3", "", "no", "no", "yes", "yes","card", "Master", "yes", "yes", "yes", "yes", "", "","", "yes")  
// GqlBooking(".stg01.aws", "BLI", "LAS", "ROUNDTRIP", 2, 0, 0, "7", "8", "", "no", "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "4Dep:1Return:1Both:1")  
// GqlBooking(".stg", "LAS", "BLI", "ONEWAY", "5|YPTA-2", 1, 0, "5", "0", "bonus", "yes", "no", "yes", "yes", "card", "Master", "no", "yes", "yes", "yes", "", "", "")

let object = [{
    firstName: "BKnown",
    lastName: "Traveler",
    gender: "FEMALE",
    dob: "1980-08-15",
    validKtnNum: 135701701
},
{
    firstName: "CKnown",
    lastName: "Traveler",
    gender: "MALE",
    dob: "1994-05-03",
    validKtnNum: 135707280
},
{
    firstName: "EKnown",
    lastName: "Traveler",
    gender: "FEMALE",
    dob: "1941-02-17",
    validKtnNum: 135704211
}
]

GqlBooking(".stg01.aws", "LAS", "FAT", "ROUNDTRIP", 3, 0, 0, "0", "2", "", "no", "no", "no", "no", "card", "Visa", "yes", "no", "no", "no")
    // GqlBooking("-intnexusviva.okd", "BLI", "LAS", "ONEWAY", 1, 0, 0, "4", "5", "", "no", "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "1Dep:1Return:1Both:1", "", "yes")
    .then((returnAllGqlOutputs) => {
        console.log(returnAllGqlOutputs)
        // console.log("tripSummary",JSON.stringify(returnAllGqlOutputs.TripSummaryDetails))
    })

/*method to modify ITN-add or remove bags-checkedBag:carryonBags*/
// ModifyBooking("-qatnexusg4.okd","MARIANNE","MORISSETTE","P81RRW","3Return:0Dep","Master")
// .then((returnAllGqlOutputs) => {
//     console.log(returnAllGqlOutputs)
// })

/*method to cancel ITN*/
// CancelBooking("-qatnexusg4.okd","MARIANNE","COLLINS","H6UVQJ")
// .then((returnAllGqlOutputs) => {
//     console.log(returnAllGqlOutputs)
// })


/* Booking by passing env alone */
// GqlBookingWithEnvAlone("-intnexusg4.okd")
// GqlBookingWithEnvAlone(".qa2")

/*method for flight-creation*/
// createFlight(".qa2","BMI","SFB","215NV","32B","180","2023-08-10")

// createFlight(".qa1", "XNA", "VPS", "215NV", "32E", "180", "2024-04-23", 7)
// .then((flightDetails)=>
// {
//     console.log("flightNumber: ",flightDetails.flightNumber)
// })