const CommonMethods = require('../src/helpers/common-helpers/common')
const GqlCall = require('../src/helpers/gql-helper/graph-ql-call');
const Flights = require("../src/booking-calls/flights")
const Bundles = require("../src/booking-calls/bundles")
const Seats = require("../src/booking-calls/seats")
const Travellers = require("../src/booking-calls/travellers");
const Bags = require("../src/booking-calls/bags")
const Cars = require("../src/booking-calls/cars")
const Login = require("../src/booking-calls/login")
const Payment = require("../src/booking-calls/payment")
const Hotels = require("../src/booking-calls/hotels")

let env = ".stg"
let petInCabin = "no"
let login = "yes"
let gqlCall = new GqlCall(env)
let flights = new Flights(gqlCall)
let transactionId, departureFlightId1 = "2022-12-17-G4-271", returningFlightId1 = "2022-12-16-G4-282", arrivalTime
let departDate1, returnDate1, departFlightArray, returnFlightArray, fromTimeForVehicleSearch, toTimeForVehicleSearch
let loginEmail, loginPassword, roomTypeSelected, roomsSelected, hotelId, roomsCount, roomId


/**
*Testing flights page using jest
*/
describe('I-flight tests-date selection', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('1.should return response from flights page', async () => {

        const todo = await flights.dateSelection("BLI", "LAS", "2022-2-24", "2023-02-26")
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("mockdepartDate", todo.departDate)
        departDate1 = todo.departDate
        console.log("mockReturndate", todo.returnDate)
        returnDate1 = todo.returnDate
    });
});
describe('II-flight tests-flight booking', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    //this no of travellers will be reflected in all the other pages-as order creation returns traveller id based on this 

    it('1.should return response for flight booking', async () => {
        const todo = await flights.flightBooking("ROUNDTRIP", "BLI", "LAS", 4,
            6, 14, 1, 1, 0, "", "")
        jest.setTimeout(20000);
        expect(todo.departureFlightId).not.toBe(undefined);
        expect(todo.returningFlightId).not.toBe(undefined);
        expect(todo.arrivalTime).not.toBe(undefined);
        expect(todo.departingTime).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("mockdepartureFlightId1", todo.departureFlightId)
        departureFlightId1 = todo.departureFlightId
        console.log(" mockreturningFlightId1", todo.returningFlightId)
        returningFlightId1 = todo.returningFlightId
        arrivalTime = todo.arrivalTime
    });

    it('order creation', async () => {

        const todo = await flights.orderCreation("ROUNDTRIP", departureFlightId1, returningFlightId1)
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });

        console.log("mock travellerid", todo)

    });
    it('should return transactionID', async () => {
        const todo = await flights.getTransactionId();
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("mocktransactionId", todo)
        transactionId = todo
    });

});

/**
* Testing bundles page using jest
*/

describe('bundles tests', () => {
    beforeEach(() => {
        jest.setTimeout(20000);
    });

    it('1.should return response from bundles page', async () => {
        let bundles = new Bundles(gqlCall, transactionId)
        const todo = await bundles.bundleSelection("ROUNDTRIP", "BLI", "LAS", departDate1,
            returnDate1)
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);

    });
    let bundleType = ""
    if (bundleType) {
        it('2.should return response for bundle selection', async () => {
            let bundles = new Bundles(gqlCall, transactionId)
            const todo = await bundles.bundlemutation("")
            jest.setTimeout(20000);
            expect(todo).not.toBe(undefined);
            console.log("bundles", todo)
        });
    }

});
/**
*Testing travellers page using jest
*/
describe('traveller tests', () => {
    beforeEach(() => {
        jest.setTimeout(20000);
    });

    it('1.should return response from travellers page', async () => {
        let travellers = new Travellers(gqlCall, transactionId)

        const todo = await travellers.travellerDetails(1, ['1', '2'], "no", "no", "no", 0, departureFlightId1, returningFlightId1, "ROUNDTRIP", "2:WCHRA-2:WCHRSA-2");
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("mockTravelerDetails", todo)
    });


});
/**
*Testing Seats page using jest
*/
describe('seat tests', () => {
    beforeEach(() => {
        jest.setTimeout(20000);
    });

    it('1.should return correct seatid-Arrays', async () => {
        let seats = new Seats(gqlCall, transactionId)

        const todo = await seats.seatMap("BLI", "LAS", departDate1, returnDate1)

        jest.setTimeout(20000);
        expect(todo).not.toBe(null);

        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("mock departFlightArray", todo.departFlightArray)
        departFlightArray = todo.departFlightArray
        console.log("mock returnFlightArray", todo.returnFlightArray)
        returnFlightArray = todo.returnFlightArray
    });


    it('should return response for Seat Selection', async () => {
        let seats = new Seats(gqlCall, transactionId)
        const todo = await seats.seatSelection("ROUNDTRIP", ['1', '2'], departFlightArray, departureFlightId1, returnFlightArray, returningFlightId1, "", 1, 1, "yes")
        jest.setTimeout(20000);
        expect(todo).not.toBe(null);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
    });

});

/**
*Testing Bags page using jest
*/

describe('bag tests', () => {
    beforeEach(() => {
        jest.setTimeout(20000);
    });
    it('1.should return response in bags page', async () => {
        let bags = new Bags(gqlCall, transactionId)
        const todo = await bags.bagSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '1Return', '1Both', '1'],"")
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
    });
    it('1.should return response for tripFlexSelection', async () => {
        let bags = new Bags(gqlCall, transactionId)
        const todo = await bags.tripFlexSelection(['1Dep', '1Return', '1Both', '1'],"")
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
    });

    it('1.should return response for priorityAccessSelection', async () => {
        let bags = new Bags(gqlCall, transactionId)
        const todo = await bags.priorityAccessSelection(['1', '2'], departureFlightId1, returningFlightId1, ['1Dep', '1Return', '1Both', '1'],"")
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
    });

    if (petInCabin === "yes") {
        it('1.should return response for  petInCabinSelection', async () => {
            let bags = new Bags(gqlCall, transactionId)
            const todo = await bags.petInCabinSelection(['1', '2'], departureFlightId1, returningFlightId1)
            jest.setTimeout(20000);
            expect(todo).not.toBe(undefined);
        });
    }
});
/**
*Testing  hotels page using jest
*/
describe('hotel tests', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });

    it('1.should return response from hotels page', async () => {
        let hotels = new Hotels(gqlCall, transactionId)
        const todo = await hotels.hotelList("BLI", "LAS", departDate1, returnDate1, roomTypeSelected, roomsSelected, 2)
        jest.setTimeout(30000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("mock hotelID", todo.hotelId)
        hotelId = todo.hotelId
        console.log("mock roomsCount", todo.roomsCount)
        roomsCount = todo.roomsCount
    });
    if (hotelId !== undefined) {
        returnAllGqlOutputs.hotelId = hotelId
        it('2.should return response for hotel Booking', async () => {
            let hotels = new Hotels(gqlCall, transactionId)

            const todo = await hotels.hotelBooking(hotelId, "LAS", departDate1, returnDate1, roomsCount);
            jest.setTimeout(20000);
            expect(todo).not.toBe(undefined);
            const valueReturned = false;
            jest.fn(() => {
                if (!valueReturned) {
                    valueReturned = true;
                    return { todo }
                }
            });
            console.log("mock roomID", todo.roomId)
            roomId = todo.roomId

        });
        it('3.should return response for room booking', async () => {
            let hotels = new Hotels(gqlCall, transactionId)
            const todo = await hotels.roomSelection(roomId);
            expect(todo).not.toBe(undefined);
        });

    }

});

/**
*Testing  cars page using jest
*/
describe('car tests', () => {
    beforeEach(() => {
        jest.setTimeout(10000);
    });
    it('should return from time for vehicle', async () => {
        const todo = await CommonMethods.getTimeBasedOnArrivalTime(arrivalTime)
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        fromTimeForVehicleSearch = todo
        console.log("fromTimeForVehicleSearch", todo)
    });
    it('should return response in cars page', async () => {
        const todo = await CommonMethods.addDays(fromTimeForVehicleSearch, 3)
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        toTimeForVehicleSearch = todo
        console.log("toTimeForVehicleSea", todo)
    });
    it('should return response for car Selection', async () => {
        let cars = new Cars(gqlCall, transactionId)
        const todo = await cars.vehicleList("BLI", "LAS", departDate1, "Compact", fromTimeForVehicleSearch, toTimeForVehicleSearch);
        jest.setTimeout(20000);
        expect(todo).not.toBe(undefined);
        const valueReturned = false;
        jest.fn(() => {
            if (!valueReturned) {
                valueReturned = true;
                return { todo }
            }
        });
        console.log("cars page", todo)
    });
});

/**
*Testing login page using jest
*/

if (login === "yes") {
    describe('login tests', () => {
        beforeEach(() => {
            jest.setTimeout(10000);
        });
        it('should return email and password ', async () => {
            let loginAccount = new Login(gqlCall, transactionId)
            const todo = await loginAccount.accountCreation("Louis", "Bernard")
            jest.setTimeout(20000);
            expect(todo).not.toBe(undefined);
            const valueReturned = false;
            jest.fn(() => {
                if (!valueReturned) {
                    valueReturned = true;
                    return { todo }
                }
            });
            loginEmai = todo.loginEmai
            loginPassword = todo.loginPassword
            console.log("mockloginEmail", todo.loginEmail)
            console.log("mockloginPassword", todo.loginPassword)

        });
    });
    it('should return response for login', async () => {
        let loginAccount = new Login(gqlCall, transactionId)
        const todo = await loginAccount.login(loginEmail, loginPassword)
        expect(todo).not.toBe(undefined);
    });

}

/**
*Testing payment page using jest
*/

describe('payment tests', () => {
    beforeEach(() => {
        jest.setTimeout(20000);
    });
    it('should return response from payment page', async () => {
        let payment = new Payment(gqlCall, transactionId)
        const todo = await payment.paymentPage(env, "Master");
        expect.anything();
        // itn not obtained-as it is not a continuous booking flow


    }, 6000);

});
