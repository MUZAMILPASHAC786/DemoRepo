const {
    BeforeAll,
    Before,
    BeforeStep,
    AfterStep,
    After,
    AfterAll,
} = require("@cucumber/cucumber");
const CatHooks = require('../cat-helpers/cat-portal-hooks.js');
const CatPortalHooks = new CatHooks();
let scenarioStatus = 'Passed'
let uriDetails = ""
let featureCall = false

BeforeAll(async function () {
    await CatPortalHooks.onPrepare();
});

Before(async function (scenario) {
    if (uriDetails !== scenario.gherkinDocument.uri) {
        uriDetails = scenario.gherkinDocument.uri
        await CatPortalHooks.beforeFeature(scenario.gherkinDocument.uri, scenario.gherkinDocument.feature, scenario.gherkinDocument.feature.children);
        featureCall = true
    }
    await CatPortalHooks.beforeScenario(scenario.gherkinDocument.uri, scenario.gherkinDocument.feature, scenario.pickle, scenario.gherkinDocument.feature.location);
});

BeforeStep(async function (scenario) {
    CatPortalHooks.beforeStep(scenario.gherkinDocument.uri, scenario.gherkinDocument.feature, scenario.pickleStep);
});

AfterStep(async function (scenario) {
    CatPortalHooks.afterStep(scenario.gherkinDocument.uri, scenario.gherkinDocument.feature, scenario.pickleStep, scenario.result.message, scenario.result.status);
});

After(async function (scenario) {
    let reqDetails = {}
    let wholeRequest = {}
    wholeRequest = this.spec.requestDetails
    console.log(wholeRequest)
    reqDetails.endpoint = wholeRequest.method + " " + this.spec.uri;
    if(wholeRequest.method !== "GET") {
        reqDetails.Request = wholeRequest.body;
    }else{
        reqDetails.Request = {}
    }
    reqDetails.Response = this.response;
    reqDetails.headers = wholeRequest.headers;

    await CatPortalHooks.afterScenario(scenario.gherkinDocument.uri, scenario.gherkinDocument.feature, scenario.pickle, scenario.result, scenario.gherkinDocument.feature.location, reqDetails);
    if (featureCall === true) {
        await CatPortalHooks.afterFeature(scenario.gherkinDocument.uri, scenario.gherkinDocument.feature, scenario.gherkinDocument.feature.children);
        featureCall = false;
    }
    scenarioStatus = scenario.result.status
});

AfterAll(async function () {
    await CatPortalHooks.onComplete(scenarioStatus);
});