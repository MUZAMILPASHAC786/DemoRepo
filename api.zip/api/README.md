# Prova-api
prova-api is a JavaScript library and api automation framework which uses BDD from cucumber js 
----

### Etymology
`Prova` is a translation of `Testing` in Italian
API stands for `Application programming interface`

### Goals
* Help test the REST APIs independently.

### Dependencies
* Install python (if you are new installation)
* Node >= v14
* Npm >= v6
* Node Gyp v6.1.0
* [Prova CLI](https://git.allegiantair.com:8443/projects/GQA/repos/prova-cli/browse)
* Java >= v8 (Needed only if you use prova-autonextgen-bindings module)

### Install
```bash

# install prova-api
npm install @g4/prova-api

# Run tests
prova test-api

# Specify tags in tests
tag='@basic' prova test-api

# execute the following command to execute unit tests
npm run test:unit

#execute the following command,to get the test-coverage(part of code covered by unit-tests)
npm run test:coverage
```
<br />

### Documentation
* [Contribute to Prova-api Development](docs/contribute.md)
* Helpers
    - [Page](docs/page-helper.md)

* Examples are found under 
https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/test/features/StepsTest.feature 
* sample test file are available under 
https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/test/test-files

### Release Notes
* Please find release notes under CHANGELOG
    https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/CHANGELOG.md 

### Sharepoint
For More information check in below
https://allegiantair0.sharepoint.com/sites/AutomationEngineering/SitePages/Prova-API-Framework-playbook.aspx

### Confluence 
For More information check in below
https://confluence.allegiantair.com/display/QTA/Prova-Api+framework+Playbook 

### Contribute
Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License
Copyright (c) Allegiant Travel Company

