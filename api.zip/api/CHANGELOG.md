# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.3.6](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.3.5...v0.3.6) (2024-06-26)

### [0.3.5](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.3.4...v0.3.5) (2024-06-03)


### Features

* QAA-27797_Upgraded the @cucumber/cucumber version to 9.0.0 ([ddb4230](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/ddb4230fd90003b120fe139c7fd0fd63084d6707))

### [0.3.4](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.3.3...v0.3.4) (2024-05-23)

### [0.3.3](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.3.2...v0.3.3) (2024-05-16)

### [0.3.2](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.3.1...v0.3.2) (2024-05-07)


### Features

* QAA-26854 Added form-data dependency ([059e29e](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/059e29e73ec725da32cbe1c65cf7585970b61d29))
* QAA-27526 Added prettierignore file ([254b0ab](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/254b0ab7dde29259cb9a719aeaa15b895cf3e812))
* QAA-27526 Added unit test cases for prova-api using jest ([44f60aa](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/44f60aa3ec4ca153c006f9f735a8ffad0388a430))
* QAA-27526 Added unit test cases,fixed test coverage issue and added unit test command in precommit ([1d7d453](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/1d7d453d0c44bf10fbcb4924b457f567b64b6159))
* QAA-27526 Added unit-tests and test coverage for the library ([f0f1824](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/f0f18243506146d0c3e570a938eea50d209b1907))
* QAA-27526 Modified Readme file with data of unit test and test-coverage ([f5e8f66](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/f5e8f66739f027427e66632074c6ac9e43862f17))
* QAA-27526 Removed mocha and added jest for unit -testing ([bd9237c](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/bd9237ce91bf662cce15ebc3d31daec2bb97fec8))

### [0.3.1](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.3.0...v0.3.1) (2023-07-31)


### Features

* #QAA-26607 Added the snippet to upload csv ([2f174a0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/2f174a0d5030b30f2c3084c87b0b473f983b4ffd)), closes [#QAA-26607](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/issues/QAA-26607)

## [0.3.0](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/compare/v0.2.2...v0.3.0) (2023-07-31)


### Features

* QAA-26580 resolved form data stepdef and added regex ([69be8fd](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/69be8fd3a89d76f0b12c3a563e71cb5e4d071a18))

### 0.2.2 (2023-07-12)


### Features

* added standard version in provaAPI ([37c0028](https://git.allegiantair.com:8443/projects/GQA/repos/prova-api/browse/commit/37c0028e034234be17ef13eb7799dfc354e90308))

## [0.2.1] - 2022-09-02
- QAA-25151 Update the prova-api library for process.env.confirmationNumber

## [0.2.0] - 2022-05-19
- QAA-24295 Added response time validation step definition
- QAA-23807 Added Basic Authorization step definition

## [0.1.1] - 2022-04-13 
- QAA-23806 Added Error handling to json response 
- Fixed the issue test step is shown as passed even after fail
- QAA-24120 Added XML realted step definitions,Calls API with xml request and also validates response with xpath
- Added step to accept datatable for params, response headers, response fields & additionalKeyValues
- Added string validation on the whole response as text

## [0.1.0] - 2022-03-15
- QAA-24037 Added Graph QL related steps (Accepts both Query and varibles even in the  file path)
- Removed JsonConverter class dependency QAA
- Moved status code validations and header validation to ResponseValidator Class
- Added the timeout paramter to I receive reponse step to 60 sec
- Added World Class to access the Request Spec object for custom steps as well
- Added Unit tests to test the steps implemented in the
- QAA-23902 - Made changes to new CAT integration for API results

## [0.0.11] - 2022-01-21
- Fixed error with reponse being empty always QAA-23890

## [0.0.10] - 2022-01-10 
- Fixed error with query params not taking multiple values QAA-23862
- Handled ? in basePath and fixed the empty response error
- Added version bump and change log with pre commit hook QAA-23860
- Added eslint yml file for lint configurations
- fixed issue to verify field at path QAA-23804
- Added Generic function to manage jsonPaths QAA-23804

## [0.0.9] - 2021-12-21
- This version contains the very first commit into the master repo
