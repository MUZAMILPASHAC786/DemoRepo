## Prova API Development
----
#### Lets make prova api better, together !!

We are thrilled that you chose to contibute !! Welcome aboard !!

### Dependencies
* Node >= v10 (This lib was tested with v10.16.0)
* Npm >= v6 (This lib was tested with v6.9.0)

### Installation
# Clone repo
git clone ssh://git@git.allegiantair.com:7999/gqa/prova-api.git

# Install dependencies
npm install --unsafe-perm
```

### Linting
Have added pre-commit hook to lint

### Version Bump
npm run release
Note: above command works only on master branch

### Publishing to Nexus
```bash
# Login to Nexu Repo using your AD credentials
npm login --registry=https://nexus3.allegiantair.com/repository/g4npm_hosted/

# Publish
npm publish
```

### Contribute
Pull Requests always welcome, as well as any feedback or issues. Be sure link JIRA # to commits when possible.

### License
Copyright (c) Allegiant Travel Company
