const RequestSpec = require('../helpers/RequestSpec.js');
const ResponseSpec = require('../helpers/ResponseSpec.js');
const ResponseValidator = require('../helpers/ResponseValidator.js');
const XMLRespValidator = require('../helpers/XmlRespValidator.js');

const {
    setWorldConstructor,
    Given,
    When,
    Then,
} = require('@cucumber/cucumber');

/**
 * This class initilies the World params required for steps
 */
class Initialize {

    /**
     * This is Initialize class constructor
     */
    constructor() {
        this.spec = new RequestSpec();
        this.respSpec = new ResponseSpec(this.spec);
        this.respValidator = new ResponseValidator(this.respSpec);
        this.xmlRespValidator = new XMLRespValidator(this.respSpec);
    }
}
setWorldConstructor(Initialize)

Given(/^I have a "?([^"]+)"?$/, function (baseUri) {
    let env = process.env.env
    let baseUrl = baseUri.replace("{env}", env)
    this.spec.setBaseUri(baseUrl);
});

Given(/^I make a "?([^"]+)"? request to "?([^"]+)"?$/, function (method, basePath) {
    this.spec.setMethod(method.toUpperCase());
    this.spec.setBasePath(basePath);
});

Given(/^I set path param "?([^"]+)"? to "?([^"]+)"?$/, function (key, value) {
    this.spec.setPathParams(key, value);
});

Given(/^I set form data "?([^"]+)"? to "?([^"]+)"?$/, function (formKey, formValue) {
    this.spec.setFormData(formKey, formValue);
});
Given(/^I set urlencoded form data "?([^"]+)"? to "?([^"]+)"?$/, function (formKey, formValue) {
    this.spec.setFormDataEncoded(formKey, formValue);
});
Given(/^I upload csv form data "?([^"]+)"? to "?([^"]+)"?$/, function (key, path) {
    this.spec.setUploadCSVFormData(key, path);
});
Given(/^I set following path params:$/, function (dataTable) {
    for (const [key, value] of Object.entries(dataTable.rowsHash())) {
        this.spec.setPathParams(key, value);
    }
});

Given(/^I set query param "?([^"]+)"? to "?([^"]+)"?$/, function (key, value) {
    this.spec.setQueryParams(key, value);
});

Given(/^I set following query params:$/, function (dataTable) {
    for (const [key, value] of Object.entries(dataTable.rowsHash())) {
        this.spec.setQueryParams(key, value);
    }
});

Given(/^I set header "?([^"]+)"? to "?([^"]+)"?$/, function (key, value) {
    this.spec.setHeader(key, value);
});

Given(/^I set basic auth header with username:"?([^"]+)"? and password:"?([^"]+)"?$/, function (username, password) {
    let encoded = Buffer.from(username + ':' + password).toString('base64');
    this.spec.setHeader("Authorization", "Basic " + encoded);
});

Given(/^I set following header params:$/, function (dataTable) {
    for (const [key, value] of Object.entries(dataTable.rowsHash())) {
        this.spec.setHeader(key, value);
    }
});

Given(/^I set body to$/, function (body) {
    this.spec.setRequest(body);
});

Given(/^I set request body from file "?([^"]+)"?$/, function (filePath) {
    this.spec.setRequestBodyFromFile(filePath);
});

Given(/^I set graphql request query without variables$/, function (query) {
    this.spec.setGraphqlRequest(query);
});

Given(/^I set graphql request body query with variables$/, function (queryWithVaribles) {
    let queryDetails = queryWithVaribles.split("graphQlVariables")
    this.spec.setGraphqlRequest(queryDetails[0], queryDetails[1]);
});

Given(/^I set graphql request only query from file "?([^"]+)"?$/, function (queryFilePath) {
    this.spec.setGraphqlRequestFromQueryFile(queryFilePath);
});

Given(/^I set graphql request query from file "?([^"]+)"? and variables from file "?([^"]+)"?$/, function (queryFilePath, variablesFilepath) {
    this.spec.setGraphqlRequestFromQueryAndVariableFile(queryFilePath, variablesFilepath);
});

When(/^I receive a response$/, {
    timeout: 60 * 1000,
}, async function () {
    await this.respSpec.toss();
    await this.respValidator.setResponse();
    this.response = this.respValidator.getJsonResponse();
});

When(/^I receive xml response$/, {
    timeout: 60 * 1000,
}, async function () {
    await this.respSpec.tossXml();
    await this.xmlRespValidator.setXmlResponse();
    this.response = this.xmlRespValidator.getXmlResponse();
});

Then(/^I expect response should have a status "?([^"]+)"?$/, function (statusCode) {
    this.respValidator.verifyStatusCode(statusCode)
});

Then(/^I expect response time should be less than "?([^"]+)"? milliseconds$/, function (expectedResponseTime) {
    this.respValidator.verifyResponseTime(parseInt(expectedResponseTime))
});

Then(/^I expect response should follow schema at path "?([^"]+)"?$/, async function (filePath) {
    await this.respValidator.verifyJsonSchema(filePath)
});

Then(/^I expect response should have JSON like at path "?([^"]+)"?$/, async function (filePath) {
    await this.respValidator.verifyExactJsonFromFile(filePath)
});

Then(/^I expect response should have exact JSON$/, async function (body) {
    await this.respValidator.verifyExactJson(body)
});

Then(/^I expect response header "?([^"]+)"? should have "?([^"]+)"?$/, function (key, value) {
    this.respValidator.verifyResponseHeader(key, value);
});

Then(/^I expect response should have following headers:$/, function (dataTable) {
    for (const [key, value] of Object.entries(dataTable.rowsHash())) {
        this.respValidator.verifyResponseHeader(key, value);
    }
});

Then(/^Log Request and Response details$/, async function () {
    console.log("URI ::" + this.spec.uri);
    console.log(this.spec.requestDetails);
    console.log(this.respSpec.getheaders());
    console.log(this.response);
});

Then(/^Check Request details$/, async function () {
    console.log("URI ::" + this.spec.getRequestUri());
    console.log(this.spec.getRequestDetails());
});

Then(/^I expect response should have a value "?([^"]+)"? at jsonPath "?([^"]+)"?$/, function (value, path) {
    this.respValidator.verifyValueAtPath(path, value);
});

Then(/^I expect response should following values at jsonPaths:$/, function (dataTable) {
    for (const [key, value] of Object.entries(dataTable.rowsHash())) {
        this.respValidator.verifyValueAtPath(key, value);
    }
});

Then(/^I expect response should have field "?([^"]+)"? at jsonPath "?([^"]+)"?/, function (field, path) {
    this.respValidator.verifyFieldAtPath(path, field);
});

Then(/^I expect response should following fields at jsonPaths:$/, function (dataTable) {
    for (const [value, path] of Object.entries(dataTable.rowsHash())) {
        this.respValidator.verifyFieldAtPath(path, value);
    }
});

Then(/^I expect response should have a value "?([^"]+)"? at xpath "?([^"]+)"?$/, function (value, path) {
    this.xmlRespValidator.verifyValueAtPath(value, path);
});

Then(/^I expect response should following values at xpaths:$/, function (dataTable) {
    for (const [value, path] of Object.entries(dataTable.rowsHash())) {
        this.xmlRespValidator.verifyValueAtPath(value, path);
    }
});

Then(/^I expect json response should contain string "?([^"]+)"?$/, function (str) {
    this.respValidator.verifyStringInResponse(str);
});

Then(/^I expect xml response should contain string "?([^"]+)"?$/, function (str) {
    this.xmlRespValidator.verifyStringInResponse(str);
});

