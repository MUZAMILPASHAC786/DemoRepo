const fs = require('fs');
var FormData = require('form-data');
module.exports = class RequestSpec {

    /**
     * This is RequestSpec class Constructor
     */
    constructor() {
        this._queryParams = new Map();
        this._pathParams = new Map();
        this._headers = new Map();
        this._baseUri = '';
        this._basePath = '';
        this._method = '';
        this._request = {};
        this.uri = '';
        this.requestDetails = {};
        this._formData = new FormData();
        this._encoded = new URLSearchParams();
    }

    /**
     * This method sets base uri for the request
     * @param {string} baseUri contains the baseUri 
     */
    setBaseUri(baseUri) {
        this._baseUri = baseUri;
    }

    /**
     * This method sets base path for the request
     * @param {string} basePath contains the basePath 
     */
    setBasePath(basePath) {
        this._basePath = basePath;
    }

    /**
     * This method sets query Parameters for the request
     * @param {Map} paramMap contains the paramMap 
     * @param {string} paramVal contains the paramVal 
     */
    setQueryParams(paramMap, paramVal) {
        if (typeof paramMap === 'string') {
            this._queryParams.set(paramMap, paramVal)
        }
        if (paramMap instanceof Map) {
            this._queryParams = paramMap;
        }
    }

    /**
     * This method sets PathParams for the request
     * @param {Map} paramMap contains the paramMap 
     * @param {string} paramVal contains the paramVal 
     */
    setPathParams(paramMap, paramVal) {
        if (typeof paramMap === 'string') {
            this._pathParams.set(paramMap, paramVal);
        }
        if (paramMap instanceof Map) {
            this._pathParams = paramMap;
        }
    }
    /**
     * This method sets Header Params for the request
     * @param {Map} headerMap contains the headerMap 
     * @param {string} headerValue contains the headerValue 
     */
    setHeader(headerMap, headerValue) {
        if (typeof headerMap === 'string') {
            this._headers.set(headerMap, headerValue);
        }
        if (headerMap instanceof Object) {
            this._headers = headerMap;
        }
    }
    /**
     * This method sets request for the request
     * @param {json} request contains the headerMap 
     * @returns {Json} when the request is null or undefined
     */
    setRequest(request) {
        if (request === null) {
            return "null";
        }
        if (request === undefined) {
            return "undefined";
        };
        try {
            this._request = JSON.stringify(JSON.parse(request));
        } catch (e) {
            this._request = request;
        }
    }

    /**
     * This method sets request from file for the request
     * @param {json} requestFilePath contains the file path
     */
    setRequestBodyFromFile(requestFilePath) {
        let requestFromFile = fs.readFileSync(requestFilePath, 'utf8')
        try {
            this._request = JSON.stringify(JSON.parse(requestFromFile));
        } catch (e) {
            this._request = requestFromFile;
        }
    }

    /**
     * This method sets request as grapqhql query for the request
     * @param {json} query contains the query details for GraphhQl query
     * @param {json} variables contains the variables details for GraphhQl query
     */
    setGraphqlRequest(query, variables) {
        this._request = JSON.stringify({
            query,
            variables,
        });
    }

    /**
     * This method sets request as grapqhql query for the request
     * @param {json} queryfilePath contains the queryfilePath details for GraphhQl query
     * @param {json} variables is actully empty value
     */
    setGraphqlRequestFromQueryFile(queryfilePath,variables) {
        let query = fs.readFileSync(queryfilePath, 'utf8');
        this._request = JSON.stringify({
            query,
            variables,
        });
    }

    /**
     * This method sets request as grapqhql query for the request
     * @param {json} queryfilePath contains the queryfilePath details for GraphhQl query
     * @param {json} variablesFilePath contains the variablesFilePath details for GraphhQl query
     */
    setGraphqlRequestFromQueryAndVariableFile(queryfilePath,variablesFilePath) {
        let query = fs.readFileSync(queryfilePath, 'utf8');
        let variables = JSON.parse(fs.readFileSync(variablesFilePath, 'utf8'));
        this._request = JSON.stringify({
            query,
            variables,
        });
    }

    /**
     * This method sets method type for the request
     * @param {json} method contains the variables details for GraphhQl query
     */
    setMethod(method) {
        this._method = method;
    }

    /**
        * This method sets request for the form-data
        * @param {string}formKey contains the key 
        * @param {string}formValue contains the value
        */
    setFormData(formKey, formValue) {
        this._formData.append(formKey, formValue);
        console.log(this._formData)
        this._request = this._formData

    }

    /**
       * This method sets request for to add csv file in form-data
       * @param {string}key contains the key 
       * @param {string}CSVpath contains the path of files
       */
    setUploadCSVFormData(key, CSVpath) {
        const fileData = fs.readFileSync(CSVpath);
        this._formData.append(key, fileData, {
            filename: 'input.csv', // Replace with the desired filename on the server
            contentType: 'text/csv', // Replace with the appropriate content type if necessary
        });
        this._request = this._formData
    }


    /**
        * This method sets request for the x-www-form-urlencoded
        * @param {string}formKey contains the key 
        * @param {string}formValue contains the value
        */
    setFormDataEncoded(formKey, formValue) {
        this._encoded.append(formKey, formValue);
        this._request = this._encoded.toString()

    }
    /**
      * This method returns requestUri details set
      * @returns {requestUri} details from the set values
      */
    getRequestUri() {
        let uri;
        if (this._basePath.includes("?")) {
            uri = this._baseUri + this._basePath
        } else {
            uri = this._baseUri + this._basePath + '?';
        }

        if (!(Object.keys(this._pathParams).length === 0) || this._pathParams.size > 0) {
            this._pathParams.forEach(function (key, value) {
                uri = uri.replace('{' + value + '}', key);
            });
        }

        if (!(Object.keys(this._queryParams).length === 0) || this._queryParams.size > 0) {
            this._queryParams.forEach(function (key, value) {
                uri = uri + value + '=' + key + '&';
            });
        }

        this.uri = uri;
        return uri;
    }

    /**
     * This method returns requestDetails details set
     * @returns {requestDetails} details from the set values
     */
    getRequestDetails() {
        let requestDetails = new Map();
        requestDetails.set("method", this._method);
        requestDetails.set("headers", Object.fromEntries(this._headers));
        if (!(this._method === "GET" || this._method === "HEAD")) {
            requestDetails.set("body", this._request);
        }
        this.requestDetails = Object.fromEntries(requestDetails);
        return Object.fromEntries(requestDetails);
    }

    /**
     * This method returns requestDetails details set
     * @param {string} str is a String
     * @returns {requestDetails} details from the set values
     */
    isJson(){
        try {
            JSON.parse(this._request);
        } catch (e) {
            return false;
        }
        return true;
    }
};