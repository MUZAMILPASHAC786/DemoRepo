const fs = require('fs');
const assert = require('hamjest');
const JsonPath = require('jsonpath')
const JsonSchema = require('jsonschema')

module.exports = class ResponseValidator {

    /**
     * This is ResponseValidator class constructor
     * @param {responseSpec} responseSpec contains Responsespec Class object
     */
    constructor(responseSpec) {
        this.responseSpec = responseSpec;
        this.jsonResponse = {};
        this.headers = responseSpec.getheaders();
    };
    /**
     * This method fetches the response from the request made and stores in the local varibales
     */
    async setResponse() {
        try {
            await this.responseSpec.getJsonResponse().then(
                (response) => {
                    this.jsonResponse = response;
                });
        } catch (err) {
            console.error("No/Empty Response body available for this request")
        }
    }
    /**
     * This method returns json Response
     * @returns {Json} json Responses 
     */
    getJsonResponse() {
        return this.jsonResponse;
    }
    /**
     * This method verifies the expected headers from the response
     * @param {string} key contains expected response header key
     * @param {string} value contains expected response header key
     */
    verifyHeaders(key, value) {
        assert.assertThat("Header verification", this.headers[key], value)
    }

    /**
     * This method verifies the expected JSON Schema from file provided
     * @param {string} schemaFilePath contains schemaFilePath
     */
    async verifyJsonSchema(schemaFilePath) {
        let schema = JSON.parse(fs.readFileSync(schemaFilePath, 'utf8'));
        var validate = JsonSchema.validate;
        assert.assertThat("Json Schema verification", validate(this.jsonResponse, schema).valid, true)
    }

    /**
     * This method verifies the expected JSON
     * @param {json} responseJson contains JSON
     */
    verifyExactJson(responseJson) {
        assert.assertThat("Exact Json Verification", JSON.stringify(this.jsonResponse), JSON.stringify(JSON.parse(responseJson)))
    }

    /**
     * This method Verifies expected status Code from response
     * @param {string} code contains expected status code
     */
    verifyStatusCode(code) {
        assert.assertThat("Status Code Verification", this.responseSpec.getStatusCode(), code)
    }

    /**
     * This method Verifies expected Response header from response
     * @param {string} key contains expected header key
     * @param {string} value contains expected header value
     */
    verifyResponseHeader(key, value) {
        assert.assertThat("Response Header Verification", this.responseSpec.getheaders().get(key), value)
    }

    /**
     * This method verifies the exact JSON from file
     * @param {string} schemaFilePath contains schemaFilePath
     */
    async verifyExactJsonFromFile(schemaFilePath) {
        let schemaJson = JSON.parse(fs.readFileSync(schemaFilePath, 'utf8'));
        assert.assertThat("Exact Json from file verification", JSON.stringify(this.jsonResponse), JSON.stringify(schemaJson))
    }
    /**
     * This method verifies the value at the mentioned jsonPath
     * @param {string} path contains jsonpath 
     * @param {string} value contains expected value at the mentioned jsonPath
     */
    verifyValueAtPath(path, value) {
        let actualvalue = JsonPath.query(this.jsonResponse, stringifyJson(path))
        assert.assertThat("Validate value at jsonpath", actualvalue.toString().includes(value.toString()), true)
    }
    /** 
     * This method verifies the field at the mentioned jsonPath
     * @param {string} path contains jsonpath 
     * @param {string} value contains expected field value at the mentioned jsonPath
     */
    verifyFieldAtPath(path, value) {
        let actualvalue = JsonPath.query(this.jsonResponse, stringifyJson(path))
        assert.assertThat("Validate property at jsonpath ", actualvalue[0].hasOwnProperty(value), true)
    }

    /**
     * This method verifies the if the given string exists in the response
     * @param {string} str contains string to be searching in the response
     */
    verifyStringInResponse(str) {
        assert.assertThat("Validate if the string exists in the response", JSON.stringify(this.jsonResponse).includes(str), true);
    }

    /**
     * This method verifies the if the reponse time is less then expected value
     * @param {string} expectedResTime Expected response time
     */
    verifyResponseTime(expectedResTime) {
        assert.assertThat("Validate if the response time is less than : " + expectedResTime , this.responseSpec.getResponseTime(),assert.is(assert.lessThanOrEqualTo(expectedResTime)));
    }

}

/**
 * This function converts the provided Jsonpath in aray format
 * @param {string} path contains jsonpath 
 * @returns {string} returns a construncted jsonPath
 */
function stringifyJson(path) {
    let array = path.split(".")
    array.forEach(function (ele, index) {
        if (!isNaN(parseFloat(ele))) {
            array[index] = parseFloat(ele)
        }
    })
    return JsonPath.stringify(array)
}