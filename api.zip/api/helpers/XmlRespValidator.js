const XpathObj = require('xpath');
const DomParser = require('xmldom').DOMParser
const assert = require('hamjest');

module.exports = class XmlRespValidator {

    /**
     * This is XmlRespValidator class constructor
     * @param {responseSpec} responseSpec contains Responsespec Class object
     */
    constructor(responseSpec) {
        this.responseSpec = responseSpec;
        this.xmlResponse = "";
        this.headers = responseSpec.getheaders();
    };
    /**
     * This method fetches the response from the request made and stores in the local varibales
     */
    async setXmlResponse() {
        try {
            await this.responseSpec.getXmlResponse().then(
                (response) => {
                    this.xmlResponse =response;
                });
        } catch (err) {
            console.log("No/Empty Response body available for this request")
        }
    }
    /**
     * This method returns json Response
     * @returns {Json} json Responses 
     */
    getXmlResponse() {
        return this.xmlResponse;
    }
    /**
     * This method return the value using xpath
     * @param {string} xPath is the path for which the value needs to be fetched
     * @returns {string} value from xml from te provided xml path
     */
    getValuefromXpath(xPath) {
        let doc = new DomParser().parseFromString(this.xmlResponse)        
        return XpathObj.select(xPath, doc)[0].firstChild.data
    }   

    /**
     * This method Verifies expected value at specified xpath
     * @param {string} value contains value
     * @param {string} xpath contains xpath
     */
    verifyValueAtPath(value,xpath){
        assert.assertThat("Validate value at xpath",value,this.getValuefromXpath(xpath));
    }

    /**
     * This method verifies the if the given string exists in the response
     * @param {string} str contains string to be searching in the response
     */
    verifyStringInResponse(str) {
        assert.assertThat("Validate if the string exists in the response",this.xmlResponse.includes(str),true);
    }

}