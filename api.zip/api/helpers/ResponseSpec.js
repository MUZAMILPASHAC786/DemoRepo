const fetch = require('node-fetch');

module.exports = class ResponseSpec {

    /**
     * This is ResponseSpec class Constructor
     * @param {requestSpec} requestSpec object from RequestSpec Class
     */
    constructor(requestSpec) {
        this._responseCode = '';
        this._requestSpec = requestSpec;
        this._headers = {};
        this._url = '';
        this._statusText = '';
        this._response = {};
        this._responseTime = 0;
    };

    /**
     * This method performs the fetch call and stores the response values to class variables
     */
    async toss() {
        let startTime, endTime;
        startTime = new Date();
        await getResponse(this._requestSpec).then(
            (response) => {
                this._responseCode = response.status;
                this._headers = response.headers;
                this._statusText = response.statusText;
                this._url = response.url;
                try {
                    this._response = response.json();
                } catch (err) {
                    console.error("The reponse was either empty or there is something wrong with the request. Please Recheck")
                }
            });
        endTime = new Date();
        this._responseTime = endTime - startTime;
    }

    /**
     * This method performs the fetch call with Xml requests and stores the xml response values to class variables
     */
    async tossXml() {
        let startTime, endTime;
        startTime = new Date();
        await getResponse(this._requestSpec).then(
            (response) => {
                this._xmlResponse = response.text();
                this._responseCode = response.status;
                this._headers = response.headers;
                this._statusText = response.statusText;
                this._url = response.url;
            });
        endTime = new Date();
        this._responseTime = endTime - startTime;
    }

    /**
     * This method returns status code from the response
     * @returns {int} statusCode
     */
    getStatusCode() {
        return this._responseCode.toString();
    }

    /**
     * This method returns status text from the response
     * @returns {string} statusText
     */
    getstatusText() {
        return this._statusText;
    }

    /**
     * This method returns headers from the response made
     * @returns {int} response time
     */
    getResponseTime() {
        return parseInt(this._responseTime);
    }

    /**
     * This method returns headers from the response made
     * @returns {string} response headers
     */
    getheaders() {
        return this._headers;
    }
    /**
     * This method returns request url from the request
     * @returns {string} request url
     */
    geturl() {
        return this._url;
    }
    /**
     * This method returns Json Response from the response
     * @returns {json} Json Response
     */
    getJsonResponse() {
        return this._response;
    }

    /**
     * This method returns Json Response from the response
     * @returns {json} Json Response
     */
    getXmlResponse() {
        return this._xmlResponse;
    }

}

/**
 * This function performs the fetch call to recieve the responseSpec
 * @param {requestSpec} requestSpec contains the requestSpec object
 * @returns {json} Json Response
 */
async function getResponse(requestSpec) {
    let requestUri = requestSpec.getRequestUri();
    let requestDetails = requestSpec.getRequestDetails();
    let res = {};
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    try {
        res = await fetch(requestUri, requestDetails);
    } catch (err) {
        console.error(err);
    } finally {
        process.env.NODE_TLS_REJECT_UNAUTHORIZED = "1";
    }

    return res;
}