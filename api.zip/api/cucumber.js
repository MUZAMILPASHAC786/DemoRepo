let common = [
    'test/features/StepsTest.feature',
    '--require-module @babel/register',
    '-r step-definitions',
    '-r hooks',
    '--format html:./cucumber-report.html',
    '--format json:report.json',
    '--publish-quiet',
].join(' ');

// Below code handles the run time tags
if (!(process.env.tag === undefined)) {
    common = common + " --tags " + process.env.tag
};

// Below code handles disabling SSL flag for testing purpose
if (process.env.disableSSL === "true") {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
};

module.exports = {
    default: common,
};