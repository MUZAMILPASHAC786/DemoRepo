const RequestSpec = require('../helpers/RequestSpec.js');
const ResponseSpec = require('../helpers/ResponseSpec.js');
var spec = new RequestSpec();
var respSpec = new ResponseSpec(spec);

describe('IIV)return value from response file', () => {

    test('1)mockName-getStatusCode', async () => {
        const mockFn = jest.fn(respSpec.getStatusCode())
        let value = "201"
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('2)mockName-getResponseTime', async () => {
        const mockFn = jest.fn(respSpec.getResponseTime())
        let value = 457
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('3)mockName-getheaders', async () => {
        const mockFn = jest.fn(respSpec.getheaders())
        let value = `Headers {
      [Symbol(map)]: [Object: null prototype] {
        'content-type': [ 'application/json;charset=UTF-8' ],
        date: [ 'Fri, 12 Apr 2024 05:56:09 GMT' ],
        'content-length': [ '315' ],
        connection: [ 'close' ]
      }
    }
    Headers {
      [Symbol(map)]: [Object: null prototype] {
        'content-type': [ 'application/json;charset=UTF-8' ],
        date: [ 'Fri, 12 Apr 2024 05:56:09 GMT' ],
        'content-length': [ '315' ],
        connection: [ 'close' ]
      }
    }
    {
      timestamp: '2024-04-12T05:56:09.542+0000',
      status: 500,
      error: 'Internal Server Error',
      message: 'Failed to parse multipart servlet request; nested exception is java.io.IOException: The temporary upload location [/tmp/tomcat.7999245729530865401.8980/work/Tomcat/localhost/ROOT] is not valid',
      path: '/bulkCancel'
    }`
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('4)mockName-toss', async () => {
        global.error = jest.spyOn(console, 'error').mockImplementation(() => { })
        let value = ` {
      method: 'POST',
      headers: { 'x-gen2-caller-key': 'Testing', 'x-gen2-user-id': 'VU2F' },
      body: FormData {
        _overheadLength: 157,
        _valueLength: 108,
        _valuesToMeasure: [],
        writable: false,
        readable: true,
        dataSize: 0,
        maxDataSize: 2097152,
        pauseStreams: true,
        _released: false,
        _streams: [
          '----------------------------675936099477553721831970\r\n' +
            'Content-Disposition: form-data; name="uploadedFile"; filename="input.csv"\r\n' +
            'Content-Type: text/csv\r\n' +
            '\r\n',
          <Buffer 46 6c 69 67 68 74 20 44 61 74 65 2c 46 6c 69 67 68 74 20 4e 75 6d 62 65 72 2c 46 6c 69 67 68 74 20 4c 65 67 2c 52 65 61 73 6f 6e 20 43 6f 64 65 2c 43 ... 58 more bytes>,
          [Function: bound ]
        ],
        _currentStream: null,
        _insideLoop: false,
        _pendingNext: false,
        _boundary: '--------------------------675936099477553721831970'
      }
    }
    getResponse(requestSpec) Response {
      size: 0,
      timeout: 0,
      [Symbol(Body internals)]: {
        body: PassThrough {
          _events: [Object],
          _readableState: [ReadableState],
          _writableState: [WritableState],
          allowHalfOpen: true,
          _maxListeners: undefined,
          _eventsCount: 2,
          [Symbol(shapeMode)]: true,
          [Symbol(kCapture)]: false,
          [Symbol(kCallback)]: null
        },
        disturbed: false,
        error: null
      },
      [Symbol(Response internals)]: {
        url: 'https://dlb.int.nexus.g4.usw2.aws.allegiantair.com/flight-disposition-orch/bulkCancel?callbackEmail=nz8h@allegiantair.com',
        status: 500,
        statusText: 'Internal Server Error',
        headers: Headers { [Symbol(map)]: [Object: null prototype] },
        counter: 0
      }
    }
    toss Promise { <pending> }
    getJsonResponse Promise { <pending> }
    setResponse {
      timestamp: '2024-04-12T06:57:15.945+0000',
      status: 500,
      error: 'Internal Server Error',
      message: 'Failed to parse multipart servlet request; nested exception is java.io.IOException: The temporary upload location [/tmp/tomcat.7999245729530865401.8980/work/Tomcat/localhost/ROOT] is not valid',
      path: '/bulkCancel'
    }`
        const mockFn = jest.fn(respSpec.toss())
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    // test('5)mockName-tossXml', async () => {
    //     let value = `<?xml version="1.0"?>
    // <Travelerinformation>
    //                 <name>John</name>
    //                 <email>johnc477295@gmail.com</email>
    //                 <adderes>Usa</adderes>
    // </Travelerinformation>`
    //     const mockFn = jest.fn(await respSpec.tossXml())
    //     mockFn.mockImplementation(() => value);
    //     mockFn()
    //     expect(mockFn).toHaveBeenCalled();
    //     expect(mockFn).toHaveBeenCalledTimes(1);
    // });

    test('6)mockName-geturl', async () => {
        let value = 'https://www-qatnexusg4.okd.allegiantair.com/graphql'
        const mockFn = jest.fn(respSpec.geturl())
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('7)mockName-getstatusText', async () => {
        let value = 'OK'
        const mockFn = jest.fn(respSpec.getstatusText(value))
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('8)mockName-getXmlResponse', async () => {
        let value = `{
      "data": [{
        "type": "articles",
        "id": "1",
        "attributes": {
          "title": "JSON:API paints my bikeshed!",
          "body": "The shortest article. Ever.",
          "created": "2015-05-22T14:56:29.000Z",
          "updated": "2015-05-22T14:56:28.000Z"
        },
        "relationships": {
          "author": {
            "data": {"id": "42", "type": "people"}
          }
        }
      }],
      "included": [
        {
          "type": "people",
          "id": "42",
          "attributes": {
            "name": "John",
            "age": 80,
            "gender": "male"
          }
        }
      ]
    }`
        const mockFn = jest.fn(respSpec.getXmlResponse(value))
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });
});

