const RequestSpec = require('../helpers/RequestSpec.js');
const ResponseSpec = require('../helpers/ResponseSpec.js');
const ResponseValidator = require('../helpers/ResponseValidator.js');
var spec = new RequestSpec();
var respSpec = new ResponseSpec(spec);
var respValidator = new ResponseValidator(respSpec);
const fs = require('fs')

describe('III)return value from response validator file', () => {

    test('1)mockName-setResponse', () => {
        global.error = jest.spyOn(console, 'error').mockImplementation(() => { })
        const mockFn = jest.fn(respValidator.setResponse())
        let value = {
            phoneNumber: '7094071936',
            id: '656',
            createdAt: '2024-04-12T03:00:20.734Z',
        }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(global.error).toHaveBeenCalled()
        expect(global.error).toHaveBeenCalledTimes(1);
        global.error.mockRestore();
    });

    test('2)mockName-getJsonResponse', () => {
        const mockFn = jest.fn(respValidator.getJsonResponse())
        let value = {
            timestamp: '2024-04-12T08:48:44.372+0000',
            status: 500,
            error: 'Internal Server Error',
            message: 'Failed to parse multipart servlet request; nested exception is java.io.IOException: The temporary upload location [/tmp/tomcat.7999245729530865401.8980/work/Tomcat/localhost/ROOT] is not valid',
            path: '/bulkCancel',
        }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('3)mockName-verifyHeaders', () => {
        const mockFn = jest.fn(respValidator.verifyHeaders())
        mockFn('Server', 'Apache')
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('4)mockName-verifyJsonSchema', () => {
        const mockJSONParse = jest.spyOn(JSON, "parse").mockReturnValue({ "name": "test-feature", "job": "api-test" });
        const mockReadFileSync = jest.spyOn(fs, "readFileSync").mockImplementation(() => { });
        const mockFn = jest.fn(respValidator.verifyJsonSchema("./test/test-files/validatePost.json"))
        let value = { "name": "test-feature", "job": "api-test" }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockJSONParse).toHaveBeenCalled()
        expect(mockJSONParse).toHaveBeenCalledTimes(1)
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(mockReadFileSync).toHaveBeenCalled()
        expect(mockReadFileSync).toHaveBeenCalledTimes(1)
        mockJSONParse.mockRestore();
        mockReadFileSync.mockRestore();
    });

    test('5)mockName-verifyExactJson', () => {
        const mockReadFileSync = jest.spyOn(fs, "readFileSync").mockImplementation(() => { });
        const mockJSONParse = jest.spyOn(JSON, "parse").mockReturnValue({});
        const jsonResponse = `{
            "code": "CR",
            "nbr": "CR9A19-AFBD-3D89-0D17",
            "issueDate": "2024-04-18",
            "expireDate": "2022-06-30",
            "value": 544,
            "orderId": "AA1234",
            "orderItemId": null,
            "firstName": "John",
            "lastName": "Smith",
            "middleName": null,
            "recipientId": null,
            "email": "asw*********@email.com",
            "status": "EXPIRED",
            "balance": 0.00,
            "promoCode": null,
            "params": [
                {
                    "name": "reason",
                    "value": "CR"
                }
            ],
            "redemptions": [],
            "refunds": []
        }`
        const mockFn = jest.fn(respValidator.verifyExactJson())
        mockFn(jsonResponse)
        expect(mockJSONParse).toHaveBeenCalled()
        expect(mockJSONParse).toHaveBeenCalledTimes(1)
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
        mockJSONParse.mockRestore();
        mockReadFileSync.mockRestore();
    });

    test('6)mockName-verifyStatusCode', () => {
        const mockverifyStatusCode = jest.fn(respValidator.verifyStatusCode(""))
        mockverifyStatusCode("")
        expect(mockverifyStatusCode).toHaveBeenCalled();
        expect(mockverifyStatusCode).toHaveBeenCalledTimes(1);
    });

    // test('7)mockName-verifyResponseHeader', () => {
    //     const mockverifyResponseHeader = jest.fn(respValidator.verifyResponseHeader('x-gen2-caller-key', 'Testing'))
    //     mockverifyResponseHeader('x-gen2-caller-key', 'Testing')
    //     expect(mockverifyResponseHeader).toHaveBeenCalled();
    //     expect(mockverifyResponseHeader).toHaveBeenCalledTimes(1);
    // });

    test('8)mockName-verifyExactJsonFromFile', () => {
        const mockJSONParse = jest.spyOn(JSON, "parse").mockReturnValue({});
        const mockReadFileSync = jest.spyOn(fs, "readFileSync").mockImplementation(() => { });
        const mockFn = jest.fn(respValidator.verifyExactJsonFromFile("./test/test-files/validatePost.json"))
        let value = { "name": "test-feature", "job": "api-test" }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockJSONParse).toHaveBeenCalled()
        expect(mockJSONParse).toHaveBeenCalledTimes(1)
        expect(mockFn).toHaveBeenCalled()
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(mockReadFileSync).toHaveBeenCalled()
        expect(mockReadFileSync).toHaveBeenCalledTimes(1)
        mockJSONParse.mockRestore();
        mockReadFileSync.mockRestore();
    });

    test('9)mockName-verifyValueAtPath', () => {
        const mockverifyValueAtPath = jest.fn(respValidator.verifyValueAtPath('$.data.0.first_name', ''))
        mockverifyValueAtPath('$.data.0.first_name', '')
        expect(mockverifyValueAtPath).toHaveBeenCalled();
        expect(mockverifyValueAtPath).toHaveBeenCalledTimes(1);
    });

    // test('10)mockName-verifyFieldAtPath', () => {
    //     let path = '$.data.0'
    //     let value = 'last_name'
    //     const mockverifyFieldAtPath = jest.fn(respValidator.verifyFieldAtPath(path, value))
    //     mockverifyFieldAtPath(path, value)
    //     expect(mockverifyFieldAtPath).toHaveBeenCalled();
    //     expect(mockverifyFieldAtPath).toHaveBeenCalledTimes(1);
    // });

    test('11)mockName-verifyStringInResponse', () => {
        const mockverifyStringInResponse = jest.fn(respValidator.verifyStringInResponse(""))
        mockverifyStringInResponse()
        expect(mockverifyStringInResponse).toHaveBeenCalled();
        expect(mockverifyStringInResponse).toHaveBeenCalledTimes(1);
    });

    test('12)mockName-verifyResponseTime', () => {
        const mockverifyResponseTime = jest.fn(respValidator.verifyResponseTime(2))
        mockverifyResponseTime()
        expect(mockverifyResponseTime).toHaveBeenCalled();
        expect(mockverifyResponseTime).toHaveBeenCalledTimes(1);
    });
});