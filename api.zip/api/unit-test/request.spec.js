const RequestSpec = require('../helpers/RequestSpec.js');
var spec = new RequestSpec();
const fs = require('fs')

describe('I)set value', () => {

    test('1)mockName-setBaseUri', () => {
        const mockFn = jest.fn(spec.setBaseUri());
        mockFn("https://reqres.in");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('2)mockName-setBasePath', () => {
        const mockFn = jest.fn(spec.setBasePath());
        mockFn("/api/users");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('3)mockName-setQueryParams', () => {
        const mockFn = jest.fn(spec.setQueryParams("page", "2"));
        mockFn("page", "2");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('4)mockName-setPathParams', () => {
        const mockFn = jest.fn(spec.setPathParams("id", "2970"));
        mockFn("id", "2970");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('5)mockName-setPathParams: map param', () => {
        const paramMap = new Map([["id", 500]]);
        const mockFn = jest.fn(spec.setPathParams(paramMap));
        mockFn(paramMap);
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('6)mockName-setHeader', () => {
        const mockFn = jest.fn(spec.setHeader("Content-Type", "application/json"));
        mockFn("Content-Type", "application/json");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('7)mockName-setHeader: map header', () => {
        const headerMap = new Map([["Content-Type", "application/json"]]);
        const mockFn = jest.fn(spec.setHeader(headerMap));
        mockFn(headerMap);
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('8)mockName-setRequest for GraphQL', () => {
        let queryWithVaribles = ` query flightMarket($origin: IataCode!, $destination: IataCode!) 
        { flightMarket(origin: $origin, destination: $destination) { type calendar { availableFrom availableUntil departingDates 
          { date __typename } returningDates { date __typename } __typename } __typename } }`
        let queryDetails = queryWithVaribles.split("graphQlVariables")
        const mockFn = jest.fn(spec.setGraphqlRequest());
        mockFn(queryDetails[0], queryDetails[1]);
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('9)mockName-setRequest for GraphQL query from file', () => {
        const mockReadFileSync = jest.spyOn(fs, "readFileSync").mockImplementation(() => { });
        const mockFn = jest.fn(spec.setGraphqlRequestFromQueryFile());
        mockFn("./test/test-files/GraphQlquery.txt");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(mockReadFileSync).toHaveBeenCalled()
        expect(mockReadFileSync).toHaveBeenCalledTimes(1)
    });

    test('10)mockName-setRequest for GraphQL query and variable', () => {
        const mockReadFileSync = jest.spyOn(fs, "readFileSync").mockImplementation(() => { });
        const mockJSONParse = jest.spyOn(JSON, "parse").mockReturnValue({ key: 'value' });
        let query = `query flightMarket($origin: IataCode!, $destination: IataCode!) 
        { flightMarket(origin: $origin, destination: $destination) { type calendar { availableFrom availableUntil departingDates 
          { date __typename } returningDates { date __typename } __typename } __typename } }`
        let variable = `{ origin: 'MEX', destination: 'MEX' }`
        const mockFn = jest.fn(spec.setGraphqlRequestFromQueryAndVariableFile());
        mockFn(query, variable);
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(mockReadFileSync).toHaveBeenCalled()
        expect(mockReadFileSync).toHaveBeenCalledTimes(3)
        expect(mockJSONParse).toHaveBeenCalled()
        expect(mockJSONParse).toHaveBeenCalledTimes(1)
    });

    test('11)mockName-set method', () => {
        const mockFn = jest.fn(spec.setMethod());
        mockFn("POST");
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('12)mockName-set form data', () => {
        global.log = jest.spyOn(console, 'log').mockImplementation(() => { })
        let formKey = 'firstname'
        let formValue = 'john'
        const mockFn = jest.fn(spec.setFormData(formKey, formValue));
        mockFn(formKey, formValue);
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(global.log).toHaveBeenCalled()
        expect(global.log).toHaveBeenCalledTimes(1)
        global.log.mockRestore();
    });

    // test('13)mockName-setUploadCSVFormData', () => {
    //     const mockReadFileSync = jest.spyOn(fs, "readFileSync").mockImplementation(() => { });
    //     let key = 'uploadedFile'
    //     let CSVpath = '../test/test-files/INPUT.csv'
    //     const mockFn = jest.fn(spec.setUploadCSVFormData(key, CSVpath));
    //     mockFn(key, CSVpath);
    //     expect(mockFn).toHaveBeenCalled();
    //     expect(mockFn).toHaveBeenCalledTimes(1);
    //     expect(mockReadFileSync).toHaveBeenCalled()
    //     expect(mockReadFileSync).toHaveBeenCalledTimes(1)
    // });
});

describe('II)return value from requestspec file', () => {

    test('1)mockName-setRequest', () => {
        let request = {
            "name": "test-feature",
            "job": "api-test",
        }
        const mockFn = jest.fn(spec.setRequest(request))
        let value = {
            phoneNumber: '7094071936',
            id: '656',
            createdAt: '2024-04-12T03:00:20.734Z',
        }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('2)mockName-setRequest is undefined', () => {
        let request
        const mockFn = jest.fn(spec.setRequest(request))
        let value = {
            phoneNumber: '7094071936',
            id: '656',
            createdAt: '2024-04-12T03:00:20.734Z',
        }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('3)mockName-setRequest is null', () => {
        let request = null
        const mockFn = jest.fn(spec.setRequest(request))
        let value = {
            phoneNumber: '7094071936',
            id: '656',
            createdAt: '2024-04-12T03:00:20.734Z',
        }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('4)mockName-setRequest throws error', () => {
        const mockJSONstringify = jest.spyOn(JSON, "stringify").mockImplementation(() => { });
        mockJSONstringify.mockImplementation(() => { throw new Error('Failed JSONstringify') })
        let request = {
            "name": "test-feature",
            "job": "api-test",
        }
        const mockFn = jest.fn(spec.setRequest(request))
        let value = {
            phoneNumber: '7094071936',
            id: '656',
            createdAt: '2024-04-12T03:00:20.734Z',
        }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(mockJSONstringify).toThrow('Failed JSONstringify')
        mockJSONstringify.mockRestore();
    });

    test('5)mockName-setRequest from file', () => {
        const mockFn = jest.fn(spec.setRequestBodyFromFile("./test/test-files/validatePost.json"))
        let value = { "name": "test-feature", "job": "api-test" }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('6)mockName-setRequest from file throws error', () => {
        const mockJSONParse = jest.spyOn(JSON, "parse").mockReturnValue({});
        mockJSONParse.mockImplementation(() => { throw new Error('Failed JSONParse') })
        const mockFn = jest.fn(spec.setRequestBodyFromFile("./test/test-files/validatePost.json"))
        let value = { "name": "test-feature", "job": "api-test" }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
        expect(mockJSONParse).toThrow('Failed JSONParse')
        mockJSONParse.mockRestore();
    });

    test('7)mockName-setRequest Details', () => {
        const mockFn = jest.fn(spec.getRequestDetails())
        let value = ` {
      method: 'POST',
      headers: { 'x-gen2-caller-key': 'Testing', 'x-gen2-user-id': 'VU2F' },
      body: FormData {
        _overheadLength: 157,
        _valueLength: 108,
        _valuesToMeasure: [],
        writable: false,
        readable: true,
        dataSize: 0,
        maxDataSize: 2097152,
        pauseStreams: true,
        _released: false,
        _streams: [
          '----------------------------675936099477553721831970\r\n' +
            'Content-Disposition: form-data; name="uploadedFile"; filename="input.csv"\r\n' +
            'Content-Type: text/csv\r\n' +
            '\r\n',
          <Buffer 46 6c 69 67 68 74 20 44 61 74 65 2c 46 6c 69 67 68 74 20 4e 75 6d 62 65 72 2c 46 6c 69 67 68 74 20 4c 65 67 2c 52 65 61 73 6f 6e 20 43 6f 64 65 2c 43 ... 58 more bytes>,
          [Function: bound ]
        ],
        _currentStream: null,
        _insideLoop: false,
        _pendingNext: false,
        _boundary: '--------------------------675936099477553721831970'
      }
    }
    getResponse(requestSpec) Response {
      size: 0,
      timeout: 0,
      [Symbol(Body internals)]: {
        body: PassThrough {
          _events: [Object],
          _readableState: [ReadableState],
          _writableState: [WritableState],
          allowHalfOpen: true,
          _maxListeners: undefined,
          _eventsCount: 2,
          [Symbol(shapeMode)]: true,
          [Symbol(kCapture)]: false,
          [Symbol(kCallback)]: null
        },
        disturbed: false,
        error: null
      },
      [Symbol(Response internals)]: {
        url: 'https://dlb.int.nexus.g4.usw2.aws.allegiantair.com/flight-disposition-orch/bulkCancel?callbackEmail=nz8h@allegiantair.com',
        status: 500,
        statusText: 'Internal Server Error',
        headers: Headers { [Symbol(map)]: [Object: null prototype] },
        counter: 0
      }
    }
    toss Promise { <pending> }
    getJsonResponse Promise { <pending> }
    setResponse {
      timestamp: '2024-04-12T06:57:15.945+0000',
      status: 500,
      error: 'Internal Server Error',
      message: 'Failed to parse multipart servlet request; nested exception is java.io.IOException: The temporary upload location [/tmp/tomcat.7999245729530865401.8980/work/Tomcat/localhost/ROOT] is not valid',
      path: '/bulkCancel'
    }`
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });

    test('8)mockName-setRequest from file', () => {
        const mockFn = jest.fn(spec.setRequestBodyFromFile("./test/test-files/validatePost.json"))
        let value = { "name": "test-feature", "job": "api-test" }
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });
    test('9)mockName-isJson', () => {
        const mockFn = jest.fn(spec.isJson())
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });
    test('10)mockName-setFormDataEncoded', () => {
        let formKey = 'phoneNumber'
        let formValue = '7094071936'
        const mockFn = jest.fn(spec.setFormDataEncoded(formKey, formValue))
        mockFn(formKey, formValue)
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });
    test('11)mockName-getRequestUri - - if basepath includes ?', () => {
        let value = `https://reqres.in/api/users?page=2`
        const mockFn = jest.fn(spec.getRequestUri(spec.setBasePath("api/users?page=2")))
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });
    test('12)mockName-getRequestUri - if basepath doesnot includes ?', () => {
        let value = `https://gorest.co.in/public/v2/users/6859467`
        const mockFn = jest.fn(spec.getRequestUri(spec.setBasePath("/public/v2/users/{id}")))
        mockFn.mockImplementation(() => value);
        mockFn()
        expect(mockFn).toHaveBeenCalled();
        expect(mockFn).toHaveBeenCalledTimes(1);
    });
});
