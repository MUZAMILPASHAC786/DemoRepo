const { Given, When, Then } = require('@cucumber/cucumber');
const fs = require("fs");
const { func } = require('hamjest');
const { GqlBooking } = require('@g4/gql-booking-util/src/gql-booking')

Then('I create new credentials', function(){
    //read the file
    //create new cred
    //write fille
    let Email='sireesha.sriram+'
    let random= Math.floor((Math.random()*99999)+1)
    newEmail= Email+random+'@allegiantair.com';
    //let newPass='Test1@'+random;
    let jsonFromFile = JSON.parse(fs.readFileSync("./test/test-files/CreateCustomer/Createcustomer.json", 'utf8'));
    jsonFromFile.emailAddress= newEmail;
    jsonFromFile.credential.userName= newEmail;
    fs.writeFileSync('./test/test-files/CreateCustomer/Createcustomer.json', JSON.stringify(jsonFromFile), function (err) {
        if (err) {
            console.log(err);
        }
    });
   
})

Then('I store the resonse', function(){
    // console.log("customised step response ", this.response);
    let actualResponse = this.response

    this.mainId = actualResponse.id
    this.transmitId = actualResponse.transmitId
    this.customerId = actualResponse.customerId
    this.loyaltyId = actualResponse.loyaltyId
    // this.emailAddress = actualResponse.emailAddress
    this.username = actualResponse.credential.userName
})


Given(/^I complete the Booking using gql for claiming points$/, {
    timeout: 60 * 2000,
},
async () => {
    let Env = process.env.env
    await GqlBooking(Env, 'LAS', 'BLI', 'ONEWAY', 1, 0, 0, "2", "2", "", 'no', "no", "no", "no", "card", "Master", "no", "no", "no", "no", "", "", "")
    .then((response) => {
      console.log("confNum ", response.confNumber)
      this.confirmationNumber = response.confNumber
    })
})

Given(/^I make the "?([^"]+)"? request to "?([^"]+)"?$/, function (method, actualScenario) {
    this.spec.setMethod(method.toUpperCase());
    let idValue = this.mainId
    let basePath
    if (actualScenario === "claimPoints") {
        let confNumb = this.confirmationNumber
         basePath = `/v3/api/customers/${idValue}/claimMyPoints/${confNumb}`
        //  basePath = `/v3/api/customers/${idValue}/claimMyPoints/J4WPFP`
    } else if (actualScenario === "passwordreset") {
        basePath = `/v3/api/customers/${idValue}/passwordresets`
    }
    this.spec.setBasePath(basePath);

});

// Given(/^I make the "?([^"]+)"? request to passwordreser$/, function (method) {
//     this.spec.setMethod(method.toUpperCase());
//     let idValue = this.mainId
//     let basePath = `/v3/api/customers/${idValue}/passwordresets`
//     this.spec.setBasePath(basePath);
// });


// Given(/^I make the "?([^"]+)"? request to claimPoints$/, function (method) {
//     this.spec.setMethod(method.toUpperCase());
//     let idValue = this.mainId
//     let confNumb = this.confirmationNumber
//     let basePath = `/v3/api/customers/${idValue}/claimMyPoints/${confNumb}`
//     this.spec.setBasePath(basePath);
// });